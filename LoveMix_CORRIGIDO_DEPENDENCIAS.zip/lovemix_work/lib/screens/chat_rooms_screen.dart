import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'love_room_screen.dart';
import 'live_broadcast_screen.dart';

class ChatRoomsScreen extends StatelessWidget {
  const ChatRoomsScreen({super.key});
  static const pink = Color(0xFFFF2DAB);
  static const panel = Color(0xFF1B1028);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _createLive(context),
        backgroundColor: pink,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Criar sala', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 100),
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF40105E), Color(0xFF1B1230), Color(0xFF321044)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFB33CFF).withOpacity(.65)),
              boxShadow: [BoxShadow(color: const Color(0xFF9B27FF).withOpacity(.16), blurRadius: 20, offset: const Offset(0, 7))],
            ),
            child: const Row(children: [
              Icon(Icons.graphic_eq_rounded, color: Color(0xFFFF54C4), size: 34),
              SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Salas LoveMix', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white)),
                SizedBox(height: 4),
                Text('Entre, converse e conheça pessoas novas 💜', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ])),
            ]),
          ),
          _liveSection(context, title: 'Lives de vídeo', mediaMode: 'video'),
          _liveSection(context, title: 'Lives de voz', mediaMode: 'audio'),
          const Padding(
            padding: EdgeInsets.fromLTRB(18, 18, 18, 8),
            child: Text('Salas públicas', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          ),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: DataService.instance.publicRooms(),
            builder: (context, snap) {
              if (snap.hasError) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('Não foi possível carregar as salas públicas. As transmissões ao vivo continuam sendo carregadas separadamente.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
                );
              }
              if (!snap.hasData) {
                return const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator(color: pink)),
                );
              }
              final rooms = snap.data!.docs.where((d) =>
                d.data()['isLive'] != true).toList();
              if (rooms.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                  child: Text('Ainda não há salas de bate-papo públicas.', textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60)),
                );
              }
              return Column(children: rooms.map((doc) {
                final room = doc.data();
                final members = List<String>.from(room['members'] ?? []);
                return Container(
                  margin: const EdgeInsets.fromLTRB(14, 4, 14, 8),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF251333), Color(0xFF171022)]),
                    borderRadius: BorderRadius.circular(17),
                    border: Border.all(color: const Color(0xFF65358B).withOpacity(.8)),
                  ),
                  child: ListTile(
                    leading: const CircleAvatar(backgroundColor: Color(0xFF7027A5),
                      child: Icon(Icons.forum_rounded, color: Colors.white)),
                    title: Text((room['name'] ?? 'Sala').toString(),
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${members.length} participantes • ${(room['lastMessage'] ?? 'Entre para conversar').toString()}',
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFFFF54C4), size: 17),
                    onTap: () async {
                      try {
                        if (!members.contains(DataService.instance.uid)) {
                          await DataService.instance.joinRoom(doc.id);
                        }
                        if (context.mounted) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) =>
                            LoveRoomScreen(roomId: doc.id, roomName: (room['name'] ?? 'Sala').toString())));
                        }
                      } catch (e) {
                        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Não foi possível entrar: $e')));
                      }
                    },
                  ),
                );
              }).toList());
            },
          ),
        ],
      ),
    );
  }

  Widget _liveSection(BuildContext context, {required String title, required String mediaMode}) {
    final isVideo = mediaMode == 'video';
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
        child: Row(children: [
          Icon(isVideo ? Icons.videocam_rounded : Icons.mic_rounded,
            color: const Color(0xFFFF54C4), size: 21),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(color: const Color(0xFF351044), borderRadius: BorderRadius.circular(20)),
            child: const Text('AO VIVO', style: TextStyle(color: Color(0xFFFF64C8),
              fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .8)),
          ),
        ]),
      ),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: DataService.instance.publicLiveRooms(mediaMode: mediaMode),
        builder: (context, snap) {
          if (snap.hasError) {
            return const Padding(padding: EdgeInsets.all(14),
              child: Text('Não foi possível carregar esta lista de lives.',
                style: TextStyle(color: Colors.white60)));
          }
          if (!snap.hasData) {
            return const Padding(padding: EdgeInsets.all(12),
              child: Center(child: SizedBox(width: 22, height: 22,
                child: CircularProgressIndicator(strokeWidth: 2, color: pink))));
          }
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(18, 5, 18, 12),
              child: Text(isVideo ? 'Ninguém está fazendo live de vídeo agora.' :
                'Ninguém está fazendo live de voz agora.',
                style: const TextStyle(color: Colors.white54, fontSize: 12)),
            );
          }
          return SizedBox(
            height: 100,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              scrollDirection: Axis.horizontal,
              itemCount: docs.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final doc = docs[index];
                final data = doc.data();
                final members = List<String>.from(data['members'] ?? []);
                return InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () async {
                    try {
                      if (isVideo) {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) =>
                          LiveBroadcastScreen(roomId: doc.id,
                            roomName: (data['name'] ?? 'Live LoveMix').toString())));
                      } else {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) =>
                          LoveRoomScreen(roomId: doc.id,
                            roomName: (data['name'] ?? 'Sala de voz').toString())));
                      }
                    } catch (e) {
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Não foi possível entrar: $e')));
                    }
                  },
                  child: Container(
                    width: 190,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: panel,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF9B35FF)),
                    ),
                    child: Row(children: [
                      CircleAvatar(
                        backgroundColor: const Color(0xFF7027A5),
                        child: Icon(isVideo ? Icons.videocam : Icons.mic, color: Colors.white)),
                      const SizedBox(width: 9),
                      Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text((data['name'] ?? 'Live LoveMix').toString(),
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                          const SizedBox(height: 5),
                          Text('${members.length} participantes • AO VIVO',
                            maxLines: 1, style: const TextStyle(fontSize: 10, color: Colors.white60)),
                        ])),
                    ]),
                  ),
                );
              },
            ),
          );
        },
      ),
    ]);
  }

  Future<void> _createLive(BuildContext context) async {
    final controller = TextEditingController();
    String mode = 'audio';
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setDialogState) => AlertDialog(
        backgroundColor: const Color(0xFF21132F),
        title: const Text('Criar transmissão'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: controller, maxLength: 40, autofocus: true,
            decoration: const InputDecoration(labelText: 'Nome da sala')),
          const SizedBox(height: 8),
          RadioListTile<String>(value: 'audio', groupValue: mode,
            activeColor: pink, title: const Text('🎙️ Live de voz'),
            onChanged: (v) => setDialogState(() => mode = v!)),
          RadioListTile<String>(value: 'video', groupValue: mode,
            activeColor: pink, title: const Text('📹 Live de vídeo'),
            onChanged: (v) => setDialogState(() => mode = v!)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () {
              if (controller.text.trim().length >= 3) Navigator.pop(ctx, mode);
            },
            child: const Text('Entrar ao vivo'),
          ),
        ],
      )),
    );
    final name = controller.text.trim();
    controller.dispose();
    if (result == null || name.length < 3 || !context.mounted) return;
    String? createdId;
    try {
      createdId = await DataService.instance.createRoom(
        name,
        category: result == 'audio' ? 'Salas de Voz' : 'Lives',
        description: result == 'audio' ? 'Live pública de voz do LoveMix' : 'Live pública de vídeo do LoveMix',
        isLive: true,
        mediaMode: result,
      );
      if (!context.mounted) return;
      if (result == 'audio') {
        await Navigator.push(context, MaterialPageRoute(builder: (_) =>
          LoveRoomScreen(roomId: createdId!, roomName: name)));
      } else {
        await Navigator.push(context, MaterialPageRoute(builder: (_) =>
          LiveBroadcastScreen(roomId: createdId!, roomName: name)));
      }
    } catch (e) {
      if (createdId != null) {
        try { await DataService.instance.endLiveRoom(createdId); } catch (_) {}
      }
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao iniciar transmissão: $e')));
    }
  }
}
