import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../widgets/profile_frame.dart';

class ProfileFramesScreen extends StatefulWidget {
  const ProfileFramesScreen({super.key});
  @override
  State<ProfileFramesScreen> createState() => _ProfileFramesScreenState();
}

class _ProfileFramesScreenState extends State<ProfileFramesScreen> {
  static const _pink = Color(0xFFFF19B8);
  static const _purple = Color(0xFF8D35FF);
  bool busy = false;
  final codeController = TextEditingController();
  bool redeeming = false;

  @override
  void dispose() { codeController.dispose(); super.dispose(); }

  Future<void> _redeemCode() async {
    if (redeeming) return;
    final code = codeController.text.trim();
    if (code.isEmpty) return;
    setState(() => redeeming = true);
    try {
      final result = await FirebaseFunctions.instance.httpsCallable("redeemLoveMixCode").call({"code": code});
      final data = Map<String, dynamic>.from(result.data as Map);
      codeController.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data["reward"] == "vip" ? "VIP liberado com sucesso!" : "Você recebeu 2.000 moedas e 2.000 diamantes!")));
    } on FirebaseFunctionsException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? "Não foi possível resgatar o código.")));
    } finally { if (mounted) setState(() => redeeming = false); }
  }
  final items = const [
    {'id':'classic','name':'Clássica','description':'Moldura padrão do LoveMix','emoji':'💜','currency':'free','cost':0},
    {'id':'neon','name':'Neon Love','description':'Brilho neon roxo, rosa e azul','emoji':'✨','currency':'coins','cost':250},
    {'id':'hearts','name':'Corações','description':'Moldura romântica com corações','emoji':'💗','currency':'coins','cost':400},
    {'id':'gold','name':'Dourada VIP','description':'Visual dourado de destaque','emoji':'👑','currency':'diamonds','cost':50},
    {'id':'cosmic','name':'Galáxia','description':'Efeito cósmico colorido','emoji':'🌌','currency':'diamonds','cost':100},
    {'id':'royal_crown','name':'Rainha Real','description':'Coroa dourada com joias','emoji':'👑','currency':'diamonds','cost':80},
    {'id':'kitty','name':'Gatinho','description':'Orelhinhas e bigodes fofos','emoji':'🐱','currency':'coins','cost':500},
    {'id':'butterfly','name':'Borboletas','description':'Borboletas brilhantes','emoji':'🦋','currency':'coins','cost':550},
    {'id':'rose','name':'Rosa Negra','description':'Rosas elegantes em neon','emoji':'🌹','currency':'coins','cost':600},
    {'id':'headphones','name':'Music Love','description':'Fones e ondas musicais','emoji':'🎧','currency':'coins','cost':450},
    {'id':'pink_bow','name':'Laço Rosa','description':'Laço delicado com corações','emoji':'🎀','currency':'coins','cost':450},
    {'id':'flame','name':'Chamas','description':'Aura de fogo roxo','emoji':'🔥','currency':'diamonds','cost':70},
    {'id':'angel','name':'Asas de Anjo','description':'Asas luminosas e halo','emoji':'🪽','currency':'diamonds','cost':90},
    {'id':'love_wings','name':'Asas LoveMix','description':'Asas e placa LoveMix','emoji':'💞','currency':'diamonds','cost':120},
    {'id':'flower','name':'Jardim','description':'Flores e pétalas coloridas','emoji':'🌸','currency':'coins','cost':500},
    {'id':'sparkle','name':'Estrelas','description':'Estrelas e brilho mágico','emoji':'⭐','currency':'coins','cost':350},
    {'id':'diamond_heart','name':'Coração de Diamante','description':'Coração rosa com cristais','emoji':'💎','currency':'diamonds','cost':110},
    {'id':'broken_heart','name':'Coração Rebelde','description':'Coração neon estilizado','emoji':'💔','currency':'coins','cost':400},
    {'id':'royal_purple','name':'Realeza Roxa','description':'Coroa e aro violeta','emoji':'💜','currency':'diamonds','cost':75},
    {'id':'couple','name':'Casal Apaixonado','description':'Silhueta romântica e corações','emoji':'💑','currency':'coins','cost':650},
  ];

  Future<void> _buyOrEquip(Map<String, Object> item, Map<String, dynamic> data) async {
    if (busy) return;
    final id = item['id'] as String;
    final owned = List<String>.from(data['ownedProfileFrames'] ?? const ['classic']);
    try {
      setState(() => busy = true);
      if (!owned.contains(id)) {
        if (id != 'classic') {
          await FirebaseFunctions.instance.httpsCallable('purchaseProfileFrame').call({'frameId': id});
        }
      }
      await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid)
          .set({'selectedProfileFrame': id}, SetOptions(merge: true));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${item['name']} equipada no seu perfil!')));
    } on FirebaseFunctionsException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Não foi possível comprar a moldura.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erro: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Molduras de perfil'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          final data = snap.data?.data() ?? <String, dynamic>{};
          final owned = List<String>.from(data['ownedProfileFrames'] ?? const ['classic']);
          final selected = (data['selectedProfileFrame'] ?? 'classic').toString();
          final photo = (data['photoUrl'] ?? '').toString();
          final coins = data['coins'] ?? 0;
          final diamonds = data['diamonds'] ?? 0;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF32104D), Color(0xFF12091E)]),
              border: Border.all(color: _purple.withOpacity(.7))),
              child: Column(children: [
                const Text('Sua moldura atual', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                ProfileFrameAvatar(photoUrl: photo, frameId: selected, size: 94),
                const SizedBox(height: 10),
                Text(items.firstWhere((e) => e['id'] == selected, orElse: () => items.first)['name'] as String,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('🪙 $coins', style: const TextStyle(color: Color(0xFFFFD56A), fontWeight: FontWeight.bold)),
                  const SizedBox(width: 18),
                  Text('💎 $diamonds', style: const TextStyle(color: Color(0xFF70DFFF), fontWeight: FontWeight.bold)),
                ]),
              ]),
            ),
            const SizedBox(height: 20),
            Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(18), border: Border.all(color: _purple.withOpacity(.6))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Resgatar código', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('Digite seu código para liberar o benefício.', style: TextStyle(color: Colors.white60, fontSize: 12)),
              const SizedBox(height: 10),
              Row(children: [Expanded(child: TextField(controller: codeController, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(hintText: 'Digite o código', filled: true, fillColor: Color(0xFF0D0815), border: OutlineInputBorder()))), const SizedBox(width: 8), ElevatedButton(onPressed: redeeming ? null : _redeemCode, style: ElevatedButton.styleFrom(backgroundColor: _purple), child: redeeming ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Resgatar'))]),
            ])),
            const SizedBox(height: 20),
            const Text('Molduras VIP', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFFFFD56A))),
            const Text('Prévia das molduras especiais disponíveis para contas VIP.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 10),
            const Text('Loja de molduras' , style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Compre com moedas ou diamantes e equipe quando quiser.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 12),
            ...items.map((item) {
              final id = item['id'] as String;
              final has = owned.contains(id);
              final active = selected == id;
              final currency = item['currency'] as String;
              final cost = item['cost'];
              return Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: active ? _pink : _purple.withOpacity(.35))),
                child: Row(children: [
                  ProfileFrameAvatar(photoUrl: photo, frameId: id, size: 55),
                  const SizedBox(width: 13),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${item['emoji']} ${item['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(item['description'] as String, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    const SizedBox(height: 4),
                    Text(currency == 'free' ? 'Grátis' : currency == 'coins' ? '🪙 $cost moedas' : '💎 $cost diamantes',
                      style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 12, fontWeight: FontWeight.bold)),
                  ])),
                  const SizedBox(width: 8),
                  SizedBox(width: 100, child: ElevatedButton(
                    onPressed: busy || active ? null : () => _buyOrEquip(item, data),
                    style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10)),
                    child: Text(active ? 'Ativa' : has ? 'Equipar' : 'Comprar', style: const TextStyle(fontSize: 12)),
                  )),
                ]),
              );
            }),
            if (busy) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: _pink))),
          ]);
        },
      ),
    );
  }
}
