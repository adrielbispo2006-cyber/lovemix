import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

const _gold = Color(0xFFFF2DAB);
const _panel = Color(0xFF241333);

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Column(children: [
        const TabBar(isScrollable: true, indicatorColor: _gold, labelColor: _gold,
          tabs: [Tab(text: 'Saldo'), Tab(text: 'Tarefas'), Tab(text: 'Presentes'), Tab(text: 'Alianças')]),
        Expanded(child: TabBarView(children: [
          const _BalanceTab(), const _TasksTab(), const _GiftsTab(), const _AlliancesTab(),
        ])),
      ]),
    );
  }
}

class _BalanceTab extends StatelessWidget {
  const _BalanceTab();
  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: DataService.instance.myProfile(),
    builder: (context, snap) {
      final p = snap.data?.data() ?? {};
      return ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [Expanded(child: _currencyCard('Moedas', '${p['coins'] ?? 0}', '🪙')), const SizedBox(width: 10), Expanded(child: _currencyCard('Diamantes', '${p['diamonds'] ?? 0}', '💎'))]),
        const SizedBox(height: 12),
        const Card(color: Color(0xFF29200D), child: ListTile(leading: Icon(Icons.card_giftcard, color: _gold), title: Text('Bônus de boas-vindas'), subtitle: Text('Toda pessoa que criar uma conta nova recebe 200 moedas grátis.'))),
        const SizedBox(height: 8),
        const Card(color: _panel, child: ListTile(leading: Icon(Icons.chat_bubble, color: _gold), title: Text('Chat sempre grátis'), subtitle: Text('Conversar com seus matches não consome moedas.'))),
        const SizedBox(height: 16),
        const Text('Resgatar moedas e diamantes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Adicione saldo usando somente códigos promocionais. Não há compras com dinheiro nesta aba.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 8),
        const _WalletCodeRedeemer(),
        const SizedBox(height: 20), const Text('Diamantes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Diamantes são uma moeda especial para presentes e alianças premium.'),
      ]);
    },
  );

  Widget _currencyCard(String title, String amount, String emoji) => Card(color: _panel, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Text(emoji, style: const TextStyle(fontSize: 30)), Text(amount, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: _gold)), Text(title)])));
}


class _WalletCodeRedeemer extends StatefulWidget {
  const _WalletCodeRedeemer();
  @override
  State<_WalletCodeRedeemer> createState() => _WalletCodeRedeemerState();
}

class _WalletCodeRedeemerState extends State<_WalletCodeRedeemer> {
  final _controller = TextEditingController();
  bool _loading = false;

  Future<void> _redeem() async {
    final code = _controller.text.trim().toUpperCase();
    if (code.isEmpty || _loading) return;
    setState(() => _loading = true);
    try {
      final result = await FirebaseFunctions.instance.httpsCallable('redeemLoveMixCode').call({'code': code});
      final data = Map<String, dynamic>.from(result.data as Map);
      final message = data['reward'] == 'vip'
          ? 'VIP liberado com sucesso!'
          : 'Código resgatado! Saldo atualizado.';
      _controller.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } on FirebaseFunctionsException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Código inválido ou já utilizado.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível validar o código. Tente novamente.')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Card(
    color: _panel, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      TextField(controller: _controller, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Código de resgate', hintText: 'Digite seu código', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      ElevatedButton(onPressed: _loading ? null : _redeem, child: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Resgatar código')),
    ])),
  );
}

class _TasksTab extends StatelessWidget {
  const _TasksTab();
  static const tasks = [
    ('complete_profile', 'Complete seu perfil', 'Adicione foto, bio e informações.', 100, Icons.person),
    ('daily_login', 'Entre no LoveMix', 'Recompensa diária.', 30, Icons.login),
    ('send_messages', 'Converse com alguém', 'Envie 10 mensagens.', 100, Icons.chat),
    ('like_profiles', 'Descubra pessoas', 'Curta 5 perfis.', 50, Icons.favorite),
  ];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Tarefas para ganhar moedas', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: _gold)),
    const Text('Complete atividades e resgate moedas. Cada tarefa pode ser resgatada uma vez por dia, quando disponível.'),
    const SizedBox(height: 14),
    ...tasks.map((t) => Card(color: _panel, child: ListTile(
      leading: Icon(t.$5, color: _gold), title: Text(t.$2), subtitle: Text('${t.$3}  •  +${t.$4} moedas'),
      trailing: IconButton(icon: const Icon(Icons.card_giftcard, color: _gold), onPressed: () => _claim(context, t.$1)),
    ))),
  ]);

  Future<void> _claim(BuildContext context, String taskId) async {
    try {
      final result = await FirebaseFunctions.instance.httpsCallable('claimDailyTask').call({'taskId': taskId});
      final amount = (result.data['coins'] ?? 0).toString();
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Você ganhou $amount moedas!')));
    } on FirebaseFunctionsException catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Não foi possível resgatar esta tarefa.')));
    } catch (_) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível resgatar. Tente novamente.')));
    }
  }
}

class _GiftsTab extends StatelessWidget {
  const _GiftsTab();
  static const gifts = [
    ('🌹', 'Rosa', 'coins', 50), ('🧸', 'Ursinho', 'coins', 100), ('❤️', 'Coração', 'coins', 200),
    ('🎂', 'Bolo', 'coins', 300), ('💐', 'Buquê', 'diamonds', 15), ('👑', 'Coroa', 'diamonds', 50),
    ('💎', 'Diamante', 'diamonds', 100), ('🚗', 'Carro de luxo', 'diamonds', 150),
  ];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Presentes especiais', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: _gold)),
    const Text('Escolha um presente e informe o código de usuário de quem vai receber.'),
    const SizedBox(height: 12),
    GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: gifts.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.25, crossAxisSpacing: 10, mainAxisSpacing: 10),
      itemBuilder: (context, i) { final g = gifts[i]; return Card(color: _panel, child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => _sendDialog(context, g.$1, g.$2, g.$3, g.$4, 'gift'), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(g.$1, style: const TextStyle(fontSize: 34)), Text(g.$2, style: const TextStyle(fontWeight: FontWeight.bold)), Text('${g.$4} ${g.$3 == 'coins' ? 'moedas' : 'diamantes'}', style: const TextStyle(color: _gold)), const Text('Toque para enviar', style: TextStyle(color: Colors.white54, fontSize: 11))]))); },
    ),
  ]);
}

class _AlliancesTab extends StatelessWidget {
  const _AlliancesTab();
  static const rings = [
    ('💜', 'Aliança BFF', 'Melhores amigos para sempre', 'coins', 250, 'bff'),
    ('💙', 'Aliança Irmãos', 'Laço de família e parceria', 'coins', 300, 'siblings'),
    ('❤️', 'Aliança Casal', 'Um símbolo de carinho a dois', 'diamonds', 50, 'couple'),
  ];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Alianças especiais', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: _gold)),
    const Text('Envie uma aliança para demonstrar carinho e amizade a outra pessoa.'),
    const SizedBox(height: 12),
    ...rings.map((r) => Card(color: _panel, child: ListTile(leading: Text(r.$1, style: const TextStyle(fontSize: 32)), title: Text(r.$2), subtitle: Text('${r.$3}\n${r.$5} ${r.$4 == 'coins' ? 'moedas' : 'diamantes'}'), isThreeLine: true, trailing: IconButton(icon: const Icon(Icons.send, color: _gold), onPressed: () => _sendDialog(context, r.$1, r.$2, r.$4, r.$5, r.$6))))),
    Card(color: const Color(0xFF251342), child: ListTile(leading: const Text('🎁', style: TextStyle(fontSize: 32)), title: const Text('Aliança grátis', style: TextStyle(color: _gold, fontWeight: FontWeight.bold)), subtitle: const Text('Resgate uma aliança BFF gratuita para enviar a um amigo. Uma por conta.'), trailing: const Icon(Icons.card_giftcard, color: _gold), onTap: () => _sendDialog(context, '💛', 'Aliança BFF grátis', 'free', 0, 'free_bff'))),
  ]);
}

Future<void> _sendDialog(BuildContext context, String emoji, String itemName, String currency, int cost, String itemType) async {
  final controller = TextEditingController();
  final targetUid = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
    title: Text('$emoji $itemName'), content: TextField(controller: controller, decoration: const InputDecoration(labelText: 'Código de usuário (UID)', hintText: 'Cole o UID do amigo')),
    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Continuar'))],
  ));
  if (targetUid == null || targetUid.isEmpty) return;
  try {
    await FirebaseFunctions.instance.httpsCallable('sendStoreItem').call({'targetUid': targetUid, 'itemType': itemType, 'itemName': itemName, 'emoji': emoji, 'currency': currency, 'cost': cost});
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enviado! A pessoa receberá sua aliança ou presente.')));
  } on FirebaseFunctionsException catch (e) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Não foi possível enviar.')));
  } catch (_) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Falha ao enviar. Tente novamente.')));
  }
}
