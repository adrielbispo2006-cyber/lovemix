# Decorações de Nick: compra local e exibição pública

- A lista de decorações compradas fica no armazenamento local do aparelho (`SharedPreferences`), por usuário autenticado.
- O Firebase não recebe `ownedNicknameStyles` nem uma lista/histórico de compras.
- O saldo de moedas da conta continua sendo debitado de forma atômica no documento do usuário.
- Somente `vipNicknameStyle` e `nicknameDecorationActive` são sincronizados no perfil para que outras pessoas vejam a decoração no perfil e nos balões do chat.
- Por ser uma compra local, o inventário não acompanha automaticamente a pessoa em outro aparelho ou após limpar os dados/reinstalar o app.
- O identificador do estilo ativo é público; não contém a lista de compras.
