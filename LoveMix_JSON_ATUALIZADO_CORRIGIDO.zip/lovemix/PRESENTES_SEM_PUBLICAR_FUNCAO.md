# Presentes na live sem publicar Cloud Function

O app tenta primeiro a função `sendRoomGift`. Se ela não estiver publicada (NOT_FOUND), o app envia o
presente direto, usando as regras atuais do Firestore (nenhuma publicação necessária):

- cobra moedas/diamantes de quem envia;
- mostra o presente e a animação na sala;
- atualiza a última mensagem da sala.

Limitação: sem a função no servidor, o app NÃO consegue creditar moedas ao anfitrião, carisma ou
pontos da coroa (as regras do Firestore não deixam um usuário alterar o saldo de outro, por segurança).
Esses créditos só voltam quando a função `sendRoomGift` for publicada.
