# Atualização LoveMix — Salas VIP, jogos, loja e missões

- O formulário de criação de sala ganhou a opção “Sala VIP com animações”. A sala grava `isVipRoom: true` e exibe um banner dourado pulsante.
- O cabeçalho das salas de voz ganhou o atalho de jogos. O sorteio de uma rodada publica o desafio no chat da sala para que os participantes acompanhem.
- A tela inicial ganhou atalhos para a vitrine de presentes e para as missões diárias.
- A vitrine mostra o catálogo já existente de presentes e os preços em moedas/diamantes. O envio e o débito continuam ocorrendo pelo fluxo de envio dentro da sala.
- Missões permitem marcar quatro atividades e resgatar +50 pontos diários. Os pontos de missão são locais ao aparelho, não são moedas/diamantes e não são sincronizados entre dispositivos.

## Observações

- A opção de sala VIP é atualmente um destaque visual; ainda não há cobrança de moedas/diamantes nem permissões exclusivas de VIP.
- Os minijogos são sorteios de perguntas e desafios compartilhados como mensagem no chat; ainda não há placar competitivo ou sincronização de respostas.
- As missões ainda não verificam automaticamente a conclusão das ações. O usuário marca cada atividade manualmente.
- `firestore.rules` recebeu validação opcional para o campo booleano `isVipRoom` na criação de salas. Publique as regras atualizadas para permitir esse campo se as regras atuais do projeto forem restritivas.
- Não foi possível executar `flutter analyze` ou compilar APK neste ambiente porque Flutter/Dart SDK não estão instalados.
