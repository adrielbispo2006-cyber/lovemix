# Recompensas de moedas nas lives — removidas

O LoveMix não concede mais moedas ao anfitrião quando espectadores enviam presentes durante uma Live.

- O envio e a exibição dos presentes continuam funcionando.
- O saldo de quem envia continua sendo debitado normalmente.
- Não há contador de moedas recebidas na tela da Live.
- Os presentes recebidos passam a ser registrados na aba **Presentes recebidos** do perfil.
- O envio da Live pelo aplicativo não chama mais a função `sendRoomGift`.

Para habilitar o histórico de presentes em perfis existentes, publique somente as regras atualizadas do Firestore incluídas neste projeto. Não é necessário publicar Cloud Functions para esse fluxo.
