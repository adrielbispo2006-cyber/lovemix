# Atualização da tela inicial conforme referência

- Cabeçalho agora usa a arte oficial `assets/icon/lovemix.png`.
- Cartão de descoberta passou a ser um carrossel horizontal de perfis, com indicadores de página.
- Cartão exibe estado `AO VIVO` quando `isLive == true`, `Online` quando `isOnline == true` e `Perfil` nos demais casos.
- Nome, idade calculada a partir de `birthday` e cidade/país continuam ligados aos dados públicos do perfil.
- Aba inferior `Presentes` agora abre `GiftsScreen`, que permite procurar o destinatário por UID, escolher presente e enviar pelo serviço existente.
- Aba `Chats` continua abrindo `MessagesScreen` e agora mostra a soma das mensagens não lidas com base em `unreadCounts` dos chats do usuário, ignorando conversas ocultadas por ele.
- A carteira continua acessível pelos chips de moedas e diamantes do cabeçalho.

## Limitações de validação

A alteração foi feita no código Flutter do projeto. O ambiente desta execução não possui Flutter/Dart instalado, então não foi possível executar `flutter analyze`, testes ou gerar APK. É necessário compilar e validar em ambiente Flutter e conferir as regras/índices do Firebase no projeto de produção.
