# Correção do ID LoveMix e nome da sala

- O ID público usado nas salas agora segue o formato curto de 8 caracteres alfanuméricos já gerado pelo DataService.
- Se a conta autenticada ainda não tiver documento em `users/{uid}`, o app cria um perfil mínimo com os campos exigidos pelas regras atuais e gera o ID.
- O ID do anfitrião continua visível no cabeçalho da sala e pode ser tocado para copiar.
- O anfitrião passa a ter um ícone de edição ao lado do nome da sala. A alteração é salva no documento `rooms/{roomId}` e aparece em tempo real para todos os participantes.
- As regras do Firestore foram ajustadas para aceitar o ID curto nos participantes da live e permitir que somente o dono altere o nome da própria sala (3 a 40 caracteres).

## Aplicação

Publique o arquivo `firestore.rules` atualizado no Firebase Console > Firestore Database > Rules antes de testar a edição do nome. Depois gere uma nova versão do APK.

Observação: não foi possível compilar/testar com Flutter neste ambiente porque o SDK Flutter/Dart não está instalado. Faça o teste com uma conta que já tenha perfil e outra conta entrando na mesma sala.
