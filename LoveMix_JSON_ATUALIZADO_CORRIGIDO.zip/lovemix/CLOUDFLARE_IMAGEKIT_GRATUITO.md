# Ativar ImageKit no LoveMix usando Cloudflare Workers Free (sem Firebase pago)

## O que fica funcionando
- Supabase continua como armazenamento principal e mantém as URLs atuais.
- O app tenta enviar uma cópia das mesmas imagens ao ImageKit em `/lovemix-backup`.
- Se o Worker ou ImageKit falhar, o upload no Supabase continua válido.
- Não usa Firebase Functions nem exige ativar o plano Blaze. O Firebase Authentication existente é usado somente para validar que a pessoa está conectada.

## 1. Criar o Worker
1. Entre em https://dash.cloudflare.com/ e abra **Workers & Pages**.
2. Crie um Worker chamado `lovemix-imagekit-auth`.
3. Para publicar pelo Termux, extraia o ZIP e entre na pasta `lovemix/cloudflare-imagekit-worker`.
4. Execute:

```bash
npm install
npx wrangler login
npx wrangler deploy
```

O deploy mostra um endereço parecido com `https://lovemix-imagekit-auth.SUA-CONTA.workers.dev`.

## 2. Guardar a Private Key sem expor
Na mesma pasta, execute:

```bash
npx wrangler secret put IMAGEKIT_PRIVATE_KEY
```

Cole a **Private Key** do ImageKit quando o terminal pedir. Não a coloque no código, no ZIP, no GitHub ou no APK. Depois execute:

```bash
npx wrangler deploy
```

Também é possível cadastrar em Cloudflare Dashboard > Worker > Settings > Variables and Secrets > Add > Secret, nome `IMAGEKIT_PRIVATE_KEY`.

## 3. Configurar o endereço no Flutter
Abra `lib/services/supabase_service.dart` e substitua o valor de `imageKitAuthWorkerUrl` pelo endereço `workers.dev` que o deploy mostrou. Exemplo:

```dart
static const imageKitAuthWorkerUrl = 'https://lovemix-imagekit-auth.SUA-CONTA.workers.dev';
```

Salve e gere um novo APK. Não é necessário alterar o Supabase.

## 4. Dados ImageKit já preenchidos
- Public Key: `public_/NtjCe7/QVTvp2fYwwvvGTNeI9s=`
- Endpoint: `https://ik.imagekit.io/yecqr4bo3`
- ID: `yecqr4bo3`

A Private Key não está incluída neste ZIP.

## 5. Teste obrigatório
1. Faça login no LoveMix.
2. Envie uma nova foto de perfil.
3. Confirme que a foto continua aparecendo pelo Supabase.
4. No painel ImageKit, confirme se apareceu uma cópia em `/lovemix-backup`.

## Custos e limites
Este fluxo não chama Firebase Functions e não exige ativar o faturamento do Firebase. Cloudflare Workers Free e ImageKit Free possuem limites próprios, que podem mudar; confira o painel de uso dos dois serviços. Não há garantia de uso ilimitado/gratuito.

## Observação de segurança
O Worker valida o Firebase ID token do usuário antes de gerar a assinatura temporária do ImageKit. Isso não é um segundo login: o app usa a sessão Firebase que o usuário já tem. A Private Key fica como Secret no Cloudflare.
