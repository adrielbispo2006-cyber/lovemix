# Resgate de códigos sem Cloud Functions

- Os 20 códigos oficiais LMX-... concedem 2.000 moedas cada.
- O app valida o formato e executa uma transação Firestore que cria um registro imutável por conta/código e credita as moedas.
- Cada conta pode usar cada código uma única vez; códigos diferentes continuam disponíveis.
- A transação só é aceita pelas regras do Firestore quando o claim oficial é criado junto com o crédito de exatamente 2.000 moedas.
- Não é necessário publicar Cloud Functions para este fluxo.

## Ativação necessária

Publique o arquivo `firestore.rules` deste ZIP no Firebase Console (Firestore Database > Rules). Isso é necessário para que o Firebase aplique a validação segura e permita o crédito. Não remova as demais regras existentes.

## Decorações de Nick

A visualização do Nick usa uma cor sólida por estilo. Ao equipar outro estilo, o nome, os símbolos, o brilho e o ícone da loja acompanham a cor daquele estilo.
