# Chat da live limpo

- Quem entra na live só vê as mensagens enviadas a partir do momento em que entrou
  (usa a hora do servidor do registro de entrada). Funciona sem publicar nada.
- Quando o anfitrião encerra a live, o app apaga as mensagens da sala.
  Isso exige publicar o `firestore.rules` deste ZIP (Firebase Console > Firestore > Regras > Publicar).
  Sem publicar, o chat antigo continua no banco, mas fica oculto para quem entra depois.
