# Banimento de usuários — painel administrativo LoveMix

Foi adicionada ao painel administrativo uma ação para banir e desbanir contas comuns.

- O painel identifica contas banidas e mostra a ação correspondente.
- A operação é validada no servidor por uma callable Cloud Function.
- A função exige as claims `admin` e `founder`, não permite banir a própria conta nem contas administrativas.
- O banimento desativa a conta no Firebase Authentication, revoga tokens de atualização e grava `isBanned` no perfil.
- O app mostra uma tela de conta banida se uma sessão já estiver aberta.
- O desbanimento reativa a conta no Firebase Authentication e remove os marcadores de banimento.

## Importante: alterações locais, sem publicação

Este ZIP contém o código-fonte alterado. Nada foi publicado no Firebase nem distribuído aos usuários. Para que o botão consiga executar banimentos reais, será necessário compilar e implantar a Cloud Function `adminSetLoveMixUserBan` no projeto Firebase. Para que a tela de bloqueio chegue aos usuários, será necessário publicar uma nova versão do aplicativo. Até essas etapas, a alteração fica somente neste projeto local.
