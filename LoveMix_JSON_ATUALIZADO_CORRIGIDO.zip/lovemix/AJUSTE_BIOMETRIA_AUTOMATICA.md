# Biometria automática ao abrir o LoveMix

- Quando a conta já tem PIN salvo e a biometria continua disponível no aparelho, o LoveMix chama o diálogo nativo de autenticação automaticamente assim que a tela de acesso rápido termina de carregar.
- Não é necessário tocar no ícone de impressão digital.
- Se a pessoa cancelar ou a autenticação falhar, a tela permanece disponível para usar o PIN.
- Se não houver biometria configurada/disponível, o app não dispara um diálogo impossível e mantém o acesso por PIN.
- A autenticação continua sendo feita pelo Android via `local_auth`; o app não lê nem armazena dados biométricos.

Para validar: `flutter pub get`, `flutter analyze` e gerar um novo APK. Testar em aparelho Android com impressão digital cadastrada e também cancelar o prompt para confirmar o fallback por PIN.
