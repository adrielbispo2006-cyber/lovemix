# Presentes enviados pelo perfil para o PV

- O perfil público agora oferece o botão **Enviar presente**.
- O destinatário é identificado pelo UID real do documento `users/{uid}` do perfil aberto.
- O presente é registrado como mensagem `type: gift` em `chats/{chatId}/messages`, portanto aparece em tempo real no PV dos dois participantes.
- O remetente vê “Você enviou”; o destinatário vê “Você recebeu”.
- A transação desconta o custo uma única vez do saldo do remetente e cria a mensagem na mesma transação.
- A conversa precisa existir e os dois UIDs precisam ser membros dela. O fluxo atual de conversa direta exige que o remetente siga o destinatário.

## Publicação necessária

Este fluxo não usa Cloud Functions, mas exige publicar uma vez o arquivo `firestore.rules` incluído neste ZIP, pois as regras antigas não aceitavam mensagens do tipo `gift`.

**Limitação importante:** o presente aparece no PV, mas esta implementação não credita moedas/diamantes ao destinatário nem cria inventário de presentes. Isso exigiria uma operação de servidor confiável; não é seguro permitir que o app do remetente altere o saldo de outra pessoa.
