# Proteção de moedas e diamantes do LoveMix

- O saldo de cada usuário fica no Firestore e não deve ser confiado ao valor local do APK.
- As regras `firestore.rules` exigem que alterações no documento `users/{uid}` sejam feitas pelo próprio titular; uma conta comum não pode editar o saldo de outra pessoa.
- As regras atuais só aceitam aumento de saldo do titular quando há resgate de código oficial ainda não utilizado, validado na mesma transação. Os fluxos de compra/gastos continuam podendo debitar o próprio saldo, sem permitir saldo negativo.
- Ajustes administrativos de moedas e diamantes são feitos pela Cloud Function `adminUpdateLoveMixUser`, que exige o custom claim `admin`, valida limites e impede saldo negativo. A chave privada/credencial do Firebase Admin nunca deve ser colocada no aplicativo.
- O painel administrativo agora mostra moedas e diamantes e permite adicionar/remover ambos por meio da função protegida.

## Publicação

No GitHub Actions, executar **Proteger moedas e diamantes LoveMix**. O workflow compila as Cloud Functions e publica `adminUpdateLoveMixUser`, `adminListLoveMixUsers` e as regras do Firestore.

## Limite importante

A segurança depende de publicar as regras e a Cloud Function no projeto Firebase correto. Depois da publicação, testar com uma conta comum tentando atualizar o campo `coins` ou `diamonds` de outro usuário: a operação deve ser negada. Os fluxos legítimos de presentes, compras e resgates também precisam ser testados no APK.
