# Configuração das notificações push do LoveMix

O projeto já usa Firebase Cloud Messaging, grava tokens em `users/{uid}/fcmTokens` e possui Cloud Functions que enviam push para mensagens privadas, curtidas, stories, convites, atividades em salas, lives e chamadas. Esta atualização registra o handler de background, define o canal e o ícone padrão do Android e inclui um workflow para publicar os gatilhos FCM.

## 1. Conferir no Firebase Console

1. Abra https://console.firebase.google.com/ e selecione o projeto `lovemix-73849`.
2. Em Configurações do projeto > Seus apps, confirme que o app Android tem o pacote `com.example.lovemix`.
3. Em Cloud Messaging, confirme que o Firebase Cloud Messaging está disponível. Não compartilhe nem coloque chaves privadas de servidor no app.
4. Em Firestore, confirme que o app pode gravar em `users/{uid}/fcmTokens` para o próprio usuário.

## 2. Publicar as Cloud Functions

O repositório precisa conter a pasta `lovemix/` na raiz. No GitHub, abra Actions e execute **Publicar notificações push LoveMix**. O repositório precisa ter o secret `FIREBASE_SERVICE_ACCOUNT_LOVEMIX_73849`, com uma conta de serviço autorizada a publicar Cloud Functions no projeto `lovemix-73849`.

A publicação de Cloud Functions pode exigir que o projeto Firebase esteja no plano Blaze e que as APIs do Cloud Functions, Cloud Build, Artifact Registry e FCM estejam habilitadas. O workflow compila as Functions antes de publicar; se falhar, leia o primeiro erro de compilação ou permissão no log.

## 3. Gerar e instalar o APK

Depois de enviar este projeto atualizado ao GitHub, execute o workflow **LoveMix - Gerar APK**. Instale o APK, entre na conta e aceite a permissão de notificações do Android. O app registra o token FCM automaticamente.

## 4. Teste real

Use duas contas em dois celulares (ou um celular e outro dispositivo): entre na conta A, feche o LoveMix sem usar “Forçar parada”; pela conta B, envie uma mensagem privada para A. A notificação deve aparecer na bandeja do Android. Repita com o app em segundo plano. Em Android 13+, permita notificações nas configurações do aplicativo.

**Limitação importante:** se o usuário tocar em “Forçar parada” nas configurações do Android, o sistema pode bloquear a entrega até que o app seja aberto novamente. Economia de bateria agressiva também pode atrasar entregas. A entrega depende de internet, permissão do usuário e disponibilidade do Firebase/Google Play Services.
