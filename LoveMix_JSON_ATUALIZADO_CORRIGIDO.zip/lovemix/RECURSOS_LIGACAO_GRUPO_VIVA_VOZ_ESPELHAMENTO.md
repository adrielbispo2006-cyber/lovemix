# LoveMix — recursos de ligação

- As chamadas usam o modo de grupo do ZEGOCLOUD, inclusive quando só há duas pessoas.
- O menu da chamada inclui troca de saída de áudio (alto-falante/auricular), microfone, câmera (em vídeo), encerrar e compartilhar tela.
- O botão de adicionar pessoas lista perfis públicos e cria convites individuais para a chamada ativa. O destinatário precisa estar com o LoveMix aberto e conectado para receber o convite nesta implementação.
- O compartilhamento de tela usa a interface do ZEGOCLOUD em layout Gallery. No Android, o sistema mostra a confirmação de captura de tela; o usuário pode parar quando quiser.
- Para Android 14+, foram declaradas as permissões FOREGROUND_SERVICE e FOREGROUND_SERVICE_MEDIA_PROJECTION exigidas pelo ZEGOCLOUD.
- iOS exige configurar uma Broadcast Upload Extension (ReplayKit) no projeto Xcode; o ZIP Android/GitHub Actions não configura sozinho esse target.

## Publicação

1. Publique as regras atualizadas de `firestore.rules` no Firebase Console.
2. Gere o APK pelo GitHub Actions.
3. Teste com duas ou mais contas em aparelhos diferentes: viva-voz, convite, aceitar/recusar, compartilhamento e parar compartilhamento.

A compilação deve ser validada no GitHub Actions antes de distribuir o APK.
