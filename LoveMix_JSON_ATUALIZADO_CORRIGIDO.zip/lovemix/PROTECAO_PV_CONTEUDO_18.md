# Proteção de conteúdo +18 no PV

## Implementado nesta versão

- Mensagens de texto no PV são criadas como `pending` e ficam ocultas para os participantes até a análise do servidor.
- A Cloud Function `moderatePrivateChatText` identifica termos adultos comuns em português, substitui os termos por `•••` e só então libera a mensagem.
- Cada ocorrência gera aviso privado e registro em `reports`.
- Após três ocorrências, o servidor grava `users/{uid}/moderation/privateChat.blocked = true`; as regras impedem novas mensagens de texto desse usuário. Reinstalar o app não remove o bloqueio.
- Fotos continuam com o fluxo SafeSearch já existente: mensagens de imagem ficam pendentes e só aparecem depois de `moderatePrivateChatImage` aprovar.

## Implantação obrigatória

Esta proteção não funciona de forma completa apenas no APK. Publique as Cloud Functions e as regras atualizadas do Firestore:

```bash
cd functions
npm install
npm run build
firebase deploy --only functions
cd ..
firebase deploy --only firestore:rules
```

A análise de fotos também exige a Cloud Vision API habilitada no projeto Google Cloud. Mensagens antigas não são reprocessadas. A lista de termos é uma barreira preventiva, não uma compreensão perfeita de contexto; mantenha denúncia e moderação humana disponíveis.
