# Missão diária: entrar em uma sala

- Ao entrar com sucesso em uma sala, o app chama a Cloud Function `claimRoomEntryMission`.
- A função verifica no servidor se o usuário está na lista de membros da sala.
- A recompensa é de 30 moedas, creditadas no documento `users/{uid}`.
- O resgate é protegido por transação e por um documento diário em `users/{uid}/taskClaims`, usando o fuso `America/Sao_Paulo`.
- Entrar em várias salas no mesmo dia não gera recompensas extras.
- A aba Missões consulta o servidor para mostrar se a recompensa do dia já foi recebida.

Para ativar na versão publicada, instale/atualize o app e implante a função `claimRoomEntryMission` no Firebase. O ZIP não foi compilado com Flutter nem testado em contas reais.
