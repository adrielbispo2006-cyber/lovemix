# Correção visual da loja de decorações de Nick

- Os cards agora usam uma linha com larguras controladas (`Expanded`) em vez do `ListTile` anterior.
- O apelido de demonstração fica limitado à largura disponível e não quebra letra por letra.
- Cada decoração mostra o nome, o preço/estado de compra e uma amostra colorida baseada na paleta definida em `VipNickname.styles`.
- A cor da borda, do ícone e do estado ativo acompanha as cores de cada decoração.
- A lógica de compra local e a sincronização do estilo equipado permanecem iguais à versão anterior.
