# Buscar pessoas por ID LoveMix

- Cada perfil recebe um ID público exclusivo de 8 caracteres, gerado automaticamente.
- O ID aparece em “Meu ID LoveMix” no perfil e pode ser copiado.
- Na aba Descobrir, a pessoa pode pesquisar pelo ID completo; a busca aceita também o formato opcional `LM-XXXXXXXX`.
- Ao encontrar um resultado, tocar no cartão abre o perfil público.
- A busca retorna somente perfis com visibilidade pública; perfis privados ou restritos não são expostos por essa pesquisa.
- O UID interno do Firebase continua sendo usado para relações e permissões; o ID público serve apenas para localizar o perfil.

É necessário publicar regras compatíveis do Firestore e compilar um novo APK.
