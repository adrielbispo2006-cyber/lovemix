import { createRemoteJWKSet, jwtVerify } from "jose";

const FIREBASE_PROJECT_ID = "lovemix-73849";
const FIREBASE_ISSUER = `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`;
const FIREBASE_JWKS = createRemoteJWKSet(new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com"));

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "POST, OPTIONS",
    "access-control-allow-headers": "Authorization, Content-Type",
  }});
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "POST, OPTIONS",
      "access-control-allow-headers": "Authorization, Content-Type",
    }});
    if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);
    const auth = request.headers.get("Authorization") || "";
    if (!auth.startsWith("Bearer ")) return json({ error: "unauthenticated" }, 401);
    try {
      const token = auth.slice(7);
      await jwtVerify(token, FIREBASE_JWKS, {
        issuer: FIREBASE_ISSUER,
        audience: FIREBASE_PROJECT_ID,
        algorithms: ["RS256"],
      });
    } catch (e) {
      return json({ error: "invalid_firebase_token" }, 401);
    }
    if (!env.IMAGEKIT_PRIVATE_KEY) return json({ error: "worker_secret_missing" }, 500);
    const token = crypto.randomUUID().replaceAll("-", "");
    const expire = Math.floor(Date.now() / 1000) + 30 * 60;
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey("raw", encoder.encode(env.IMAGEKIT_PRIVATE_KEY),
      { name: "HMAC", hash: "SHA-1" }, false, ["sign"]);
    const signatureBytes = new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(token + expire)));
    const signature = [...signatureBytes].map(b => b.toString(16).padStart(2, "0")).join("");
    return json({ token, expire, signature });
  }
};
