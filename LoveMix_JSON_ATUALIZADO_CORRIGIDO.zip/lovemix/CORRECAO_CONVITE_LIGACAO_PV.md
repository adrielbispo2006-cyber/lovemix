# Correção dos convites de chamada no privado

Esta atualização corrige a recepção de convites de voz/vídeo no PV:

- Mantém a escuta dos documentos `chats/{chatId}/calls` para exibir Atender/Recusar com o app aberto.
- Ao voltar para o primeiro plano, consulta convites pendentes novamente. A consulta filtra por `calleeUid` no servidor e verifica `status`/validade localmente, evitando exigir índice composto adicional.
- Adiciona a Cloud Function `notifyOnIncomingCall`, que envia notificação push de alta prioridade ao destinatário quando uma chamada é criada com status `ringing`.
- Usa o canal Android `lovemix_updates`, já registrado pelo serviço de notificações.

## Ativação necessária para chamadas com o app fechado/em segundo plano

A notificação push depende de publicar as Cloud Functions no projeto Firebase e de o usuário ter permitido notificações no Android. Na pasta `lovemix`, execute:

```bash
cd functions
npm install
npm run build
cd ..
firebase deploy --only functions:notifyOnIncomingCall
```

Se estiver usando o fluxo normal de deploy de todas as funções, também pode executar `firebase deploy --only functions`.

Depois gere e instale um APK novo. O APK sozinho não publica a Cloud Function no Firebase.

## Observação

Não foi possível executar um build Flutter/TypeScript completo neste ambiente porque as dependências do projeto não estão instaladas. Portanto, gere o APK no GitHub Actions e confira o log do build antes de distribuir. Para convites com o app totalmente encerrado, confirme também que a função foi implantada e que o token FCM do usuário aparece em `users/{uid}/fcmTokens`.
