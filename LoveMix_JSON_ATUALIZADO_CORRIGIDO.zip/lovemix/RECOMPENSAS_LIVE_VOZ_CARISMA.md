# Presentes em lives e salas de voz

O envio de presentes continua disponível nas salas. A recompensa de moedas ao anfitrião foi removida: receber um presente durante a Live não aumenta o saldo de moedas.

Os presentes enviados são registrados no histórico **Presentes recebidos** do perfil, com nome, remetente e indicação de origem (Live ou perfil).

O cliente não chama mais a callable `sendRoomGift` para enviar presentes de Live. A função de servidor também não contém mais o trecho que credita moedas ao anfitrião.
