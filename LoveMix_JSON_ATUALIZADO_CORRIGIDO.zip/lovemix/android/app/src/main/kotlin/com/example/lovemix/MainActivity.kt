package com.example.lovemix

import io.flutter.embedding.android.FlutterFragmentActivity

// Necessário para o prompt biométrico nativo do Android (local_auth).
class MainActivity : FlutterFragmentActivity()
