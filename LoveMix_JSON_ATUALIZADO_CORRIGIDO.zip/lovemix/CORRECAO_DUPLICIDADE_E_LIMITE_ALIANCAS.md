# Correção do Mural de Alianças

- O mural agrupa registros antigos repetidos pelo mesmo par de usuários e pelo mesmo tipo de relação, mostrando apenas o registro mais recente.
- Cada usuário pode ter no máximo uma relação pendente ou aceita de cada tipo: Namorados, BFF e Amigos.
- Relações de tipos diferentes continuam permitidas, inclusive com pessoas diferentes.
- Um segundo convite de Namorados é bloqueado tanto na criação pelo Mural quanto no envio de aliança pelo PV.
- Convites recusados e alianças encerradas não bloqueiam um novo convite daquele tipo.

A validação Flutter não pôde ser executada neste ambiente porque o SDK Flutter/Dart não está instalado. É necessário executar `flutter analyze` e testar com duas contas no Firebase antes de publicar.
