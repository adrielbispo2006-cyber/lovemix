# Catálogo com 100 presentes

O catálogo de presentes contém 100 IDs únicos, incluindo iPhone 18, iPhone 18 Pro Max, iPhone 18 Ultra e iPhone 18 Dobrável como itens virtuais.

Os 30 itens adicionados estão cadastrados tanto no catálogo Flutter (`lib/data/gift_catalog.dart`) quanto na lista permitida pela Cloud Function `sendRoomGift` (`functions/src/index.ts`). Isso mantém a loja fora da sala (envio por UID) e os presentes das salas usando os mesmos IDs, moedas/diamantes e preços.

Os valores são preços virtuais definidos para o LoveMix; os nomes iPhone 18 são itens virtuais do catálogo e não representam venda ou entrega de aparelhos reais.
