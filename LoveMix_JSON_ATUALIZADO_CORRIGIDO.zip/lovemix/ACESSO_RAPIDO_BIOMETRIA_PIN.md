# Acesso rápido LoveMix

- Após entrar na conta pela primeira vez, o app oferece a criação de um PIN local de 4 a 6 dígitos.
- Em aparelhos com biometria cadastrada e suportada, a tela de acesso rápido oferece impressão digital/biometria e PIN.
- O PIN é armazenado somente como hash no armazenamento seguro do Android; não é enviado ao Firebase.
- O botão “Trocar de conta” encerra a sessão Firebase.
- Se o usuário escolher “Agora não” durante a configuração, continua para o app sem ativar o bloqueio rápido naquela abertura.
- Dependências: `local_auth` e `flutter_secure_storage`.
- Android: `MainActivity` usa `FlutterFragmentActivity` e o manifesto declara `USE_BIOMETRIC`.

É necessário executar `flutter pub get` e gerar um novo APK. A validação final deve ser feita em aparelho Android com biometria configurada; este ambiente não possui Flutter/Android SDK para compilar o APK.
