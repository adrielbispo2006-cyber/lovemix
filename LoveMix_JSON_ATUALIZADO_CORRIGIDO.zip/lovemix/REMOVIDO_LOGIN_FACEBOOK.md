# Remoção do login pelo Facebook

O botão “Entrar com Facebook” foi removido da tela de autenticação (`lib/screens/auth_screen.dart`), pois não havia integração real: o botão apenas exibia uma mensagem informando que o login não estava configurado.

Os demais métodos de acesso (e-mail/senha, Google, criação de conta e convidado) foram preservados. Nenhum pacote de autenticação do Facebook existia no `pubspec.yaml`, portanto não foi necessário remover dependências.
