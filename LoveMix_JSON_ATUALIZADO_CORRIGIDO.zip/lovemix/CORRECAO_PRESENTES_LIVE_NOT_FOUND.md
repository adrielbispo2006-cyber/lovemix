# Presentes na live de vídeo: erro "not found"

O app chama a Cloud Function `sendRoomGift` (região us-central1). O catálogo de presentes do app
e o do servidor estão iguais, então o `NOT_FOUND` puro significa que a função NÃO está publicada
no projeto Firebase `lovemix-73849`. Trocar o APK não publica funções.

## Publicar (escolha um)
**GitHub Actions:** Actions > "Publicar envio direto de presentes LoveMix" > Run workflow
(precisa do secret `FIREBASE_SERVICE_ACCOUNT_LOVEMIX_73849`).

**Terminal:**
```
cd functions && npm install && npm run build && cd ..
npx firebase-tools deploy --only functions:sendRoomGift --project lovemix-73849
```

## Outras mensagens (agora aparecem claras no app)
- "A sala desta transmissão não foi encontrada": o documento rooms/{id} não existe; saia e entre na live.
- "Seu perfil não foi encontrado": falta o documento users/{uid}; entre de novo na conta.
- "perfil de quem vai receber...": o destinatário não tem users/{uid}.
