# ImageKit usando Cloudflare Workers

Siga o guia `CLOUDFLARE_IMAGEKIT_GRATUITO.md`. Não é necessário cadastrar `IMAGEKIT_PRIVATE_KEY` no Firebase Functions. A chave privada deve ser cadastrada como Secret no Cloudflare Worker.
