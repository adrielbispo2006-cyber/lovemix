import 'package:flutter/material.dart';

import '../screens/home_screen.dart';

/// Keeps the live screen mounted while the user browses the rest of LoveMix.
/// The floating bubble restores the exact room route and its active session.
class LiveRoomMiniService {
  LiveRoomMiniService._();

  static const String _homeRouteName = 'lovemix_minimized_live_home';
  static OverlayEntry? _entry;
  static NavigatorState? _navigator;
  static bool _minimizing = false;

  static Future<void> minimize(
    BuildContext context, {
    required String roomName,
    required IconData icon,
  }) async {
    if (_minimizing || _entry != null) return;

    final navigator = Navigator.of(context, rootNavigator: true);
    final overlay = navigator.overlay;
    if (!navigator.mounted || overlay == null) return;

    _minimizing = true;
    _navigator = navigator;

    // Push Home above the live instead of popping the live route. This leaves
    // the live widget, Zego connection, microphone and room presence intact.
    final homeClosed = navigator.push<void>(
      MaterialPageRoute<void>(
        settings: const RouteSettings(name: _homeRouteName),
        builder: (_) => const HomeScreen(),
      ),
    );

    await Future<void>.delayed(const Duration(milliseconds: 250));
    if (!navigator.mounted || navigator.overlay == null) {
      _minimizing = false;
      _navigator = null;
      return;
    }

    _entry = OverlayEntry(
      builder: (overlayContext) => Positioned(
        right: 14,
        bottom: 112,
        child: SafeArea(
          child: Material(
            color: Colors.transparent,
            child: GestureDetector(
              onTap: restore,
              child: Container(
                width: 78,
                height: 88,
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF25133D),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: const Color(0xFFB66BFF), width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x99000000),
                      blurRadius: 14,
                      offset: Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: const BoxDecoration(
                        color: Color(0xFF43236B),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(icon, color: const Color(0xFFFF65D8), size: 27),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      roomName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
    navigator.overlay!.insert(_entry!);

    // This future completes only when the temporary Home route is removed.
    // Keep the overlay/service state alive until the user restores the live.
    await homeClosed;
    _removeEntry();
    _navigator = null;
    _minimizing = false;
  }

  static void restore() {
    final navigator = _navigator;
    if (navigator == null || !navigator.mounted) return;

    _removeEntry();
    // Return to the temporary Home route even if the user opened another
    // LoveMix page, then remove it to reveal the still-mounted live screen.
    navigator.popUntil((route) => route.settings.name == _homeRouteName);
    if (navigator.canPop()) navigator.pop();
  }

  static void _removeEntry() {
    _entry?.remove();
    _entry = null;
  }
}
