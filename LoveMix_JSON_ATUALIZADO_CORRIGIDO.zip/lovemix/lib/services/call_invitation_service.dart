import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../app.dart';
import '../screens/call_screen.dart';

class CallInvitationService with WidgetsBindingObserver {
  CallInvitationService._();
  static final instance = CallInvitationService._();

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _subscription;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _groupSubscription;
  final Set<String> _handled = <String>{};
  User? _activeUser;
  bool _observerRegistered = false;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _activeUser != null) {
      _refreshPending(_activeUser!.uid);
    }
  }

  Future<void> _refreshPending(String uid) async {
    try {
      final pending = await FirebaseFirestore.instance
          .collectionGroup('calls')
          .where('calleeUid', isEqualTo: uid)
          .get();
      for (final doc in pending.docs) {
        if (_handled.contains(doc.reference.path)) continue;
        final data = doc.data();
        final createdAt = data['createdAt'];
        if (data['status'] == 'ringing' && createdAt is Timestamp &&
            DateTime.now().difference(createdAt.toDate()).inSeconds <= 35) {
          _showIncoming(doc.reference, data);
        }
      }
      final groupPending = await FirebaseFirestore.instance
          .collectionGroup('callInvites')
          .where('calleeUid', isEqualTo: uid)
          .get();
      for (final doc in groupPending.docs) {
        final data = doc.data();
        final createdAt = data['createdAt'];
        if (data['status'] == 'ringing' && !_handled.contains(doc.reference.path) &&
            createdAt is Timestamp &&
            DateTime.now().difference(createdAt.toDate()).inSeconds <= 45) {
          _showGroupIncoming(doc.reference, data);
        }
      }
    } catch (error) {
      debugPrint('Não foi possível atualizar convites de chamada: $error');
    }
  }

  void startForUser(User user) {
    _activeUser = user;
    if (!_observerRegistered) {
      WidgetsBinding.instance.addObserver(this);
      _observerRegistered = true;
    }
    _subscription?.cancel();
    _groupSubscription?.cancel();
    _handled.clear();
    _subscription = FirebaseFirestore.instance
        .collectionGroup('calls')
        .where('calleeUid', isEqualTo: user.uid)
        .snapshots()
        .listen((snapshot) {
      for (final doc in snapshot.docs) {
        final data = doc.data();
        if (data['status'] != 'ringing' || _handled.contains(doc.reference.path)) continue;
        final createdAt = data['createdAt'];
        if (createdAt is Timestamp &&
            DateTime.now().difference(createdAt.toDate()).inSeconds > 35) continue;
        _showIncoming(doc.reference, data);
      }
    }, onError: (error) {
      debugPrint('Erro no serviço de chamadas: $error');
    });
    _groupSubscription = FirebaseFirestore.instance
        .collectionGroup('callInvites')
        .where('calleeUid', isEqualTo: user.uid)
        .snapshots()
        .listen((snapshot) {
      for (final doc in snapshot.docs) {
        final data = doc.data();
        if (data['status'] != 'ringing' || _handled.contains(doc.reference.path)) continue;
        final createdAt = data['createdAt'];
        if (createdAt is Timestamp &&
            DateTime.now().difference(createdAt.toDate()).inSeconds > 45) continue;
        _showGroupIncoming(doc.reference, data);
      }
    }, onError: (error) {
      debugPrint('Erro ao receber convites para chamada em grupo: $error');
    });
  }

  Future<void> stop() async {
    await _subscription?.cancel();
    await _groupSubscription?.cancel();
    _subscription = null;
    _groupSubscription = null;
    _handled.clear();
    _activeUser = null;
    if (_observerRegistered) {
      WidgetsBinding.instance.removeObserver(this);
      _observerRegistered = false;
    }
  }


  Future<void> _showGroupIncoming(
    DocumentReference<Map<String, dynamic>> inviteRef,
    Map<String, dynamic> data,
  ) async {
    final navigator = rootNavigatorKey.currentState;
    final context = navigator?.context;
    if (navigator == null || context == null || _handled.contains(inviteRef.path)) return;
    _handled.add(inviteRef.path);
    final video = data['video'] == true;
    final callerName = (data['callerName'] ?? 'Alguém').toString();
    final answer = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF21132E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: Text(video ? 'Convite para chamada de vídeo' : 'Convite para chamada de voz',
            style: const TextStyle(color: Colors.white)),
        content: Text('$callerName convidou você para entrar em uma ligação em grupo.',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Recusar', style: TextStyle(color: Colors.redAccent)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF2DAB)),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Entrar'),
          ),
        ],
      ),
    );
    try {
      if (answer == true) {
        final callPath = (data['callPath'] ?? '').toString();
        final roomCallId = (data['roomCallId'] ?? '').toString();
        if (callPath.isEmpty || roomCallId.isEmpty) throw Exception('Convite inválido.');
        await inviteRef.update({
          'status': 'accepted',
          'acceptedAt': FieldValue.serverTimestamp(),
        });
        final parentRef = FirebaseFirestore.instance.doc(callPath);
        final current = rootNavigatorKey.currentState;
        current?.push(MaterialPageRoute(
          builder: (_) => CallScreen(
            callRef: inviteRef,
            video: video,
            roomCallId: roomCallId,
            parentCallRef: parentRef,
            isGroupInvite: true,
          ),
        ));
      } else {
        await inviteRef.update({
          'status': 'rejected',
          'endedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (error) {
      final currentContext = rootNavigatorKey.currentState?.context;
      if (currentContext != null) {
        ScaffoldMessenger.of(currentContext).showSnackBar(
          SnackBar(content: Text('Não foi possível responder ao convite: $error')),
        );
      }
    }
  }

  Future<void> _showIncoming(
      DocumentReference<Map<String, dynamic>> callRef,
      Map<String, dynamic> data) async {
    final navigator = rootNavigatorKey.currentState;
    final context = navigator?.context;
    if (navigator == null || context == null) {
      // Não marca como tratado: o app pode ainda estar montando a navegação.
      return;
    }
    if (_handled.contains(callRef.path)) return;
    _handled.add(callRef.path);
    final video = data['video'] == true;
    final callerName = (data['callerName'] ?? 'Alguém').toString();
    final answer = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF21132E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: Text(video ? 'Chamada de vídeo' : 'Chamada de voz',
            style: const TextStyle(color: Colors.white)),
        content: Text('$callerName está ligando para você.',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Recusar', style: TextStyle(color: Colors.redAccent)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF2DAB)),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Atender'),
          ),
        ],
      ),
    );
    try {
      if (answer == true) {
        await callRef.update({
          'status': 'accepted',
          'acceptedAt': FieldValue.serverTimestamp(),
        });
        final current = rootNavigatorKey.currentState;
        if (current != null) {
          current.push(MaterialPageRoute(
            builder: (_) => CallScreen(callRef: callRef, video: video),
          ));
        }
      } else {
        await callRef.update({
          'status': 'rejected',
          'endedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (error) {
      final currentContext = rootNavigatorKey.currentState?.context;
      if (currentContext != null) {
        ScaffoldMessenger.of(currentContext).showSnackBar(
          SnackBar(content: Text('Não foi possível responder à chamada: $error')),
        );
      }
    }
  }
}
