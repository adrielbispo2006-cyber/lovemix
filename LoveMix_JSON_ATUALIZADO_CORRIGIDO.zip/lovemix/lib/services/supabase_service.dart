import 'dart:typed_data';
import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';

/// Integração do LoveMix com Supabase Storage.
/// A chave publishable pode ficar no app; nunca coloque service_role aqui.
class SupabaseService {
  SupabaseService._();
  static final instance = SupabaseService._();

  static const projectId = 'pcruxbtuimndtjtuclhf';
  static const projectUrl = 'https://pcruxbtuimndtjtuclhf.supabase.co';
  static const publishableKey =
      'sb_publishable_eFocZg9VHa6PWHmg3_ae9w_X2ChWfZO';
  static const bucket = 'lovemix-photos';

  // ImageKit atua como cópia secundária; a URL principal continua sendo a do Supabase.
  static const imageKitPublicKey = 'public_/NtjCe7/QVTvp2fYwwvvGTNeI9s=';
  static const imageKitEndpoint = 'https://ik.imagekit.io/yecqr4bo3';
  static const imageKitUploadUrl = 'https://upload.imagekit.io/api/v1/files/upload';
  // Depois de publicar o Worker, substitua pelo endereço workers.dev exibido pela Cloudflare.
  static const imageKitAuthWorkerUrl = 'https://lovemix.adrielbispo2006.workers.dev';

  bool _initialized = false;
  bool get isInitialized => _initialized;
  SupabaseClient get client => Supabase.instance.client;

  Future<void> initialize() async {
    if (_initialized) return;
    await Supabase.initialize(
      url: projectUrl,
      publishableKey: publishableKey,
    );
    _initialized = true;
  }

  /// Envia arquivo para o bucket público e devolve a URL pública.
  Future<String> uploadPhoto({
    required String path,
    required Uint8List bytes,
    required String contentType,
  }) async {
    if (!_initialized) throw Exception('Supabase ainda não foi inicializado.');
    if (bytes.isEmpty) throw Exception('O arquivo está vazio.');
    await client.storage.from(bucket).uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(
        contentType: contentType,
        upsert: true,
        cacheControl: '3600',
      ),
    );
    final supabaseUrl = client.storage.from(bucket).getPublicUrl(path);

    // Cópia secundária no ImageKit. Falhas aqui não interrompem o envio já
    // concluído no Supabase nem alteram a URL usada atualmente pelo aplicativo.
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login para enviar arquivos ao ImageKit.');
      if (imageKitAuthWorkerUrl.contains('SUBSTITUA-PELO-SEU-WORKER')) {
        throw Exception('Configure a URL do Cloudflare Worker em SupabaseService.');
      }
      final idToken = await user.getIdToken(true);
      final authResponse = await http.post(
        Uri.parse(imageKitAuthWorkerUrl),
        headers: {'Authorization': 'Bearer $idToken', 'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 20));
      if (authResponse.statusCode != 200) {
        throw Exception('Autenticação ImageKit recusada: ${authResponse.statusCode} ${authResponse.body}');
      }
      final data = Map<String, dynamic>.from(jsonDecode(authResponse.body) as Map);
      final request = http.MultipartRequest('POST', Uri.parse(imageKitUploadUrl));
      request.fields.addAll({
        'fileName': path.split('/').last,
        'publicKey': imageKitPublicKey,
        'token': data['token'].toString(),
        'expire': data['expire'].toString(),
        'signature': data['signature'].toString(),
        'useUniqueFileName': 'false',
        'folder': '/lovemix-backup',
      });
      request.files.add(http.MultipartFile.fromBytes(
        'file', bytes, filename: path.split('/').last,
      ));
      final response = await request.send().timeout(const Duration(seconds: 45));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final body = await response.stream.bytesToString();
        throw Exception('ImageKit upload falhou: ${response.statusCode} $body');
      }
    } catch (error) {
      // Mantém o Supabase como fonte principal para não quebrar o app existente.
      // A falha do backup pode ser consultada no log durante os testes.
      print('ImageKit backup indisponível: $error');
    }
    return supabaseUrl;
  }

  Future<void> deleteFile(String path) async {
    if (!_initialized) return;
    await client.storage.from(bucket).remove([path]);
  }

  Future<bool> deletePublicUrl(String url) async {
    if (!_initialized) return false;
    final marker = '/storage/v1/object/public/$bucket/';
    final index = url.indexOf(marker);
    if (index < 0) return false;
    final path = Uri.decodeComponent(url.substring(index + marker.length));
    if (path.isEmpty) return false;
    await deleteFile(path);
    return true;
  }
}
