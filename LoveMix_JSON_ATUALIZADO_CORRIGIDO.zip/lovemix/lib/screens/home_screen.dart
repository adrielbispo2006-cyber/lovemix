import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import 'discover_screen.dart';
import 'messages_screen.dart';
import 'profile_screen.dart';
import 'profile_view_screen.dart';
import 'wallet_screen.dart';
import 'gifts_screen.dart';
import 'chat_rooms_screen.dart';
import 'love_room_screen.dart';
import 'live_broadcast_screen.dart';
import 'ranking_screen.dart';
import 'resources_screen.dart';
import 'stories_widget.dart';
import 'notifications_screen.dart';
import 'extras_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  static const panel = Color(0xFF171022);
  int index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    DataService.instance.setOnlineStatus(true);
    DataService.instance.startCharismaTicker();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DataService.instance.setOnlineStatus(true);
      DataService.instance.startCharismaTicker();
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      DataService.instance.stopCharismaTicker();
      DataService.instance.setOnlineStatus(false);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    DataService.instance.stopCharismaTicker();
    DataService.instance.setOnlineStatus(false);
    super.dispose();
  }

  void open(int page) => setState(() => index = page);

  @override
  Widget build(BuildContext context) {
    final pages = [
      _LoveMixFeed(onDiscover: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()))),
      const _DiscoverRoute(),
      const GiftsScreen(),
      const MessagesScreen(),
      ProfileViewScreen(userId: FirebaseAuth.instance.currentUser?.uid ?? ''),
    ];
    return Scaffold(
      appBar: null,
      body: IndexedStack(index: index, children: pages),
            bottomNavigationBar: NavigationBar(
        height: 68,
        backgroundColor: const Color(0xFF100A19),
        indicatorColor: const Color(0xFF49205F),
        selectedIndex: index,
        onDestinationSelected: open,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: pink), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore, color: pink), label: 'Descobrir'),
          NavigationDestination(icon: Icon(Icons.card_giftcard, color: Color(0xFFFFD700)), selectedIcon: Icon(Icons.card_giftcard, color: Color(0xFFFFD700)), label: 'Presentes'),
          NavigationDestination(
            icon: _ChatNavIcon(selected: false),
            selectedIcon: _ChatNavIcon(selected: true),
            label: 'Chats',
          ),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: pink), label: 'Perfil'),
        ],
      ),
    );
  }

  Future<void> _createRoom(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();
    final password = TextEditingController();
    bool isPublic = true;
    bool isVipRoom = false;
    String category = 'Amizades';
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context, isScrollControlled: true, backgroundColor: panel,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Criar sua sala 👑', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: name, maxLength: 40, decoration: const InputDecoration(hintText: 'Nome da sala')),
          TextField(controller: description, maxLength: 120, decoration: const InputDecoration(hintText: 'Descrição (opcional)')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'Categoria'),
            items: const ['Amizades', 'Namoro', 'Música', 'Jogos', 'Conversas'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) { if (v != null) setSheet(() => category = v); },
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: isVipRoom,
            activeColor: const Color(0xFFFFD45C),
            title: const Text('Sala VIP com animações 👑'),
            subtitle: const Text('Ativa destaque dourado e efeitos especiais na sala'),
            onChanged: (v) => setSheet(() => isVipRoom = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: isPublic,
            activeColor: pink,
            title: Text(isPublic ? 'Sala pública' : 'Sala privada'),
            subtitle: Text(isPublic ? 'Qualquer pessoa pode entrar' : 'Sala privada, não aparece na lista pública'),
            onChanged: (v) => setSheet(() => isPublic = v),
          ),
          if (!isPublic) ...[
            const SizedBox(height: 8),
            TextField(controller: password, obscureText: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Senha da sala', hintText: 'Crie uma senha para compartilhar')),
          ],
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(ctx, {
            'name': name.text.trim(), 'description': description.text.trim(),
            'category': category, 'isPublic': isPublic, 'isVipRoom': isVipRoom, 'password': password.text.trim(),
          }), child: const Text('Criar Sala ✨'))),
        ]),
      )),
    );
    if (result == null || (result['name'] as String).isEmpty) return;
    try {
      final roomName = result['name'] as String;
      final id = await DataService.instance.createRoom(
        roomName,
        isPublic: result['isPublic'] as bool,
        category: result['category'] as String,
        description: result['description'] as String,
        password: result['password'] as String,
        isVipRoom: result['isVipRoom'] as bool? ?? false,
        isLive: true,
        mediaMode: 'audio',
      );
      if (!mounted) return;
      open(1);
      Navigator.push(context, MaterialPageRoute(builder: (_) => LoveRoomScreen(roomId: id, roomName: roomName)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
}


class _ChatNavIcon extends StatelessWidget {
  const _ChatNavIcon({required this.selected});
  final bool selected;

  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: DataService.instance.myChats(),
    builder: (context, snapshot) {
      final uid = DataService.instance.uid;
      var unread = 0;
      for (final doc in snapshot.data?.docs ?? const []) {
        final data = doc.data();
        if ((data['hiddenFor'] as List<dynamic>? ?? const []).contains(uid)) continue;
        final counts = data['unreadCounts'];
        final value = counts is Map ? counts[uid] : null;
        if (value is num) unread += value.toInt();
      }
      return Stack(clipBehavior: Clip.none, children: [
        Icon(selected ? Icons.chat_bubble : Icons.chat_bubble_outline, color: selected ? const Color(0xFFFF19B8) : Colors.white),
        if (unread > 0) Positioned(
          right: -10, top: -8,
          child: Container(
            constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
            decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
            alignment: Alignment.center,
            child: Text(unread > 99 ? '99+' : '$unread', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
          ),
        ),
      ]);
    },
  );
}


class _LoveMixFeed extends StatefulWidget {
  const _LoveMixFeed({required this.onDiscover});
  final VoidCallback onDiscover;
  @override
  State<_LoveMixFeed> createState() => _LoveMixFeedState();
}

class _LoveMixFeedState extends State<_LoveMixFeed> {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  final _message = TextEditingController();
  bool _publishing = false;
  String _homeFilter = 'Descobrir';
  int _featuredIndex = 0;

  void _selectHomeFilter(String value) {
    setState(() { _homeFilter = value; _featuredIndex = 0; });
  }
  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db = FirebaseFirestore.instance;

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  Future<void> _publish({bool withPhoto = false}) async {
    if (_publishing) return;
    XFile? photo;
    if (withPhoto) {
      photo = await ImagePicker().pickImage(
        source: ImageSource.gallery, imageQuality: 82, maxWidth: 1440,
      );
      if (photo == null) return;
    }
    final text = _message.text.trim();
    if (text.isEmpty && photo == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escreva uma mensagem ou escolha uma foto.')),
      );
      return;
    }
    setState(() => _publishing = true);
    try {
      final profile = await _db.collection('users').doc(_uid).get();
      String photoUrl = '';
      if (photo != null) {
        final bytes = await photo.readAsBytes();
        if (bytes.length > 5 * 1024 * 1024) {
          throw Exception('A foto deve ter no máximo 5 MB.');
        }
        final ext = photo.name.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
        photoUrl = await SupabaseService.instance.uploadPhoto(
          path: 'feed_posts/$_uid/${DateTime.now().millisecondsSinceEpoch}.$ext',
          bytes: bytes,
          contentType: ext == 'png' ? 'image/png' : 'image/jpeg',
        );
      }
      await _db.collection('feed_posts').add({
        'ownerId': _uid,
        'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
        'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
        'imageUrl': photoUrl,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });
      _message.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Publicação compartilhada!')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível publicar: $e')),
      );
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  Future<void> _deletePost(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF21132E),
        title: const Text('Apagar publicação?'),
        content: const Text('Essa publicação será removida do feed.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final imageUrl = (doc.data()['imageUrl'] ?? '').toString();
      // Se a publicação veio da galeria do perfil (mesmo id), remove de lá
      // também; assim a foto não fica quebrada no perfil nem volta ao feed.
      final owner = (doc.data()['ownerId'] ?? '').toString();
      final batch = _db.batch();
      batch.delete(doc.reference);
      if (owner.isNotEmpty) {
        batch.delete(_db.collection('users').doc(owner).collection('posts').doc(doc.id));
      }
      await batch.commit();
      if (imageUrl.isNotEmpty) {
        await SupabaseService.instance.deletePublicUrl(imageUrl);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível apagar: $e')),
      );
    }
  }

  CollectionReference<Map<String, dynamic>> _postLikes(String postId) =>
      _db.collection('feed_posts').doc(postId).collection('likes');
  CollectionReference<Map<String, dynamic>> _postComments(String postId) =>
      _db.collection('feed_posts').doc(postId).collection('comments');

  Future<void> _toggleCommunityLike(String postId) async {
    if (_uid.isEmpty) return;
    final ref = _postLikes(postId).doc(_uid);
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (snap.exists) {
          tx.delete(ref);
        } else {
          tx.set(ref, {'uid': _uid, 'createdAt': FieldValue.serverTimestamp()});
        }
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível curtir: $e')),
      );
    }
  }

  Future<void> _openCommunityComments(String postId) async {
    final controller = TextEditingController();
    Future<void> send(StateSetter setSheet) async {
      final text = controller.text.trim();
      if (text.isEmpty || _uid.isEmpty) return;
      try {
        final profile = await _db.collection('users').doc(_uid).get();
        await _postComments(postId).add({
          'uid': _uid,
          'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
          'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
          'text': text,
          'createdAt': FieldValue.serverTimestamp(),
        });
        controller.clear();
        setSheet(() {});
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível comentar: $e')),
        );
      }
    }
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF171022),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (sheetContext) => StatefulBuilder(builder: (ctx, setSheet) =>
        Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SizedBox(height: MediaQuery.of(ctx).size.height * .65, child: Column(children: [
            const Padding(padding: EdgeInsets.all(16), child: Text('Comentários da comunidade', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
            Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _postComments(postId).orderBy('createdAt', descending: true).limit(100).snapshots(),
              builder: (ctx, snap) {
                if (snap.hasError) return const Center(child: Text('Não foi possível carregar os comentários.'));
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                if (snap.data!.docs.isEmpty) return const Center(child: Text('Seja a primeira pessoa a comentar!'));
                return ListView(children: snap.data!.docs.map((doc) {
                  final c = doc.data();
                  return ListTile(
                    leading: CircleAvatar(backgroundImage: (c['photoUrl'] ?? '').toString().isNotEmpty ? NetworkImage(c['photoUrl']) : null, child: (c['photoUrl'] ?? '').toString().isEmpty ? const Icon(Icons.person) : null),
                    title: Text((c['name'] ?? 'Pessoa').toString(), style: const TextStyle(color: Color(0xFFFF8BD5), fontWeight: FontWeight.bold)),
                    subtitle: Text((c['text'] ?? '').toString()),
                    trailing: c['uid'] == _uid ? IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white54), onPressed: () => doc.reference.delete()) : null,
                  );
                }).toList());
              },
            )),
            Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 14), child: Row(children: [
              Expanded(child: TextField(controller: controller, maxLength: 300, buildCounter: (_, {required currentLength, required isFocused, maxLength}) => null, decoration: const InputDecoration(hintText: 'Escreva um comentário...'))),
              IconButton(onPressed: () => send(setSheet), icon: const Icon(Icons.send, color: pink)),
            ])),
          ])),
        ),
      ),
    );
    controller.dispose();
  }

  Widget _communityInteractions(String postId) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Row(children: [
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postLikes(postId).snapshots(),
        builder: (context, snap) {
          final liked = snap.data?.docs.any((d) => d.id == _uid) ?? false;
          final count = snap.data?.docs.length ?? 0;
          return Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(visualDensity: VisualDensity.compact, onPressed: () => _toggleCommunityLike(postId),
              icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.redAccent : Colors.white70, size: 25)),
            Text('$count curtidas', style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ]);
        },
      ),
      const SizedBox(width: 12),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postComments(postId).snapshots(),
        builder: (context, snap) => TextButton.icon(
          onPressed: () => _openCommunityComments(postId),
          icon: const Icon(Icons.mode_comment_outlined, color: Colors.white70, size: 20),
          label: Text('${snap.data?.docs.length ?? 0} comentários', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ),
      ),
    ]),
  );

  @override
  Widget build(BuildContext context) => Container(
    color: Colors.black,
    child: ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        _homeHeader(),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 10),
          child: InkWell(
            onTap: widget.onDiscover,
            borderRadius: BorderRadius.circular(28),
            child: Container(
              height: 54,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF1B0828),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: const Color(0xFF9B22D8), width: 1.4),
                boxShadow: const [BoxShadow(color: Color(0x553F00FF), blurRadius: 14)],
              ),
              child: const Row(children: [
                Icon(Icons.search, color: Color(0xFFE77BFF), size: 27),
                SizedBox(width: 12),
                Expanded(child: Text('Buscar pessoas por ID, nome ou cidade...', style: TextStyle(color: Color(0xFFD6B8E7), fontSize: 14))),
                Icon(Icons.tune, color: Color(0xFFE77BFF)),
              ]),
            ),
          ),
        ),
        const StoriesStrip(),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              _homePill('🔥', 'Descobrir', _homeFilter == 'Descobrir', () => _selectHomeFilter('Descobrir')),
              _homePill('👥', 'Amigos', _homeFilter == 'Amigos', () => _selectHomeFilter('Amigos')),
              _homePill('💜', 'Seguindo', _homeFilter == 'Seguindo', () => _selectHomeFilter('Seguindo')),
              _homePill('⭐', 'Para você', _homeFilter == 'Para você', () => _selectHomeFilter('Para você')),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        _featuredDiscoverCard(),
        const SizedBox(height: 22),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
          child: Row(children: [
            const Icon(Icons.sensors, color: Color(0xFFE83DFF), size: 28),
            const SizedBox(width: 10),
            const Expanded(child: Text('Salas Ao Vivo', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Colors.white))),
            TextButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RoomsRoute())),
              child: const Text('Ver todas ➜', style: TextStyle(color: Color(0xFFE879FF), fontWeight: FontWeight.bold)),
            ),
          ]),
        ),
        _liveRoomsBanner(),
      ],
    ),
  );

  Widget _homeHeader() => Padding(
    padding: const EdgeInsets.fromLTRB(18, 12, 14, 10),
    child: Row(children: [
      const Expanded(
        child: Align(
          alignment: Alignment.centerLeft,
          child: SizedBox(
            width: 142,
            height: 76,
            child: Image(
              image: AssetImage('assets/icon/lovemix.png'),
              fit: BoxFit.contain,
              filterQuality: FilterQuality.medium,
            ),
          ),
        ),
      ),
      _balanceChip('🪙', 'Moedas', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen()))),
      const SizedBox(width: 6),
      _balanceChip('💎', 'Diamantes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen()))),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _db.collection('users').doc(_uid).collection('notifications').snapshots(),
        builder: (context, snap) {
          final unread = snap.data?.docs.where((d) => d.data()['read'] != true).length ?? 0;
          return IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
            icon: Stack(clipBehavior: Clip.none, children: [
              const Icon(Icons.notifications, color: Colors.white, size: 28),
              if (unread > 0) Positioned(right: -6, top: -7, child: CircleAvatar(radius: 9, backgroundColor: Colors.red, child: Text(unread > 9 ? '9+' : '$unread', style: const TextStyle(fontSize: 9, color: Colors.white)))),
            ]),
          );
        },
      ),
    ]),
  );

  Widget _balanceChip(String emoji, String label, VoidCallback onTap) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
    stream: _db.collection('users').doc(_uid).snapshots(),
    builder: (context, snap) {
      final profile = snap.data?.data() ?? const <String, dynamic>{};
      final amount = label == 'Moedas' ? (profile['coins'] ?? 0) : (profile['diamonds'] ?? 0);
      return InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: BoxDecoration(color: const Color(0xFF160B20), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF6F3A85))),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(emoji, style: const TextStyle(fontSize: 13)),
            const SizedBox(width: 4),
            Text('$amount', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(width: 3),
            const Icon(Icons.add_circle, color: Color(0xFFE348FF), size: 16),
          ]),
        ),
      );
    },
  );

  Widget _homePill(String emoji, String label, bool selected, VoidCallback onTap) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(24), child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
      decoration: BoxDecoration(
        gradient: selected ? const LinearGradient(colors: [Color(0xFFB000FF), Color(0xFF6500C9)]) : null,
        color: selected ? null : const Color(0xFF1B1028),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: selected ? const Color(0xFFE34CFF) : const Color(0xFF382044)),
        boxShadow: selected ? const [BoxShadow(color: Color(0xAA9B00FF), blurRadius: 12)] : null,
      ),
      child: Text('$emoji  $label', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
    )),
  );

  Widget _featuredDiscoverCard() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: DataService.instance.discoverUsers(),
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return _emptyFeatured('Não foi possível carregar pessoas agora.');
      }
      if (!snapshot.hasData) {
        return const SizedBox(height: 300, child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF))));
      }
      final profiles = snapshot.data!.docs.where((doc) {
        final p = doc.data();
        return doc.id != _uid &&
            p['isActive'] != false &&
            p['profileVisibility'] == 'public' &&
            (p['photoUrl'] ?? '').toString().trim().isNotEmpty;
      }).toList();

      if (_homeFilter == 'Amigos') {
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _db.collection('alliances').where('members', arrayContains: _uid).snapshots(),
          builder: (context, allianceSnapshot) {
            if (!allianceSnapshot.hasData) {
              return const SizedBox(height: 300, child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF))));
            }
            final friendIds = <String>{};
            for (final alliance in allianceSnapshot.data!.docs) {
              final data = alliance.data();
              if (data['invitationStatus'] != 'accepted') continue;
              if (!['Amigos', 'BFF', 'Namorados'].contains(data['relationshipType'])) continue;
              final members = (data['members'] as List<dynamic>? ?? const []).map((v) => v.toString()).toList();
              friendIds.addAll(members.where((id) => id != _uid));
            }
            final friends = profiles.where((d) => friendIds.contains(d.id)).toList();
            return _buildFeaturedProfile(friends, 'Você ainda não tem amizades ou alianças aceitas.');
          },
        );
      }

      if (_homeFilter == 'Seguindo') {
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _db.collection('users').doc(_uid).collection('following').snapshots(),
          builder: (context, followingSnapshot) {
            if (!followingSnapshot.hasData) {
              return const SizedBox(height: 300, child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF))));
            }
            final ids = followingSnapshot.data!.docs.map((d) => d.id).toSet();
            final followed = profiles.where((d) => ids.contains(d.id)).toList();
            return _buildFeaturedProfile(followed, 'Você ainda não segue ninguém.');
          },
        );
      }

      if (_homeFilter == 'Para você') {
        profiles.sort((a, b) {
          final aOnline = a.data()['isOnline'] == true ? 1 : 0;
          final bOnline = b.data()['isOnline'] == true ? 1 : 0;
          return bOnline.compareTo(aOnline);
        });
      }
      // "Amigos" mostra perfis públicos para iniciar novas amizades.
      return _buildFeaturedProfile(profiles, 'Ainda não há perfis públicos com foto.');
    },
  );

  Widget _buildFeaturedProfile(
    List<QueryDocumentSnapshot<Map<String, dynamic>>> profiles,
    String emptyMessage,
  ) {
    if (profiles.isEmpty) return _emptyFeatured(emptyMessage);
    if (_featuredIndex >= profiles.length) _featuredIndex = 0;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: 390,
          child: PageView.builder(
            key: ValueKey(profiles.map((profile) => profile.id).join('|')),
            itemCount: profiles.length,
            onPageChanged: (value) => setState(() => _featuredIndex = value),
            itemBuilder: (context, index) => _featuredProfileCard(profiles[index]),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(profiles.length > 7 ? 7 : profiles.length, (index) {
            final selected = index == (_featuredIndex % (profiles.length > 7 ? 7 : profiles.length));
            return AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: selected ? 24 : 10,
              height: 10,
              decoration: BoxDecoration(
                color: selected ? const Color(0xFFB000FF) : const Color(0xFF59466B),
                borderRadius: BorderRadius.circular(20),
                boxShadow: selected ? const [BoxShadow(color: Color(0xAA9B00FF), blurRadius: 8)] : null,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _featuredProfileCard(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final p = doc.data();
    final photo = (p['photoUrl'] ?? '').toString();
    final name = (p['name'] ?? p['displayName'] ?? 'Pessoa').toString();
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    final place = [city, country].where((v) => v.isNotEmpty).join(', ');
    final birthday = p['birthday'];
    String age = '';
    if (birthday is Timestamp) {
      final date = birthday.toDate();
      var years = DateTime.now().year - date.year;
      if (DateTime.now().month < date.month ||
          (DateTime.now().month == date.month && DateTime.now().day < date.day)) years--;
      if (years > 0 && years < 120) age = '$years';
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      height: 390,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFF16091F),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFD84AFF), width: 1.5),
        boxShadow: const [BoxShadow(color: Color(0x664F00FF), blurRadius: 16)],
      ),
      child: Stack(children: [
        Positioned.fill(
          child: GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id))),
            child: CachedNetworkImage(
              imageUrl: photo,
              fit: BoxFit.cover,
              memCacheWidth: 900,
              fadeInDuration: const Duration(milliseconds: 180),
              placeholder: (_, __) => const ColoredBox(color: Color(0xFF24102F), child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF)))),
              errorWidget: (_, __, ___) => const ColoredBox(color: Color(0xFF24102F), child: Center(child: Icon(Icons.person, size: 100, color: Colors.white54))),
            ),
          ),
        ),
        Positioned.fill(child: IgnorePointer(child: DecoratedBox(
          decoration: BoxDecoration(gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [Colors.black.withValues(alpha: 0.08), Colors.transparent, Colors.black.withValues(alpha: 0.88)],
            stops: const [0, 0.42, 1],
          )),
        ))),
        Positioned(left: 14, top: 14, child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(color: const Color(0xFF351052), borderRadius: BorderRadius.circular(20)),
          child: Row(children: [
            Icon(
              Icons.circle,
              size: 10,
              color: p['isLive'] == true
                  ? const Color(0xFFFF3DAB)
                  : (p['isOnline'] == true ? Colors.greenAccent : Colors.white38),
            ),
            const SizedBox(width: 6),
            Text(
              p['isLive'] == true
                  ? 'AO VIVO'
                  : (p['isOnline'] == true ? 'Online' : 'OFF'),
              style: TextStyle(
                color: p['isLive'] == true
                    ? const Color(0xFFFF75D4)
                    : (p['isOnline'] == true ? Colors.greenAccent : Colors.white70),
                fontWeight: FontWeight.bold,
              ),
            ),
          ]),
        )),
        Positioned(right: 12, top: 10, child: IconButton(
          onPressed: () async {
            try {
              final followed = await DataService.instance.toggleFollow(doc.id);
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(followed ? 'Você começou a seguir $name 💗' : 'Você deixou de seguir $name.')));
            } catch (e) {
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível curtir: $e')));
            }
          },
          icon: const Icon(Icons.favorite_border, color: Color(0xFFFF70E8), size: 30),
          style: IconButton.styleFrom(backgroundColor: Colors.black54),
        )),
        Positioned(left: 18, right: 14, bottom: 18, child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                Text('$name${age.isNotEmpty ? ', $age' : ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                if (place.isNotEmpty) Row(children: [
                  const Icon(Icons.location_on, color: Colors.white, size: 16),
                  const SizedBox(width: 4),
                  Expanded(child: Text(place, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 13))),
                ]),
              ]),
            )),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: () async {
                try {
                  final followed = await DataService.instance.toggleFollow(doc.id);
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(followed ? 'Você começou a seguir 💗' : 'Você deixou de seguir.')));
                } catch (_) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível curtir este perfil.')));
                }
              },
              icon: const Icon(Icons.favorite, size: 18),
              label: const Text('Curtir'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFB000D9), foregroundColor: Colors.white,
                shape: const StadiumBorder(), side: const BorderSide(color: Color(0xFFFF7CEB)),
              ),
            ),
          ],
        )),
      ]),
    );
  }

  Widget _emptyFeatured(String message) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    height: 260,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: const Color(0xFFD84AFF)),
      gradient: const LinearGradient(colors: [Color(0xFF351044), Color(0xFF100817)]),
    ),
    child: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.people_alt_outlined, color: Color(0xFFE34CFF), size: 56),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
        TextButton(onPressed: widget.onDiscover, child: const Text('Ver pessoas', style: TextStyle(color: Color(0xFFE879FF)))),
      ]),
    )),
  );

  Widget _liveRoomsBanner() => InkWell(
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RoomsRoute())),
    borderRadius: BorderRadius.circular(22),
    child: Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE04AFF), width: 1.5),
        gradient: const LinearGradient(colors: [Color(0xFF330052), Color(0xFF11051D), Color(0xFF30004A)]),
        boxShadow: const [BoxShadow(color: Color(0x884C00FF), blurRadius: 14)],
      ),
      child: Column(children: [
        const Icon(Icons.mic, size: 82, color: Color(0xFFE33BFF)),
        const Text('Entre nas salas de voz e faça novas amizades!', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
          decoration: BoxDecoration(color: const Color(0xFFB000D9), borderRadius: BorderRadius.circular(28), border: Border.all(color: const Color(0xFFFF8AFF))),
          child: const Text('▶  Entrar em uma sala', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
        ),
      ]),
    ),
  );

  static Widget _unusedKeepCategory(String emoji, String label, VoidCallback onTap) => const SizedBox.shrink();
  static Widget _unusedKeepQuick(String emoji, String title, VoidCallback onTap) => const SizedBox.shrink();

  static void _goDiscover(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()));
  static void _goRooms(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RoomsRoute()));

  Widget _composer() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4C2869))),
    child: Column(children: [
      TextField(
        controller: _message, minLines: 1, maxLines: 5, maxLength: 1000,
        decoration: const InputDecoration(
          hintText: 'O que você quer compartilhar?',
          counterText: '', border: InputBorder.none, filled: false,
        ),
      ),
      Row(children: [
        TextButton.icon(
          onPressed: _publishing ? null : () => _publish(withPhoto: true),
          icon: const Icon(Icons.photo_library_outlined, color: pink),
          label: const Text('Foto', style: TextStyle(color: pink)),
        ),
        const Spacer(),
        FilledButton(
          onPressed: _publishing ? null : () => _publish(),
          style: FilledButton.styleFrom(backgroundColor: pink),
          child: _publishing
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Text('Publicar'),
        ),
      ]),
    ]),
  );

  Widget _postCard(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final p = doc.data();
    final image = (p['imageUrl'] ?? '').toString();
    final text = (p['text'] ?? '').toString();
    final owner = (p['ownerId'] ?? '').toString();
    final avatar = (p['photoUrl'] ?? '').toString();
    final ts = p['createdAt'];
    final when = ts is Timestamp ? _ago(ts) : 'agora';
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 6, 14, 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF3C2456))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            radius: 20, backgroundColor: const Color(0xFF351052),
            backgroundImage: avatar.isNotEmpty ? NetworkImage(avatar) : null,
            child: avatar.isEmpty ? const Icon(Icons.person, color: Colors.white70) : null,
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text((p['name'] ?? 'Pessoa').toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(when, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ])),
          if (owner == _uid) IconButton(
            tooltip: 'Apagar publicação',
            onPressed: () => _deletePost(doc),
            icon: const Icon(Icons.delete_outline, color: Colors.white70),
          ),
        ]),
        if (text.isNotEmpty) Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 4),
          child: Text(text, style: const TextStyle(fontSize: 14)),
        ),
        if (image.isNotEmpty) ...[
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(image, width: double.infinity, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox(height: 120, child: Center(child: Icon(Icons.broken_image)))),
          ),
        ],
        _communityInteractions(doc.id),
      ]),
    );
  }

  String _ago(Timestamp timestamp) {
    final d = DateTime.now().difference(timestamp.toDate());
    if (d.inMinutes < 1) return 'agora';
    if (d.inHours < 1) return 'há ${d.inMinutes} min';
    if (d.inDays < 1) return 'há ${d.inHours} h';
    return 'há ${d.inDays} d';
  }

  static Widget _category(String emoji, String label, VoidCallback onTap) => Expanded(child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(
      height: 78, decoration: BoxDecoration(color: const Color(0xFF1C1229), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF3C2456))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 25)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]),
    )),
  ));

  static Widget _quick(String emoji, String title, VoidCallback onTap) => InkWell(onTap: onTap, child: Container(
    padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: const Color(0xFF1A1028), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF4C2869))),
    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 22)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
  ));

}

class _OnlineBadge extends StatelessWidget {
  const _OnlineBadge({required this.isOnline});
  final bool isOnline;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: const Color(0xFF351052), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.circle, color: isOnline ? const Color(0xFF35E85A) : Colors.white38, size: 11),
      const SizedBox(width: 6),
      Text(isOnline ? 'Online' : 'OFF', style: TextStyle(
        color: isOnline ? Colors.greenAccent : Colors.white70,
        fontWeight: FontWeight.bold,
      )),
    ]),
  );
}

class _DiscoverRoute extends StatelessWidget {
  const _DiscoverRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Descobrir pessoas')), body: DiscoverScreen());
}
class _RoomsRoute extends StatelessWidget {
  const _RoomsRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Salas LoveMix')), body: ChatRoomsScreen());
}
