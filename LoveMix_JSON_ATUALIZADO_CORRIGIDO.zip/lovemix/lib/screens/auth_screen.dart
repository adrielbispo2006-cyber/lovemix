import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../services/data_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool busy = false;
  bool obscurePassword = true;
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  DateTime? birthday;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  bool _isAdult(DateTime date) {
    final today = DateTime.now();
    final age = today.year - date.year -
        ((today.month < date.month ||
                (today.month == date.month && today.day < date.day))
            ? 1
            : 0);
    return age >= 18;
  }

  Future<DateTime?> _askBirthday() async {
    final now = DateTime.now();
    return showDatePicker(
      context: context,
      firstDate: DateTime(1900),
      lastDate: DateTime(now.year - 18, now.month, now.day),
      initialDate: DateTime(now.year - 25, now.month, now.day),
      helpText: 'Confirme que você tem 18 anos ou mais',
    );
  }

  Future<void> _claimFounderIfEligible() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email?.toLowerCase() != 'adrielbispo3009@gmail.com' || !user.emailVerified && user.providerData.every((p) => p.providerId != 'google.com')) return;
    try {
      await FirebaseFunctions.instance.httpsCallable('claimFounderAdmin').call();
    } catch (_) {
      // A função só fica disponível depois de publicar as Cloud Functions.
      // O login normal continua funcionando enquanto isso.
    }
  }

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      show('Informe seu e-mail e sua senha.');
      return;
    }
    if (register && name.text.trim().isEmpty) {
      show('Informe seu nome.');
      return;
    }
    if (register && birthday == null) {
      show('Informe sua data de nascimento.');
      return;
    }
    if (register && !_isAdult(birthday!)) {
      show('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }

    setState(() => busy = true);
    try {
      if (register) {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await cred.user!.updateDisplayName(name.text.trim());
        await DataService.instance.createUser(
          name: name.text.trim(),
          birthday: birthday!,
        );
        await _claimFounderIfEligible();
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        // Tenta conceder a função de fundador e atualiza o token antes de
        // abrir o painel/perfil, para que a interface reconheça a permissão.
        await _claimFounderIfEligible();
        await FirebaseAuth.instance.currentUser?.getIdToken(true);
      }
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } catch (e) {
      show('Não foi possível concluir. Verifique sua internet e tente novamente.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> signInGuest() async {
    if (busy) return;
    final guestName = TextEditingController();
    DateTime? guestBirthday;
    final details = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF16091E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: Color(0xFFB000FF)),
          ),
          title: const Text('Entrar como convidado', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: guestName,
                maxLength: 24,
                textCapitalization: TextCapitalization.words,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Como podemos te chamar?',
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  final date = await _askBirthday();
                  if (date != null) setDialogState(() => guestBirthday = date);
                },
                icon: const Icon(Icons.calendar_month),
                label: Text(guestBirthday == null
                    ? 'Data de nascimento (18+)'
                    : '${guestBirthday!.day.toString().padLeft(2, '0')}/${guestBirthday!.month.toString().padLeft(2, '0')}/${guestBirthday!.year}'),
              ),
              const SizedBox(height: 8),
              const Text(
                'O acesso de convidado cria um perfil temporário neste aparelho. Para não perder o acesso, depois vincule uma conta de e-mail.',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (guestName.text.trim().isEmpty || guestBirthday == null) return;
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Continuar'),
            ),
          ],
        ),
      ),
    );
    if (details != true) {
      guestName.dispose();
      return;
    }
    if (!_isAdult(guestBirthday!)) {
      guestName.dispose();
      show('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }

    setState(() => busy = true);
    try {
      final credential = await FirebaseAuth.instance.signInAnonymously();
      final user = credential.user;
      if (user == null) throw Exception('Não foi possível criar a sessão de convidado.');
      await user.updateDisplayName(guestName.text.trim());
      await DataService.instance.createUser(
        name: guestName.text.trim(),
        birthday: guestBirthday!,
      );
      await DataService.instance.updateProfile({
        'isGuest': true,
        'guestCreatedAt': FieldValue.serverTimestamp(),
      });
    } on FirebaseAuthException catch (e) {
      show(e.code == 'operation-not-allowed'
          ? 'Ative o provedor Anônimo nas configurações de autenticação do Firebase para liberar o acesso como convidado.'
          : _authError(e));
      if (FirebaseAuth.instance.currentUser?.isAnonymous == true) {
        await FirebaseAuth.instance.signOut();
      }
    } catch (_) {
      if (FirebaseAuth.instance.currentUser?.isAnonymous == true) {
        await FirebaseAuth.instance.signOut();
      }
      show('Não foi possível entrar como convidado. Verifique sua internet e as regras do Firestore.');
    } finally {
      guestName.dispose();
      if (mounted) setState(() => busy = false);
    }
  }

  // O ID OAuth WEB é injetado pelo workflow a partir do google-services.json.
  // O valor padrão mantém compatibilidade com builds locais deste projeto.
  static const String _googleServerClientId = String.fromEnvironment(
    'GOOGLE_SERVER_CLIENT_ID',
    defaultValue: '985069046748-eb17v8ri34e4c9l5kevua27kt0ibgj50.apps.googleusercontent.com',
  );

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    serverClientId: _googleServerClientId,
    scopes: const ['email'],
  );

  Future<void> signInGoogle() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      // O seletor nativo do Google funciona com a configuração OAuth Android.
      // Usa o cliente WEB correspondente ao google-services.json do build.
      // O cliente Android é selecionado pelo pacote + SHA-1 da assinatura.
      await _googleSignIn.signOut();
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return; // O usuário cancelou.

      final googleAuth = await googleUser.authentication;
      if (googleAuth.idToken == null || googleAuth.idToken!.isEmpty) {
        throw Exception(
          'O Google não retornou um ID token. Confira o cliente OAuth WEB e o SHA-1/SHA-256 da assinatura deste APK no Firebase.',
        );
      }
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final result = await FirebaseAuth.instance.signInWithCredential(credential);
      final user = result.user;
      if (user == null) throw Exception('Não foi possível obter a conta Google.');

      // Cria o perfil no Firestore somente na primeira entrada e solicita
      // data de nascimento para respeitar a regra de uso para maiores de 18.
      final profile = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (!profile.exists) {
        if (!mounted) return;
        final date = await _askBirthday();
        if (date == null) {
          await FirebaseAuth.instance.signOut();
          await _googleSignIn.signOut();
          show('Para criar sua conta, confirme sua data de nascimento.');
          return;
        }
        if (!_isAdult(date)) {
          await FirebaseAuth.instance.signOut();
          await _googleSignIn.signOut();
          show('O LoveMix é destinado somente a maiores de 18 anos.');
          return;
        }
        final displayName = (user.displayName ?? '').trim();
        final fallbackName = user.email?.split('@').first ?? 'Pessoa LoveMix';
        await DataService.instance.createUser(
          name: displayName.isEmpty ? fallbackName : displayName,
          birthday: date,
        );
      }
      // Não bloqueia a transição para a tela principal aguardando uma função
      // administrativa opcional do Firebase.
      await _claimFounderIfEligible();
      await FirebaseAuth.instance.currentUser?.getIdToken(true);
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } on PlatformException catch (e) {
      final details = '${e.code}: ${e.message ?? e.details ?? 'sem detalhes'}';
      if (details.contains('10') ||
          details.contains('DEVELOPER_ERROR') ||
          details.contains('sign_in_failed')) {
        show('O Google recusou este APK (DEVELOPER_ERROR). O pacote deve ser com.example.lovemix e o SHA-1 da chave que assinou este APK precisa estar cadastrado no Firebase. Depois baixe um novo google-services.json e gere outro APK. Detalhe: $details');
      } else {
        show('Falha no seletor do Google ($details). Atualize o Google Play Services e tente novamente.');
      }
    } catch (e) {
      show('Não foi possível concluir o login Google: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _authError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'O e-mail informado é inválido.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'E-mail ou senha incorretos.';
      case 'email-already-in-use':
        return 'Este e-mail já possui uma conta. Tente entrar.';
      case 'weak-password':
        return 'Escolha uma senha com pelo menos 6 caracteres.';
      case 'network-request-failed':
        return 'Sem conexão. Verifique sua internet e tente novamente.';
      case 'operation-not-allowed':
        return 'Este método de login ainda não foi ativado no Firebase.';
      case 'configuration-not-found':
        return 'Configuração de autenticação ausente no Firebase. Confira o provedor e as configurações do aplicativo.';
      default:
        return e.message ?? 'Não foi possível autenticar. Tente novamente.';
    }
  }

  void show(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _openEmailForm({bool createAccount = false}) async {
    register = createAccount;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final bottomInset = MediaQuery.of(context).viewInsets.bottom;
          return Padding(
            padding: EdgeInsets.only(bottom: bottomInset),
            child: Container(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .88),
              decoration: const BoxDecoration(
                color: Color(0xFF100719),
                borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                border: Border(top: BorderSide(color: Color(0xFFB000FF), width: 1.5)),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(8))),
                    const SizedBox(height: 18),
                    Row(children: [
                      const Spacer(),
                      Text(register ? 'Criar uma conta' : 'Boas-vindas de volta', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
                      const Spacer(),
                      IconButton(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.close, color: Colors.white70)),
                    ]),
                    if (register) ...[
                      TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Nome completo', prefixIcon: Icon(Icons.person_outline))),
                      const SizedBox(height: 12),
                    ],
                    TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(hintText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
                    const SizedBox(height: 12),
                    TextField(
                      controller: password,
                      obscureText: obscurePassword,
                      autofillHints: register ? const [AutofillHints.newPassword] : const [AutofillHints.password],
                      decoration: InputDecoration(
                        hintText: 'Senha',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setSheetState(() => obscurePassword = !obscurePassword),
                          icon: Icon(obscurePassword ? Icons.visibility : Icons.visibility_off),
                        ),
                      ),
                    ),
                    if (register) ...[
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: busy ? null : () async {
                          final d = await _askBirthday();
                          if (d != null && mounted) setSheetState(() => birthday = d);
                        },
                        icon: const Icon(Icons.calendar_month),
                        label: Text(birthday == null ? 'Data de nascimento (18+)' : '${birthday!.day}/${birthday!.month}/${birthday!.year}'),
                      ),
                    ],
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: busy ? null : () async {
                          setSheetState(() => busy = true);
                          await submit();
                          if (!mounted || !sheetContext.mounted) return;
                          // Fecha a folha assim que FirebaseAuth confirmar a
                          // sessão; o StreamBuilder raiz abre a Home/perfil.
                          if (FirebaseAuth.instance.currentUser != null) {
                            Navigator.of(sheetContext).pop();
                          } else {
                            setSheetState(() => busy = false);
                          }
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF22B7), shape: const StadiumBorder()),
                        child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(register ? 'Criar minha conta' : 'Entrar'),
                      ),
                    ),
                    TextButton(
                      onPressed: busy ? null : () => setSheetState(() => register = !register),
                      child: Text(register ? 'Já tem uma conta? Entrar' : 'Não tem uma conta? Criar conta', style: const TextStyle(color: Color(0xFFFF4CC7))),
                    ),
                    if (!register)
                      TextButton(
                        onPressed: busy ? null : () async {
                          if (email.text.trim().isEmpty) return show('Digite seu e-mail primeiro.');
                          try {
                            await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
                            show('Enviamos um link de recuperação para seu e-mail.');
                          } on FirebaseAuthException catch (e) { show(_authError(e)); }
                        },
                        child: const Text('Esqueci minha senha', style: TextStyle(color: Color(0xFFFF4CC7))),
                      ),
                    const SizedBox(height: 6),
                    const Text('Acesso exclusivo para maiores de 18 anos', style: TextStyle(color: Colors.white38, fontSize: 11)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildLanding(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final compact = size.height < 760;
    const gold = Color(0xFFFFC928);
    const purple = Color(0xFFB000FF);
    const pink = Color(0xFFFF20C0);

    InputDecoration fieldDecoration(String hint, IconData icon, {Widget? suffix}) {
      return InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFFD2C5D8), fontSize: 15),
        prefixIcon: Icon(icon, color: Colors.white, size: 22),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFF190B22).withValues(alpha: .92),
        contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(28),
          borderSide: const BorderSide(color: Color(0xFF59335F), width: 1.4),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(28),
          borderSide: const BorderSide(color: gold, width: 1.6),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF050208),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment(0, -.35),
                    radius: 1.1,
                    colors: [Color(0xFF21052B), Color(0xFF09030E), Color(0xFF030106)],
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(8, 5, 8, 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: purple.withValues(alpha: .9), width: 2),
                    boxShadow: [
                      BoxShadow(color: purple.withValues(alpha: .42), blurRadius: 18, spreadRadius: 2),
                      BoxShadow(color: pink.withValues(alpha: .2), blurRadius: 30, spreadRadius: 1),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(top: 120, left: 22, child: _neonHeart(34)),
            Positioned(top: 82, right: 32, child: _neonHeart(25)),
            Positioned(
              top: compact ? 4 : 12,
              left: 18,
              right: 18,
              bottom: 8,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 460),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(height: compact ? 5 : 12),
                      SizedBox(
                        height: compact ? 205 : 235,
                        child: Image.asset(
                          'assets/icon/lovemix.png',
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const Icon(Icons.favorite, color: gold, size: 120),
                        ),
                      ),
                      const SizedBox(height: 2),
                      const Text(
                        'Bem-vindo de volta!',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Entre para continuar',
                        style: TextStyle(color: Color(0xFFD8C9DE), fontSize: 15),
                      ),
                      SizedBox(height: compact ? 17 : 24),
                      TextField(
                        controller: email,
                        keyboardType: TextInputType.emailAddress,
                        autofillHints: const [AutofillHints.email],
                        style: const TextStyle(color: Colors.white),
                        decoration: fieldDecoration('Seu e-mail', Icons.email_outlined),
                      ),
                      const SizedBox(height: 9),
                      TextField(
                        controller: password,
                        obscureText: obscurePassword,
                        autofillHints: const [AutofillHints.password],
                        style: const TextStyle(color: Colors.white),
                        decoration: fieldDecoration(
                          'Sua senha',
                          Icons.lock_outline,
                          suffix: IconButton(
                            onPressed: () => setState(() => obscurePassword = !obscurePassword),
                            icon: Icon(obscurePassword ? Icons.visibility_off : Icons.visibility, color: Colors.white70),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [Color(0xFFFFE56A), Color(0xFFFFB600), Color(0xFF9D5700)]),
                            borderRadius: BorderRadius.circular(30),
                            boxShadow: [BoxShadow(color: gold.withValues(alpha: .55), blurRadius: 17, spreadRadius: 1)],
                          ),
                          child: ElevatedButton(
                            onPressed: busy ? null : () async {
                              setState(() => busy = true);
                              await submit();
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              foregroundColor: const Color(0xFF271300),
                              shape: const StadiumBorder(),
                            ),
                            child: busy
                                ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF271300)))
                                : const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Spacer(),
                                      Text('Entrar', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                                      Spacer(),
                                      Padding(padding: EdgeInsets.only(right: 13), child: Icon(Icons.arrow_forward, size: 27)),
                                    ],
                                  ),
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: busy ? null : () async {
                          if (email.text.trim().isEmpty) return show('Digite seu e-mail primeiro.');
                          try {
                            await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
                            show('Enviamos um link de recuperação para seu e-mail.');
                          } on FirebaseAuthException catch (e) { show(_authError(e)); }
                        },
                        child: const Text('Esqueceu sua senha?', style: TextStyle(color: Color(0xFFE34BFF), fontWeight: FontWeight.bold, decoration: TextDecoration.underline)),
                      ),
                      Row(
                        children: [
                          const Expanded(child: Divider(color: Color(0xFF806A83))),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Text('ou', style: TextStyle(color: Colors.white.withValues(alpha: .9), fontSize: 16)),
                          ),
                          const Expanded(child: Divider(color: Color(0xFF806A83))),
                        ],
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        height: 47,
                        child: ElevatedButton.icon(
                          onPressed: busy ? null : signInGoogle,
                          icon: const Text('G', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Color(0xFF4285F4))),
                          label: const Text('Entrar com Google', style: TextStyle(color: Color(0xFF171321), fontSize: 16, fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.white, shape: const StadiumBorder()),
                        ),
                      ),
                      const SizedBox(height: 13),
                      SizedBox(
                        width: double.infinity,
                        height: 47,
                        child: OutlinedButton(
                          onPressed: busy ? null : () => _openEmailForm(createAccount: true),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFFFFA8F1),
                            side: const BorderSide(color: Color(0xFFB000FF), width: 1.6),
                            shape: const StadiumBorder(),
                          ),
                          child: const Text('Criar uma conta', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(height: 9),
                      SizedBox(
                        width: double.infinity,
                        height: 45,
                        child: TextButton.icon(
                          onPressed: busy ? null : signInGuest,
                          icon: const Icon(Icons.person_pin_circle_outlined, color: Color(0xFFE34BFF)),
                          label: const Text('Entrar como convidado', style: TextStyle(color: Color(0xFFECA7FF), fontSize: 15, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text('Acesso exclusivo para maiores de 18 anos', style: TextStyle(color: Colors.white38, fontSize: 11)),
                    ],
                  ),
                ),
              ),
            ),
            if (busy)
              const Positioned(
                top: 8,
                right: 18,
                child: SizedBox(height: 16, width: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFC928))),
              ),
          ],
        ),
      ),
    );
  }

  Widget _neonHeart(double size) {
    return Icon(
      Icons.favorite_border_rounded,
      size: size,
      color: const Color(0xFFFF20C0),
      shadows: [
        Shadow(color: const Color(0xFFFF20C0).withValues(alpha: .9), blurRadius: 14),
        Shadow(color: const Color(0xFF9B28FF).withValues(alpha: .7), blurRadius: 22),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    // Tela inicial preta e dourada do LoveMix; cadastro por e-mail abre em formulário modal.
    return _buildLanding(context);
  }
}
