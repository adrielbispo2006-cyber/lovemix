import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'profile_view_screen.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});
  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  static const _bg = Color(0xFF08040D);
  static const _panel = Color(0xFF160B20);
  static const _purple = Color(0xFFB52CFF);
  static const _pink = Color(0xFFFF35C8);
  static const _gold = Color(0xFFFFD36A);
  final _search = TextEditingController();
  int _tab = 0;
  Set<String> _hiddenOnlineIds = <String>{};

  @override
  void initState() {
    super.initState();
    _loadHiddenOnlinePeople();
  }

  Future<void> _loadHiddenOnlinePeople() async {
    final hidden = await DataService.instance.hiddenOnlinePeople();
    if (mounted) setState(() => _hiddenOnlineIds = hidden);
  }

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _openPerson(String id, String name) async {
    try {
      final chatId = await DataService.instance.openDirectChat(id);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: chatId, otherName: name)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível abrir a conversa: $e')));
    }
  }

  Future<void> _hideConversation(String chatId, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('Apagar conversa?', style: TextStyle(color: Colors.white)),
        content: Text('A conversa com $name será removida somente da sua lista. A outra pessoa continuará vendo o histórico.', style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar', style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await DataService.instance.hideChatForMe(chatId);
      await _loadHiddenOnlinePeople();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Conversa apagada e pessoa removida do Online desta conta.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar a conversa: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(children: [
          _header(),
          _stories(),
          _categoryFilters(),
          _searchBar(),
          Expanded(child: _conversations()),
        ]),
      ),
    );
  }

  Widget _header() => Container(
    padding: const EdgeInsets.fromLTRB(16, 9, 14, 12),
    decoration: BoxDecoration(
      border: Border(bottom: BorderSide(color: _purple.withOpacity(.22))),
      gradient: LinearGradient(colors: [_purple.withOpacity(.10), _bg, _gold.withOpacity(.035)]),
    ),
    child: Row(children: [
      Container(
        width: 54, height: 54,
        decoration: BoxDecoration(shape: BoxShape.circle, color: _purple.withOpacity(.14),
          boxShadow: [BoxShadow(color: _pink.withOpacity(.35), blurRadius: 18)]),
        child: const Stack(alignment: Alignment.center, children: [
          Icon(Icons.favorite, color: _gold, size: 43),
          Icon(Icons.favorite, color: _pink, size: 25),
          Positioned(top: 0, child: Icon(Icons.workspace_premium, color: _gold, size: 19)),
        ]),
      ),
      const SizedBox(width: 10),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('LoveMix', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: -.8)),
        Text('Conecte • Converse • Faça Amigos 💜', maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(color: Color(0xFFE1CDEB), fontSize: 11, fontWeight: FontWeight.w500)),
      ])),
      _headerAction(Icons.workspace_premium, 'VIP', () => setState(() => _tab = 4), gold: true),
      _headerAction(Icons.notifications_none, null, () => ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Suas notificações aparecem na área de notificações do LoveMix.'))), badge: '•'),
      _headerAction(Icons.person_add_alt_1, null, () => setState(() => _tab = 1)),
    ]),
  );

  Widget _headerAction(IconData icon, String? label, VoidCallback onTap, {bool gold = false, String? badge}) =>
    Padding(padding: const EdgeInsets.only(left: 7), child: InkWell(
      onTap: onTap, borderRadius: BorderRadius.circular(30),
      child: Container(width: 48, height: 48,
        decoration: BoxDecoration(shape: BoxShape.circle, color: _panel,
          border: Border.all(color: gold ? _gold : _purple.withOpacity(.75), width: 1.3),
          boxShadow: [BoxShadow(color: (gold ? _gold : _purple).withOpacity(.18), blurRadius: 10)]),
        child: Stack(alignment: Alignment.center, children: [
          Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: gold ? _gold : const Color(0xFFE8C9FF), size: 22),
            if (label != null) Text(label, style: TextStyle(color: gold ? _gold : Colors.white, fontSize: 9, fontWeight: FontWeight.w900)),
          ]),
          if (badge != null) Positioned(right: 5, top: 3, child: Container(width: 9, height: 9,
            decoration: const BoxDecoration(color: _pink, shape: BoxShape.circle))),
        ]),
      ),
    ));

  Widget _stories() => SizedBox(
    height: 154,
    child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').where('isOnline', isEqualTo: true).limit(25).snapshots(),
      builder: (context, snap) {
        final people = (snap.data?.docs ?? []).where((d) {
          final p = d.data(); final name = (p['name'] ?? '').toString().trim();
          final photo = (p['photoUrl'] ?? '').toString().trim();
          final deleted = p['isDeleted'] == true || p['accountDeleted'] == true || p['deletedAt'] != null;
          return d.id != DataService.instance.uid && !_hiddenOnlineIds.contains(d.id) &&
            p['isActive'] != false && !deleted && name.isNotEmpty && !(name.toLowerCase() == 'pessoa' && photo.isEmpty);
        }).toList();
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: const EdgeInsets.fromLTRB(18, 9, 16, 2), child: Row(children: [
            const Icon(Icons.play_circle_fill, color: _pink, size: 20), const SizedBox(width: 8),
            const Text('Stories', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
            const Spacer(), TextButton(onPressed: () => setState(() => _tab = 1), child: const Text('Ver todos ›', style: TextStyle(color: Color(0xFFD7A9F5), fontSize: 12))),
          ])),
          Expanded(child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              _storyTile(label: 'Seu Story', add: true, onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Publique um story pela área de Início.')))),
              ...people.map((d) { final p=d.data(); return _storyTile(label: (p['name'] ?? 'Pessoa').toString(),
                photo: (p['photoUrl'] ?? '').toString(), online: true, live: p['isLive'] == true,
                onTap: () => _openPerson(d.id, (p['name'] ?? 'Pessoa').toString())); }),
              _storyTile(label: 'Amigos', crown: true, onTap: () => setState(() => _tab = 1)),
            ],
          )),
        ]);
      },
    ),
  );

  Widget _storyTile({required String label, String? photo, bool add = false, bool online = false, bool live = false, bool crown = false, required VoidCallback onTap}) =>
    SizedBox(width: 86, child: InkWell(onTap: onTap, child: Column(children: [
      Stack(clipBehavior: Clip.none, children: [
        Container(width: 76, height: 76, padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(shape: BoxShape.circle,
            border: Border.all(color: live ? _pink : _purple, width: live ? 3 : 2.5),
            boxShadow: [BoxShadow(color: (live ? _pink : _purple).withOpacity(.38), blurRadius: live ? 14 : 10)]),
          child: CircleAvatar(backgroundColor: _panel, backgroundImage: (photo != null && photo.isNotEmpty) ? NetworkImage(photo) : null,
            child: crown ? const Icon(Icons.workspace_premium, color: _gold, size: 35) : (add ? const Icon(Icons.add, color: Colors.white, size: 39) : ((photo == null || photo.isEmpty) ? const Icon(Icons.person, color: Colors.white70, size: 32) : null))),
        ),
        if (live) Positioned(right: -1, top: -1, child: Container(width: 16, height: 16,
          decoration: BoxDecoration(color: _pink, shape: BoxShape.circle, border: Border.all(color: _panel, width: 2)))),
      ]),
      if (live) const Padding(padding: EdgeInsets.only(top: 3), child: Text('AO VIVO', style: TextStyle(color: _pink, fontSize: 9, fontWeight: FontWeight.w900))),
      if (online && !live) const Padding(padding: EdgeInsets.only(top: 3), child: Text('Online', style: TextStyle(color: Color(0xFF35E879), fontSize: 9, fontWeight: FontWeight.w700))),
      if (!online) const SizedBox(height: 12),
      Padding(padding: const EdgeInsets.only(top: 2), child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600))),
    ])));

  Widget _categoryFilters() => SingleChildScrollView(scrollDirection: Axis.horizontal,
    padding: const EdgeInsets.fromLTRB(12, 5, 12, 8), child: Row(children: [
      _pill('Todos', 0, Icons.forum), _pill('Online', 1, Icons.people_alt),
      _pill('Não lidas', 2, Icons.mark_email_unread), _pill('Favoritos', 3, Icons.star),
    ]));

  Widget _pill(String label, int value, IconData icon) => Padding(padding: const EdgeInsets.only(right: 7), child: InkWell(
    onTap: () => setState(() => _tab = value), borderRadius: BorderRadius.circular(24),
    child: AnimatedContainer(duration: const Duration(milliseconds: 180), padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), color: _tab == value ? _purple.withOpacity(.34) : _panel,
        border: Border.all(color: _tab == value ? _pink : _purple.withOpacity(.38)),
        boxShadow: _tab == value ? [BoxShadow(color: _pink.withOpacity(.25), blurRadius: 12)] : []),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 17, color: _tab == value ? _pink : const Color(0xFFDCC8EA)),
        const SizedBox(width: 6), Text(label, style: TextStyle(color: _tab == value ? Colors.white : const Color(0xFFDCC8EA), fontSize: 12, fontWeight: FontWeight.w800))]),
    ),
  ));

  Widget _searchBar() => Padding(padding: const EdgeInsets.fromLTRB(14, 2, 14, 8), child: Row(children: [
    Expanded(child: Container(height: 46, decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(28), border: Border.all(color: _purple.withOpacity(.7))),
      child: TextField(controller: _search, onChanged: (_) => setState(() {}), style: const TextStyle(color: Colors.white, fontSize: 14),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search, color: Color(0xFFDDBBFA)), hintText: 'Buscar conversas...', hintStyle: TextStyle(color: Colors.white54, fontSize: 13), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(vertical: 12))))),
    const SizedBox(width: 8), InkWell(onTap: () => showModalBottomSheet(context: context, backgroundColor: _panel,
      builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Filtrar conversas', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12), ListTile(leading: const Icon(Icons.people, color: _pink), title: const Text('Online', style: TextStyle(color: Colors.white)), onTap: () { Navigator.pop(ctx); setState(() => _tab = 1); }),
        ListTile(leading: const Icon(Icons.mark_email_unread, color: _pink), title: const Text('Não lidas', style: TextStyle(color: Colors.white)), onTap: () { Navigator.pop(ctx); setState(() => _tab = 2); }),
        ListTile(leading: const Icon(Icons.star, color: _gold), title: const Text('Favoritos', style: TextStyle(color: Colors.white)), onTap: () { Navigator.pop(ctx); setState(() => _tab = 3); }),
        ListTile(leading: const Icon(Icons.workspace_premium, color: _gold), title: const Text('VIPs', style: TextStyle(color: Colors.white)), onTap: () { Navigator.pop(ctx); setState(() => _tab = 4); }),
      ])))), borderRadius: BorderRadius.circular(30), child: Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, color: _panel, border: Border.all(color: _purple)), child: const Icon(Icons.tune, color: Color(0xFFE5C5FF)))),
  ]));

  int unreadCount(Map<String, dynamic> data, String uid) { final m = data['unreadCounts']; return m is Map && m[uid] is num ? (m[uid] as num).toInt() : 0; }

  Widget _conversations() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: DataService.instance.myChats(),
    builder: (context, snap) {
      if (snap.hasError) return const Center(child: Text('Não foi possível carregar as conversas.', style: TextStyle(color: Colors.white70)));
      if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: _pink));
      final chats = [...snap.data!.docs]
        ..removeWhere((doc) => List<String>.from(doc.data()['hiddenFor'] ?? const []).contains(DataService.instance.uid))
        ..sort((a, b) {
        final at = a.data()['lastMessageAt']; final bt = b.data()['lastMessageAt'];
        final am = at is Timestamp ? at.millisecondsSinceEpoch : 0; final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
        return bm.compareTo(am);
      });
      if (chats.isEmpty) return _empty();
      return ListView.builder(padding: const EdgeInsets.fromLTRB(12, 12, 12, 18), itemCount: chats.length, itemBuilder: (context, i) {
        final chat = chats[i]; final data = chat.data(); final users = List<String>.from(data['users'] ?? const []);
        final other = users.firstWhere((id) => id != DataService.instance.uid, orElse: () => '');
        if (other.isEmpty) return const SizedBox.shrink();
        return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('users').doc(other).snapshots(),
          builder: (context, userSnap) {
            final p = userSnap.data?.data() ?? <String, dynamic>{};
            if (!userSnap.hasData || !userSnap.data!.exists || p['isActive'] == false) return const SizedBox.shrink();
            final name = (p['name'] ?? 'Novo match').toString(); final photo = (p['photoUrl'] ?? '').toString();
            if (_search.text.trim().isNotEmpty && !name.toLowerCase().contains(_search.text.trim().toLowerCase())) return const SizedBox.shrink();
            if (_tab == 1 && p['isOnline'] != true) return const SizedBox.shrink();
            if (_tab == 2 && unreadCount(data, DataService.instance.uid) == 0) return const SizedBox.shrink();
            if (_tab == 3 && data['isFavorite'] != true && p['isFavorite'] != true) return const SizedBox.shrink();
            if (_tab == 4 && p['isVip'] != true) return const SizedBox.shrink();
            final online = p['isOnline'] == true; final live = p['isLive'] == true; final vip = p['isVip'] == true; final verified = p['isVerified'] == true;
            final preview = (data['lastMessage'] ?? 'Comece uma conversa 💜').toString();
            final stamp = data['lastMessageAt'];
            final time = stamp is Timestamp ? _formatTime(stamp.toDate()) : '';
            final unreadMap = data['unreadCounts']; final unread = unreadMap is Map ? (unreadMap[DataService.instance.uid] is num ? (unreadMap[DataService.instance.uid] as num).toInt() : 0) : 0;
            return Container(margin: const EdgeInsets.only(bottom: 10), decoration: BoxDecoration(color: _panel.withOpacity(.82), borderRadius: BorderRadius.circular(25), border: Border.all(color: live ? _pink.withOpacity(.95) : (vip ? _gold.withOpacity(.9) : _purple.withOpacity(.45)), width: live ? 1.7 : (vip ? 1.5 : 1)), boxShadow: [BoxShadow(color: (vip ? _gold : _purple).withOpacity(vip ? .20 : .09), blurRadius: vip ? 15 : 12)]), child: InkWell(borderRadius: BorderRadius.circular(25), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: chat.id, otherName: name))), child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
              GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: other))), child: Stack(clipBehavior: Clip.none, children: [Container(padding: const EdgeInsets.all(2), decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: live ? _pink : (vip ? _gold : _purple), width: live ? 3 : 2), boxShadow: [BoxShadow(color: (vip ? _gold : _pink).withOpacity(.25), blurRadius: 9)]), child: CircleAvatar(radius: 35, backgroundColor: const Color(0xFF321846), backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null, child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white70, size: 30) : null)), Positioned(right: 0, bottom: 1, child: Container(width: 17, height: 17, decoration: BoxDecoration(color: live ? _pink : (online ? const Color(0xFF20E65A) : Colors.white24), shape: BoxShape.circle, border: Border.all(color: _panel, width: 2))))])),
              const SizedBox(width: 13), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Flexible(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))), if (vip) ...[const SizedBox(width: 4), const Icon(Icons.workspace_premium, color: _gold, size: 17)], if (verified) ...[const SizedBox(width: 4), const Icon(Icons.verified, color: Color(0xFF438BFF), size: 18)]],), const SizedBox(height: 6), Text(preview, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFD4B9E1), fontSize: 14)), if (live) const Padding(padding: EdgeInsets.only(top: 4), child: Text('AO VIVO agora', style: TextStyle(color: _pink, fontSize: 10, fontWeight: FontWeight.w900))) else if (online) const Padding(padding: EdgeInsets.only(top: 4), child: Text('Online agora', style: TextStyle(color: Color(0xFF39E878), fontSize: 10)))])),
              const SizedBox(width: 5), Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(time, style: const TextStyle(color: Color(0xFFC9A6DC), fontSize: 11)),
                const SizedBox(height: 3),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  if (unread > 0) Container(width: 25, height: 25, alignment: Alignment.center, decoration: const BoxDecoration(color: _pink, shape: BoxShape.circle, boxShadow: [BoxShadow(color: _pink, blurRadius: 9)]), child: Text('$unread', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
                  PopupMenuButton<String>(
                    tooltip: 'Opções da conversa',
                    color: _panel,
                    icon: const Icon(Icons.more_vert, color: Color(0xFFD8B5E8)),
                    onSelected: (value) { if (value == 'delete') _hideConversation(chat.id, name); },
                    itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete_outline, color: Colors.redAccent), SizedBox(width: 8), Text('Apagar conversa', style: TextStyle(color: Colors.white))]))],
                  ),
                ]),
              ]),
            ]))));
          },
        );
      });
    },
  );

  Widget _empty() => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.forum_outlined, color: _purple.withOpacity(.8), size: 55), const SizedBox(height: 12), const Text('Suas conversas aparecerão aqui', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)), const SizedBox(height: 7), const Text('Toque em uma pessoa online para abrir uma conversa e enviar sua primeira mensagem.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, height: 1.4))])));

  String _formatTime(DateTime date) { final now = DateTime.now(); if (now.difference(date).inDays == 0) return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}'; return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}'; }
}
