import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/gift_catalog.dart';
import '../services/data_service.dart';

const _pink = Color(0xFFFF2DAB);
const _purple = Color(0xFF8B35FF);
const _gold = Color(0xFFFFD45C);
const _bg = Color(0xFF080510);
const _panel = Color(0xFF1B1028);

class LoveMixExtrasScreen extends StatelessWidget {
  const LoveMixExtrasScreen({super.key, this.initialTab = 0});
  final int initialTab;
  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 2,
    initialIndex: initialTab.clamp(0, 1),
    child: Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        title: const Text('LoveMix ✨', style: TextStyle(fontWeight: FontWeight.w900, color: _pink)),
        bottom: const TabBar(
          indicatorColor: _pink,
          labelColor: _pink,
          unselectedLabelColor: Colors.white60,
          tabs: [Tab(icon: Icon(Icons.favorite), text: 'Alianças'), Tab(icon: Icon(Icons.task_alt), text: 'Missões')],
        ),
      ),
      body: const TabBarView(children: [_AllianceRingStoreTab(), _DailyMissionsTab()]),
    ),
  );
}

class _AllianceRingStoreTab extends StatefulWidget {
  const _AllianceRingStoreTab();
  @override
  State<_AllianceRingStoreTab> createState() => _AllianceRingStoreTabState();
}

class _AllianceRingStoreTabState extends State<_AllianceRingStoreTab> {
  final _publicId = TextEditingController();
  String? _sendingId;
  @override
  void dispose() { _publicId.dispose(); super.dispose(); }

  Future<void> _sendRing(Map<String, dynamic> ring) async {
    final id = _publicId.text.trim().toUpperCase();
    if (id.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Digite o ID público da pessoa que vai receber.')));
      return;
    }
    setState(() => _sendingId = ring['id'].toString());
    try {
      final found = await DataService.instance.findUserByPublicId(id);
      if (found.docs.isEmpty) throw Exception('Não encontramos esse perfil público.');
      final recipient = found.docs.first;
      if (recipient.id == DataService.instance.uid) throw Exception('Você não pode enviar uma aliança para si mesmo.');
      final chatId = await DataService.instance.openDirectChat(recipient.id);
      await DataService.instance.sendDirectGift(chatId: chatId, recipientUid: recipient.id, giftId: ring['id'].toString());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${ring['name']} enviada no PV de ${(recipient.data()['name'] ?? 'seu par')}! Convite de casal enviado para o Mural de Aliança. 💍')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => _sendingId = null); }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: DataService.instance.myProfile(),
    builder: (context, snap) {
      final profile = snap.data?.data() ?? <String, dynamic>{};
      return ListView(padding: const EdgeInsets.all(14), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF301044), Color(0xFF160B20), Color(0xFF321047)]),
          borderRadius: BorderRadius.circular(20), border: Border.all(color: _purple.withOpacity(.8), width: 1.3)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('💍 Alianças LoveMix', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _pink)),
            SizedBox(height: 6), Text('Envie a aliança no PV e convide a pessoa para formar um casal. Ela poderá aceitar no Mural de Aliança.', style: TextStyle(color: Colors.white70)),
          ])),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: _purple.withOpacity(.65))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Seu saldo: ${profile['coins'] ?? 0} 🪙   ${profile['diamonds'] ?? 0} 💎', style: const TextStyle(color: _gold, fontWeight: FontWeight.w900)),
          const SizedBox(height: 9),
          TextField(controller: _publicId, textCapitalization: TextCapitalization.characters, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'ID público do seu par', hintText: 'Ex.: A7K2Q9X4', prefixIcon: Icon(Icons.person_search))),
          const SizedBox(height: 5), const Text('Digite o ID curto da pessoa. Ela precisa ter perfil público e você precisa segui-la para abrir o PV.', style: TextStyle(color: Colors.white54, fontSize: 11)),
        ])),
        const SizedBox(height: 18),
        const Center(child: Text('♡  ESCOLHA SUA ALIANÇA  ♡', textAlign: TextAlign.center, style: TextStyle(color: _pink, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1))),
        const SizedBox(height: 12),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: kAllianceRings.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 12, childAspectRatio: .76),
          itemBuilder: (context, i) {
            final ring = kAllianceRings[i];
            final busy = _sendingId == ring['id'];
            final asset = ring['asset']?.toString();
            return Container(padding: const EdgeInsets.fromLTRB(9, 9, 9, 10), decoration: BoxDecoration(
              color: const Color(0xFF180E22), borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _purple.withOpacity(.75), width: 1.2),
              boxShadow: [BoxShadow(color: _purple.withOpacity(.10), blurRadius: 12, spreadRadius: 1)]),
              child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Expanded(child: asset != null
                  ? Image.asset(asset, fit: BoxFit.contain, errorBuilder: (_, __, ___) => Center(child: Text(ring['emoji'].toString(), style: const TextStyle(fontSize: 58))))
                  : Center(child: Text(ring['emoji'].toString(), style: const TextStyle(fontSize: 58)))),
                const SizedBox(height: 3),
                Text(ring['name'].toString(), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Colors.white)),
                const SizedBox(height: 5),
                Text('${ring['cost']}  ${ring['currency'] == 'diamonds' ? '💎' : '🪙'}', style: const TextStyle(color: _gold, fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                SizedBox(width: double.infinity, height: 43, child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white, disabledBackgroundColor: _pink.withOpacity(.45), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), padding: const EdgeInsets.symmetric(horizontal: 5)),
                  onPressed: _sendingId != null ? null : () => _sendRing(ring),
                  icon: busy ? const SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send_rounded, size: 17),
                  label: Text(busy ? 'Enviando' : 'Enviar al PV', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                )),
              ]));
          }),
      ]);
    },
  );
}


class _DailyMissionsTab extends StatefulWidget {
  const _DailyMissionsTab();
  @override
  State<_DailyMissionsTab> createState() => _DailyMissionsTabState();
}

class _DailyMissionsTabState extends State<_DailyMissionsTab> {
  static const _tasks = [
    ('room', 'Entre em uma sala', 'Conheça as conversas da comunidade', Icons.graphic_eq),
    ('gift', 'Envie um presente', 'Demonstre carinho a alguém', Icons.card_giftcard),
    ('chat', 'Converse com alguém', 'Mande uma mensagem no chat', Icons.chat_bubble),
    ('profile', 'Visite seu perfil', 'Confira suas personalizações', Icons.person),
  ];
  bool _loading = true;
  bool _claimed = false;
  int _points = 0;
  Set<String> _done = {};

  String get _dayKey {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final day = prefs.getString('lovemix_missions_day') ?? '';
    if (day != _dayKey) {
      await prefs.setString('lovemix_missions_day', _dayKey);
      await prefs.setStringList('lovemix_missions_done', []);
      await prefs.setBool('lovemix_missions_claimed', false);
    }
    if (!mounted) return;
    setState(() {
      _done = (prefs.getStringList('lovemix_missions_done') ?? []).toSet();
      _claimed = prefs.getBool('lovemix_missions_claimed') ?? false;
      _points = prefs.getInt('lovemix_mission_points') ?? 0;
      _loading = false;
    });
  }

  Future<void> _toggle(String id, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() { value ? _done.add(id) : _done.remove(id); });
    await prefs.setStringList('lovemix_missions_done', _done.toList());
  }

  Future<void> _claim() async {
    if (_done.length != _tasks.length || _claimed) return;
    final prefs = await SharedPreferences.getInstance();
    final points = _points + 50;
    await prefs.setBool('lovemix_missions_claimed', true);
    await prefs.setInt('lovemix_mission_points', points);
    if (!mounted) return;
    setState(() { _claimed = true; _points = points; });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Você recebeu 50 pontos de missão!'),
      backgroundColor: Color(0xFF6B3B91),
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _pink));
    final allDone = _done.length == _tasks.length;
    return ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 24), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF541078), Color(0xFF241035), Color(0xFF4A173F)]),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _gold.withOpacity(.7)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('RECOMPENSA DIÁRIA', style: TextStyle(color: _gold, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 14),
          const Text('🎁  +50 pontos de missão', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('Pontos acumulados neste aparelho: $_points', style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 18),
          SizedBox(width: double.infinity, height: 48, child: ElevatedButton.icon(
            onPressed: allDone && !_claimed ? _claim : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: _claimed ? const Color(0xFF5B3A69) : _pink,
              disabledBackgroundColor: const Color(0xFF5B3A69),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: Icon(_claimed ? Icons.check_circle : Icons.card_giftcard),
            label: Text(_claimed ? 'RECOMPENSA DE HOJE RESGATADA' : 'RESGATAR 50 PONTOS',
              style: const TextStyle(fontWeight: FontWeight.w900)),
          )),
        ]),
      ),
      const SizedBox(height: 26),
      const Text('MISSÕES DO DIA', style: TextStyle(color: _pink, fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 12),
      ..._tasks.map((task) {
        final done = _done.contains(task.$1);
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF1B1028),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _gold.withOpacity(.65), width: 1.2),
          ),
          child: CheckboxListTile(
            value: done,
            onChanged: _claimed ? null : (v) => _toggle(task.$1, v ?? false),
            activeColor: _gold,
            checkColor: const Color(0xFF241333),
            controlAffinity: ListTileControlAffinity.trailing,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            secondary: CircleAvatar(
              backgroundColor: const Color(0xFF42166A),
              child: Icon(task.$4, color: _pink),
            ),
            title: Text(task.$2, style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.white, fontSize: 16)),
            subtitle: Text(task.$3, style: const TextStyle(color: Colors.white60, fontSize: 13)),
          ),
        );
      }),
      const SizedBox(height: 8),
      const Text('Marque as atividades concluídas para ganhar pontos de missão. Os pontos ficam salvos localmente neste aparelho e não são moedas nem diamantes da conta.',
        style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]);
  }
}

class VipRoomBanner extends StatefulWidget {
  const VipRoomBanner({super.key});
  @override
  State<VipRoomBanner> createState() => _VipRoomBannerState();
}
class _VipRoomBannerState extends State<VipRoomBanner> with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  @override
  void initState() { super.initState(); _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..repeat(reverse: true); }
  @override
  void dispose() { _pulse.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: _pulse, builder: (context, _) {
    final glow = 8.0 + _pulse.value * 13.0;
    return Container(margin: const EdgeInsets.fromLTRB(14, 5, 14, 7), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF6B3B00), Color(0xFF2B1640), Color(0xFF7A145C)]), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFFFD45C), width: 1.2), boxShadow: [BoxShadow(color: const Color(0xFFFFD45C).withOpacity(.16 + _pulse.value * .2), blurRadius: glow)]), child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.workspace_premium, color: Color(0xFFFFD45C), size: 18), SizedBox(width: 8), Text('SALA VIP LOVE MIX • EFEITOS ESPECIAIS', style: TextStyle(color: Color(0xFFFFE8A3), fontWeight: FontWeight.w900, fontSize: 11, letterSpacing: .5))]));
  });
}

Future<void> showRoomMiniGames(BuildContext context, {required String roomId}) async {
  const games = <String, List<String>>{
    'Verdade ou desafio': ['Qual foi sua primeira impressão de alguém desta sala?', 'Conte uma coisa engraçada que já aconteceu com você.', 'Faça um elogio sincero a alguém da sala.', 'Qual música combina com seu momento atual?', 'Conte um sonho que ainda quer realizar.'],
    'Quiz relâmpago': ['Qual é o maior planeta do Sistema Solar? • Júpiter', 'Quantos lados tem um hexágono? • Seis', 'Qual é a capital do Japão? • Tóquio', 'Quanto é 9 × 7? • 63', 'Qual animal é conhecido como rei da selva? • Leão'],
    'Complete a frase': ['Amizade de verdade é...', 'Meu lugar favorito seria...', 'Uma coisa que sempre me faz sorrir é...', 'Se eu pudesse viajar agora, iria para...'],
  };
  String selected = games.keys.first;
  String prompt = games[selected]!.first;
  await showModalBottomSheet<void>(context: context, isScrollControlled: true, backgroundColor: _panel, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))), builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(padding: EdgeInsets.fromLTRB(18, 20, 18, MediaQuery.of(ctx).viewInsets.bottom + 24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('🎮 Jogos da sala', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: _pink)),
    const SizedBox(height: 12), DropdownButtonFormField<String>(value: selected, decoration: const InputDecoration(labelText: 'Escolha um jogo'), items: games.keys.map((k) => DropdownMenuItem(value: k, child: Text(k))).toList(), onChanged: (v) { if (v != null) setSheet(() { selected = v; prompt = games[v]!.first; }); }),
    const SizedBox(height: 16), Container(width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFF10091A), borderRadius: BorderRadius.circular(16), border: Border.all(color: _purple)), child: Text(prompt, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
    const SizedBox(height: 14), SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: () async { final list = games[selected]!; final next = list[Random().nextInt(list.length)]; setSheet(() { prompt = next; }); try { await DataService.instance.sendRoomMessage(roomId, '🎮 $selected: $next'); } catch (_) {} }, icon: const Icon(Icons.casino), label: const Text('Sortear e compartilhar na sala'))),
  ]))));
}
