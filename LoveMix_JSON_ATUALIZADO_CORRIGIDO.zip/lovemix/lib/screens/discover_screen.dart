import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'profile_view_screen.dart';
import 'alliance_wall_screen.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';

const _gold = Color(0xFFFF2DAB);
const _panel = Color(0xFF171022);

/// Tela de descoberta com visual familiar de aplicativo de namoro:
/// cartões de perfil com foto, localização e ações.
class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});
  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  String tab = 'Descobrir';
  final Set<String> _passedUserIds = <String>{};

  @override
  void initState() {
    super.initState();
    DataService.instance.ensurePublicId().catchError((_) {});
    _loadPassedUsers();
  }

  Future<void> _loadPassedUsers() async {
    try {
      final ids = await DataService.instance.getPassedUserIds();
      if (mounted) setState(() => _passedUserIds.addAll(ids));
    } catch (_) {
      // A lista continua utilizável; o erro será tratado ao dispensar alguém.
    }
  }

  Future<void> _passUser(String userId) async {
    if (_passedUserIds.contains(userId)) return;
    try {
      await DataService.instance.pass(userId);
      if (!mounted) return;
      setState(() => _passedUserIds.add(userId));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pessoa removida das suas descobertas.')),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível remover essa pessoa. Tente novamente.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: service.discoverUsers(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Não foi possível carregar pessoas agora.'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator(color: _gold));
        }
        final all = snapshot.data!.docs.where((d) {
          final p = d.data();
          return d.id != service.uid &&
              !_passedUserIds.contains(d.id) &&
              p['isActive'] != false &&
              p['profileVisibility'] != 'private' &&
              p['profileVisibility'] != 'friends';
        }).toList();
        final visible = all.where((d) {
          final p = d.data();
          if (tab == 'Online' && p['isOnline'] != true) return false;
          if (tab == 'Novos' && p['createdAt'] is Timestamp) {
            final created = (p['createdAt'] as Timestamp).toDate();
            if (DateTime.now().difference(created).inDays > 30) return false;
          }
          return true;
        }).toList();
        if (tab == 'Novos') {
          visible.sort((a, b) {
            final ad = a.data()['createdAt']; final bd = b.data()['createdAt'];
            final at = ad is Timestamp ? ad.millisecondsSinceEpoch : 0;
            final bt = bd is Timestamp ? bd.millisecondsSinceEpoch : 0;
            return bt.compareTo(at);
          });
        }

        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(children: [
              Expanded(child: SingleChildScrollView(scrollDirection: Axis.horizontal,
                child: Row(children: [
                  _topTab('Descobrir'), _topTab('Online'), _topTab('Novos'), _topTab('💍 Mural'),
                ]))),
            ]),
          ),
          Expanded(child: tab == '💍 Mural'
            ? const AllianceWallScreen()
            : visible.isEmpty
              ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Nenhuma pessoa encontrada.')))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 18),
                  itemCount: visible.length,
                  itemBuilder: (context, i) => _profileCard(visible[i]),
                )),
        ]);
      },
    );
  }

  Widget _topTab(String label) {
    final selected = tab == label;
    return Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(
      label: Text(label), selected: selected,
      onSelected: (_) => setState(() => tab = label),
      selectedColor: _gold, backgroundColor: _panel,
      labelStyle: TextStyle(color: selected ? Colors.black : Colors.white70, fontWeight: FontWeight.w600),
      side: BorderSide(color: selected ? _gold : Colors.white12),
    ));
  }

  Widget _story(QueryDocumentSnapshot<Map<String, dynamic>>? doc, String name, {bool own = false}) {
    final p = doc?.data() ?? {};
    final photo = (p['photoUrl'] ?? '').toString();
    return GestureDetector(
      onTap: () {
        if (doc != null) Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id)));
        else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Publique uma foto no seu perfil para criar seu story.')));
      },
      child: SizedBox(width: 76, child: Column(children: [
        Container(width: 66, height: 66, padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _gold, width: 2)),
          child: ClipOval(child: photo.isEmpty
            ? Container(color: _panel, child: Icon(own ? Icons.add : Icons.person, color: _gold, size: 30))
            : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                errorWidget: (_, __, ___) => const Icon(Icons.person, color: _gold)))),
        const SizedBox(height: 5),
        VipNickname(name: name, isVip: (p['isVip'] == true || p['nicknameDecorationActive'] == true), styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontSize: 11)),
      ])),
    );
  }

  int _calculateAge(DateTime birthday) {
    final now = DateTime.now();
    var age = now.year - birthday.year;
    if (now.month < birthday.month || (now.month == birthday.month && now.day < birthday.day)) age--;
    return age;
  }

  Widget _profileCard(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final p = doc.data();
    final birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
    final age = birthday == null ? '' : '${_calculateAge(birthday)} anos';
    final photo = (p['photoUrl'] ?? '').toString();
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    final place = city.isEmpty ? country : country.isEmpty ? city :
        (country.toLowerCase() == 'brasil' && city.contains('-') ? city : '$city • $country');
    final bio = (p['bio'] ?? '').toString().trim();

    return Card(
      color: _panel, margin: const EdgeInsets.only(bottom: 18), clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFF5A4823))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id))),
          child: Stack(children: [
            SizedBox(width: double.infinity, height: 430,
              child: photo.isEmpty
                ? Container(color: const Color(0xFF252016), child: const Icon(Icons.person, size: 110, color: Colors.white24))
                : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => Container(color: _panel, child: const Icon(Icons.person, size: 100))),
            ),
            Positioned(right: 14, top: 12, child: ProfileFrameAvatar(
              photoUrl: photo,
              frameId: (p['selectedProfileFrame'] ?? 'classic').toString(),
              size: 48,
            )),
            Positioned(left: 12, top: 12, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(30)),
              child: Row(children: [Icon(Icons.circle, size: 9, color: p['isOnline'] == true ? Colors.greenAccent : Colors.white38), const SizedBox(width: 6), Text(p['isOnline'] == true ? 'Online' : 'Perfil', style: const TextStyle(fontSize: 12))]),
            )),
            Positioned(left: 0, right: 0, bottom: 0, child: Container(
              padding: const EdgeInsets.fromLTRB(16, 42, 16, 14),
              decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87, Colors.black])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(child: VipNickname(name: (p['name'] ?? 'Pessoa').toString(), isVip: (p['isVip'] == true || p['nicknameDecorationActive'] == true), styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
                  if ((p['gender'] ?? '').toString() == 'woman') const Text(' ♀', style: TextStyle(color: _gold, fontSize: 19)),
                  if ((p['gender'] ?? '').toString() == 'man') const Text(' ♂', style: TextStyle(color: _gold, fontSize: 19)),
                ]),
                if (age.isNotEmpty || place.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text([if (age.isNotEmpty) age, if (place.isNotEmpty) place].join(' • '), style: const TextStyle(color: Colors.white70))),
                if (bio.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Text(bio, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white))),
              ]),
            )),
          ]),
        ),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8), child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _actionButton(Icons.close, Colors.white70, () => _passUser(doc.id)),
            _actionButton(Icons.favorite, Colors.pinkAccent, () async {
              try {
                final following = await DataService.instance.toggleFollow(doc.id);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(following ? 'Você começou a seguir 💗' : 'Você deixou de seguir.')));
              } catch (_) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar a curtida.')));
              }
            }, large: true),
            _actionButton(Icons.star, _gold, () async {
              try {
                await DataService.instance.like(doc.id);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Curtida especial enviada!')));
              } catch (_) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar.')));
              }
            }),
          ],
        )),
      ]),
    );
  }

  Widget _actionButton(IconData icon, Color color, VoidCallback onTap, {bool large = false}) =>
      IconButton.filledTonal(
        onPressed: onTap, icon: Icon(icon, color: color, size: large ? 29 : 23),
        style: IconButton.styleFrom(backgroundColor: const Color(0xFF292318), fixedSize: Size(large ? 58 : 48, large ? 58 : 48)),
      );
}
