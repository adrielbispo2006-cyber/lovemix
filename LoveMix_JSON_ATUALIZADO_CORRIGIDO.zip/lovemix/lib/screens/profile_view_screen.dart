import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'gifts_screen.dart';
import 'profile_screen.dart';
import 'post_interactions_screen.dart';
import '../widgets/full_photo.dart';
import '../widgets/vip_nickname.dart';

const _profilePink = Color(0xFFB54CFF);
const _profilePurple = Color(0xFF8B35FF);
const _profileSilver = Color(0xFFD9DCE8);
const _profilePanel = Color(0xFF100D18);

class ProfileViewScreen extends StatefulWidget {
  const ProfileViewScreen({super.key, required this.userId});
  final String userId;

  @override
  State<ProfileViewScreen> createState() => _ProfileViewScreenState();
}

class _ProfileViewScreenState extends State<ProfileViewScreen> {
  late Future<DocumentSnapshot<Map<String, dynamic>>> _profileFuture;
  late Future<bool> _matchFuture;
  int _visitorTab = 0;

  @override
  void initState() {
    super.initState();
    _profileFuture = FirebaseFirestore.instance.collection('users').doc(widget.userId).get();
    _matchFuture = _checkMatch();
  }

  Future<void> _editOwnProfile() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
    if (!mounted) return;
    setState(() {
      _profileFuture = FirebaseFirestore.instance.collection('users').doc(widget.userId).get();
    });
  }

  Future<bool> _checkMatch() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || uid == widget.userId) return false;
    final matches = await FirebaseFirestore.instance.collection('matches')
        .where('users', arrayContains: uid).get();
    return matches.docs.any((d) => List<String>.from(d.data()['users'] ?? []).contains(widget.userId));
  }

  int? _age(DateTime? birthday) {
    if (birthday == null) return null;
    final now = DateTime.now();
    var age = now.year - birthday.year;
    if (now.month < birthday.month || (now.month == birthday.month && now.day < birthday.day)) age--;
    return age;
  }

  String _place(Map<String, dynamic> p) {
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    if (city.isEmpty) return country;
    if (country.isEmpty) return city;
    if (country.toLowerCase() == 'brasil' && city.contains('-')) return city;
    return '$city • $country';
  }

  String _genderSymbol(String gender) => const {
    'woman': '♀', 'man': '♂', 'non_binary': '⚧', 'other': '✦',
  }[gender] ?? '';

  @override
  Widget build(BuildContext context) {
    final currentUid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final isOwner = currentUid == widget.userId;
    return Scaffold(
      backgroundColor: const Color(0xFF05040A),
      appBar: null,
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: _profileFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: _profilePink));
          }
          if (snap.hasError || !snap.hasData || !snap.data!.exists) {
            return const Center(child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Este perfil está indisponível ou é privado.', textAlign: TextAlign.center),
            ));
          }
          final p = snap.data!.data() ?? <String, dynamic>{};
          final cover = (p['profileCoverUrl'] ?? '').toString();
          final photo = cover.isNotEmpty ? cover : (p['photoUrl'] ?? '').toString();
          final birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
          final age = _age(birthday);
          final location = _place(p);
          final gender = (p['gender'] ?? '').toString();
          final genderSymbol = _genderSymbol(gender);
          final interests = List<String>.from(p['interests'] ?? const []);
          final bio = (p['bio'] ?? '').toString().trim();
          final online = p['isOnline'] == true;
          final name = (p['name'] ?? 'Pessoa').toString();

          return FutureBuilder<bool>(
            future: _matchFuture,
            builder: (context, matchSnap) {
              final isMatched = matchSnap.data == true;
              if (!isOwner) {
                return _visitorProfile(
                  context, p, name: name, photo: (p['photoUrl'] ?? '').toString(),
                  cover: cover, age: age, location: location, genderSymbol: genderSymbol,
                  online: online, bio: bio, interests: interests, isMatched: isMatched,
                );
              }
              return _visitorProfile(
                context, p, name: name, photo: (p['photoUrl'] ?? '').toString(),
                cover: cover, age: age, location: location, genderSymbol: genderSymbol,
                online: online, bio: bio, interests: interests, isMatched: true,
                isOwner: true,
              );
            },
          );
        },
      ),
    );
  }


  Widget _visitorProfile(
    BuildContext context,
    Map<String, dynamic> p, {
    required String name,
    required String photo,
    required String cover,
    required int? age,
    required String location,
    required String genderSymbol,
    required bool online,
    required String bio,
    required List<String> interests,
    required bool isMatched,
    bool isOwner = false,
  }) {
    final isVip = p['isVip'] == true;
    final isVerified = p['isVerified'] == true;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Container(
      color: const Color(0xFF05020A),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 28),
        children: [
          Row(children: [
            if (!isOwner)
              IconButton(
                onPressed: () => Navigator.maybePop(context),
                icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
              )
            else
              const SizedBox(width: 42),
            const Spacer(),
            const Icon(Icons.favorite, color: Color(0xFFFF45D2), size: 25),
            const SizedBox(width: 7),
            const Text('LoveMix', style: TextStyle(
              fontSize: 27, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic,
              color: Color(0xFFE7B8FF), shadows: [Shadow(color: _profilePink, blurRadius: 13)],
            )),
            const SizedBox(width: 7),
            const Icon(Icons.workspace_premium, color: Color(0xFFFFD45C), size: 27),
            const Spacer(),
            const Icon(Icons.favorite_border, color: Color(0xFFFF4AD8), size: 27),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              onSelected: (v) {
                if (v == 'report') _report(context);
                if (v == 'block') _block(context);
                if (v == 'edit') _editOwnProfile();
              },
              itemBuilder: (_) => isOwner ? const [
                PopupMenuItem(value: 'edit', child: Text('Editar perfil')),
              ] : const [
                PopupMenuItem(value: 'report', child: Text('Denunciar perfil')),
                PopupMenuItem(value: 'block', child: Text('Bloquear usuário')),
              ],
            ),
          ]),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: _profilePink, width: 1.6),
              boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.42), blurRadius: 24)],
              gradient: const LinearGradient(
                begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFF210A37), Color(0xFF09040F), Color(0xFF160725)],
              ),
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(children: [
              if (cover.isNotEmpty)
                Positioned.fill(child: Opacity(
                  opacity: .22,
                  child: CachedNetworkImage(imageUrl: cover, fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => const SizedBox.shrink()),
                )),
              Positioned(right: -22, top: 20, child: Icon(Icons.favorite, size: 150, color: _profilePink.withOpacity(.10))),
              Positioned(left: 8, top: 55, child: Icon(Icons.auto_awesome, size: 30, color: Colors.purpleAccent.withOpacity(.7))),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 18),
                child: Column(children: [
                  Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
                    Container(
                      width: 204, height: 204,
                      decoration: BoxDecoration(shape: BoxShape.circle,
                        border: Border.all(color: _profilePink, width: 5),
                        boxShadow: [BoxShadow(color: _profilePink.withOpacity(.7), blurRadius: 22),
                          BoxShadow(color: Colors.deepPurpleAccent.withOpacity(.45), blurRadius: 35)],
                      ),
                      padding: const EdgeInsets.all(5),
                      child: ClipOval(
                        child: photo.isEmpty
                          ? const ColoredBox(color: _profilePanel, child: Icon(Icons.person, size: 90, color: Colors.white70))
                          : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                              placeholder: (_, __) => const ColoredBox(color: _profilePanel, child: Center(child: CircularProgressIndicator(color: _profilePink))),
                              errorWidget: (_, __, ___) => const ColoredBox(color: _profilePanel, child: Icon(Icons.person, size: 80, color: Colors.white70))),
                      ),
                    ),
                    Positioned(top: -21, child: Text(isVip ? '👑' : '💜', style: const TextStyle(fontSize: 43, shadows: [Shadow(color: Color(0xFFFFC84A), blurRadius: 12)]))),
                    Positioned(left: -18, child: Icon(Icons.auto_awesome, color: Colors.purpleAccent.withOpacity(.9), size: 36)),
                    Positioned(right: -18, child: Icon(Icons.auto_awesome, color: Colors.pinkAccent.withOpacity(.9), size: 36)),
                    if (isVip) Positioned(bottom: -8, child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                      decoration: BoxDecoration(color: const Color(0xFF170923), borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFFFFD45C), width: 1.5),
                        boxShadow: const [BoxShadow(color: Color(0x99FFC84A), blurRadius: 12)]),
                      child: const Text('👑 VIP', style: TextStyle(color: Color(0xFFFFD45C), fontWeight: FontWeight.w900)),
                    )),
                  ]),
                  const SizedBox(height: 20),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Flexible(child: VipNickname(name: name,
                      isVip: isVip || p['nicknameDecorationActive'] == true,
                      styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(),
                      textStyle: const TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: Colors.white))),
                    if (genderSymbol.isNotEmpty) Text(' $genderSymbol', style: const TextStyle(color: Color(0xFFFF63CE), fontSize: 25)),
                    if (isVerified) const Padding(padding: EdgeInsets.only(left: 7), child: Icon(Icons.verified, color: Color(0xFF269CFF), size: 25)),
                  ]),
                  const SizedBox(height: 7),
                  if (age != null) Text('$age anos', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
                  if (location.isNotEmpty) Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.location_on, color: _profilePink, size: 20),
                      Flexible(child: Text(location, style: const TextStyle(color: Colors.white70, fontSize: 15), textAlign: TextAlign.center)),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(color: const Color(0xFF160D22), borderRadius: BorderRadius.circular(18), border: Border.all(color: online ? Colors.greenAccent : Colors.white24)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.circle, size: 9, color: online ? Colors.greenAccent : Colors.white38),
                      const SizedBox(width: 6),
                      Text(online ? 'Online' : 'Offline', style: TextStyle(color: online ? Colors.greenAccent : Colors.white60, fontSize: 12, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                  if (bio.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    Container(width: double.infinity, padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(.32), borderRadius: BorderRadius.circular(14), border: Border.all(color: _profilePink.withOpacity(.4))),
                      child: Text(bio, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, height: 1.35, fontSize: 14))),
                  ],
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          _profileStats(isOwner: isOwner),
          const SizedBox(height: 14),
          // Proprietário: Editar Perfil. Visitante: Curtir Perfil + Mensagem.
          if (isOwner) ...[
            SizedBox(height: 52, child: ElevatedButton.icon(
              onPressed: () => _editOwnProfile(),
              icon: const Icon(Icons.manage_accounts, color: Colors.white),
              label: const Text('Editar Perfil', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(backgroundColor: _profilePurple, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25))),
            )),
          ] else ...[
            Row(children: [
              Expanded(child: _profileLikeButton(context)),
              const SizedBox(width: 9),
              Expanded(child: SizedBox(height: 52, child: OutlinedButton.icon(
                onPressed: () => _openChat(context, name),
                icon: const Icon(Icons.chat_bubble_outline, color: Colors.white, size: 19),
                label: const Text('Mensagem', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis),
                style: OutlinedButton.styleFrom(side: const BorderSide(color: _profilePink, width: 1.5), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25))),
              ))),
            ]),
            const SizedBox(height: 9),
            StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: DataService.instance.followingStatus(widget.userId),
              builder: (context, followSnap) {
                final following = followSnap.data?.exists == true;
                return SizedBox(height: 45, child: OutlinedButton.icon(
                  onPressed: followSnap.connectionState == ConnectionState.waiting ? null : () => _toggleFollow(context),
                  icon: Icon(following ? Icons.check : Icons.person_add_alt_1, color: Colors.white),
                  label: Text(following ? 'Seguindo' : 'Seguir pessoa', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  style: OutlinedButton.styleFrom(side: BorderSide(color: _profilePurple.withOpacity(.8)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
                ));
              },
            ),
          ],
          const SizedBox(height: 17),
          Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(color: const Color(0xFF100817), borderRadius: BorderRadius.circular(22), border: Border.all(color: _profilePurple.withOpacity(.55))),
            child: Row(children: [
              _visitorTabButton('Fotos', Icons.photo_library, 0),
              _visitorTabButton('Conquistas', Icons.star, 1),
              _visitorTabButton('VIP', Icons.workspace_premium, 2),
            ]),
          ),
          const SizedBox(height: 13),
          if (_visitorTab == 0) _photosGallery(isOwner: isOwner, canSeeFriends: isMatched),
          if (_visitorTab == 1) _visitorAchievements(),
          if (_visitorTab == 2) _visitorVipCard(isVip),
          const SizedBox(height: 17),
          _visitorAbout(bio, interests),
          const SizedBox(height: 16),
          if (isOwner) ...[
            // A edição é exclusiva do proprietário; visitantes nunca recebem esta ação.
            SizedBox(
              width: double.infinity,
              child: _visitorActionButton(
                'Meus presentes', '🎁',
                () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: widget.userId))),
              ),
            ),
          ] else ...[
            Row(children: [
              Expanded(child: _visitorActionButton('Enviar presente', '🎁', () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: widget.userId))))),
              const SizedBox(width: 8),
              Expanded(child: _visitorActionButton('Enviar diamantes', '💎', () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: widget.userId))))),
            ]),
            const SizedBox(height: 9),
            SizedBox(height: 48, child: OutlinedButton.icon(
              onPressed: () => _showVipInfo(context, isVip),
              icon: const Icon(Icons.workspace_premium, color: Color(0xFFFFD45C)),
              label: const Text('Ver benefícios VIP', style: TextStyle(color: Color(0xFFFFD45C), fontWeight: FontWeight.w900)),
              style: OutlinedButton.styleFrom(side: const BorderSide(color: Color(0xFFFFD45C)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
            )),
            const SizedBox(height: 14),
            OutlinedButton.icon(onPressed: () => _report(context), icon: const Icon(Icons.flag_outlined), label: const Text('Denunciar perfil')),
            OutlinedButton.icon(onPressed: () => _block(context), icon: const Icon(Icons.block), label: const Text('Bloquear usuário')),
          ],
          const SizedBox(height: 20),
          _receivedGiftsSection(),
        ],
      ),
    );
  }

  Widget _visitorTabButton(String label, IconData icon, int index) {
    final selected = _visitorTab == index;
    return Expanded(child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => setState(() => _visitorTab = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 3),
        decoration: BoxDecoration(
          color: selected ? _profilePurple : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
          boxShadow: selected ? [BoxShadow(color: _profilePink.withOpacity(.45), blurRadius: 12)] : null,
        ),
        child: Column(children: [
          Icon(icon, color: selected ? Colors.white : _profileSilver, size: 21),
          const SizedBox(height: 3),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: TextStyle(color: selected ? Colors.white : _profileSilver, fontSize: 11, fontWeight: FontWeight.w800)),
        ]),
      ),
    ));
  }

  Widget _visitorAchievements() {
    final query = FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('achievements');
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return _visitorEmpty('Não foi possível carregar as conquistas.', Icons.star_border);
        if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: _profilePink));
        final docs = snap.data!.docs;
        if (docs.isEmpty) return _visitorEmpty('Ainda não há conquistas publicadas.', Icons.emoji_events_outlined);
        return GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: docs.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: 1.5),
          itemBuilder: (_, i) {
            final data = docs[i].data();
            final title = (data['title'] ?? data['name'] ?? 'Conquista').toString();
            final description = (data['description'] ?? '').toString();
            final emoji = (data['emoji'] ?? '🏆').toString();
            return Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(
              color: _profilePanel, borderRadius: BorderRadius.circular(15), border: Border.all(color: _profilePurple.withOpacity(.65)),
              boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.14), blurRadius: 10)],
            ), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(emoji, style: const TextStyle(fontSize: 25)),
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.white)),
              if (description.isNotEmpty) Text(description, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, fontSize: 10)),
            ]));
          },
        );
      },
    );
  }

  Widget _visitorVipCard(bool isVip) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFD45C).withOpacity(.75)),
      boxShadow: [BoxShadow(color: const Color(0xFFFFD45C).withOpacity(.13), blurRadius: 14)]),
    child: Column(children: [
      const Icon(Icons.workspace_premium, color: Color(0xFFFFD45C), size: 44),
      const SizedBox(height: 8),
      Text(isVip ? 'Membro VIP' : 'Ainda não é VIP', style: const TextStyle(color: Color(0xFFFFD45C), fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5),
      Text(isVip ? 'Este perfil possui benefícios VIP ativos.' : 'Este perfil ainda não possui o selo VIP.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
    ]),
  );

  Widget _visitorAbout(String bio, List<String> interests) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: const Color(0xFF100817), borderRadius: BorderRadius.circular(18), border: Border.all(color: _profilePurple.withOpacity(.65))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.info, color: _profilePink), SizedBox(width: 8), Text('Sobre mim', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))]),
      const SizedBox(height: 9),
      Text(bio.isEmpty ? 'Esta pessoa ainda não adicionou uma biografia.' : bio, style: const TextStyle(color: Colors.white, height: 1.4, fontSize: 14)),
      if (interests.isNotEmpty) ...[
        const SizedBox(height: 12),
        Wrap(spacing: 7, runSpacing: 7, children: interests.map((item) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(color: const Color(0xFF251033), borderRadius: BorderRadius.circular(22), border: Border.all(color: _profilePink.withOpacity(.65))),
          child: Text(item, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
        )).toList()),
      ],
    ]),
  );

  Widget _visitorActionButton(String label, String emoji, VoidCallback onTap) => SizedBox(
    height: 48,
    child: OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        foregroundColor: Colors.white,
        side: const BorderSide(color: _profilePink, width: 1.4),
        backgroundColor: const Color(0xFF160A22),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
      ),
      child: FittedBox(fit: BoxFit.scaleDown, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(emoji, style: const TextStyle(fontSize: 19)), const SizedBox(width: 6),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
      ])),
    ),
  );

  Widget _visitorEmpty(String message, IconData icon) => Container(
    width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 14),
    decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: _profilePurple.withOpacity(.5))),
    child: Column(children: [Icon(icon, color: _profilePurple, size: 34), const SizedBox(height: 8), Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))]),
  );

  void _showVipInfo(BuildContext context, bool isVip) {
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF160A22),
      title: const Text('LoveMix VIP', style: TextStyle(color: Color(0xFFFFD45C), fontWeight: FontWeight.w900)),
      content: Text(isVip ? 'Este perfil possui o selo VIP ativo.' : 'Este perfil ainda não possui o selo VIP. Você pode conferir as opções VIP na área de perfil da sua conta.', style: const TextStyle(color: Colors.white70)),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fechar'))],
    ));
  }

  Widget _profileStats({bool isOwner = false}) {
    final user = FirebaseFirestore.instance.collection('users').doc(widget.userId);
    if (isOwner) {
      return Row(children: [
        Expanded(child: _liveStat(user.collection('followers'), Icons.people_alt_rounded, 'Seguidores')),
        const SizedBox(width: 6),
        Expanded(child: _liveStat(user.collection('profileLikes'), Icons.favorite_rounded, 'Curtidas')),
        const SizedBox(width: 6),
        Expanded(child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: user.snapshots(),
          builder: (context, snap) => _statTile(Icons.auto_awesome, '${snap.data?.data()?['charisma'] ?? 0}', 'Carisma'),
        )),
        const SizedBox(width: 6),
        Expanded(child: _liveStat(user.collection('receivedGifts'), Icons.card_giftcard, 'Presentes')),
      ]);
    }
    return Row(children: [
      Expanded(child: _liveStat(user.collection('followers'), Icons.people_alt_rounded, 'Seguidores')),
      const SizedBox(width: 8),
      Expanded(child: _liveStat(user.collection('following'), Icons.person_add_alt_1_rounded, 'Seguindo')),
      const SizedBox(width: 8),
      Expanded(child: _liveStat(user.collection('profileLikes'), Icons.favorite_rounded, 'Curtidas')),
    ]);
  }

  Widget _statTile(IconData icon, String value, String label) => Container(
    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
    decoration: BoxDecoration(
      color: const Color(0xFF100B18),
      borderRadius: BorderRadius.circular(17),
      border: Border.all(color: _profileSilver.withOpacity(.38)),
      boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.16), blurRadius: 12)],
    ),
    child: Column(children: [
      Icon(icon, color: _profilePurple, size: 23),
      const SizedBox(height: 4),
      Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
      Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _profileSilver, fontSize: 9)),
    ]),
  );

  Widget _liveStat(Query<Map<String, dynamic>> query, IconData icon, String label) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
          decoration: BoxDecoration(
            color: const Color(0xFF100B18),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _profileSilver.withOpacity(.38)),
            boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.16), blurRadius: 12)],
          ),
          child: Column(children: [
            Icon(icon, color: _profilePurple, size: 23),
            const SizedBox(height: 4),
            Text('$count', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _profileSilver, fontSize: 10)),
          ]),
        );
      },
    );
  }

  Widget _receivedGiftsSection() {
    final gifts = FirebaseFirestore.instance.collection('users').doc(widget.userId)
        .collection('receivedGifts').orderBy('createdAt', descending: true).limit(60);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Icon(Icons.card_giftcard, color: _profilePink, size: 21),
        const SizedBox(width: 8),
        const Text('Presentes recebidos', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      ]),
      const SizedBox(height: 10),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: gifts.snapshots(),
        builder: (context, snap) {
          if (snap.hasError) {
            return const Text('Não foi possível carregar os presentes.', style: TextStyle(color: Colors.white60));
          }
          if (!snap.hasData) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator(color: _profilePink)));
          }
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
              decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
              child: const Column(children: [
                Icon(Icons.redeem, color: _profilePurple, size: 32),
                SizedBox(height: 7),
                Text('Ainda não recebeu presentes', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
              ]),
            );
          }
          return GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: docs.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .9,
            ),
            itemBuilder: (context, index) {
              final gift = docs[index].data();
              final emoji = (gift['emoji'] ?? '🎁').toString();
              final name = (gift['giftName'] ?? 'Presente').toString();
              final sender = (gift['senderName'] ?? 'Alguém').toString();
              return Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF21132E),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _profileSilver.withOpacity(.42)),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(emoji, style: const TextStyle(fontSize: 34)),
                  const SizedBox(height: 5),
                  Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text('De: $sender', maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white60, fontSize: 9)),
                  if (gift['source'] == 'live')
                    const Text('LIVE', style: TextStyle(color: _profilePink, fontSize: 8, fontWeight: FontWeight.w900)),
                ]),
              );
            },
          );
        },
      ),
    ]);
  }

  Widget _photosGallery({required bool isOwner, required bool canSeeFriends}) {
    final posts = FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('posts');
    if (isOwner) {
      return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: posts.snapshots(),
        builder: (context, snap) => _galleryContent(context, snap.data?.docs ?? [], loading: !snap.hasData, error: snap.hasError),
      );
    }
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: posts.where('visibility', isEqualTo: 'public').snapshots(),
      builder: (context, publicSnap) {
        if (publicSnap.hasError) return _galleryContent(context, [], loading: false, error: true);
        if (!canSeeFriends) {
          return _galleryContent(context, publicSnap.data?.docs ?? [], loading: !publicSnap.hasData);
        }
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: posts.where('visibility', isEqualTo: 'friends').snapshots(),
          builder: (context, friendsSnap) {
            if (friendsSnap.hasError) return _galleryContent(context, publicSnap.data?.docs ?? [], loading: !publicSnap.hasData);
            final combined = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
            combined.addAll(publicSnap.data?.docs ?? []);
            combined.addAll(friendsSnap.data?.docs ?? []);
            combined.sort((a, b) {
              final at = a.data()['createdAt'];
              final bt = b.data()['createdAt'];
              final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
              final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
              return bm.compareTo(am);
            });
            return _galleryContent(context, combined, loading: !publicSnap.hasData || !friendsSnap.hasData);
          },
        );
      },
    );
  }

  Widget _galleryContent(BuildContext context,
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
      {required bool loading, bool error = false}) {
    if (error) return const Text('As fotos não estão disponíveis para este perfil.', style: TextStyle(color: Colors.white60));
    if (loading) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(color: _profilePink)));
    if (docs.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 26),
        decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
        child: const Column(children: [
          Icon(Icons.photo_library_outlined, color: _profilePurple, size: 34),
          SizedBox(height: 8),
          Text('Nenhuma foto disponível ainda.', style: TextStyle(color: Colors.white70)),
        ]),
      );
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: docs.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 7, mainAxisSpacing: 7),
      itemBuilder: (_, i) {
        final url = (docs[i].data()['photoUrl'] ?? '').toString();
        return GestureDetector(
          onTap: url.isEmpty ? null : () => _showPhoto(context, docs[i].id, url),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: url.isEmpty
                ? const ColoredBox(color: _profilePanel, child: Icon(Icons.broken_image))
                : CachedNetworkImage(imageUrl: url, fit: BoxFit.cover,
                    placeholder: (_, __) => const ColoredBox(color: _profilePanel, child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: _profilePink))),
                    errorWidget: (_, __, ___) => const ColoredBox(color: _profilePanel, child: Icon(Icons.broken_image))),
          ),
        );
      },
    );
  }

  void _showPhoto(BuildContext context, String postId, String url) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: postId, photoUrl: url)));
  }

  Widget _profileLikeButton(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final likes = FirebaseFirestore.instance.collection('users')
        .doc(widget.userId).collection('profileLikes');
    if (uid == null || uid == widget.userId) return const SizedBox.shrink();
    final myLike = likes.doc(uid);
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: myLike.snapshots(),
      builder: (context, likeSnap) {
        final liked = likeSnap.data?.exists == true;
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: likes.snapshots(),
          builder: (context, countSnap) {
            final count = countSnap.data?.docs.length ?? 0;
            return SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: likeSnap.connectionState == ConnectionState.waiting
                    ? null : () => _toggleProfileLike(context, liked),
                icon: Icon(liked ? Icons.favorite : Icons.favorite_border,
                    color: Colors.white, size: 25),
                label: Text(liked ? 'Perfil curtido  •  $count' : 'Curtir Perfil  •  $count',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: liked ? const Color(0xFF542078) : _profilePurple,
                  foregroundColor: Colors.white,
                  elevation: 8,
                  shadowColor: _profilePurple.withOpacity(.45),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                    side: const BorderSide(color: _profileSilver, width: 1.2),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _toggleProfileLike(BuildContext context, bool alreadyLiked) async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null || me.uid == widget.userId) return;
    final db = FirebaseFirestore.instance;
    final likeRef = db.collection('users').doc(widget.userId)
        .collection('profileLikes').doc(me.uid);
    try {
      if (alreadyLiked) {
        await likeRef.delete();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Curtida removida.')),
        );
        return;
      }
      final myProfile = await db.collection('users').doc(me.uid).get();
      final myName = (myProfile.data()?['name'] ?? me.displayName ?? 'Alguém').toString();
      await likeRef.set({
        'uid': me.uid,
        'name': myName,
        'createdAt': FieldValue.serverTimestamp(),
      });
      await db.collection('users').doc(widget.userId).collection('notifications').add({
        'type': 'profile_like',
        'fromUid': me.uid,
        'fromName': myName,
        'body': '$myName curtiu seu perfil. 💜',
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Você curtiu este perfil! 💜')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível curtir o perfil: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    }
  }

  Future<void> _toggleFollow(BuildContext context) async {
    try {
      final following = await DataService.instance.toggleFollow(widget.userId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(following ? 'Você começou a seguir 💗' : 'Você deixou de seguir.'),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _openChat(BuildContext context, String otherName) async {
    if (FirebaseAuth.instance.currentUser == null) return;
    try {
      final chatId = await DataService.instance.openDirectChat(widget.userId);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => ChatScreen(chatId: chatId, otherName: otherName),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }


  Future<void> _report(BuildContext context) async {
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Denunciar perfil'),
        children: ['Perfil falso', 'Assédio ou discurso de ódio', 'Conteúdo impróprio', 'Outro']
            .map((r) => SimpleDialogOption(onPressed: () => Navigator.pop(ctx, r), child: Text(r))).toList(),
      ),
    );
    if (reason == null) return;
    try {
      await DataService.instance.reportUser(widget.userId, reason);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Denúncia enviada para análise.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar a denúncia.')));
    }
  }

  Future<void> _block(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bloquear usuário?'),
        content: const Text('Este perfil não deverá mais aparecer para você.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bloquear')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await DataService.instance.blockUser(widget.userId);
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível bloquear este usuário.')));
    }
  }
}
