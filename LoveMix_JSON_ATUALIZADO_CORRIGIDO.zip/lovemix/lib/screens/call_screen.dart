import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zego_uikit/zego_uikit.dart' show ZegoLayout;
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import '../services/zego_config.dart';

Future<bool> _granted(bool video) async {
  final wanted = <Permission>[Permission.microphone, if (video) Permission.camera];
  for (final p in wanted) {
    if (!(await p.status).isGranted) return false;
  }
  return true;
}

/// Espera o usuário voltar das configurações do aparelho ao app.
class _ResumeWaiter with WidgetsBindingObserver {
  _ResumeWaiter() { WidgetsBinding.instance.addObserver(this); }
  final _c = Completer<void>();
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_c.isCompleted) _c.complete();
  }
  Future<void> wait() async {
    await _c.future.timeout(const Duration(minutes: 5), onTimeout: () {});
    WidgetsBinding.instance.removeObserver(this);
  }
}

/// Pede as permissões necessárias (microfone; câmera também no vídeo).
/// Se estiverem bloqueadas, leva o usuário às configurações e, ao voltar,
/// confere de novo. Retorna true somente se tudo foi liberado.
Future<bool> requestCallPermissions(BuildContext context, {required bool video}) async {
  final wanted = <Permission>[Permission.microphone, if (video) Permission.camera];
  final result = await wanted.request();
  if (result.values.every((s) => s.isGranted)) return true;
  if (!context.mounted) return false;

  final blocked = result.values.any((s) => s.isPermanentlyDenied || s.isRestricted);
  final what = video ? 'à câmera e ao microfone' : 'ao microfone';
  final openSettings = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF21132E),
      title: const Text('Permissão necessária'),
      content: Text(blocked
          ? 'Para fazer chamadas de ${video ? 'vídeo' : 'voz'}, permita o acesso $what nas configurações do aparelho (Permissões). Depois é só voltar ao app que a chamada continua.'
          : 'Sem acesso $what não é possível fazer a chamada. Toque em "Permitir" para continuar.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Agora não')),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(blocked ? 'Abrir configurações' : 'Permitir'),
        ),
      ],
    ),
  );
  if (openSettings != true) return false;

  if (!blocked) return requestCallPermissions(context, video: video);

  final waiter = _ResumeWaiter();
  await openAppSettings();
  await waiter.wait();
  return _granted(video);
}

/// Chamada privada ou em grupo, com convite e cronômetro após atender.
class CallScreen extends StatefulWidget {
  const CallScreen({
    super.key,
    required this.callRef,
    required this.video,
    this.isCaller = false,
    this.roomCallId,
    this.parentCallRef,
    this.isGroupInvite = false,
  });

  final DocumentReference<Map<String, dynamic>> callRef;
  final bool video;
  final bool isCaller;
  final String? roomCallId;
  final DocumentReference<Map<String, dynamic>>? parentCallRef;
  final bool isGroupInvite;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  Timer? _ringTimeout;
  Timer? _clock;
  int _elapsedSeconds = 0;
  bool _enteredCall = false;
  bool _closing = false;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _parentSubscription;
  bool _inviteBusy = false;

  @override
  void initState() {
    super.initState();
    if (widget.isCaller && !widget.isGroupInvite) {
      _ringTimeout = Timer(const Duration(seconds: 30), _expireIfUnanswered);
    }
    if (widget.isGroupInvite && widget.parentCallRef != null) {
      _parentSubscription = widget.parentCallRef!.snapshots().listen((snapshot) {
        final parentStatus = snapshot.data()?['status'];
        if (parentStatus == 'ended' && mounted && !_closing) {
          _closing = true;
          Navigator.of(context).maybePop();
        }
      });
    }
  }

  Future<void> _expireIfUnanswered() async {
    if (!mounted || _enteredCall) return;
    try {
      final snap = await widget.callRef.get();
      if (snap.data()?['status'] == 'ringing') {
        await widget.callRef.update({
          'status': 'missed',
          'endedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (_) {}
  }

  void _startClock(Timestamp? acceptedAt) {
    if (_enteredCall) return;
    _enteredCall = true;
    _ringTimeout?.cancel();
    final start = acceptedAt?.toDate() ?? DateTime.now();
    _elapsedSeconds = DateTime.now().difference(start).inSeconds.clamp(0, 86400).toInt();
    _clock = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _elapsedSeconds = DateTime.now().difference(start).inSeconds.clamp(0, 86400).toInt();
      });
    });
  }

  String get _formattedTime {
    final minutes = (_elapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (_elapsedSeconds % 60).toString().padLeft(2, '0');
    final hours = (_elapsedSeconds ~/ 3600);
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:$minutes:$seconds';
    }
    return '$minutes:$seconds';
  }

  Future<void> _finishCall() async {
    if (_closing) return;
    _closing = true;
    _ringTimeout?.cancel();
    _clock?.cancel();
    try {
      await widget.callRef.update({
        'status': widget.isGroupInvite ? 'left' : 'ended',
        'endedAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _ringTimeout?.cancel();
    _clock?.cancel();
    _parentSubscription?.cancel();
    // Sair da chamada em grupo remove apenas este convidado; a chamada principal continua.
    if (_enteredCall && !_closing) {
      widget.callRef.update({
        'status': widget.isGroupInvite ? 'left' : 'ended',
        'endedAt': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
    super.dispose();
  }


  Future<void> _invitePeople() async {
    if (_inviteBusy || widget.isGroupInvite) return;
    final me = FirebaseAuth.instance.currentUser;
    if (me == null) return;
    setState(() => _inviteBusy = true);
    try {
      final rootCall = widget.callRef;
      final callSnap = await rootCall.get();
      final callData = callSnap.data() ?? <String, dynamic>{};
      if (callData['status'] != 'accepted') {
        throw Exception('A chamada ainda não está conectada.');
      }
      final already = <String>{
        ...List<String>.from(callData['participants'] ?? const <String>[]),
        me.uid,
      };
      final usersSnap = await FirebaseFirestore.instance
          .collection('users')
          .where('profileVisibility', isEqualTo: 'public')
          .limit(100)
          .get();
      final candidates = usersSnap.docs.where((d) => !already.contains(d.id)).toList();
      if (!mounted) return;
      if (candidates.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não há outras pessoas públicas disponíveis para convidar.')),
        );
        return;
      }
      final selected = <String>{};
      final confirmed = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        backgroundColor: const Color(0xFF1B1026),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        builder: (sheetContext) => StatefulBuilder(
          builder: (context, setSheetState) => SafeArea(
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.68,
              child: Column(children: [
                const SizedBox(height: 16),
                const Text('Adicionar pessoas à ligação',
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                const Padding(
                  padding: EdgeInsets.all(10),
                  child: Text('Escolha quem deseja convidar para esta chamada.',
                      style: TextStyle(color: Colors.white70)),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: candidates.length,
                    itemBuilder: (_, index) {
                      final doc = candidates[index];
                      final data = doc.data();
                      final display = (data['name'] ?? data['displayName'] ?? 'Pessoa').toString();
                      final photo = (data['photoUrl'] ?? '').toString();
                      final checked = selected.contains(doc.id);
                      return CheckboxListTile(
                        value: checked,
                        activeColor: const Color(0xFFFF2DAB),
                        checkColor: Colors.white,
                        title: Text(display, style: const TextStyle(color: Colors.white)),
                        secondary: CircleAvatar(
                          backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                          child: photo.isEmpty ? const Icon(Icons.person) : null,
                        ),
                        onChanged: (value) => setSheetState(() {
                          if (value == true) { selected.add(doc.id); } else { selected.remove(doc.id); }
                        }),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 18),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF2DAB)),
                      onPressed: selected.isEmpty ? null : () => Navigator.pop(sheetContext, true),
                      icon: const Icon(Icons.person_add_alt_1),
                      label: Text('Convidar (${selected.length})'),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );
      if (confirmed != true || selected.isEmpty) return;
      final callerProfile = await FirebaseFirestore.instance.collection('users').doc(me.uid).get();
      final callerName = (callerProfile.data()?['name'] ?? me.displayName ?? 'LoveMix').toString();
      final batch = FirebaseFirestore.instance.batch();
      for (final targetUid in selected) {
        final inviteRef = rootCall.collection('callInvites').doc(targetUid);
        batch.set(inviteRef, {
          'callerUid': me.uid,
          'calleeUid': targetUid,
          'callerName': callerName,
          'video': widget.video,
          'status': 'ringing',
          'roomCallId': widget.roomCallId ?? rootCall.id,
          'callPath': rootCall.path,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${selected.length} convite(s) enviado(s).')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível convidar: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _inviteBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final name = (user?.displayName ?? '').trim();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: widget.callRef.snapshots(),
      builder: (context, snapshot) {
        final data = snapshot.data?.data() ?? <String, dynamic>{};
        final status = (data['status'] ?? 'ringing').toString();

        if (status == 'accepted') {
          final acceptedAt = data['acceptedAt'];
          _startClock(acceptedAt is Timestamp ? acceptedAt : null);
        }

        if (status == 'rejected' || status == 'missed' || status == 'ended' || status == 'left') {
          if (!_closing) {
            _closing = true;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (!mounted) return;
              final message = status == 'missed'
                  ? 'Ninguém atendeu. Chamada encerrada.'
                  : status == 'rejected'
                      ? 'A chamada foi recusada.'
                      : 'A chamada foi encerrada.';
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
              Navigator.of(context).pop();
            });
          }
          return const Scaffold(
            backgroundColor: Color(0xFF100A19),
            body: Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB))),
          );
        }

        if (status != 'accepted') {
          return Scaffold(
            backgroundColor: const Color(0xFF100A19),
            body: SafeArea(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(widget.video ? Icons.videocam : Icons.call,
                        color: const Color(0xFFFF2DAB), size: 76),
                    const SizedBox(height: 18),
                    Text(widget.isCaller ? 'Chamando...' : 'Conectando...',
                        style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('Aguardando a outra pessoa atender',
                        style: TextStyle(color: Colors.white70)),
                    const SizedBox(height: 28),
                    IconButton.filled(
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        minimumSize: const Size(66, 66),
                      ),
                      onPressed: _finishCall,
                      icon: const Icon(Icons.call_end, color: Colors.white, size: 30),
                    ),
                    const SizedBox(height: 10),
                    const Text('Cancelar', style: TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
            ),
          );
        }

        final callerUid = (data['callerUid'] ?? '').toString();
        final calleeUid = (data['calleeUid'] ?? '').toString();
        final callerPhotoUrl = (data['callerPhotoUrl'] ?? '').toString();
        final calleePhotoUrl = (data['calleePhotoUrl'] ?? '').toString();
        // O modo de grupo suporta 1:1 e permite que novos participantes entrem
        // no mesmo callID. Mantemos a câmera desligada nas chamadas de voz.
        // Usamos a base de vídeo em ambos os tipos para habilitar o compartilhamento
        // de tela também nas chamadas iniciadas como voz; a câmera fica desligada
        // até que seja uma chamada de vídeo.
        final callConfig = ZegoUIKitPrebuiltCallConfig.groupVideoCall();
        callConfig.layout = ZegoLayout.gallery();
        callConfig.bottomMenuBarConfig = ZegoBottomMenuBarConfig(buttons: [
          if (widget.video) ZegoCallMenuBarButtonName.toggleCameraButton,
          ZegoCallMenuBarButtonName.toggleMicrophoneButton,
          ZegoCallMenuBarButtonName.switchAudioOutputButton,
          ZegoCallMenuBarButtonName.hangUpButton,
          ZegoCallMenuBarButtonName.toggleScreenSharingButton,
        ]);
        // O layout padrão de vídeo da ZEGOCLOUD já inclui o botão de câmera:
        // cada participante pode desligar/ligar sua própria câmera durante a chamada.
        if (widget.video) {
          callConfig.turnOnCameraWhenJoining = true;
        } else {
          callConfig.turnOnCameraWhenJoining = false;
          callConfig.avatarBuilder = (context, size, zegoUser, extraInfo) {
            final participantId = zegoUser?.id ?? '';
            final photoUrl = participantId == callerUid
                ? callerPhotoUrl
                : participantId == calleeUid
                    ? calleePhotoUrl
                    : '';
            return Container(
              width: size.width,
              height: size.height,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF321846),
                image: photoUrl.isNotEmpty
                    ? DecorationImage(
                        image: NetworkImage(photoUrl),
                        fit: BoxFit.cover,
                        onError: (_, __) {},
                      )
                    : null,
              ),
              child: photoUrl.isEmpty
                  ? Icon(Icons.person, color: Colors.white70, size: size.width * 0.55)
                  : null,
            );
          };
        }

        return Scaffold(
          backgroundColor: const Color(0xFF100A19),
          body: Stack(
            children: [
              SafeArea(
                child: ZegoUIKitPrebuiltCall(
                  appID: ZegoConfig.appId,
                  appSign: ZegoConfig.appSign,
                  userID: user?.uid ?? 'anon',
                  userName: name.isEmpty ? 'LoveMix' : name,
                  callID: 'lovemix_${widget.roomCallId ?? widget.callRef.id}',
                  config: callConfig,
                ),
              ),
              Positioned(
                top: MediaQuery.of(context).padding.top + 8,
                left: 0,
                right: 0,
                child: IgnorePointer(
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                      decoration: BoxDecoration(
                        color: const Color(0xDD160B20),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFFFF2DAB)),
                      ),
                      child: Text(
                        '⏱ $_formattedTime',
                        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
              if (!widget.isGroupInvite) Positioned(
                top: MediaQuery.of(context).padding.top + 4,
                right: 8,
                child: Material(
                  color: const Color(0xFF321846),
                  shape: const CircleBorder(),
                  child: IconButton(
                    tooltip: 'Adicionar pessoas',
                    onPressed: _inviteBusy ? null : _invitePeople,
                    icon: const Icon(Icons.person_add_alt_1, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
