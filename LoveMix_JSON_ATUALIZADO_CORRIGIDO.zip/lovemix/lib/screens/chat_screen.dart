import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'profile_view_screen.dart';
import 'call_screen.dart';
import '../services/data_service.dart';
import '../services/notification_service.dart';
import '../services/supabase_service.dart';
import '../services/translation_service.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  bool sendingImage = false;
  @override
  void initState() {
    super.initState();
    NotificationService.instance.activeChatId = widget.chatId;
  }

  @override
  void dispose() {
    if (NotificationService.instance.activeChatId == widget.chatId) {
      NotificationService.instance.activeChatId = null;
    }
    input.dispose();
    super.dispose();
  }

  Future<void> _send(String value) async {
    final text = value.trim();
    if (text.isEmpty) return;
    input.clear();
    try { await DataService.instance.sendMessage(widget.chatId, text); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível enviar: $e'))); }
  }

  Future<void> _showTranslator({String initialText = ''}) async {
    final textController = TextEditingController(text: initialText);
    String source = 'en';
    String target = 'pt-BR';
    String? result;
    bool loading = false;
    String? error;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1B1028),
          title: const Row(children: [
            Icon(Icons.translate, color: Color(0xFFFF2DAB)),
            SizedBox(width: 9),
            Text('Tradutor LoveMix'),
          ]),
          content: SingleChildScrollView(child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: source,
                dropdownColor: const Color(0xFF241A31),
                decoration: const InputDecoration(labelText: 'Idioma original'),
                items: const [
                  DropdownMenuItem(value: 'en', child: Text('Inglês')),
                  DropdownMenuItem(value: 'es', child: Text('Espanhol')),
                  DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() { source = v; if (source == target) target = source == 'pt-BR' ? 'en' : 'pt-BR'; }); },
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: target,
                dropdownColor: const Color(0xFF241A31),
                decoration: const InputDecoration(labelText: 'Traduzir para'),
                items: const [
                  DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                  DropdownMenuItem(value: 'en', child: Text('Inglês')),
                  DropdownMenuItem(value: 'es', child: Text('Espanhol')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() => target = v); },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: textController,
                minLines: 2,
                maxLines: 5,
                maxLength: 450,
                decoration: const InputDecoration(
                  hintText: 'Digite uma palavra ou frase...',
                  border: OutlineInputBorder(),
                ),
              ),
              if (loading) const Center(child: Padding(
                padding: EdgeInsets.all(12),
                child: CircularProgressIndicator(color: Color(0xFFFF2DAB)),
              )),
              if (error != null) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(error!, style: const TextStyle(color: Colors.redAccent)),
              ),
              if (result != null) Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF321846),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SelectableText(result!, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ],
          )),
          actions: [
            TextButton(onPressed: loading ? null : () => Navigator.pop(dialogContext), child: const Text('Fechar')),
            FilledButton.icon(
              onPressed: loading ? null : () async {
                setDialogState(() { loading = true; error = null; result = null; });
                try {
                  final translated = await TranslationService.instance.translate(
                    text: textController.text,
                    sourceLanguage: source,
                    targetLanguage: target,
                  );
                  setDialogState(() => result = translated);
                } catch (e) {
                  setDialogState(() => error = e.toString().replaceFirst('Exception: ', ''));
                } finally {
                  setDialogState(() => loading = false);
                }
              },
              icon: const Icon(Icons.translate),
              label: const Text('Traduzir'),
            ),
          ],
        ),
      ),
    );
    textController.dispose();
  }

  Future<void> _sendPhoto() async {
    if (sendingImage) return;
    try {
      final source = await showModalBottomSheet<ImageSource>(
        context: context,
        backgroundColor: const Color(0xFF1B1028),
        builder: (sheetContext) => SafeArea(
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFFFF2DAB)),
              title: const Text('Escolher da galeria'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFFFF2DAB)),
              title: const Text('Tirar uma foto agora'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.camera),
            ),
          ]),
        ),
      );
      if (source == null || !mounted) return;
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 78,
        maxWidth: 1600,
      );
      if (picked == null || !mounted) return;
      setState(() => sendingImage = true);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Entre na sua conta novamente.');
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A foto selecionada está vazia.');
      if (bytes.length > 4 *  1024 * 1024) {
        throw Exception('A foto deve ter no máximo 4 MB para passar pela verificação de segurança.');
      }
      final fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'chats/${widget.chatId}/$uid/$fileName',
        bytes: bytes, contentType: 'image/jpeg',
      );
      // A função analisa antes de criar a mensagem: foto comum aparece na hora;
      // somente conteúdo adulto/sugestivo entra na fila de revisão.
      await FirebaseFunctions.instance.httpsCallable('sendPrivateChatImage').call({
        'chatId': widget.chatId,
        'imageUrl': url,
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível enviar a foto: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sendingImage = false);
    }
  }


  Future<void> _deleteMessage(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final mine = data['senderId'] == FirebaseAuth.instance.currentUser?.uid;
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('Apagar mensagem', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
        ListTile(leading: const Icon(Icons.delete_outline, color: Colors.white70), title: const Text('Apagar somente para mim'), onTap: () => Navigator.pop(ctx, 'me')),
        if (mine) ListTile(leading: const Icon(Icons.delete_forever, color: Colors.redAccent), title: const Text('Apagar para todos'), subtitle: const Text('A mensagem será removida da conversa'), onTap: () => Navigator.pop(ctx, 'all')),
        ListTile(title: const Text('Cancelar'), onTap: () => Navigator.pop(ctx)),
      ])),
    );
    if (choice == null) return;
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      if (choice == 'me') {
        await doc.reference.update({'hiddenFor': FieldValue.arrayUnion([uid])});
      } else {
        final imageUrl = (data['imageUrl'] ?? '').toString();
        await doc.reference.delete();
        if (imageUrl.isNotEmpty) {
          try { final removed = await SupabaseService.instance.deletePublicUrl(imageUrl); if (!removed) await FirebaseStorage.instance.refFromURL(imageUrl).delete(); } catch (_) {}
        }
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mensagem apagada.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar: $e')));
    }
  }

  void _quickReactions() {
    const reactions = ['❤️','😍','🥰','😘','😂','🔥','💜','🌹','🎁','🧸','💎','👑'];
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => Padding(padding: const EdgeInsets.all(18), child: Wrap(
        spacing: 12, runSpacing: 12,
        children: reactions.map((emoji) => InkWell(
          onTap: () { Navigator.pop(ctx); _send(emoji); },
          child: Container(width: 52, height: 52, alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF321846), borderRadius: BorderRadius.circular(14)),
            child: Text(emoji, style: const TextStyle(fontSize: 27))),
        )).toList(),
      )));
  }

  Widget _allianceInvites(String uid) {
    final db = FirebaseFirestore.instance;
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: db.collection('chats').doc(widget.chatId).snapshots(),
      builder: (context, chatSnap) {
        final users = List<String>.from(chatSnap.data?.data()?['users'] ?? const []);
        final otherIds = users.where((id) => id != uid).toList();
        if (otherIds.isEmpty) return const SizedBox.shrink();
        final otherUid = otherIds.first;
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: db.collection('alliances').where('members', arrayContains: uid).snapshots(),
          builder: (context, allianceSnap) {
            if (!allianceSnap.hasData) return const SizedBox.shrink();
            final invites = allianceSnap.data!.docs.where((doc) {
              final data = doc.data();
              return data['createdBy'] == otherUid &&
                  data['invitedUid'] == uid &&
                  data['invitationStatus'] == 'pending';
            }).toList();
            if (invites.isEmpty) return const SizedBox.shrink();
            return Column(
              children: invites.map((doc) {
                final data = doc.data();
                final type = (data['relationshipType'] ?? 'Amigos').toString();
                final ring = (data['ringGiftName'] ?? 'Aliança').toString();
                final sender = (data['creatorName'] ?? widget.otherName).toString();
                final message = (data['message'] ?? '').toString().trim();
                final inviteDescription = switch (type) {
                  'Namorados' => 'formar um casal',
                  'BFF' => 'ser seu melhor amigo(a) (BFF)',
                  _ => 'ser seu amigo(a)',
                };
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(12, 10, 12, 5),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF42164F), Color(0xFF251033)]),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFFF65C8), width: 1.3),
                    boxShadow: [BoxShadow(color: const Color(0xFFFF2DAB).withOpacity(.18), blurRadius: 14)],
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Row(children: [
                      Icon(Icons.favorite, color: Color(0xFFFF72C6)),
                      SizedBox(width: 8),
                      Expanded(child: Text('CONVITE DE ALIANÇA', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1))),
                    ]),
                    const SizedBox(height: 8),
                    Text('$sender convidou você para $inviteDescription no LoveMix!',
                      style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 5),
                    Text('💍 $ring  •  $type', style: const TextStyle(color: Color(0xFFFFB7E4), fontWeight: FontWeight.w700)),
                    if (message.isNotEmpty) ...[
                      const SizedBox(height: 7),
                      Text(message, style: const TextStyle(color: Colors.white70)),
                    ],
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: OutlinedButton(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white70, side: const BorderSide(color: Colors.white38)),
                        onPressed: () async {
                          try {
                            await DataService.instance.respondAlliance(doc.id, false);
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Convite recusado.')));
                          } catch (e) {
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível responder: $e')));
                          }
                        },
                        child: const Text('Recusar'),
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE92D9B), foregroundColor: Colors.white),
                        onPressed: () async {
                          try {
                            await DataService.instance.respondAlliance(doc.id, true);
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Aliança aceita! Ela já aparece no mural. 💗')));
                          } catch (e) {
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível aceitar: $e')));
                          }
                        },
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text('Aceitar'),
                      )),
                    ]),
                  ]),
                );
              }).toList(),
            );
          },
        );
      },
    );
  }

  @override Widget build(BuildContext context) {
    final service = DataService.instance;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId).snapshots(),
            builder: (context, snap) {
              final ids = List<String>.from(snap.data?.data()?['users'] ?? const []);
              final others = ids.where((id) => id != uid).toList();
              final other = others.isEmpty ? null : others.first;
              if (other == null) return const CircleAvatar(radius: 18, child: Icon(Icons.person));
              return FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
                future: FirebaseFirestore.instance.collection('users').doc(other).get(),
                builder: (context, userSnap) {
                  final userData = userSnap.data?.data() ?? <String, dynamic>{};
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ProfileViewScreen(userId: other),
                    )),
                    child: ProfileFrameAvatar(photoUrl: (userData['photoUrl'] ?? '').toString(),
                      frameId: (userData['selectedProfileFrame'] ?? 'classic').toString(), size: 34),
                  );
                });
            },
          ),
          const SizedBox(width: 9),
          Expanded(child: StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId).snapshots(),
            builder: (context, chatSnap) {
              final ids = List<String>.from(chatSnap.data?.data()?['users'] ?? const []);
              final others = ids.where((id) => id != uid).toList();
              final other = others.isEmpty ? null : others.first;
              if (other == null) {
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(widget.otherName, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  const Text('Disponível para conversar', style: TextStyle(fontSize: 10, color: Color(0xFFB7A9C4))),
                ]);
              }
              return StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
                stream: FirebaseFirestore.instance.collection('users').doc(other).snapshots(),
                builder: (context, userSnap) {
                  final data = userSnap.data?.data() ?? <String, dynamic>{};
                  final displayName = (data['name'] ?? data['displayName'] ?? widget.otherName).toString();
                  final active = data['nicknameDecorationActive'] == true || data['isVip'] == true;
                  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    VipNickname(name: displayName, isVip: active,
                      styleId: (data['vipNicknameStyle'] ?? 'royal_gold').toString(),
                      textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                    const Text('Disponível para conversar', style: TextStyle(fontSize: 10, color: Color(0xFFB7A9C4))),
                  ]);
                },
              );
            },
          )),
        ]),
        actions: [
          IconButton(tooltip: 'Tradutor', onPressed: () => _showTranslator(), icon: const Icon(Icons.translate, color: Color(0xFFFF2DAB))),
          IconButton(tooltip: 'Chamada de voz', onPressed: () => _startCall(video: false), icon: const Icon(Icons.call, color: Color(0xFFFF2DAB))),
          IconButton(tooltip: 'Chamada de vídeo', onPressed: () => _startCall(video: true), icon: const Icon(Icons.videocam, color: Color(0xFFFF2DAB))),
        ],
      ),
      body: Column(children: [
        if (uid != null) _allianceInvites(uid),
        Container(
          width: double.infinity,
          margin: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF28152F),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFFFB74D).withOpacity(.65)),
          ),
          child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.shield_outlined, color: Color(0xFFFFC56E), size: 19),
            SizedBox(width: 8),
            Expanded(child: Text(
              'Assistente LoveMix: converse normalmente e respeite as pessoas. Palavras, fotos ou vídeos com nudez ou conteúdo sexual +18 são proibidos. Quem insistir após os avisos poderá ser banido.',
              style: TextStyle(color: Colors.white70, fontSize: 11.5, height: 1.35),
            )),
          ]),
        ),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
          stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Não foi possível carregar as mensagens.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs.where((d) {
              final data = d.data();
              final hidden = List<String>.from(data['hiddenFor'] ?? const []);
              if (hidden.contains(uid)) return false;
              // Fotos aguardam análise visual. Textos normais aparecem imediatamente:
              // o cliente já mascara termos +18 e a Cloud Function confirma/corrige
              // a censura no servidor sem prender a conversa em 'verificando'.
              if (data['type'] == 'image' && data['moderationStatus'] != 'approved') return false;
              return true;
            }).toList();
            if (docs.isEmpty) return const Center(child: Text('Diga oi e comece uma nova conversa! 💗'));
            return ListView.builder(padding: const EdgeInsets.all(14), itemCount: docs.length,
              itemBuilder: (context, i) {
                final m = docs[i].data();
                final mine = m['senderId'] == uid;
                final isGift = m['type'] == 'gift';
                final giftLabel = '${(m['giftEmoji'] ?? '🎁').toString()} ${(m['giftName'] ?? 'Presente').toString()}';
                final rawValue = (m['text'] ?? '').toString();
                final value = isGift
                    ? (mine ? '🎁 Você enviou $giftLabel' : '🎁 Você recebeu $giftLabel')
                    : (m['type'] == 'text'
                        ? DataService.maskPrivateAdultText(rawValue)
                        : rawValue);
                final isImage = m['type'] == 'image' && (m['imageUrl'] ?? '').toString().isNotEmpty;
                return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: GestureDetector(
                    onLongPress: () => _deleteMessage(docs[i]),
                    child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                    constraints: const BoxConstraints(maxWidth: 290),
                    decoration: BoxDecoration(
                      // Balões VIP exclusivos do PV: enviados em roxo real com borda dourada,
                      // recebidos em grafite violeta com borda champanhe. A decoração é apenas visual;
                      // não altera o conteúdo nem a gravação das mensagens.
                      gradient: mine
                          ? const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFF7A1FD6), Color(0xFF4A0F8C), Color(0xFF220847)],
                            )
                          : const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xFF2B2145), Color(0xFF1A1430), Color(0xFF0E0A1C)],
                            ),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(20),
                        topRight: const Radius.circular(20),
                        bottomLeft: Radius.circular(mine ? 20 : 5),
                        bottomRight: Radius.circular(mine ? 5 : 20),
                      ),
                      border: Border.all(
                        color: isGift
                            ? const Color(0xFFFFD45C)
                            : (mine ? const Color(0xFFFFD66B) : const Color(0xFFD9C79A)),
                        width: isGift ? 1.8 : 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (mine ? const Color(0xFFFFC83D) : const Color(0xFFB79CFF))
                              .withOpacity(mine ? 0.30 : 0.18),
                          blurRadius: 16,
                          spreadRadius: 1,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: isImage
                        ? GestureDetector(
                            onTap: () => showDialog<void>(
                              context: context,
                              builder: (dialogContext) => Dialog(
                                backgroundColor: const Color(0xFF100A19),
                                child: InteractiveViewer(
                                  child: Image.network(
                                    (m['imageUrl'] ?? '').toString(),
                                    fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => const Padding(
                                      padding: EdgeInsets.all(24),
                                      child: Text('Não foi possível carregar esta foto.'),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                (m['imageUrl'] ?? '').toString(),
                                width: 230,
                                height: 250,
                                fit: BoxFit.cover,
                                loadingBuilder: (context, child, progress) => progress == null
                                    ? child
                                    : const SizedBox(
                                        width: 230, height: 180,
                                        child: Center(child: CircularProgressIndicator()),
                                      ),
                                errorBuilder: (_, __, ___) => const SizedBox(
                                  width: 230, height: 100,
                                  child: Center(child: Text('Foto indisponível')),
                                ),
                              ),
                            ),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Exibe a decoração de Nick do autor dentro do próprio balão.
                              // O perfil é observado em tempo real para refletir trocas de decoração.
                              if ((m['senderId'] ?? '').toString().isNotEmpty)
                                StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                                  stream: FirebaseFirestore.instance
                                      .collection('users')
                                      .doc(m['senderId'].toString())
                                      .snapshots(),
                                  builder: (context, senderSnap) {
                                    final sender = senderSnap.data?.data() ?? <String, dynamic>{};
                                    final decorated = sender['nicknameDecorationActive'] == true || sender['isVip'] == true;
                                    if (!decorated) return const SizedBox.shrink();
                                    final senderName = (sender['name'] ?? sender['displayName'] ?? (mine ? 'Você' : widget.otherName)).toString();
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: 5),
                                      child: VipNickname(
                                        name: senderName,
                                        isVip: true,
                                        styleId: (sender['vipNicknameStyle'] ?? 'royal_gold').toString(),
                                        textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                                      ),
                                    );
                                  },
                                ),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Text(
                                      value,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: isGift ? 20 : 15,
                                        height: 1.28,
                                        fontWeight: isGift ? FontWeight.w800 : FontWeight.w500,
                                        shadows: const [Shadow(color: Color(0x55300050), blurRadius: 5)],
                                      ),
                                    ),
                                  ),
                                  if (!isGift && value.trim().isNotEmpty) ...[
                                    const SizedBox(width: 7),
                                    Icon(
                                      mine ? Icons.favorite : Icons.favorite_border,
                                      size: 13,
                                      color: mine ? const Color(0xFFFFD66B) : const Color(0xFFE9D9A8),
                                    ),
                                  ],
                                ],
                              ),
                              if (!isGift && value.trim().isNotEmpty) Align(
                                alignment: Alignment.centerRight,
                                child: TextButton.icon(
                                  style: TextButton.styleFrom(
                                    foregroundColor: const Color(0xFFFFE3A0),
                                    visualDensity: VisualDensity.compact,
                                    padding: const EdgeInsets.only(top: 5, left: 4, right: 4),
                                  ),
                                  onPressed: () => _showTranslator(initialText: value),
                                  icon: const Icon(Icons.translate, size: 15),
                                  label: const Text('Traduzir', style: TextStyle(fontSize: 11)),
                                ),
                              ),
                            ],
                          ),
                  ),
                  ),
                );
              });
          },
        )),
        SafeArea(top: false, child: Container(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
          decoration: const BoxDecoration(color: Color(0xFF100A19), border: Border(top: BorderSide(color: Color(0xFF422052)))),
          child: Row(children: [
            IconButton(
              tooltip: 'Enviar foto',
              onPressed: sendingImage ? null : _sendPhoto,
              icon: sendingImage
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.photo_library_outlined, color: Color(0xFFFF2DAB)),
            ),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white70)),
            Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, textInputAction: TextInputAction.send, onSubmitted: _send,
              decoration: InputDecoration(hintText: 'Envie uma mensagem...', isDense: true,
                filled: true, fillColor: const Color(0xFF21162D), contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.card_giftcard, color: Color(0xFFFF2DAB))),
            IconButton(onPressed: () => _send(input.text), icon: const Icon(Icons.send_rounded, color: Color(0xFFFF2DAB))),
          ]),
        )),
      ]),
    );
  }

  Future<void> _startCall({required bool video}) async {
    final ok = await requestCallPermissions(context, video: video);
    if (!ok || !mounted) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
      final chat = await chatRef.get();
      final users = List<String>.from(chat.data()?['users'] ?? const []);
      final calleeUid = users.firstWhere((id) => id != uid, orElse: () => '');
      if (calleeUid.isEmpty) throw Exception('Não foi possível encontrar a outra pessoa da conversa.');
      final me = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final otherUser = await FirebaseFirestore.instance.collection('users').doc(calleeUid).get();
      final callRef = chatRef.collection('calls').doc();
      await callRef.set({
        'callId': callRef.id,
        'callerUid': uid,
        'calleeUid': calleeUid,
        'callerName': (me.data()?['name'] ?? 'LoveMix').toString(),
        'callerPhotoUrl': (me.data()?['photoUrl'] ?? '').toString(),
        'calleePhotoUrl': (otherUser.data()?['photoUrl'] ?? '').toString(),
        'participants': [uid, calleeUid],
        'video': video,
        'status': 'ringing',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => CallScreen(callRef: callRef, video: video, isCaller: true),
      ));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível iniciar a chamada: $e')),
        );
      }
    }
  }
}
