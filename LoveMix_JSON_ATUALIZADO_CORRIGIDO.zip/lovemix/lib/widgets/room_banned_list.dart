import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/data_service.dart';

/// Lista de pessoas banidas da sala (expulsas pelo anfitrião) com botão de desbanir.
/// Quem foi banido só consegue entrar de novo depois de ser desbanido aqui.
Future<void> showBannedUsersSheet(BuildContext context, String roomId) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF1B1028),
    builder: (ctx) => SafeArea(
      child: SizedBox(
        height: MediaQuery.of(ctx).size.height * .6,
        child: Column(children: [
          const SizedBox(height: 16),
          const Text('Banidos da sala',
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Só voltam a entrar se você desbanir',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
          const Divider(color: Colors.white12),
          Expanded(
            child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance.collection('rooms').doc(roomId).snapshots(),
              builder: (_, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB)));
                }
                final banned = List<String>.from(snap.data!.data()?['bannedUsers'] ?? const []);
                if (banned.isEmpty) {
                  return const Center(
                    child: Text('Ninguém banido.', style: TextStyle(color: Colors.white60)),
                  );
                }
                return ListView.builder(
                  itemCount: banned.length,
                  itemBuilder: (_, i) {
                    final id = banned[i];
                    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      future: FirebaseFirestore.instance.collection('users').doc(id).get(),
                      builder: (_, u) {
                        final name = (u.data?.data()?['name'] ?? 'Usuário').toString();
                        final photo = (u.data?.data()?['photoUrl'] ?? '').toString();
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: const Color(0x33FFFFFF),
                            backgroundImage: photo.isEmpty ? null : NetworkImage(photo),
                            child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white70) : null,
                          ),
                          title: Text(name, style: const TextStyle(color: Colors.white)),
                          trailing: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFFFFD66B),
                              side: const BorderSide(color: Color(0xFFFFD66B)),
                              visualDensity: VisualDensity.compact,
                            ),
                            onPressed: () async {
                              try {
                                await DataService.instance.unbanRoomMember(roomId, id);
                                if (ctx.mounted) {
                                  ScaffoldMessenger.of(ctx).showSnackBar(
                                    SnackBar(content: Text('$name foi desbanido e pode entrar de novo.')),
                                  );
                                }
                              } catch (e) {
                                if (ctx.mounted) {
                                  ScaffoldMessenger.of(ctx).showSnackBar(
                                    SnackBar(content: Text('Não foi possível desbanir: ${e.toString().replaceFirst('Exception: ', '')}')),
                                  );
                                }
                              }
                            },
                            child: const Text('Desbanir'),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ]),
      ),
    ),
  );
}
