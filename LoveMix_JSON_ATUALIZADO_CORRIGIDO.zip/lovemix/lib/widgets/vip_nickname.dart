import 'package:flutter/material.dart';

class VipNickname extends StatelessWidget {
  const VipNickname({super.key, required this.name, this.isVip = false, this.styleId = 'royal_gold', this.textStyle});
  final String name;
  final bool isVip;
  final String styleId;
  final TextStyle? textStyle;

  static const styles = <String, Map<String, Object>>{
    'royal_gold': {'label':'Coroa Real','left':'♛','right':'†','colors':[Color(0xFFFFE08A),Color(0xFFFFB52E)]},
    'purple_king': {'label':'Rei Roxo','left':'♛','right':'✦','colors':[Color(0xFFD88BFF),Color(0xFF8D35FF)]},
    'pink_love': {'label':'Love Rosa','left':'♥','right':'♥','colors':[Color(0xFFFF8BCB),Color(0xFFFF19B8)]},
    'blue_legend': {'label':'Lenda Azul','left':'♛','right':'†','colors':[Color(0xFF83E7FF),Color(0xFF368CFF)]},
    'red_flame': {'label':'Chama','left':'♛','right':'†','colors':[Color(0xFFFFA06B),Color(0xFFFF3B55)]},
    'emerald': {'label':'Esmeralda','left':'♛','right':'✧','colors':[Color(0xFF8DFFD0),Color(0xFF19B887)]},
    'silver_moon': {'label':'Lua Prateada','left':'☾','right':'☽','colors':[Color(0xFFE9E7FF),Color(0xFF9C9CDA)]},
    'cosmic_fire': {'label':'Fogo Cósmico','left':'♨','right':'♨','colors':[Color(0xFFFFD36E),Color(0xFFFF542E)]},
    'blue_diamond': {'label':'Diamante Azul','left':'◆','right':'◆','colors':[Color(0xFFB8F4FF),Color(0xFF258BFF)]},
    'sakura_bloom': {'label':'Flor de Cerejeira','left':'✿','right':'✿','colors':[Color(0xFFFFD0E8),Color(0xFFFF65B8)]},
    'rainbow': {'label':'Arco-Íris','left':'🌈','right':'🌈','colors':[Color(0xFFFFA6E7),Color(0xFF75D9FF)]},
    'golden_comet': {'label':'Cometa Dourado','left':'☄','right':'✦','colors':[Color(0xFFFFF0A8),Color(0xFFFFA52E)]},
    'crystal_ice': {'label':'Gelo Cristal','left':'❄','right':'❄','colors':[Color(0xFFE0FAFF),Color(0xFF52BFFF)]},
    'ruby_dragon': {'label':'Dragão Rubi','left':'♜','right':'♜','colors':[Color(0xFFFFB0B8),Color(0xFFDC183F)]},
    'star_cloud': {'label':'Nuvem de Estrelas','left':'☁','right':'☁','colors':[Color(0xFFFFE9C7),Color(0xFFCE9BFF)]},
    'sky_butterfly': {'label':'Borboleta Celeste','left':'🦋','right':'🦋','colors':[Color(0xFFC5F4FF),Color(0xFF687BFF)]},
    'emerald_aura': {'label':'Aura Esmeralda','left':'❖','right':'❖','colors':[Color(0xFFD7FF9D),Color(0xFF22B96D)]},
    'galaxy': {'label':'Galáxia','left':'✧','right':'✧','colors':[Color(0xFFE0B8FF),Color(0xFF7652FF)]},
    'vip_wings': {'label':'Asas VIP','left':'🪽','right':'🪽','colors':[Color(0xFFFFB7F0),Color(0xFFFF3BC8)]},
    'golden_star': {'label':'Estrela Dourada','left':'★','right':'✦','colors':[Color(0xFFFFF1A8),Color(0xFFFFB21C)]},
    'enchanted_rose': {'label':'Rosa Encantada','left':'🌹','right':'🌹','colors':[Color(0xFFFFA0B4),Color(0xFFE51E48)]},
    'purple_butterfly': {'label':'Borboleta Roxa','left':'🦋','right':'🦋','colors':[Color(0xFFE2B8FF),Color(0xFF923BFF)]},
  };

  @override
  Widget build(BuildContext context) {
    final base = textStyle ?? const TextStyle(fontSize: 14, fontWeight: FontWeight.w800);
    if (!isVip) return Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: base);
    final style = styles[styleId] ?? styles['royal_gold']!;
    final colors = style['colors'] as List<Color>;
    // A decoração usa uma única cor sólida em todos os elementos do Nick.
    final solidColor = colors.last;
    return Text('${style['left']}  $name  ${style['right']}', maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: base.copyWith(color: solidColor, shadows: [
        Shadow(color: solidColor.withOpacity(.8), blurRadius: 8),
      ]));
  }
}
