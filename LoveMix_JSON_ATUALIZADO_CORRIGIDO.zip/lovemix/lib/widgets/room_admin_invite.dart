import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/data_service.dart';

/// Escuta o convite de administrador da sala e mostra "Aceitar / Recusar".
/// Só vira administrador quem aceitar.
class RoomAdminInviteWatcher {
  RoomAdminInviteWatcher(this._state, this.roomId);

  final State _state;
  final String roomId;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _sub;
  bool _showing = false;

  void start() {
    final uid = DataService.instance.uid;
    _sub = FirebaseFirestore.instance
        .collection('rooms')
        .doc(roomId)
        .collection('adminInvites')
        .doc(uid)
        .snapshots()
        .listen((snap) async {
      final data = snap.data();
      if (!snap.exists || data == null || data['status'] != 'pending') return;
      if (_showing || !_state.mounted) return;
      _showing = true;
      try {
        final accept = await showDialog<bool>(
          context: _state.context,
          barrierDismissible: false,
          builder: (dctx) => AlertDialog(
            backgroundColor: const Color(0xFF241331),
            title: const Text('Convite de administrador 👑',
                style: TextStyle(color: Colors.white)),
            content: const Text(
              'O anfitrião quer que você seja administrador desta sala. '
              'Você terá as mesmas funções dele: expulsar e banir, desbanir, '
              'bloquear bate-papo e entrada, trocar nome e papel de parede '
              '(só não pode encerrar a sala nem dar administrador a outras pessoas). '
              'Deseja aceitar?',
              style: TextStyle(color: Colors.white70),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dctx, false),
                child: const Text('Recusar'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF2DAB)),
                onPressed: () => Navigator.pop(dctx, true),
                child: const Text('Aceitar'),
              ),
            ],
          ),
        );
        if (accept == true) {
          await DataService.instance.acceptRoomAdminInvite(roomId);
          _toast('Você agora é administrador da sala.');
        } else {
          await DataService.instance.declineRoomAdminInvite(roomId);
          _toast('Convite recusado.');
        }
      } catch (e) {
        _toast('Não foi possível responder: ${e.toString().replaceFirst('Exception: ', '')}');
      } finally {
        _showing = false;
      }
    }, onError: (_) {});
  }

  void _toast(String text) {
    if (!_state.mounted) return;
    ScaffoldMessenger.of(_state.context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  void dispose() => _sub?.cancel();
}
