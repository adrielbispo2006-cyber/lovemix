# Carisma sobe enquanto a pessoa usa o app

- Com o app aberto (tela principal ativa), o carisma do perfil ganha +1 a cada minuto.
- Ao minimizar/fechar o app, a contagem para.
- Sem Cloud Functions. Mas precisa publicar o `firestore.rules` UMA vez:
  Firebase Console > Firestore Database > Regras > cole o arquivo > Publicar.
- Segurança: as regras só aceitam +1 por vez, com hora do servidor e mínimo de ~50 s entre pontos
  (máximo ~1.440 pontos por dia por conta).
- Sem publicar as regras, o app continua normal e apenas não soma carisma.
