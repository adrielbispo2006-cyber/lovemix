# Correcoes LoveMix — Chat, lives e PV

## O que foi alterado

1. **Apagar conversa da lista:** cada conversa tem o menu `⋮` > `Apagar conversa`. A exclusao e somente para a conta atual; nao apaga o historico da outra pessoa.
2. **Banimento em sala/live:** a verificacao de `bannedUsers` agora ocorre antes de aceitar que a conta ja consta em `members`. Isso corrige o caso em que um usuario banido anteriormente continuava conseguindo reabrir a sala.
3. **PV:** foi incluido um workflow para publicar as Cloud Functions `moderatePrivateChatText` e `moderatePrivateChatImage`. As mensagens de texto e fotos ficam pendentes e so aparecem depois da aprovacao dessas funcoes.

## Como aplicar

1. Extraia o ZIP e envie a pasta `lovemix` para o repositorio GitHub mantendo a estrutura.
2. No GitHub, abra **Actions** e execute **Corrigir PV e moderacao LoveMix**. O repositorio precisa ter o segredo `FIREBASE_SERVICE_ACCOUNT_LOVEMIX_73849` configurado, como os workflows anteriores.
3. Execute **Gerar APK LoveMix** para compilar o aplicativo atualizado e instale o novo APK.

## Importante

- O APK antigo nao recebe essas alteracoes automaticamente.
- A exclusao de conversa e local para o usuario que a executa; a outra pessoa continua com a conversa.
- O bloqueio de entrada depende de o anfitriao/administrador usar **Expulsar e banir** na sala. Para liberar novamente, o dono deve desbanir a conta.
- Nao foi possivel executar `flutter analyze` neste ambiente porque o Flutter/Dart SDK nao esta instalado. Compile pelo workflow do GitHub antes de distribuir o APK.
