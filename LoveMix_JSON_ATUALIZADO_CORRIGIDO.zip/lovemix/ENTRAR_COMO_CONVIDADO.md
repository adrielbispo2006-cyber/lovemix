ACESSO COMO CONVIDADO — LOVEMIX

A tela inicial agora oferece “Entrar como convidado”. O usuário informa um apelido e a data de nascimento; o app valida a idade mínima de 18 anos, cria uma sessão Firebase Authentication anônima e gera o perfil inicial no Firestore com o campo isGuest=true.

CONFIGURAÇÃO OBRIGATÓRIA NO FIREBASE
1. Abra Firebase Console > Authentication > Sign-in method (ou Provedores de login).
2. Ative o provedor “Anônimo” / “Anonymous”.
3. Confirme que o Cloud Firestore está ativo e que as regras permitem ao usuário autenticado criar/ler/atualizar o próprio documento em users/{uid}.
4. Gere um novo APK depois de atualizar o projeto.

IMPORTANTE
- A sessão anônima fica associada à instalação/aparelho e não é recuperável por e-mail caso o usuário desinstale o app, limpe os dados ou saia da conta.
- Para uso permanente, o próximo passo recomendado é adicionar a opção “Vincular e-mail” para converter a conta anônima em uma conta recuperável sem perder o perfil.
- O acesso como convidado também exige confirmação de 18 anos ou mais, seguindo a regra já aplicada ao cadastro do LoveMix.
