# Presentes diretos com moedas e diamantes

O fluxo das salas LoveMix usa a função Firebase `sendRoomGift`:
- não cria postagem no feed;
- valida o saldo no servidor;
- desconta moedas ou diamantes da conta de quem envia;
- grava o presente diretamente nas mensagens da sala;
- credita a recompensa ao anfitrião e atualiza o baú da sala conforme as regras existentes.

## Publicar a função
1. Envie o conteúdo deste ZIP ao repositório GitHub mantendo a pasta `lovemix/`.
2. Em GitHub > Settings > Secrets and variables > Actions, confirme que existe o secret
   `FIREBASE_SERVICE_ACCOUNT_LOVEMIX_73849`.
3. Abra Actions > **Publicar envio direto de presentes LoveMix** > Run workflow.
4. Aguarde a publicação da função `sendRoomGift` terminar com sucesso.

O APK sozinho não publica Cloud Functions. Se a função ainda não estiver publicada no Firebase,
o botão de enviar não conseguirá concluir a operação.
