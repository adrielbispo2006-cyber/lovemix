import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  @override
  void dispose() { input.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const CircleAvatar(radius: 17, backgroundColor: Color(0xFF47205F), child: Icon(Icons.person, color: Color(0xFFFF2DAB), size: 19)),
          const SizedBox(width: 9),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.otherName, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            const Text('● Online', style: TextStyle(fontSize: 10, color: Color(0xFF22D68A))),
          ]),
        ]),
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder(
            stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              return ListView.builder(
                reverse: false,
                padding: const EdgeInsets.all(14),
                itemCount: docs.length,
                itemBuilder: (context, i) {
                  final m = docs[i].data();
                  final mine = m['senderId'] == FirebaseAuth.instance.currentUser!.uid;
                  return Align(
                    alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 5),
                      padding: const EdgeInsets.all(12),
                      constraints: const BoxConstraints(maxWidth: 280),
                      decoration: BoxDecoration(
                        color: mine ? const Color(0xFF7621C9) : const Color(0xFF241A31),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text((m['text'] ?? '').toString(), style: const TextStyle(color: Colors.white)),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'Digite uma mensagem...', isDense: true))),
              IconButton(
                icon: const Icon(Icons.send, color: Color(0xFFFF2DAB)),
                onPressed: () async {
                  final text = input.text;
                  input.clear();
                  await service.sendMessage(widget.chatId, text);
                },
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
