import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';

class DataService {
  DataService._();
  static final instance = DataService._();
  final db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> createUser({
    required String name,
    required DateTime birthday,
    String bio = '',
  }) async {
    final user = FirebaseAuth.instance.currentUser!;
    final publicId = 'LM-${sha256.convert(utf8.encode(user.uid)).toString().substring(0, 12).toUpperCase()}';
    await db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'publicId': publicId,
      'name': name.trim(),
      'birthday': Timestamp.fromDate(birthday),
      'bio': bio,
      'photoUrl': '',
      'city': '',
      'country': '',
      'interests': <String>[],
      'coins': 100,
      'diamonds': 0,
      'profileVisibility': 'public',
      'postVisibility': 'public',
      'isVip': false,
      'isAdmin': false,
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': true,
      'isOnline': false,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }


  Future<void> setOnlineStatus(bool online) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(user.uid).set({
      'isOnline': online,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> ensurePublicId() async {
    final userId = uid;
    final ref = db.collection('users').doc(userId);
    final snap = await ref.get();
    if (!snap.exists) return;
    final current = (snap.data()?['publicId'] ?? '').toString().trim();
    if (current.isNotEmpty) return;
    final publicId = 'LM-${sha256.convert(utf8.encode(userId)).toString().substring(0, 12).toUpperCase()}';
    await ref.set({'publicId': publicId}, SetOptions(merge: true));
  }

  Future<QuerySnapshot<Map<String, dynamic>>> findUserByPublicId(String value) =>
      db.collection('users').where('publicId', isEqualTo: value.trim().toUpperCase()).limit(1).get();

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() =>
      db.collection('users').doc(uid).snapshots();

  Future<void> updateProfile(Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set(data, SetOptions(merge: true));

  Stream<QuerySnapshot<Map<String, dynamic>>> discoverUsers() =>
      db.collection('users')
          .where('isActive', isEqualTo: true)
          .where('profileVisibility', isEqualTo: 'public')
          .limit(500)
          .snapshots();

  Future<void> pass(String targetUid) async {
    if (targetUid == uid) return;
    await db.collection('users').doc(uid).collection('passed').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<bool> like(String targetUid) async {
    final callable = FirebaseFunctions.instance.httpsCallable('likeUser');
    final result = await callable.call({'targetUid': targetUid});
    return result.data is Map && result.data['matched'] == true;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myMatches() => db
      .collection('matches')
      .where('users', arrayContains: uid)
      .orderBy('lastMessageAt', descending: true)
      .snapshots();

  CollectionReference<Map<String, dynamic>> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages');



  CollectionReference<Map<String, dynamic>> roomMessages(String roomId) =>
      db.collection('rooms').doc(roomId).collection('messages');

  Stream<QuerySnapshot<Map<String, dynamic>>> publicRooms() => db
      .collection('rooms').where('isPublic', isEqualTo: true)
      .orderBy('createdAt', descending: true).limit(50).snapshots();

  Future<String> createRoom(String name, {bool isPublic = true, String category = 'Amizades', String description = '', String password = ''}) async {
    final clean = name.trim();
    if (clean.length < 3 || clean.length > 40) {
      throw Exception('O nome da sala deve ter entre 3 e 40 caracteres.');
    }
    if (!isPublic && password.trim().length < 4) {
      throw Exception('A senha da sala privada deve ter pelo menos 4 caracteres.');
    }
    final ref = await db.collection('rooms').add({
      'name': clean,
      'ownerId': uid,
      'members': [uid],
      'isPublic': isPublic,
      'category': category,
      'description': description.trim(),
      'passwordHash': isPublic ? null : sha256.convert(utf8.encode(password.trim())).toString(),
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': 'Sala criada. Dê boas-vindas!',
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> joinRoom(String roomId) async {
    await db.collection('rooms').doc(roomId).update({
      'members': FieldValue.arrayUnion([uid]),
    });
  }

  CollectionReference<Map<String, dynamic>> roomSeats(String roomId) =>
      db.collection('rooms').doc(roomId).collection('seats');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchRoomSeats(String roomId) =>
      roomSeats(roomId).snapshots();

  Future<void> takeRoomSeat(String roomId, int seatNumber) async {
    if (seatNumber < 1 || seatNumber > 8) {
      throw Exception('Assento inválido.');
    }
    final seats = roomSeats(roomId);
    await db.runTransaction((transaction) async {
      final refs = List.generate(8, (i) => seats.doc('${i + 1}'));
      final snapshots = <DocumentSnapshot<Map<String, dynamic>>>[];
      for (final ref in refs) {
        snapshots.add(await transaction.get(ref));
      }
      for (var i = 0; i < snapshots.length; i++) {
        final data = snapshots[i].data();
        if (data != null && data['uid'] == uid && i + 1 != seatNumber) {
          transaction.delete(refs[i]);
        }
        if (i + 1 == seatNumber && snapshots[i].exists && data?['uid'] != uid) {
          throw Exception('Esse assento já está ocupado. Escolha outro.');
        }
      }
      transaction.set(refs[seatNumber - 1], {
        'uid': uid,
        'seatNumber': seatNumber,
        'micOn': false,
        'joinedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> leaveRoomSeat(String roomId) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    for (final seat in ownSeat.docs) {
      await seat.reference.delete();
    }
  }

  Future<void> setRoomSeatMic(String roomId, bool enabled) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    if (ownSeat.docs.isEmpty) return;
    await ownSeat.docs.first.reference.update({'micOn': enabled});
  }

  Future<void> sendRoomMessage(String roomId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 1000) return;
    final room = db.collection('rooms').doc(roomId);
    await roomMessages(roomId).add({
      'senderId': uid, 'text': clean, 'type': 'text',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await room.update({'lastMessage': clean, 'lastMessageAt': FieldValue.serverTimestamp()});
  }

  Future<void> sendRoomGift(String roomId, String recipientUid, String giftId,
      String emoji, String giftName) async {
    final callable = FirebaseFunctions.instance.httpsCallable('sendRoomGift');
    await callable.call(<String, dynamic>{
      'roomId': roomId,
      'recipientUid': recipientUid,
      'giftId': giftId,
    });
  }

  Future<void> blockUser(String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode bloquear sua própria conta.');
    await db.collection('users').doc(uid).collection('blocked').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> reportUser(String targetUid, String reason, {String details = ''}) async {
    final cleanReason = reason.trim();
    if (targetUid == uid || cleanReason.isEmpty) {
      throw Exception('Selecione um motivo válido para a denúncia.');
    }
    await db.collection('reports').add({
      'reporterId': uid,
      'reportedUserId': targetUid,
      'reason': cleanReason,
      'details': details.trim(),
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteMyAccount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(uid).delete();
    await user.delete();
  }

  Future<void> sendMessage(String chatId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    final chat = db.collection('chats').doc(chatId);
    // O chat é criado pela Cloud Function no momento do match.
    // Aqui atualizamos somente o chat existente; não criamos conversas arbitrárias.
    await chat.update({
      'lastMessage': clean,
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    await messages(chatId).add({
      'senderId': uid,
      'text': clean,
      'createdAt': FieldValue.serverTimestamp(),
      'type': 'text',
    });
  }
}
