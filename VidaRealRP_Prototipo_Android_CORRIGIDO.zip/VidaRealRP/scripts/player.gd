extends CharacterBody3D

const SPEED := 6.0
const JUMP_VELOCITY := 5.0
var move_input := Vector2.ZERO
var camera_pivot: Node3D
var camera: Camera3D
var sync_timer := 0.0

func _ready() -> void:
	_build_avatar()
	camera.current = is_multiplayer_authority()

func _build_avatar() -> void:
	var body := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.42
	capsule.height = 1.8
	body.mesh = capsule
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.55, 0.08, 0.65) if is_multiplayer_authority() else Color(0.06, 0.42, 0.55)
	mat.metallic = 0.18
	mat.roughness = 0.5
	body.material_override = mat
	body.position.y = 0.9
	add_child(body)
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.42
	shape.height = 1.8
	collision.shape = shape
	collision.position.y = 0.9
	add_child(collision)
	var tag := Label3D.new()
	tag.text = "VOCÊ" if is_multiplayer_authority() else "JOGADOR"
	tag.position.y = 2.15
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.font_size = 30
	tag.modulate = Color(1.0, 0.55, 0.9)
	add_child(tag)
	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0, 1.5, 0)
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 2.1, 6.5)
	camera.rotation_degrees.x = -13
	camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	var input_dir := move_input
	if input_dir == Vector2.ZERO:
		input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := Vector3(input_dir.x, 0, input_dir.y).normalized()
	if direction.length() > 0.01:
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
		rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), delta * 9.0)
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED * 5.0 * delta)
		velocity.z = move_toward(velocity.z, 0, SPEED * 5.0 * delta)
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = JUMP_VELOCITY
	move_and_slide()
	sync_timer += delta
	if sync_timer >= 0.08 and multiplayer.has_multiplayer_peer():
		sync_timer = 0.0
		var root := get_tree().current_scene
		if multiplayer.is_server():
			root.relay_transform.rpc(get_multiplayer_authority(), global_transform)
		else:
			root.submit_transform.rpc_id(1, get_multiplayer_authority(), global_transform)
