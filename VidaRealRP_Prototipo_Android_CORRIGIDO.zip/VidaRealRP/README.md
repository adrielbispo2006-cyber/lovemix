# Vida Real RP — protótipo Android multiplayer

Protótipo 3D em Godot 4.3 com cidade noturna neon, personagem em terceira pessoa, botões de toque, criação/entrada em sala e sincronização inicial de posição via ENet.

## Abrir
1. Instale Godot 4.3 (ou versão compatível 4.x) no computador.
2. Importe `project.godot` e execute a cena principal.
3. Para testar na mesma rede, execute duas instâncias: em uma, toque **CRIAR SALA**; na outra, informe o IP local do host e toque **ENTRAR NA SALA**.
4. No computador, use WASD e Espaço. No Android, use os botões na tela.

## Multiplayer
O protótipo usa ENet/UDP na porta 2456, com limite inicial de 32 jogadores por sala. `127.0.0.1` só conecta à mesma máquina. Para internet, é necessário hospedar um servidor público, liberar UDP 2456 e configurar autenticação, persistência, reconexão, moderação e proteção contra trapaças. O botão **CRIAR SALA** cria uma sessão hospedada pelo próprio dispositivo; isso não substitui servidores dedicados para um lançamento público.

## Gerar APK
O workflow `.github/workflows/android.yml` exporta um APK de teste arm64 pelo GitHub Actions. No primeiro uso, confira os logs do Actions e a configuração dos templates Android do Godot. O APK gerado é de depuração e não está assinado para publicação na Play Store.

## Estado do projeto
É uma base inicial jogável para evoluir. Não inclui ainda carros dirigíveis, interiores, casas compráveis, empregos, economia persistente, contas, chat, voz, animações finais, anti-cheat nem infraestrutura de servidores públicos. Os avatares e prédios são formas 3D provisórias.
