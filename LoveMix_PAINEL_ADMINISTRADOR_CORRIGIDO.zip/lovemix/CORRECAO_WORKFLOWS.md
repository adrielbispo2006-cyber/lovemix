CORREÇÃO DE WORKFLOWS — LOVEMIX

O workflow principal mantido é .github/workflows/main.yml.
O workflow duplicado build.yml foi renomeado para build.yml.disabled para impedir que o GitHub Actions o execute automaticamente.
O conteúdo original foi preservado; para reativá-lo, renomeie o arquivo para build.yml, depois de revisar as configurações.

Esta alteração evita dois pipelines de APK concorrentes com configurações Android diferentes. Nenhum código Dart, configuração Firebase, recurso ou tela do aplicativo foi alterado.

Observação: esta correção não equivale a uma compilação validada. Execute o workflow main.yml no GitHub Actions e confira o resultado.
