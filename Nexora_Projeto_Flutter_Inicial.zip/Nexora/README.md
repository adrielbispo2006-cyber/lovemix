# Nexora

Projeto Flutter independente do LoveMix para uma loja própria de aplicativos Android.

## O que já está no projeto
- Interface escura com identidade roxa/violeta.
- Vitrine de aplicativos, busca e detalhes.
- Painel administrativo dentro do próprio app.
- Seleção e envio de APK para Supabase Storage.
- Cadastro de metadados no banco Supabase.
- Download do APK e abertura do instalador Android.

## Requisitos
- Flutter stable instalado.
- Projeto Supabase.
- Android Studio/Android SDK para compilar localmente, ou GitHub Actions.

## Configuração do Supabase
1. Crie um projeto em https://supabase.com.
2. Abra SQL Editor e execute `supabase/schema.sql`.
3. Em Authentication > Users, crie o usuário que será usado no painel administrativo.
4. Copie o UUID desse usuário e execute no SQL Editor: `insert into public.admin_users (user_id) values ('UUID_DO_USUARIO');`
5. Copie Project URL e anon/public key.
6. Compile passando as variáveis:
   `flutter build apk --release --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA`

## Segurança antes de publicar para o público
O SQL restringe publicação e upload aos UUIDs cadastrados em `admin_users`. Cadastre apenas sua conta nessa tabela. Nunca coloque a `service_role` key dentro do aplicativo. A chave anon/public pode estar no app, com RLS corretamente configurado.

## Observações
- O Android pode pedir autorização para instalar apps desta fonte. O usuário precisa permitir a instalação nas configurações do Android.
- O Nexora não ignora o aviso de instalação do Android.
- O arquivo APK fica no Storage e o catálogo no banco; assim os aplicativos publicados podem aparecer em outros celulares.
- Esta é a base inicial do projeto. Configure as credenciais e valide as políticas de segurança antes de distribuir.
