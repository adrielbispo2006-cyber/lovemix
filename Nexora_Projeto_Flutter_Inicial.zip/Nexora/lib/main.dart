import 'dart:io';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const configured = supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (configured) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const NexoraApp());
}

class NexoraApp extends StatelessWidget {
  const NexoraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Nexora',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF090812),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF9B4DFF), brightness: Brightness.dark),
      useMaterial3: true,
      cardTheme: CardThemeData(color: const Color(0xFF171326), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: const StoreHome(),
  );
}

class StoreHome extends StatefulWidget {
  const StoreHome({super.key});
  @override
  State<StoreHome> createState() => _StoreHomeState();
}

class _StoreHomeState extends State<StoreHome> {
  int tab = 0;
  String search = '';
  bool loading = false;
  List<Map<String, dynamic>> apps = [];
  final searchController = TextEditingController();

  SupabaseClient? get db => configured ? Supabase.instance.client : null;

  @override
  void initState() { super.initState(); loadApps(); }

  Future<void> loadApps() async {
    if (db == null) { setState(() { apps = demoApps; }); return; }
    setState(() => loading = true);
    try {
      final rows = await db!.from('apps').select().eq('published', true).order('created_at', ascending: false);
      setState(() => apps = List<Map<String, dynamic>>.from(rows));
    } catch (_) {
      setState(() => apps = demoApps);
    } finally { if (mounted) setState(() => loading = false); }
  }

  List<Map<String, dynamic>> get visibleApps {
    final q = search.toLowerCase().trim();
    if (q.isEmpty) return apps;
    return apps.where((a) => ('${a['name']} ${a['description']} ${a['category']}').toLowerCase().contains(q)).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [Icon(Icons.hexagon_rounded, color: Color(0xFFB66CFF)), SizedBox(width: 9), Text('NEXORA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2))]),
        actions: [IconButton(tooltip: 'Atualizar', onPressed: loadApps, icon: const Icon(Icons.refresh)), IconButton(tooltip: 'Administração', onPressed: openAdmin, icon: const Icon(Icons.admin_panel_settings_outlined))],
      ),
      body: tab == 2 ? const AboutPage() : Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 12), child: Container(
          padding: const EdgeInsets.all(18), decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF35105E), Color(0xFF17132D), Color(0xFF102D4A)]),
            border: Border.all(color: const Color(0xFF7441A8).withOpacity(.5))),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SEU UNIVERSO DIGITAL', style: TextStyle(color: Color(0xFFD7B5FF), fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
            SizedBox(height: 8), Text('Descubra seu próximo app.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
            SizedBox(height: 4), Text('Aplicativos independentes em um só lugar.', style: TextStyle(color: Colors.white70)),
          ]),
        )),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(
          controller: searchController, onChanged: (v) => setState(() => search = v),
          decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Buscar aplicativos...', filled: true, fillColor: const Color(0xFF171326), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
        )),
        const SizedBox(height: 14),
        Expanded(child: loading ? const Center(child: CircularProgressIndicator()) : visibleApps.isEmpty
          ? const Center(child: Text('Nenhum aplicativo encontrado.'))
          : RefreshIndicator(onRefresh: loadApps, child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 20), children: [
              const Text('APLICATIVOS', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.5, color: Color(0xFFCC9BFF))),
              const SizedBox(height: 8),
              ...visibleApps.map((a) => AppTile(app: a, onTap: () => openDetails(a))),
            ]))),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Loja'), NavigationDestination(icon: Icon(Icons.download_outlined), label: 'Downloads'), NavigationDestination(icon: Icon(Icons.info_outline), label: 'Sobre')],
      ),
    );
  }

  void openDetails(Map<String, dynamic> app) => showModalBottomSheet(
    context: context, isScrollControlled: true, backgroundColor: const Color(0xFF171326),
    builder: (_) => AppDetails(app: app),
  );

  Future<void> openAdmin() async {
    if (!configured) {
      showMessage('Configure o Supabase para ativar login, publicação e downloads compartilhados.');
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()));
    loadApps();
  }

  void showMessage(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
}

class AppTile extends StatelessWidget {
  final Map<String, dynamic> app; final VoidCallback onTap;
  const AppTile({super.key, required this.app, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(
    contentPadding: const EdgeInsets.all(12), onTap: onTap,
    leading: Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFF30204B), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.apps_rounded, color: Color(0xFFD5A8FF), size: 30)),
    title: Text('${app['name'] ?? 'Aplicativo'}', style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text('${app['description'] ?? 'Aplicativo disponível na Nexora.'}', maxLines: 2, overflow: TextOverflow.ellipsis),
    trailing: const Icon(Icons.chevron_right),
  ));
}

class AppDetails extends StatelessWidget {
  final Map<String, dynamic> app;
  const AppDetails({super.key, required this.app});
  @override
  Widget build(BuildContext context) => SafeArea(child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const CircleAvatar(radius: 30, backgroundColor: Color(0xFF382052), child: Icon(Icons.apps, size: 32, color: Color(0xFFD5A8FF))), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${app['name']}', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), Text('Versão ${app['version'] ?? '1.0.0'} · ${app['category'] ?? 'Geral'}', style: const TextStyle(color: Colors.white60))]))]),
    const SizedBox(height: 18), Text('${app['description'] ?? 'Sem descrição.'}'),
    const SizedBox(height: 20), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () async {
      final url = app['apk_url']?.toString() ?? '';
      if (url.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Arquivo APK ainda não disponível.'))); return; }
      Navigator.pop(context);
      await downloadAndInstall(context, url, '${app['name'] ?? 'nexora'}.apk');
    }, icon: const Icon(Icons.download), label: const Text('BAIXAR APK'))),
  ])));

Future<void> downloadAndInstall(BuildContext context, String url, String filename) async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final safeName = filename.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
    final path = '${dir.path}/$safeName';
    await Dio().download(url, path, onReceiveProgress: (r, t) {});
    final result = await OpenFilex.open(path, type: 'application/vnd.android.package-archive');
    if (result.type != ResultType.done && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('APK baixado. Abra o arquivo para instalar: $path')));
    }
  } catch (e) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível baixar: $e')));
  }
}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});
  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final email = TextEditingController(), password = TextEditingController();
  final name = TextEditingController(), description = TextEditingController(), version = TextEditingController(text: '1.0.0'), category = TextEditingController(text: 'Geral');
  bool busy = false;
  String? selectedPath;
  String? selectedName;
  SupabaseClient get db => Supabase.instance.client;
  bool get logged => db.auth.currentUser != null;

  Future<void> signIn() async {
    setState(() => busy = true);
    try { await db.auth.signInWithPassword(email: email.text.trim(), password: password.text); }
    catch (e) { msg('Falha no login: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> chooseApk() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['apk'], withData: true);
    if (result != null) { setState(() { selectedPath = result.files.single.path; selectedName = result.files.single.name; }); }
  }
  Future<void> publish() async {
    if (name.text.trim().isEmpty || selectedPath == null) { msg('Informe o nome e selecione um APK.'); return; }
    setState(() => busy = true);
    try {
      final bytes = await File(selectedPath!).readAsBytes();
      final objectName = '${DateTime.now().millisecondsSinceEpoch}_${selectedName!}';
      await db.storage.from('apks').uploadBinary(objectName, bytes, fileOptions: const FileOptions(contentType: 'application/vnd.android.package-archive', upsert: false));
      final url = db.storage.from('apks').getPublicUrl(objectName);
      await db.from('apps').insert({'name': name.text.trim(), 'description': description.text.trim(), 'version': version.text.trim(), 'category': category.text.trim(), 'apk_url': url, 'published': true});
      msg('Aplicativo publicado na Nexora!');
      name.clear(); description.clear(); selectedPath = null; selectedName = null;
      setState(() {});
    } catch (e) { msg('Erro ao publicar: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  void msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Painel Nexora')),
    body: !logged ? ListView(padding: const EdgeInsets.all(20), children: [
      const Icon(Icons.admin_panel_settings, size: 60, color: Color(0xFFB66CFF)), const SizedBox(height: 12),
      const Text('Acesso administrativo', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const Text('Entre com a conta de administrador criada no Supabase.'),
      const SizedBox(height: 20),
      TextField(controller: email, decoration: const InputDecoration(labelText: 'E-mail')),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Senha')),
      const SizedBox(height: 18), FilledButton(onPressed: busy ? null : signIn, child: Text(busy ? 'Entrando...' : 'Entrar')),
    ]) : ListView(padding: const EdgeInsets.all(20), children: [
      const Text('PUBLICAR APLICATIVO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, color: Color(0xFFD0A0FF))),
      const SizedBox(height: 14),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome do aplicativo')),
      TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'Descrição')),
      TextField(controller: version, decoration: const InputDecoration(labelText: 'Versão')),
      TextField(controller: category, decoration: const InputDecoration(labelText: 'Categoria')),
      const SizedBox(height: 14),
      OutlinedButton.icon(onPressed: chooseApk, icon: const Icon(Icons.attach_file), label: Text(selectedName ?? 'Selecionar arquivo APK')),
      const SizedBox(height: 14),
      FilledButton.icon(onPressed: busy ? null : publish, icon: const Icon(Icons.cloud_upload), label: Text(busy ? 'Enviando...' : 'Publicar na Nexora')),
      const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: () async { await db.auth.signOut(); setState(() {}); }, icon: const Icon(Icons.logout), label: const Text('Sair da administração')),
      const SizedBox(height: 10), const Text('A publicação exige conexão com a internet e permissões de administrador configuradas no banco.', style: TextStyle(color: Colors.white60)),
    ]),
  );
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Padding(padding: EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(Icons.hexagon, size: 64, color: Color(0xFFB66CFF)), SizedBox(height: 14),
    Text('NEXORA', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 3)),
    SizedBox(height: 8), Text('Sua loja. Seus aplicativos. Seu universo.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
    SizedBox(height: 18), Text('Uma plataforma independente para descobrir e distribuir aplicativos Android.', textAlign: TextAlign.center),
  ])));
}

final demoApps = <Map<String, dynamic>>[
  {'name':'Nexora Demo','description':'Exemplo de como seus aplicativos aparecerão na loja.','version':'1.0.0','category':'Destaque','apk_url':''},
  {'name':'Seus próximos apps','description':'Publique seus próprios APKs pelo painel de administração.','version':'—','category':'Novidades','apk_url':''},
];
