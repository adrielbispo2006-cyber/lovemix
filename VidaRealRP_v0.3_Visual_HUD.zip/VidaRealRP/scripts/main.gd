extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const PORT := 2456
const MAX_PLAYERS := 32
const PURPLE := Color(0.66, 0.30, 1.0)
const JOY_RADIUS := 90.0
const CLUB_POS := Vector3(21.0, 0.0, -34.0)

var players: Dictionary = {}
var player_container: Node3D
var mat_cache: Dictionary = {}
var win_albedo: ImageTexture
var win_emis: ImageTexture

var touch_layer: Control
var chat_label: RichTextLabel
var chat_lines: Array[String] = []
var money := 24567
var money_label: Label
var health_bar: ProgressBar
var info_label: RichTextLabel
var online_panel: PanelContainer
var status_label: Label
var ip_input: LineEdit
var run_button: Button
var mic_button: Button
var minimap_view: SubViewport
var minimap_cam: Camera3D
var minimap_overlay: Control
var hud_timer := 0.0

var joy_index := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var cam_index := -1

func _ready() -> void:
	randomize()
	_build_world()
	_build_ui()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	spawn_player(multiplayer.get_unique_id())

# ---------------------------------------------------------------- MUNDO

func _mat(color: Color, emit := 0.0, rough := 0.8) -> StandardMaterial3D:
	var key := "%s_%s_%s" % [color.to_html(true), emit, rough]
	if mat_cache.has(key):
		return mat_cache[key] as StandardMaterial3D
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if emit > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emit
	mat_cache[key] = m
	return m

func _add_box(label: String, pos: Vector3, size: Vector3, mat: Material, collision := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = label
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	add_child(mi)
	if collision:
		var body := StaticBody3D.new()
		body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		body.add_child(shape_node)
		add_child(body)
	return mi

func _map_box(pos: Vector3, size: Vector3, color: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.layers = 2
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	mi.material_override = m
	add_child(mi)

func _make_window_textures() -> void:
	var cols := 4
	var rows := 8
	var cw := 16
	var ch := 16
	var albedo := Image.create(cols * cw, rows * ch, true, Image.FORMAT_RGBA8)
	var emis := Image.create(cols * cw, rows * ch, true, Image.FORMAT_RGBA8)
	albedo.fill(Color(0.55, 0.55, 0.6))
	emis.fill(Color(0.0, 0.0, 0.0))
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for r in range(rows):
		for c in range(cols):
			var roll := rng.randf()
			var rect := Rect2i(c * cw + 3, r * ch + 3, cw - 6, ch - 5)
			if roll < 0.42:
				albedo.fill_rect(rect, Color(0.1, 0.1, 0.12))
				emis.fill_rect(rect, Color(1.0, 0.82, 0.48))
			elif roll < 0.56:
				albedo.fill_rect(rect, Color(0.1, 0.1, 0.12))
				emis.fill_rect(rect, Color(0.80, 0.90, 1.0))
			else:
				albedo.fill_rect(rect, Color(0.04, 0.05, 0.08))
	albedo.generate_mipmaps()
	emis.generate_mipmaps()
	win_albedo = ImageTexture.create_from_image(albedo)
	win_emis = ImageTexture.create_from_image(emis)

func _build_world() -> void:
	_make_window_textures()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.015, 0.03, 0.15)
	sky_mat.sky_horizon_color = Color(0.18, 0.12, 0.38)
	sky_mat.ground_bottom_color = Color(0.015, 0.015, 0.04)
	sky_mat.ground_horizon_color = Color(0.08, 0.06, 0.16)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.30, 0.28, 0.52)
	env.ambient_light_energy = 0.85
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_bloom = 0.1
	env.fog_enabled = true
	env.fog_light_color = Color(0.12, 0.06, 0.22)
	env.fog_density = 0.004
	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-48.0, -28.0, 0.0)
	moon.light_energy = 0.6
	moon.light_color = Color(0.58, 0.64, 1.0)
	moon.shadow_enabled = true
	moon.directional_shadow_max_distance = 80.0
	add_child(moon)
	_build_roads()
	_build_buildings()
	_build_lamps()
	_build_club()
	_build_nature()
	player_container = Node3D.new()
	player_container.name = "Players"
	add_child(player_container)

func _build_roads() -> void:
	var ground := _mat(Color(0.05, 0.05, 0.07), 0.0, 0.55)
	var road := _mat(Color(0.075, 0.075, 0.09), 0.0, 0.5)
	var walk := _mat(Color(0.30, 0.27, 0.32), 0.0, 0.9)
	var stripe := _mat(Color(0.95, 0.74, 0.30), 1.2, 0.4)
	_add_box("Chao cidade", Vector3(0.0, -0.35, 0.0), Vector3(190.0, 0.5, 190.0), ground, true)
	_add_box("Avenida principal", Vector3(0.0, -0.02, 0.0), Vector3(17.0, 0.08, 190.0), road, true)
	_add_box("Avenida transversal", Vector3(0.0, 0.0, 0.0), Vector3(190.0, 0.08, 17.0), road, true)
	for side in [-1.0, 1.0]:
		var s: float = side
		_add_box("Calcada", Vector3(s * 10.2, 0.12, 0.0), Vector3(3.2, 0.28, 190.0), walk, true)
		_add_box("Calcada", Vector3(0.0, 0.12, s * 10.2), Vector3(190.0, 0.28, 3.2), walk, true)
	for lane in range(-9, 10):
		_add_box("Faixa", Vector3(0.0, 0.055, lane * 9.8), Vector3(0.16, 0.025, 3.8), stripe)
		_add_box("Faixa", Vector3(lane * 9.8, 0.055, 0.0), Vector3(3.8, 0.025, 0.16), stripe)
	_map_box(Vector3(0.0, 0.5, 0.0), Vector3(17.0, 0.1, 190.0), Color(0.20, 0.20, 0.24))
	_map_box(Vector3(0.0, 0.6, 0.0), Vector3(190.0, 0.1, 17.0), Color(0.20, 0.20, 0.24))

func _build_buildings() -> void:
	var roof_mat := _mat(Color(0.12, 0.09, 0.16), 0.0, 0.8)
	var tints: Array[Color] = [Color(0.30, 0.32, 0.50), Color(0.42, 0.34, 0.50), Color(0.28, 0.40, 0.52)]
	for x in range(-5, 6):
		for z in range(-5, 6):
			if abs(x) <= 1 or abs(z) <= 1:
				continue
			var h := randf_range(13.0, 32.0)
			var w := randf_range(8.0, 11.0)
			var d := randf_range(8.0, 11.0)
			var p := Vector3(x * 17.5, h / 2.0, z * 17.5)
			var m := StandardMaterial3D.new()
			m.albedo_texture = win_albedo
			m.albedo_color = tints[randi_range(0, 2)]
			m.emission_enabled = true
			m.emission = Color.WHITE
			m.emission_texture = win_emis
			m.emission_energy_multiplier = 1.8
			m.roughness = 0.6
			m.uv1_scale = Vector3(w / 8.8, h / 25.6, 1.0)
			m.uv1_offset = Vector3(float(randi_range(0, 3)) * 0.25, float(randi_range(0, 7)) * 0.125, 0.0)
			_add_box("Edificio", p, Vector3(w, h, d), m, true)
			_add_box("Cobertura", p + Vector3(0.0, h / 2.0 + 0.25, 0.0), Vector3(w + 0.5, 0.5, d + 0.5), roof_mat)
			var neon_col := Color(0.95, 0.10, 0.65) if (x + z) % 2 == 0 else Color(0.15, 0.55, 1.0)
			_add_box("Letreiro neon", p + Vector3(0.0, -h * 0.25, d / 2.0 + 0.09), Vector3(w * 0.68, 0.42, 0.12), _mat(neon_col, 3.0, 0.4))
			_map_box(Vector3(p.x, 1.0, p.z), Vector3(w, 0.1, d), Color(0.45, 0.52, 0.47))

func _build_lamps() -> void:
	var pole_mat := _mat(Color(0.10, 0.09, 0.12), 0.0, 0.6)
	var lamp_mat := _mat(Color(1.0, 0.66, 0.30), 3.0, 0.4)
	for i in range(-4, 5):
		for side in [-1.0, 1.0]:
			var s: float = side
			var base := Vector3(s * 11.5, 0.0, i * 20.0)
			var pole := MeshInstance3D.new()
			var pm := CylinderMesh.new()
			pm.top_radius = 0.07
			pm.bottom_radius = 0.11
			pm.height = 5.5
			pole.mesh = pm
			pole.material_override = pole_mat
			pole.position = base + Vector3(0.0, 2.75, 0.0)
			add_child(pole)
			var head_pos := base + Vector3(-s * 0.65, 5.6, 0.0)
			_add_box("Luminaria", head_pos, Vector3(1.4, 0.16, 0.35), lamp_mat)
			var lamp := OmniLight3D.new()
			lamp.position = head_pos + Vector3(0.0, -0.4, 0.0)
			lamp.light_color = Color(1.0, 0.62, 0.28)
			lamp.light_energy = 1.8
			lamp.omni_range = 12.0
			add_child(lamp)

func _build_club() -> void:
	var c := CLUB_POS
	var wall := _mat(Color(0.62, 0.60, 0.70), 0.0, 0.7)
	var dark := _mat(Color(0.05, 0.04, 0.08), 0.0, 0.5)
	var glow := _mat(PURPLE, 3.5, 0.3)
	_add_box("Praca", Vector3(c.x, 0.1, c.z + 13.0), Vector3(24.0, 0.2, 14.0), _mat(Color(0.22, 0.20, 0.26), 0.0, 0.9), true)
	_add_box("Clube", Vector3(c.x, 2.5, c.z), Vector3(16.0, 5.0, 10.0), wall, true)
	_add_box("Clube faixa neon", Vector3(c.x, 5.1, c.z + 5.05), Vector3(16.4, 0.18, 0.2), glow)
	for k in range(5):
		_add_box("Clube janela", Vector3(c.x - 6.4 + k * 3.2, 2.4, c.z + 5.04), Vector3(2.0, 2.2, 0.1), dark)
	_build_billboard(Vector3(c.x, 10.3, c.z))
	for lx in [-6.0, 0.0, 6.0]:
		var dx: float = lx
		var l := OmniLight3D.new()
		l.position = Vector3(c.x + dx, 2.2, c.z + 7.0)
		l.light_color = PURPLE
		l.light_energy = 3.0
		l.omni_range = 14.0
		add_child(l)
	_map_box(Vector3(c.x, 1.5, c.z), Vector3(16.0, 0.1, 10.0), PURPLE)

func _build_billboard(center: Vector3) -> void:
	var frame := _mat(Color(0.02, 0.02, 0.03), 0.0, 0.6)
	_add_box("Painel", center, Vector3(13.0, 5.4, 0.5), frame)
	_add_box("Perna painel", center + Vector3(-4.0, -4.0, 0.0), Vector3(0.4, 2.6, 0.4), frame)
	_add_box("Perna painel", center + Vector3(4.0, -4.0, 0.0), Vector3(0.4, 2.6, 0.4), frame)
	var l1 := Label3D.new()
	l1.text = "VIDA REAL"
	l1.font_size = 260
	l1.pixel_size = 0.0058
	l1.outline_size = 24
	l1.outline_modulate = Color(0.30, 0.08, 0.55)
	l1.modulate = Color(1.0, 1.0, 1.0)
	l1.position = center + Vector3(0.0, 0.85, 0.3)
	add_child(l1)
	var l2 := Label3D.new()
	l2.text = "RP"
	l2.font_size = 330
	l2.pixel_size = 0.0058
	l2.outline_size = 24
	l2.outline_modulate = Color(0.12, 0.03, 0.25)
	l2.modulate = PURPLE
	l2.position = center + Vector3(0.0, -1.2, 0.3)
	add_child(l2)
	var bl := OmniLight3D.new()
	bl.position = center + Vector3(0.0, -2.0, 4.0)
	bl.light_color = PURPLE
	bl.light_energy = 2.5
	bl.omni_range = 16.0
	add_child(bl)

func _build_nature() -> void:
	var c := CLUB_POS
	for k in range(6):
		var t := float(k) / 5.0
		_add_palm(Vector3(c.x - 11.0 + t * 22.0, 0.2, c.z + 19.0), randf_range(0.9, 1.2))
	_add_palm(Vector3(c.x - 11.5, 0.2, c.z + 7.0), 1.1)
	_add_palm(Vector3(c.x + 11.5, 0.2, c.z + 7.0), 1.0)
	for i in range(-3, 4):
		if i == 0:
			continue
		_add_palm(Vector3(-12.8, -0.05, i * 22.0 + 10.0), randf_range(0.9, 1.2))
	for i in range(-2, 3):
		_add_pole(Vector3(12.9, 0.0, i * 26.0 - 8.0))

func _add_palm(pos: Vector3, scale_f: float) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees = Vector3(0.0, randf_range(0.0, 360.0), 0.0)
	add_child(root)
	var trunk := MeshInstance3D.new()
	var tm := CylinderMesh.new()
	tm.top_radius = 0.14
	tm.bottom_radius = 0.26
	tm.height = 7.0 * scale_f
	trunk.mesh = tm
	trunk.material_override = _mat(Color(0.20, 0.13, 0.08), 0.0, 0.9)
	trunk.position = Vector3(0.0, tm.height / 2.0, 0.0)
	root.add_child(trunk)
	var crown := Node3D.new()
	crown.position = Vector3(0.0, tm.height, 0.0)
	root.add_child(crown)
	var leaf := _mat(Color(0.04, 0.20, 0.07), 0.0, 0.9)
	for i in range(9):
		var arm := Node3D.new()
		arm.rotation_degrees = Vector3(-22.0, i * 40.0, 0.0)
		crown.add_child(arm)
		var frond := MeshInstance3D.new()
		var fm := BoxMesh.new()
		fm.size = Vector3(0.7, 0.05, 3.4)
		frond.mesh = fm
		frond.material_override = leaf
		frond.position = Vector3(0.0, 0.0, -1.6)
		arm.add_child(frond)

func _add_pole(pos: Vector3) -> void:
	var wood := _mat(Color(0.22, 0.14, 0.09), 0.0, 0.9)
	var pole := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 0.12
	pm.bottom_radius = 0.17
	pm.height = 9.0
	pole.mesh = pm
	pole.material_override = wood
	pole.position = pos + Vector3(0.0, 4.5, 0.0)
	add_child(pole)
	_add_box("Travessa", pos + Vector3(0.0, 8.0, 0.0), Vector3(2.6, 0.15, 0.15), wood)

# ---------------------------------------------------------------- INTERFACE

func _place(c: Control, ax: float, ay: float, l: float, t: float, r: float, b: float) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = l
	c.offset_top = t
	c.offset_right = r
	c.offset_bottom = b

func _round_style(color: Color, radius: float, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(int(radius))
	s.set_border_width_all(3)
	s.border_color = border
	return s

func _make_round_button(text: String, d: float) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(d, d)
	var normal := _round_style(Color(0.04, 0.04, 0.07, 0.72), d / 2.0, Color(1.0, 1.0, 1.0, 0.28))
	var active := _round_style(Color(0.46, 0.16, 0.78, 0.92), d / 2.0, Color(1.0, 1.0, 1.0, 0.7))
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", normal)
	b.add_theme_stylebox_override("focus", normal)
	b.add_theme_stylebox_override("pressed", active)
	b.add_theme_stylebox_override("hover_pressed", active)
	b.add_theme_font_size_override("font_size", 17)
	return b

func _outlined(l: Control, size_px: int) -> void:
	l.add_theme_font_size_override("font_size", size_px)
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color.BLACK)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	touch_layer = Control.new()
	touch_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	touch_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	touch_layer.draw.connect(_draw_touch)
	layer.add_child(touch_layer)

	# chat (canto superior esquerdo)
	var chat_panel := PanelContainer.new()
	chat_panel.position = Vector2(76.0, 12.0)
	chat_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var chat_style := StyleBoxFlat.new()
	chat_style.bg_color = Color(0.0, 0.0, 0.0, 0.35)
	chat_style.set_corner_radius_all(8)
	chat_style.set_content_margin_all(8.0)
	chat_panel.add_theme_stylebox_override("panel", chat_style)
	chat_label = RichTextLabel.new()
	chat_label.bbcode_enabled = true
	chat_label.fit_content = true
	chat_label.scroll_active = false
	chat_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chat_label.custom_minimum_size = Vector2(440.0, 0.0)
	chat_label.add_theme_font_size_override("normal_font_size", 22)
	chat_label.add_theme_constant_override("outline_size", 4)
	chat_label.add_theme_color_override("font_outline_color", Color.BLACK)
	chat_panel.add_child(chat_label)
	layer.add_child(chat_panel)

	var menu_btn := _make_round_button("...", 52.0)
	_place(menu_btn, 0.0, 0.0, 12.0, 12.0, 64.0, 64.0)
	menu_btn.pressed.connect(func(): online_panel.visible = not online_panel.visible)
	layer.add_child(menu_btn)

	# dinheiro, vida e arma (canto superior direito)
	money_label = Label.new()
	money_label.text = "$%08d" % money
	money_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	money_label.add_theme_color_override("font_color", Color(0.45, 0.85, 0.25))
	_outlined(money_label, 42)
	_place(money_label, 1.0, 0.0, -430.0, 8.0, -168.0, 66.0)
	layer.add_child(money_label)

	health_bar = ProgressBar.new()
	health_bar.min_value = 0.0
	health_bar.max_value = 100.0
	health_bar.value = 100.0
	health_bar.show_percentage = false
	var hb_fill := StyleBoxFlat.new()
	hb_fill.bg_color = Color(0.9, 0.05, 0.08)
	var hb_bg := StyleBoxFlat.new()
	hb_bg.bg_color = Color(0.2, 0.0, 0.02, 0.8)
	health_bar.add_theme_stylebox_override("fill", hb_fill)
	health_bar.add_theme_stylebox_override("background", hb_bg)
	_place(health_bar, 1.0, 0.0, -330.0, 70.0, -168.0, 88.0)
	layer.add_child(health_bar)

	var weapon := PanelContainer.new()
	weapon.add_theme_stylebox_override("panel", _round_style(Color(0.05, 0.05, 0.08, 0.75), 18.0, Color(1.0, 1.0, 1.0, 0.7)))
	_place(weapon, 1.0, 0.0, -150.0, 14.0, -18.0, 134.0)
	weapon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var weapon_label := Label.new()
	weapon_label.text = "SOCO"
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	weapon_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_outlined(weapon_label, 28)
	weapon.add_child(weapon_label)
	layer.add_child(weapon)

	# botoes laterais direitos
	mic_button = _make_round_button("MIC", 96.0)
	mic_button.toggle_mode = true
	mic_button.toggled.connect(_on_mic_toggled)
	_place(mic_button, 1.0, 0.5, -120.0, -216.0, -24.0, -120.0)
	layer.add_child(mic_button)
	var car_button := _make_round_button("CARRO", 96.0)
	car_button.pressed.connect(func(): _chat("[color=#ffcc33]Nenhum veículo por perto.[/color]"))
	_place(car_button, 1.0, 0.5, -120.0, -108.0, -24.0, -12.0)
	layer.add_child(car_button)
	var punch_button := _make_round_button("SOCO", 96.0)
	punch_button.pressed.connect(_on_punch)
	_place(punch_button, 1.0, 0.5, -120.0, 0.0, -24.0, 96.0)
	layer.add_child(punch_button)
	run_button = _make_round_button("CORRER", 96.0)
	run_button.toggle_mode = true
	_place(run_button, 1.0, 0.5, -120.0, 108.0, -24.0, 204.0)
	layer.add_child(run_button)
	var jump_button := _make_round_button("PULAR", 110.0)
	jump_button.button_down.connect(func(): Input.action_press("jump"))
	jump_button.button_up.connect(func(): Input.action_release("jump"))
	_place(jump_button, 1.0, 1.0, -260.0, -150.0, -150.0, -40.0)
	layer.add_child(jump_button)

	_build_minimap(layer)

	# FPS / ping
	info_label = RichTextLabel.new()
	info_label.bbcode_enabled = true
	info_label.fit_content = true
	info_label.scroll_active = false
	info_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	info_label.add_theme_font_size_override("normal_font_size", 22)
	info_label.add_theme_font_size_override("bold_font_size", 22)
	info_label.add_theme_constant_override("outline_size", 5)
	info_label.add_theme_color_override("font_outline_color", Color.BLACK)
	_place(info_label, 0.0, 1.0, 16.0, -42.0, 640.0, -8.0)
	layer.add_child(info_label)

	# painel online (abre no botao "...")
	online_panel = PanelContainer.new()
	online_panel.position = Vector2(76.0, 150.0)
	online_panel.custom_minimum_size = Vector2(380.0, 0.0)
	online_panel.visible = false
	online_panel.add_theme_stylebox_override("panel", _round_style(Color(0.04, 0.03, 0.08, 0.92), 14.0, PURPLE))
	var box := VBoxContainer.new()
	online_panel.add_child(box)
	var title := Label.new()
	title.text = "VIDA REAL RP - ONLINE"
	title.add_theme_color_override("font_color", PURPLE)
	box.add_child(title)
	status_label = Label.new()
	status_label.text = "Modo offline. Crie uma sala ou conecte-se."
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(status_label)
	var host := Button.new()
	host.text = "CRIAR SALA"
	host.pressed.connect(_host_game)
	box.add_child(host)
	ip_input = LineEdit.new()
	ip_input.placeholder_text = "IP do servidor"
	ip_input.text = "127.0.0.1"
	box.add_child(ip_input)
	var join := Button.new()
	join.text = "ENTRAR NA SALA"
	join.pressed.connect(_join_game)
	box.add_child(join)
	layer.add_child(online_panel)

	_chat("Conectado ao [color=#b44cff][u]Vida Real RP[/u][/color]!")
	_chat("Bem-vindo, [color=#b44cff]Jogador[/color]!")
	_chat("Aproveite sua experiência!")
	_update_info()

func _build_minimap(layer: CanvasLayer) -> void:
	minimap_view = SubViewport.new()
	minimap_view.size = Vector2i(220, 220)
	minimap_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(minimap_view)
	minimap_cam = Camera3D.new()
	minimap_cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	minimap_cam.size = 80.0
	minimap_cam.near = 0.1
	minimap_cam.far = 120.0
	minimap_cam.cull_mask = 2
	var menv := Environment.new()
	menv.background_mode = Environment.BG_COLOR
	menv.background_color = Color(0.64, 0.70, 0.64)
	minimap_cam.environment = menv
	minimap_view.add_child(minimap_cam)
	minimap_cam.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
	minimap_cam.position = Vector3(0.0, 50.0, 0.0)

	var map_rect := TextureRect.new()
	map_rect.texture = minimap_view.get_texture()
	map_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	map_rect.stretch_mode = TextureRect.STRETCH_SCALE
	map_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var shader := Shader.new()
	shader.code = "shader_type canvas_item;\nvoid fragment() {\n\tvec4 col = texture(TEXTURE, UV);\n\tfloat d = length(UV - vec2(0.5));\n\tCOLOR = vec4(col.rgb, col.a * step(d, 0.5));\n}\n"
	var sm := ShaderMaterial.new()
	sm.shader = shader
	map_rect.material = sm
	_place(map_rect, 0.0, 1.0, 22.0, -262.0, 222.0, -62.0)
	layer.add_child(map_rect)

	minimap_overlay = Control.new()
	minimap_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(minimap_overlay, 0.0, 1.0, 22.0, -262.0, 222.0, -62.0)
	minimap_overlay.draw.connect(_draw_minimap_overlay)
	layer.add_child(minimap_overlay)
	var n_label := Label.new()
	n_label.text = "N"
	n_label.position = Vector2(150.0, 6.0)
	_outlined(n_label, 26)
	minimap_overlay.add_child(n_label)

func _draw_minimap_overlay() -> void:
	var c := minimap_overlay.size / 2.0
	var r := minimap_overlay.size.x / 2.0
	minimap_overlay.draw_arc(c, r - 3.0, 0.0, TAU, 64, Color(0.04, 0.04, 0.06), 7.0, true)
	var p = _local_player()
	var ang := 0.0
	if p != null:
		ang = -float(p.rotation.y)
	var dir := Vector2(0.0, -1.0).rotated(ang)
	var perp := dir.orthogonal()
	var tip := c + dir * 14.0
	var pl := c - dir * 9.0 + perp * 9.0
	var pr := c - dir * 9.0 - perp * 9.0
	minimap_overlay.draw_colored_polygon(PackedVector2Array([tip, pl, pr]), Color(1.0, 1.0, 1.0))

func _draw_touch() -> void:
	if joy_index == -1:
		return
	touch_layer.draw_circle(joy_origin, JOY_RADIUS, Color(1.0, 1.0, 1.0, 0.10))
	touch_layer.draw_arc(joy_origin, JOY_RADIUS, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, 0.35), 3.0, true)
	touch_layer.draw_circle(joy_pos, 34.0, Color(0.70, 0.30, 1.0, 0.55))

func _chat(line: String) -> void:
	chat_lines.append(line)
	while chat_lines.size() > 5:
		chat_lines.pop_front()
	chat_label.text = "\n".join(PackedStringArray(chat_lines))

func _on_mic_toggled(on: bool) -> void:
	_chat("Microfone ligado." if on else "Microfone desligado.")

func _on_punch() -> void:
	var p = _local_player()
	if p != null:
		p.punch()

func _ping_text() -> String:
	var peer := multiplayer.multiplayer_peer
	if peer is ENetMultiplayerPeer and not multiplayer.is_server():
		var enet := peer as ENetMultiplayerPeer
		if enet.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
			var pp := enet.get_peer(1)
			if pp != null:
				return str(int(pp.get_statistic(ENetPacketPeer.PEER_ROUND_TRIP_TIME)))
	return "--"

func _update_info() -> void:
	var fps := int(Engine.get_frames_per_second())
	info_label.text = "FPS: [color=#a855f7]%d[/color]     PING: [color=#a855f7]%s[/color]     [color=#a855f7]VIDA REAL[/color] RP" % [fps, _ping_text()]

func _process(delta: float) -> void:
	var p = _local_player()
	if p != null:
		minimap_cam.global_position = Vector3(p.global_position.x, 50.0, p.global_position.z)
		p.running = run_button.button_pressed
	minimap_overlay.queue_redraw()
	hud_timer -= delta
	if hud_timer <= 0.0:
		hud_timer = 0.5
		_update_info()

# ---------------------------------------------------------------- CONTROLES

func _local_player():
	var p = players.get(multiplayer.get_unique_id())
	if p != null and is_instance_valid(p):
		return p
	return null

func _set_move(v: Vector2) -> void:
	var p = _local_player()
	if p != null:
		p.move_input = v

func _rotate_camera(rel: Vector2) -> void:
	var p = _local_player()
	if p != null:
		p.camera_yaw = float(p.camera_yaw) - rel.x * 0.006
		p.camera_pitch = clampf(float(p.camera_pitch) - rel.y * 0.004, -1.2, 0.15)

func _joy_blocked(pos: Vector2, screen: Vector2) -> bool:
	if Rect2(0.0, 0.0, 90.0, 90.0).has_point(pos):
		return true
	if Rect2(10.0, screen.y - 290.0, 250.0, 290.0).has_point(pos):
		return true
	if online_panel.visible and online_panel.get_global_rect().has_point(pos):
		return true
	return false

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		var screen := get_viewport().get_visible_rect().size
		if t.pressed:
			if t.position.x < screen.x * 0.5:
				if joy_index == -1 and not _joy_blocked(t.position, screen):
					joy_index = t.index
					joy_origin = t.position
					joy_pos = t.position
			elif t.position.x < screen.x - 280.0:
				if cam_index == -1:
					cam_index = t.index
		else:
			if t.index == joy_index:
				joy_index = -1
				_set_move(Vector2.ZERO)
			elif t.index == cam_index:
				cam_index = -1
		touch_layer.queue_redraw()
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == joy_index:
			var v := d.position - joy_origin
			if v.length() > JOY_RADIUS:
				v = v.normalized() * JOY_RADIUS
			joy_pos = joy_origin + v
			var n := v / JOY_RADIUS
			if n.length() < 0.15:
				n = Vector2.ZERO
			_set_move(n)
		elif d.index == cam_index:
			_rotate_camera(d.relative)
		touch_layer.queue_redraw()
	elif event is InputEventMouseMotion:
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			_rotate_camera((event as InputEventMouseMotion).relative)

# ---------------------------------------------------------------- ONLINE

func _close_peer() -> void:
	if multiplayer.has_multiplayer_peer():
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null

func _clear_players() -> void:
	for id in players.keys():
		var n = players[id]
		if is_instance_valid(n):
			n.get_parent().remove_child(n)
			n.queue_free()
	players.clear()

func _host_game() -> void:
	_close_peer()
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_server(PORT, MAX_PLAYERS)
	if result != OK:
		status_label.text = "Erro ao criar sala: " + error_string(result)
		spawn_player(multiplayer.get_unique_id())
		return
	multiplayer.multiplayer_peer = peer
	status_label.text = "Sala criada na porta UDP %d. Para internet, use um servidor público." % PORT
	spawn_player(1)

func _join_game() -> void:
	var address := ip_input.text.strip_edges()
	if address.is_empty():
		status_label.text = "Digite o IP do servidor."
		return
	_close_peer()
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_client(address, PORT)
	if result != OK:
		status_label.text = "Erro ao iniciar conexão: " + error_string(result)
		spawn_player(multiplayer.get_unique_id())
		return
	_clear_players()
	multiplayer.multiplayer_peer = peer
	status_label.text = "Conectando a " + address + "..."

func _on_connected() -> void:
	status_label.text = "Conectado! Entrando na cidade..."
	request_spawn.rpc_id(1)

@rpc("any_peer", "call_remote", "reliable")
func request_spawn() -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	for existing_id in players.keys():
		spawn_player.rpc_id(id, int(existing_id))
	spawn_player.rpc(id)

@rpc("authority", "call_local", "reliable")
func spawn_player(id: int) -> void:
	if players.has(id):
		return
	var player := CharacterBody3D.new()
	player.set_script(PLAYER_SCRIPT)
	player.name = "Player_%d" % id
	player.set_multiplayer_authority(id)
	player.position = Vector3(randf_range(-2.0, 2.0), 0.15, randf_range(-2.0, 2.0))
	player_container.add_child(player)
	players[id] = player
	if id == multiplayer.get_unique_id():
		status_label.text = "Você está na cidade! Jogador #%d" % id

@rpc("any_peer", "call_remote", "unreliable")
func submit_transform(id: int, value: Transform3D) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != id:
		return
	relay_transform.rpc(id, value)

@rpc("authority", "call_remote", "unreliable")
func relay_transform(id: int, value: Transform3D) -> void:
	if id == multiplayer.get_unique_id():
		return
	var player = players.get(id)
	if player != null and is_instance_valid(player):
		player.global_transform = value

func _on_peer_connected(id: int) -> void:
	if multiplayer.is_server():
		for existing_id in players.keys():
			spawn_player.rpc_id(id, int(existing_id))
		spawn_player.rpc(id)
		_chat("[color=#b44cff]Jogador %d[/color] entrou na cidade." % id)

func _on_peer_disconnected(id: int) -> void:
	if multiplayer.is_server():
		despawn_player.rpc(id)

@rpc("authority", "call_local", "reliable")
func despawn_player(id: int) -> void:
	if players.has(id):
		var n = players[id]
		if is_instance_valid(n):
			n.queue_free()
		players.erase(id)

func _on_connection_failed() -> void:
	status_label.text = "Falha ao conectar. Confira IP, servidor e porta UDP %d." % PORT
	_clear_players()
	multiplayer.multiplayer_peer = null
	spawn_player(multiplayer.get_unique_id())

func _on_server_disconnected() -> void:
	status_label.text = "Conexão com o servidor perdida."
	_clear_players()
	multiplayer.multiplayer_peer = null
	spawn_player(multiplayer.get_unique_id())
