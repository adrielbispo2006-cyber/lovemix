extends CharacterBody3D

const WALK_SPEED := 5.5
const RUN_SPEED := 9.0
const JUMP_VELOCITY := 5.2
const CUSTOM_MODEL_PATH := "res://assets/models/personagem.glb"

var move_input := Vector2.ZERO
var running := false
var camera_yaw := -0.55
var camera_pitch := -0.22
var camera_pivot: Node3D
var camera: Camera3D
var sync_timer := 0.0
var model: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var walk_phase := 0.0
var punch_time := 0.0
var last_pos := Vector3.ZERO
var anim_speed := 0.0

func _ready() -> void:
	_build_collision_and_tag()
	if not _try_custom_model():
		_build_placeholder_body()
	camera_pivot = Node3D.new()
	camera_pivot.top_level = true
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0.0, 0.5, 5.4)
	camera.fov = 70.0
	camera.far = 400.0
	camera.cull_mask = 1
	camera_pivot.add_child(camera)
	camera.current = is_multiplayer_authority()
	last_pos = global_position
	_update_camera()

func punch() -> void:
	punch_time = 0.35

func _update_camera() -> void:
	camera_pivot.global_position = global_position + Vector3(0.0, 1.55, 0.0)
	camera_pivot.rotation = Vector3(camera_pitch, camera_yaw, 0.0)

func _process(delta: float) -> void:
	var horiz := Vector3(global_position.x - last_pos.x, 0.0, global_position.z - last_pos.z)
	var spd := horiz.length() / maxf(delta, 0.0001)
	last_pos = global_position
	anim_speed = lerpf(anim_speed, spd, minf(delta * 10.0, 1.0))
	_animate(delta)
	if is_multiplayer_authority():
		_update_camera()

func _animate(delta: float) -> void:
	if arm_l == null:
		return
	var moving := clampf(anim_speed / 4.0, 0.0, 1.0)
	walk_phase += delta * (6.0 + anim_speed * 1.2)
	var swing := sin(walk_phase) * 0.85 * moving
	arm_l.rotation.x = swing
	arm_r.rotation.x = -swing
	leg_l.rotation.x = -swing
	leg_r.rotation.x = swing
	if punch_time > 0.0:
		punch_time -= delta
		var k := 1.0 - clampf(punch_time / 0.35, 0.0, 1.0)
		arm_r.rotation.x = 1.5 * sin(k * PI)

func _build_collision_and_tag() -> void:
	var collision := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 1.8
	collision.shape = shape
	collision.position.y = 0.9
	add_child(collision)
	var tag := Label3D.new()
	tag.text = "VOCÊ" if is_multiplayer_authority() else "Jogador"
	tag.position.y = 2.1
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.font_size = 40
	tag.pixel_size = 0.004
	tag.outline_size = 10
	tag.modulate = Color(0.85, 0.55, 1.0)
	add_child(tag)

func _try_custom_model() -> bool:
	if not ResourceLoader.exists(CUSTOM_MODEL_PATH):
		return false
	var scene := load(CUSTOM_MODEL_PATH) as PackedScene
	if scene == null:
		return false
	var inst := scene.instantiate() as Node3D
	if inst == null:
		return false
	model = inst
	model.rotation_degrees.y = 180.0
	add_child(model)
	return true

func _m(color: Color, rough := 0.7, metal := 0.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = rough
	mat.metallic = metal
	return mat

func _part(parent: Node3D, mesh: Mesh, pos: Vector3, mat: Material, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scl
	mi.material_override = mat
	parent.add_child(mi)
	return mi

func _capsule(r: float, h: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = r
	c.height = h
	return c

func _sphere(r: float, h: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = h
	return s

func _box(sz: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = sz
	return b

func _cyl(rt: float, rb: float, h: float) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = rt
	c.bottom_radius = rb
	c.height = h
	return c

func _make_arm(x: float, sleeve: Material, fore: Material, skin: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(x, 1.44, 0.0)
	model.add_child(pivot)
	_part(pivot, _capsule(0.07, 0.28), Vector3(0.0, -0.13, 0.0), sleeve)
	_part(pivot, _capsule(0.055, 0.30), Vector3(0.0, -0.38, 0.0), fore)
	_part(pivot, _sphere(0.055, 0.11), Vector3(0.0, -0.56, 0.0), skin)
	return pivot

func _make_leg(x: float, shorts: Material, skin: Material, shoe: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(x, 0.92, 0.0)
	model.add_child(pivot)
	_part(pivot, _capsule(0.10, 0.48), Vector3(0.0, -0.22, 0.0), shorts)
	_part(pivot, _cyl(0.065, 0.06, 0.34), Vector3(0.0, -0.62, 0.0), skin)
	_part(pivot, _box(Vector3(0.17, 0.09, 0.32)), Vector3(0.0, -0.87, -0.06), shoe)
	return pivot

func _build_placeholder_body() -> void:
	var skin := _m(Color(0.62, 0.42, 0.31), 0.6)
	var ink := _m(Color(0.30, 0.22, 0.20), 0.6)
	var black := _m(Color(0.04, 0.04, 0.05), 0.8)
	var hair := _m(Color(0.08, 0.06, 0.05), 0.9)
	var white := _m(Color(0.92, 0.92, 0.94), 0.5)
	var silver := _m(Color(0.85, 0.87, 0.92), 0.25, 0.9)
	model = Node3D.new()
	add_child(model)
	_part(model, _capsule(0.21, 0.66), Vector3(0.0, 1.2, 0.0), black, Vector3(1.12, 1.0, 0.66))
	_part(model, _box(Vector3(0.40, 0.2, 0.24)), Vector3(0.0, 0.92, 0.0), black)
	_part(model, _cyl(0.06, 0.07, 0.12), Vector3(0.0, 1.56, 0.0), skin)
	_part(model, _sphere(0.115, 0.26), Vector3(0.0, 1.68, 0.0), skin)
	_part(model, _sphere(0.075, 0.15), Vector3(0.0, 1.63, -0.07), hair, Vector3(1.0, 0.75, 0.7))
	_part(model, _box(Vector3(0.20, 0.045, 0.03)), Vector3(0.0, 1.70, -0.105), black)
	var dome := SphereMesh.new()
	dome.radius = 0.125
	dome.height = 0.125
	dome.is_hemisphere = true
	_part(model, dome, Vector3(0.0, 1.715, 0.005), black)
	_part(model, _box(Vector3(0.20, 0.014, 0.13)), Vector3(0.0, 1.72, -0.15), black)
	var chain := TorusMesh.new()
	chain.inner_radius = 0.085
	chain.outer_radius = 0.10
	_part(model, chain, Vector3(0.0, 1.50, -0.02), silver, Vector3(1.2, 1.0, 1.0))
	_part(model, _box(Vector3(0.014, 0.07, 0.012)), Vector3(0.0, 1.40, -0.14), silver)
	_part(model, _box(Vector3(0.045, 0.014, 0.012)), Vector3(0.0, 1.42, -0.14), silver)
	arm_l = _make_arm(-0.30, black, skin, skin)
	arm_r = _make_arm(0.30, black, ink, skin)
	leg_l = _make_leg(-0.12, black, skin, white)
	leg_r = _make_leg(0.12, black, skin, white)

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	var input_dir := move_input
	if input_dir == Vector2.ZERO:
		input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var speed := RUN_SPEED if running else WALK_SPEED
	var wish := Basis(Vector3.UP, camera_yaw) * Vector3(input_dir.x, 0.0, input_dir.y)
	var mag := minf(wish.length(), 1.0)
	if mag > 0.05:
		var dir := wish.normalized()
		velocity.x = dir.x * speed * mag
		velocity.z = dir.z * speed * mag
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(delta * 10.0, 1.0))
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed * 5.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, speed * 5.0 * delta)
	if not is_on_floor():
		velocity.y -= 18.0 * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = JUMP_VELOCITY
	move_and_slide()
	sync_timer += delta
	if sync_timer >= 0.08 and multiplayer.has_multiplayer_peer():
		sync_timer = 0.0
		var root: Node = get_tree().current_scene
		if multiplayer.is_server():
			root.rpc("relay_transform", get_multiplayer_authority(), global_transform)
		else:
			root.rpc_id(1, "submit_transform", get_multiplayer_authority(), global_transform)
