# Nova tela inicial (neon) — substitui a antiga

- A aba **Início** agora é a lista de conversas neon da imagem de referência: `lib/screens/lovemix_chats_home.dart`.
- Barra inferior nova: **Início · Chats · coração com asas (menu) · Descobrir · VIP** (`lib/screens/home_screen.dart`).
- O feed antigo (comunidade), Meu perfil, Salas, Notificações, Presentes e Carteira agora ficam no menu do coração central (e nos 3 pontinhos do cabeçalho).
- Conversas, fotos, online, VIP, verificado e não lidas vêm dos dados reais do Firebase. O coraçãozinho favorita a conversa (salvo no aparelho).
- Novos assets em `assets/home/` (já registrados no pubspec).
- Não havia Flutter neste ambiente: rode `flutter analyze` / compile pelo GitHub Actions para validar.
