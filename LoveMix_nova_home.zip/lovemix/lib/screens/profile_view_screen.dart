import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import '../widgets/full_photo.dart';
import '../widgets/profile_frame.dart';
import 'chat_screen.dart';
import 'gifts_screen.dart';
import 'messages_screen.dart';
import 'post_interactions_screen.dart';
import 'profile_frames_screen.dart';
import 'vip_nickname_screen.dart';
import 'wallet_screen.dart';

const _violet = Color(0xFFB62CFF);
const _violet2 = Color(0xFF7A1FD6);
const _gold = Color(0xFFFFC83D);
const _bg = Color(0xFF05010A);
const _card = Color(0xFF0B0314);

/// Perfil LoveMix: o mesmo layout para qualquer pessoa.
/// Se [userId] for o usuário logado, mostra "Editar Perfil".
class ProfileViewScreen extends StatefulWidget {
  const ProfileViewScreen({super.key, required this.userId});
  final String userId;
  @override
  State<ProfileViewScreen> createState() => _ProfileViewScreenState();
}

class _ProfileViewScreenState extends State<ProfileViewScreen> {
  int _tab = 0;
  bool _busy = false;
  String get _me => FirebaseAuth.instance.currentUser?.uid ?? '';
  bool get _mine => widget.userId.isNotEmpty && widget.userId == _me;
  DocumentReference<Map<String, dynamic>> get _ref =>
      FirebaseFirestore.instance.collection('users').doc(widget.userId);

  void _snack(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  static String _compact(num n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(n >= 10000000 ? 0 : 1).replaceAll('.0', '')}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(n >= 10000 ? 0 : 1).replaceAll('.0', '')}K';
    return '${n.toInt()}';
  }

  static String _flag(String country) {
    final c = country.toLowerCase().trim();
    const m = {
      'brasil': '🇧🇷', 'brazil': '🇧🇷', 'portugal': '🇵🇹', 'argentina': '🇦🇷',
      'estados unidos': '🇺🇸', 'eua': '🇺🇸', 'usa': '🇺🇸', 'espanha': '🇪🇸',
      'paraguai': '🇵🇾', 'uruguai': '🇺🇾', 'chile': '🇨🇱', 'méxico': '🇲🇽', 'mexico': '🇲🇽',
      'angola': '🇦🇴', 'moçambique': '🇲🇿', 'itália': '🇮🇹', 'italia': '🇮🇹',
    };
    return m[c] ?? '';
  }

  static IconData _interestIcon(String t) {
    final s = t.toLowerCase();
    if (s.contains('jogo') || s.contains('game')) return Icons.sports_esports;
    if (s.contains('mús') || s.contains('mus')) return Icons.music_note;
    if (s.contains('amiz')) return Icons.favorite;
    if (s.contains('viag')) return Icons.flight;
    if (s.contains('namor')) return Icons.favorite_border;
    if (s.contains('filme') || s.contains('série')) return Icons.movie;
    if (s.contains('espor') || s.contains('fut')) return Icons.sports_soccer;
    return Icons.star;
  }

  int? _age(Map<String, dynamic> p) {
    final b = p['birthday'];
    if (b is Timestamp) {
      final d = b.toDate();
      final now = DateTime.now();
      var a = now.year - d.year;
      if (now.month < d.month || (now.month == d.month && now.day < d.day)) a--;
      return a;
    }
    final a = p['age'];
    return a is num ? a.toInt() : null;
  }

  // ───────────────────────── ações ─────────────────────────
  Future<void> _message() async {
    if (_mine) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const Scaffold(body: SafeArea(child: MessagesScreen()))));
      return;
    }
    try {
      final id = await DataService.instance.openDirectChat(widget.userId);
      final snap = await _ref.get();
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => ChatScreen(chatId: id, otherName: (snap.data()?['name'] ?? 'Pessoa').toString())));
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        action: msg.toLowerCase().contains('siga')
            ? SnackBarAction(label: 'Seguir', onPressed: () async {
                try { await DataService.instance.toggleFollow(widget.userId); _snack('Agora toque em Enviar Mensagem.'); } catch (_) {}
              })
            : null,
      ));
    }
  }

  Future<void> _like() async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null || _mine) return;
    try {
      final ref = _ref.collection('profileLikes').doc(me.uid);
      final s = await ref.get();
      if (s.exists) {
        await ref.delete();
      } else {
        await ref.set({'uid': me.uid, 'createdAt': FieldValue.serverTimestamp()});
        _snack('Perfil curtido 💜');
      }
    } catch (e) {
      _snack('Não foi possível curtir agora.');
    }
  }

  Future<void> _publishPhoto() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Entre novamente para publicar.');
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 65, maxWidth: 1000, maxHeight: 1000);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length >= 5 * 1024 * 1024) throw Exception('Escolha uma foto válida de até 5 MB.');
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final png = picked.name.toLowerCase().endsWith('.png');
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'posts/${user.uid}/$id.${png ? 'png' : 'jpg'}',
        bytes: bytes,
        contentType: png ? 'image/png' : 'image/jpeg',
      );
      await _ref.collection('posts').doc(id).set({
        'photoUrl': url,
        'visibility': 'public',
        'createdAt': FieldValue.serverTimestamp(),
      });
      _snack('Foto publicada!');
    } catch (e) {
      _snack('Não foi possível publicar: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _changeAvatar() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login novamente.');
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 65, maxWidth: 720, maxHeight: 720);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 5 * 1024 * 1024) throw Exception('Escolha uma foto de até 5 MB.');
      final n = picked.name.toLowerCase();
      final type = n.endsWith('.png') ? 'image/png' : n.endsWith('.webp') ? 'image/webp' : 'image/jpeg';
      final ext = type == 'image/png' ? 'png' : type == 'image/webp' ? 'webp' : 'jpg';
      final url = await SupabaseService.instance.uploadPhoto(path: 'profiles/${user.uid}/profile.$ext', bytes: bytes, contentType: type);
      await DataService.instance.updateProfile({'photoUrl': '$url?v=${DateTime.now().millisecondsSinceEpoch}'});
      _snack('Foto de perfil atualizada!');
    } catch (e) {
      _snack('Não foi possível trocar a foto: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deletePost(String id, String url) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Remover foto?'),
        content: const Text('Ela some do seu perfil.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Remover')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _ref.collection('posts').doc(id).delete();
      try { await FirebaseFirestore.instance.collection('feed_posts').doc(id).delete(); } catch (_) {}
      try { await SupabaseService.instance.deletePublicUrl(url); } catch (_) {}
    } catch (e) {
      _snack('Não foi possível remover a foto.');
    }
  }

  Future<void> _edit(Map<String, dynamic> p) async {
    final name = TextEditingController(text: (p['name'] ?? '').toString());
    final bio = TextEditingController(text: (p['bio'] ?? '').toString());
    final city = TextEditingController(text: (p['city'] ?? '').toString());
    final country = TextEditingController(text: (p['country'] ?? '').toString());
    final interest = TextEditingController();
    final interests = List<String>.from(p['interests'] ?? const []);
    DateTime? birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: EdgeInsets.fromLTRB(20, 18, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Editar Perfil', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              TextField(controller: name, maxLength: 30, decoration: const InputDecoration(labelText: 'Nome')),
              TextField(controller: bio, maxLength: 300, maxLines: 3, decoration: const InputDecoration(labelText: 'Sobre mim')),
              Row(children: [
                Expanded(child: TextField(controller: city, decoration: const InputDecoration(labelText: 'Cidade'))),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: country, decoration: const InputDecoration(labelText: 'País'))),
              ]),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.cake_outlined),
                label: Text(birthday == null ? 'Data de nascimento' : '${birthday!.day.toString().padLeft(2, '0')}/${birthday!.month.toString().padLeft(2, '0')}/${birthday!.year}'),
                onPressed: () async {
                  final d = await showDatePicker(
                    context: ctx,
                    initialDate: birthday ?? DateTime(2000),
                    firstDate: DateTime(1940),
                    lastDate: DateTime.now().subtract(const Duration(days: 365 * 18)),
                  );
                  if (d != null) set(() => birthday = d);
                },
              ),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final i in interests)
                  InputChip(label: Text(i), onDeleted: () => set(() => interests.remove(i))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: interest, maxLength: 20, decoration: const InputDecoration(labelText: 'Novo interesse', counterText: ''))),
                IconButton(
                  icon: const Icon(Icons.add_circle, color: _violet),
                  onPressed: () {
                    final t = interest.text.trim();
                    if (t.isNotEmpty && !interests.contains(t) && interests.length < 12) set(() => interests.add(t));
                    interest.clear();
                  },
                ),
              ]),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: _violet),
                  onPressed: () async {
                    final n = name.text.trim();
                    if (n.length < 2) return;
                    try {
                      await DataService.instance.updateProfile({
                        'name': n,
                        'bio': bio.text.trim(),
                        'city': city.text.trim(),
                        'country': country.text.trim(),
                        'interests': interests,
                        if (birthday != null) 'birthday': Timestamp.fromDate(birthday!),
                      });
                      if (ctx.mounted) Navigator.pop(ctx);
                      _snack('Perfil atualizado!');
                    } catch (e) {
                      _snack('Não foi possível salvar o perfil.');
                    }
                  },
                  child: const Text('Salvar'),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> _moreMenu(Map<String, dynamic> p) async {
    final v = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _card,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (_mine) ...[
            ListTile(leading: const Icon(Icons.copy), title: const Text('Copiar meu ID'), onTap: () => Navigator.pop(c, 'id')),
            ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('Trocar foto de perfil'), onTap: () => Navigator.pop(c, 'avatar')),
            ListTile(leading: const Icon(Icons.auto_awesome), title: const Text('Molduras'), onTap: () => Navigator.pop(c, 'frames')),
            ListTile(leading: const Icon(Icons.workspace_premium), title: const Text('Apelido VIP'), onTap: () => Navigator.pop(c, 'vip')),
          ] else ...[
            ListTile(leading: const Icon(Icons.person_add_alt_1), title: const Text('Seguir / Deixar de seguir'), onTap: () => Navigator.pop(c, 'follow')),
            ListTile(leading: const Icon(Icons.favorite_border), title: const Text('Curtir perfil'), onTap: () => Navigator.pop(c, 'like')),
            ListTile(leading: const Icon(Icons.block), title: const Text('Bloquear'), onTap: () => Navigator.pop(c, 'block')),
            ListTile(leading: const Icon(Icons.flag_outlined), title: const Text('Denunciar'), onTap: () => Navigator.pop(c, 'report')),
          ],
        ]),
      ),
    );
    switch (v) {
      case 'id':
        final id = (p['publicId'] ?? '').toString();
        if (id.isNotEmpty) {
          await Clipboard.setData(ClipboardData(text: id));
          _snack('ID copiado!');
        }
      case 'avatar': await _changeAvatar();
      case 'frames': if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen()));
      case 'vip': if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen()));
      case 'follow':
        try { final on = await DataService.instance.toggleFollow(widget.userId); _snack(on ? 'Você começou a seguir.' : 'Você deixou de seguir.'); } catch (_) { _snack('Não foi possível seguir agora.'); }
      case 'like': await _like();
      case 'block':
        try { await DataService.instance.blockUser(widget.userId); _snack('Pessoa bloqueada.'); } catch (_) { _snack('Não foi possível bloquear.'); }
      case 'report':
        try { await DataService.instance.reportUser(widget.userId, 'Perfil denunciado'); _snack('Denúncia enviada.'); } catch (_) { _snack('Não foi possível denunciar.'); }
    }
  }

  // ───────────────────────── widgets ─────────────────────────
  BoxDecoration _neon({double r = 22, Color? fill, double glow = .35}) => BoxDecoration(
        color: fill ?? _card.withOpacity(.88),
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: _violet.withOpacity(.95), width: 1.4),
        boxShadow: [BoxShadow(color: _violet.withOpacity(glow), blurRadius: 14)],
      );

  Widget _glowIcon(IconData i, double s, {double angle = 0}) => Transform.rotate(
        angle: angle,
        child: Icon(i, size: s, color: _violet.withOpacity(.9), shadows: const [Shadow(color: _violet, blurRadius: 18)]),
      );

  Widget _pill(IconData icon, String label, VoidCallback onTap, {bool primary = false, bool selected = false, Color? iconColor}) {
    final filled = primary || selected;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          height: 52,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            gradient: filled ? const LinearGradient(colors: [Color(0xFFC13BFF), _violet2]) : null,
            color: filled ? null : _card.withOpacity(.9),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _violet.withOpacity(.95), width: 1.3),
            boxShadow: [BoxShadow(color: _violet.withOpacity(filled ? .55 : .25), blurRadius: 12)],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 21, color: iconColor ?? Colors.white),
            const SizedBox(width: 7),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5))),
          ]),
        ),
      ),
    );
  }

  Widget _stat(Widget icon, String value, String label) => Container(
        padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
        decoration: _neon(r: 18, glow: .25),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            icon,
            const SizedBox(width: 4),
            Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)))),
          ]),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: const TextStyle(fontSize: 11.5, color: Colors.white70))),
        ]),
      );

  Widget _liveStat(CollectionReference<Map<String, dynamic>> c, Widget icon, String label) =>
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: c.snapshots(),
        builder: (_, s) => _stat(icon, _compact(s.data?.docs.length ?? 0), label),
      );

  Widget _header(Map<String, dynamic> p, bool owner, bool vip, bool verified) {
    final name = (p['name'] ?? 'Pessoa').toString();
    final photo = (p['photoUrl'] ?? '').toString();
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    final flag = _flag(country);
    final place = [if (city.isNotEmpty) city, if (country.isNotEmpty) country].join(' • ');
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
        width: 150,
        child: Column(children: [
          GestureDetector(
            onTap: () => photo.isEmpty ? null : showFullPhoto(context, photo),
            child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
              Container(
                decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: _violet.withOpacity(.6), blurRadius: 26)]),
                child: ProfileFrameAvatar(
                  photoUrl: photo,
                  frameId: (p['selectedProfileFrame'] ?? 'classic').toString(),
                  size: 124,
                ),
              ),
              if (owner)
                const Positioned(top: -22, child: Text('👑', style: TextStyle(fontSize: 34, shadows: [Shadow(color: _violet, blurRadius: 14)]))),
              if (_mine)
                Positioned(
                  right: 4, bottom: 4,
                  child: GestureDetector(
                    onTap: _changeAvatar,
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(color: _violet, shape: BoxShape.circle, border: Border.all(color: _bg, width: 2)),
                      child: const Icon(Icons.photo_camera, size: 15, color: Colors.white),
                    ),
                  ),
                ),
            ]),
          ),
          if (owner) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: _neon(r: 16, fill: _card, glow: .4),
              child: const Text('👑 DONO 👑', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: .5)),
            ),
          ],
        ]),
      ),
      const SizedBox(width: 10),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.only(top: 18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Flexible(child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, height: 1.05))),
              if (verified) const Padding(padding: EdgeInsets.only(left: 6), child: Icon(Icons.verified, color: Color(0xFFB36BFF), size: 25)),
            ]),
            if (owner) ...[
              const SizedBox(height: 6),
              const Text('👑 Dono do LoveMix', style: TextStyle(color: _gold, fontSize: 17, fontWeight: FontWeight.w700)),
            ],
            const SizedBox(height: 6),
            Row(children: [
              const Icon(Icons.location_on, color: _violet, size: 24),
              const SizedBox(width: 4),
              Flexible(child: Text(place.isEmpty ? 'Brasil' : place, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16.5))),
              if (flag.isNotEmpty || place.isEmpty) Padding(padding: const EdgeInsets.only(left: 6), child: Text(flag.isEmpty ? '🇧🇷' : flag, style: const TextStyle(fontSize: 18))),
            ]),
            if (vip) ...[
              const SizedBox(height: 6),
              Row(children: [
                const Text('👑', style: TextStyle(fontSize: 22)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: _violet, width: 1.3), color: _card),
                  child: const Text('VIP', style: TextStyle(color: Color(0xFFD59BFF), fontWeight: FontWeight.w900)),
                ),
              ]),
            ],
          ]),
        ),
      ),
    ]);
  }

  Widget _photosTab() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('posts').snapshots(),
        builder: (_, s) {
          final docs = (s.data?.docs ?? []).where((d) => _mine || (d.data()['visibility'] ?? 'public') == 'public').toList()
            ..sort((a, b) {
              final x = a.data()['createdAt'], y = b.data()['createdAt'];
              return (y is Timestamp ? y.millisecondsSinceEpoch : 0).compareTo(x is Timestamp ? x.millisecondsSinceEpoch : 0);
            });
          final tiles = <Widget>[
            if (_mine)
              GestureDetector(
                onTap: _publishPhoto,
                child: Container(
                  decoration: _neon(r: 16, glow: .3),
                  child: _busy
                      ? const Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)))
                      : const Icon(Icons.add_a_photo_outlined, color: _violet, size: 32),
                ),
              ),
            for (final d in docs)
              () {
                final url = (d.data()['photoUrl'] ?? '').toString();
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: d.id, photoUrl: url))),
                  onLongPress: _mine ? () => _deletePost(d.id, url) : null,
                  child: Container(
                    decoration: _neon(r: 16, glow: .3),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Stack(fit: StackFit.expand, children: [
                        CachedNetworkImage(imageUrl: url, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white38)),
                        const Positioned(right: 6, bottom: 6, child: Icon(Icons.favorite_border, color: Colors.white, size: 21, shadows: [Shadow(color: Colors.black, blurRadius: 6)])),
                      ]),
                    ),
                  ),
                );
              }(),
          ];
          if (tiles.isEmpty) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Nenhuma foto publicada ainda.', style: TextStyle(color: Colors.white60))));
          }
          return GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            children: tiles,
          );
        },
      );

  Widget _achievementsTab() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('achievements').snapshots(),
        builder: (_, s) {
          final docs = s.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Nenhuma conquista ainda.', style: TextStyle(color: Colors.white60))));
          }
          return Wrap(spacing: 8, runSpacing: 8, children: [
            for (final d in docs)
              Container(
                width: 160,
                padding: const EdgeInsets.all(10),
                decoration: _neon(r: 16, glow: .2),
                child: Column(children: [
                  Text((d.data()['emoji'] ?? '🏆').toString(), style: const TextStyle(fontSize: 26)),
                  Text((d.data()['title'] ?? d.data()['name'] ?? 'Conquista').toString(), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
              ),
          ]);
        },
      );

  Widget _vipTab(bool vip) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: _neon(r: 18, glow: .25),
        child: Column(children: [
          const Text('👑', style: TextStyle(fontSize: 34)),
          Text(vip ? 'Membro VIP LoveMix' : 'Ainda não é VIP', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          if (!vip && _mine)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: _violet),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen())),
                child: const Text('Ver benefícios VIP'),
              ),
            ),
        ]),
      );

  Widget _about(Map<String, dynamic> p) {
    final bio = (p['bio'] ?? '').toString().trim();
    final interests = List<String>.from(p['interests'] ?? const []);
    final age = _age(p);
    final shown = interests.take(4).toList();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: _neon(r: 24, glow: .3),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(5),
            decoration: const BoxDecoration(color: _violet, shape: BoxShape.circle),
            child: const Icon(Icons.info_outline, size: 22, color: Colors.white),
          ),
          const SizedBox(width: 10),
          const Text('Sobre mim', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          if (age != null) ...[const Spacer(), Text('$age anos', style: const TextStyle(color: Colors.white70))],
        ]),
        const SizedBox(height: 8),
        Text(bio.isEmpty ? (_mine ? 'Toque em Editar Perfil para escrever sobre você.' : 'Esta pessoa ainda não escreveu nada.') : bio,
            style: const TextStyle(fontSize: 16, height: 1.35)),
        if (interests.isNotEmpty) ...[
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final t in shown)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: _violet.withOpacity(.9)), color: Colors.black26),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(_interestIcon(t), size: 17, color: const Color(0xFFD59BFF)),
                  const SizedBox(width: 6),
                  Text(t, style: const TextStyle(fontSize: 14)),
                ]),
              ),
            if (interests.length > 4)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: _violet.withOpacity(.9))),
                child: Text('+${interests.length - 4}'),
              ),
          ]),
        ],
      ]),
    );
  }

  List<Widget> _ownerContent(Map<String, dynamic> p, bool owner, bool vip, bool verified, String bio, num diamonds) => [
                  const SizedBox(height: 6),
                  _header(p, owner, vip, verified),
                  const SizedBox(height: 12),
                  // frase
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    decoration: _neon(r: 22, glow: .35),
                    child: Text(
                      bio.isEmpty ? '“Obrigado por fazer parte do LoveMix! 💜”' : '“$bio”',
                      textAlign: TextAlign.center,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 16, height: 1.3),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // estatísticas
                  Row(children: [
                    Expanded(child: _liveStat(_ref.collection('followers'), const Icon(Icons.people_alt_rounded, color: _violet, size: 24), 'Seguidores')),
                    const SizedBox(width: 7),
                    Expanded(child: _liveStat(_ref.collection('profileLikes'), const Icon(Icons.favorite, color: _violet, size: 24), 'Curtidas')),
                    const SizedBox(width: 7),
                    Expanded(child: _stat(const Icon(Icons.diamond, color: Color(0xFF3FD0FF), size: 24), _compact(diamonds), 'Diamantes')),
                    const SizedBox(width: 7),
                    Expanded(child: _liveStat(_ref.collection('receivedGifts'), const Icon(Icons.card_giftcard, color: _violet, size: 24), 'Presentes')),
                  ]),
                  const SizedBox(height: 12),
                  // botões
                  Row(children: [
                    Expanded(
                      flex: 5,
                      child: _mine
                          ? _pill(Icons.manage_accounts, 'Editar Perfil', () => _edit(p), primary: true)
                          : StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                              stream: DataService.instance.followingStatus(widget.userId),
                              builder: (_, f) {
                                final on = f.data?.exists == true;
                                return _pill(on ? Icons.check : Icons.person_add_alt_1, on ? 'Seguindo' : 'Seguir', () async {
                                  try { await DataService.instance.toggleFollow(widget.userId); } catch (e) { _snack('Não foi possível seguir agora.'); }
                                }, primary: !on);
                              },
                            ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(flex: 6, child: _pill(Icons.chat_bubble_outline, 'Enviar Mensagem', _message)),
                    const SizedBox(width: 8),
                    SizedBox(width: 52, child: _pill(Icons.more_vert, '', () => _moreMenu(p))),
                  ]),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: _pill(Icons.photo_library_outlined, 'Fotos', () => setState(() => _tab = 0), selected: _tab == 0)),
                    const SizedBox(width: 8),
                    Expanded(child: _pill(Icons.star, 'Conquistas', () => setState(() => _tab = 1), selected: _tab == 1)),
                    const SizedBox(width: 8),
                    Expanded(child: _pill(Icons.workspace_premium, 'VIP', () => setState(() => _tab = 2), selected: _tab == 2)),
                  ]),
                  const SizedBox(height: 12),
                  if (_tab == 0) _photosTab() else if (_tab == 1) _achievementsTab() else _vipTab(vip),
                  const SizedBox(height: 12),
                  _about(p),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: _pill(Icons.card_giftcard, 'Enviar Presente', () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: _mine ? '' : widget.userId))), iconColor: const Color(0xFFD59BFF))),
                    const SizedBox(width: 8),
                    Expanded(child: _pill(Icons.diamond, 'Enviar Diamantes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())), iconColor: const Color(0xFF3FD0FF))),
                    const SizedBox(width: 8),
                    Expanded(child: _pill(Icons.workspace_premium, 'Comprar VIP', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen())), iconColor: _gold)),
                  ]),
  ];


  // ───────────── layout de quem visita o perfil de outra pessoa ─────────────
  Widget _visitorHeader(Map<String, dynamic> p, bool vip, bool verified) {
    final name = (p['name'] ?? 'Pessoa').toString();
    final photo = (p['photoUrl'] ?? '').toString();
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    final flag = _flag(country);
    final place = [if (city.isNotEmpty) city, if (country.isNotEmpty) country].join(' • ');
    final age = _age(p);
    final g = (p['gender'] ?? '').toString().toLowerCase();
    final female = g.startsWith('fem') || g == 'f' || g.contains('mulher');
    final male = g.startsWith('masc') || g == 'm' || g.contains('homem');
    final bio = (p['bio'] ?? '').toString().trim();
    final line = bio.split('\n').first;
    return Column(children: [
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: 160,
          child: Column(children: [
            GestureDetector(
              onTap: () => photo.isEmpty ? null : showFullPhoto(context, photo),
              child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
                Container(
                  decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [BoxShadow(color: _violet.withOpacity(.65), blurRadius: 28)]),
                  child: ProfileFrameAvatar(photoUrl: photo, frameId: (p['selectedProfileFrame'] ?? 'classic').toString(), size: 130),
                ),
                if (vip) const Positioned(top: -24, child: Text('👑', style: TextStyle(fontSize: 36, shadows: [Shadow(color: _violet, blurRadius: 14)]))),
              ]),
            ),
            if (vip) ...[
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                decoration: _neon(r: 16, fill: _card, glow: .45),
                child: const Text('👑 VIP 👑', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
              ),
            ],
          ]),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 22),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, height: 1.05))),
                if (verified) const Padding(padding: EdgeInsets.only(left: 6), child: Icon(Icons.verified, color: Color(0xFF2E9BFF), size: 26)),
              ]),
              const SizedBox(height: 8),
              if (age != null)
                Row(children: [
                  if (female || male)
                    Icon(female ? Icons.female : Icons.male, size: 26, color: female ? const Color(0xFFFF4FB8) : const Color(0xFF4FA8FF))
                  else
                    const Icon(Icons.cake_outlined, size: 24, color: _violet),
                  const SizedBox(width: 8),
                  Text('$age anos', style: const TextStyle(fontSize: 18)),
                ]),
              const SizedBox(height: 6),
              Row(children: [
                const Icon(Icons.location_on, color: _violet, size: 26),
                const SizedBox(width: 6),
                Flexible(child: Text(place.isEmpty ? 'Brasil' : place, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18))),
                Padding(padding: const EdgeInsets.only(left: 6), child: Text(flag.isEmpty && place.isEmpty ? '🇧🇷' : flag, style: const TextStyle(fontSize: 18))),
              ]),
              if (vip) ...[
                const SizedBox(height: 6),
                Row(children: [
                  const Text('👑', style: TextStyle(fontSize: 22)),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: _violet, width: 1.3), color: _card),
                    child: const Text('VIP', style: TextStyle(color: Color(0xFFD59BFF), fontWeight: FontWeight.w900)),
                  ),
                ]),
              ],
            ]),
          ),
        ),
      ]),
      if (line.isNotEmpty) ...[
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: _neon(r: 22, glow: .3),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('💜 ', style: TextStyle(fontSize: 15)),
            Flexible(child: Text(line, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15))),
            const Text(' 💜', style: TextStyle(fontSize: 15)),
          ]),
        ),
      ],
    ]);
  }

  Widget _visitorPhotos() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('posts').snapshots(),
        builder: (_, s) {
          final docs = (s.data?.docs ?? []).where((d) => (d.data()['visibility'] ?? 'public') == 'public').toList()
            ..sort((a, b) {
              final x = a.data()['createdAt'], y = b.data()['createdAt'];
              return (y is Timestamp ? y.millisecondsSinceEpoch : 0).compareTo(x is Timestamp ? x.millisecondsSinceEpoch : 0);
            });
          if (docs.isEmpty) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Nenhuma foto publicada ainda.', style: TextStyle(color: Colors.white60))));
          }
          return GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: .82,
            children: [
              for (final d in docs)
                () {
                  final url = (d.data()['photoUrl'] ?? '').toString();
                  return GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: d.id, photoUrl: url))),
                    child: Container(
                      decoration: _neon(r: 16, glow: .35),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Stack(fit: StackFit.expand, children: [
                          CachedNetworkImage(imageUrl: url, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white38)),
                          Positioned(
                            right: 5, bottom: 5,
                            child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                              child: const Icon(Icons.favorite_border, color: Colors.white, size: 18),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  );
                }(),
            ],
          );
        },
      );

  List<Widget> _visitorContent(Map<String, dynamic> p, bool vip, bool verified) {
    final likesRef = _ref.collection('profileLikes');
    return [
      const SizedBox(height: 6),
      _visitorHeader(p, vip, verified),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _liveStat(_ref.collection('followers'), const Icon(Icons.people_alt_rounded, color: _violet, size: 28), 'Seguidores')),
        const SizedBox(width: 8),
        Expanded(child: _liveStat(_ref.collection('following'), const Icon(Icons.person_add_alt_1, color: _violet, size: 28), 'Seguindo')),
        const SizedBox(width: 8),
        Expanded(child: _liveStat(likesRef, const Icon(Icons.favorite, color: _violet, size: 28), 'Curtidas')),
      ]),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          flex: 6,
          child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: likesRef.doc(_me.isEmpty ? '_' : _me).snapshots(),
            builder: (_, mine) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: likesRef.snapshots(),
              builder: (_, all) {
                final liked = mine.data?.exists == true;
                final count = all.data?.docs.length ?? 0;
                return Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: _like,
                    child: Container(
                      height: 58,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFFC13BFF), _violet2]),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: _violet, width: 1.3),
                        boxShadow: [BoxShadow(color: _violet.withOpacity(.55), blurRadius: 12)],
                      ),
                      child: Row(children: [
                        Icon(liked ? Icons.favorite : Icons.favorite_border, size: 26),
                        const SizedBox(width: 8),
                        const Expanded(
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text('Curtir Perfil', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
                            Text('(Visitantes)', style: TextStyle(fontSize: 11.5, color: Colors.white70)),
                          ]),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(14)),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.favorite, color: Color(0xFFFF3D9A), size: 15),
                            const SizedBox(width: 3),
                            Text(_compact(count), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(flex: 6, child: SizedBox(height: 58, child: _pill(Icons.chat_bubble_outline, 'Enviar Mensagem', _message))),
        const SizedBox(width: 8),
        SizedBox(width: 52, height: 58, child: _pill(Icons.more_vert, '', () => _moreMenu(p))),
      ]),
      const SizedBox(height: 10),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('posts').snapshots(),
        builder: (_, ps) {
          final n = (ps.data?.docs ?? []).where((d) => (d.data()['visibility'] ?? 'public') == 'public').length;
          return Row(children: [
            Expanded(child: _pill(Icons.photo_library_outlined, 'Fotos ($n)', () => setState(() => _tab = 0), selected: _tab == 0)),
            const SizedBox(width: 8),
            Expanded(child: _pill(Icons.star, 'Conquistas', () => setState(() => _tab = 1), selected: _tab == 1)),
            const SizedBox(width: 8),
            Expanded(child: _pill(Icons.workspace_premium, 'VIP', () => setState(() => _tab = 2), selected: _tab == 2)),
          ]);
        },
      ),
      const SizedBox(height: 12),
      if (_tab == 0) _visitorPhotos() else if (_tab == 1) _achievementsTab() else _vipTab(vip),
      const SizedBox(height: 12),
      _about(p),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _pill(Icons.card_giftcard, 'Enviar Presente', () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: widget.userId))), iconColor: const Color(0xFFD59BFF))),
        const SizedBox(width: 8),
        Expanded(child: _pill(Icons.diamond, 'Enviar Diamantes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())), iconColor: const Color(0xFF3FD0FF))),
      ]),
    ];
  }

  @override
  Widget build(BuildContext context) {
    if (widget.userId.isEmpty) {
      return const Scaffold(backgroundColor: _bg, body: Center(child: Text('Perfil indisponível.')));
    }
    return Scaffold(
      backgroundColor: _bg,
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: _ref.snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Não foi possível carregar o perfil.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final p = snap.data!.data() ?? <String, dynamic>{};
          final owner = p['isAdmin'] == true;
          final vip = p['isVip'] == true || p['vip'] == true;
          final verified = p['isVerified'] == true || owner;
          final bio = (p['bio'] ?? '').toString().trim();
          final diamonds = (p['diamonds'] as num?) ?? 0;
          return Stack(children: [
            // fundo neon
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(-.6, -.75),
                    radius: 1.3,
                    colors: [_violet.withOpacity(.38), _bg],
                    stops: const [0, .75],
                  ),
                ),
              ),
            ),
            Positioned(right: 16, top: 70, child: _glowIcon(Icons.favorite_border, 54, angle: .2)),
            Positioned(right: 4, top: 190, child: _glowIcon(Icons.favorite_border, 80, angle: -.15)),
            Positioned(right: 40, top: 20, child: _glowIcon(Icons.favorite_border, 28)),
            SafeArea(
              bottom: false,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                children: [
                  // topo
                  SizedBox(
                    height: 64,
                    child: Stack(alignment: Alignment.center, children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Navigator.canPop(context)
                            ? IconButton(icon: const Icon(Icons.arrow_back, size: 28), onPressed: () => Navigator.pop(context))
                            : const SizedBox(width: 48),
                      ),
                      Column(mainAxisSize: MainAxisSize.min, children: [
                        Image.asset('assets/icon/lovemix.png', height: 38, cacheHeight: 128, errorBuilder: (_, __, ___) => const Text('LoveMix', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic))),
                        const Text('Conectando pessoas 💜', style: TextStyle(fontSize: 12.5)),
                      ]),
                      Align(alignment: Alignment.centerRight, child: IconButton(icon: const Icon(Icons.more_vert), onPressed: () => _moreMenu(p))),
                    ]),
                  ),
                  if (_mine) ..._ownerContent(p, owner, vip, verified, bio, diamonds) else ..._visitorContent(p, vip, verified),
                ],
              ),
            ),
          ]);
        },
      ),
    );
  }
}
