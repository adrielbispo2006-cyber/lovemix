import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'profile_view_screen.dart';

/// Nova tela "Início" do LoveMix: cabeçalho com logo neon, busca e lista de
/// conversas em cartões neon (igual à imagem de referência).
class LoveMixChatsHome extends StatefulWidget {
  const LoveMixChatsHome({
    super.key,
    required this.onCall,
    required this.onVideo,
    required this.onMenu,
  });

  /// Toque no botão de telefone do cabeçalho.
  final VoidCallback onCall;

  /// Toque no botão de vídeo do cabeçalho.
  final VoidCallback onVideo;

  /// Toque nos três pontinhos do cabeçalho.
  final VoidCallback onMenu;

  @override
  State<LoveMixChatsHome> createState() => _LoveMixChatsHomeState();
}

class _LoveMixChatsHomeState extends State<LoveMixChatsHome> {
  static const _pink = Color(0xFFFF2DAB);
  static const _purple = Color(0xFFB52CFF);
  static const _violet = Color(0xFF8D35FF);
  static const _gold = Color(0xFFFFD36A);
  static const _lilac = Color(0xFFC9A0FF);
  static const _favKey = 'lovemix_favorite_chats';

  final _search = TextEditingController();
  Set<String> _favorites = <String>{};
  bool _onlyFavorites = false;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getStringList(_favKey) ?? const <String>[];
      if (mounted) setState(() => _favorites = saved.toSet());
    } catch (_) {}
  }

  Future<void> _toggleFavorite(String chatId) async {
    setState(() {
      if (!_favorites.add(chatId)) _favorites.remove(chatId);
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_favKey, _favorites.toList());
    } catch (_) {}
  }

  String _ago(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inMinutes < 1) return 'Agora';
    if (diff.inMinutes < 60) return 'Há ${diff.inMinutes} min';
    if (diff.inHours < 24) return 'Há ${diff.inHours} h';
    if (diff.inDays < 7) return 'Há ${diff.inDays} d';
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}';
  }

  int _unread(Map<String, dynamic> data) {
    final m = data['unreadCounts'];
    final v = m is Map ? m[DataService.instance.uid] : null;
    return v is num ? v.toInt() : 0;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF14041F), Colors.black, Color(0xFF0C0216)],
          stops: [0, .35, 1],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(children: [
          _header(),
          _searchBar(),
          const SizedBox(height: 6),
          Expanded(child: _conversations()),
        ]),
      ),
    );
  }

  // ---------------------------------------------------------------- cabeçalho

  Widget _header() => SizedBox(
        height: 128,
        child: Stack(children: [
          Positioned(
            right: 0,
            bottom: 0,
            width: 128,
            child: Image.asset('assets/home/hearts.png', fit: BoxFit.contain),
          ),
          Positioned(
            left: 6,
            top: 4,
            bottom: 0,
            width: MediaQuery.of(context).size.width * .62,
            child: Image.asset('assets/home/logo.png', fit: BoxFit.contain, alignment: Alignment.centerLeft),
          ),
          Positioned(
            right: 10,
            top: 8,
            child: Row(children: [
              _circleButton(Icons.call_outlined, widget.onCall),
              const SizedBox(width: 8),
              _circleButton(Icons.videocam_rounded, widget.onVideo),
              const SizedBox(width: 8),
              _circleButton(Icons.more_vert, widget.onMenu),
            ]),
          ),
        ]),
      );

  Widget _circleButton(IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black.withOpacity(.55),
            border: Border.all(color: _purple, width: 1.4),
            boxShadow: [BoxShadow(color: _purple.withOpacity(.45), blurRadius: 10)],
          ),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
      );

  // -------------------------------------------------------------------- busca

  Widget _searchBar() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(children: [
          Expanded(
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.6),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: _purple, width: 1.3),
                boxShadow: [BoxShadow(color: _purple.withOpacity(.35), blurRadius: 12)],
              ),
              child: TextField(
                controller: _search,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(color: Colors.white, fontSize: 15),
                decoration: const InputDecoration(
                  filled: false,
                  prefixIcon: Icon(Icons.search, color: Color(0xFFE5C5FF), size: 26),
                  hintText: 'Buscar conversas...',
                  hintStyle: TextStyle(color: _lilac, fontSize: 15),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          InkWell(
            onTap: () => setState(() => _onlyFavorites = !_onlyFavorites),
            customBorder: const CircleBorder(),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _onlyFavorites ? _purple.withOpacity(.35) : Colors.black.withOpacity(.6),
                border: Border.all(color: _onlyFavorites ? _pink : _purple, width: 1.3),
                boxShadow: [BoxShadow(color: _purple.withOpacity(.35), blurRadius: 12)],
              ),
              child: Icon(_onlyFavorites ? Icons.favorite : Icons.tune,
                  color: _onlyFavorites ? _pink : const Color(0xFFE5C5FF), size: 24),
            ),
          ),
        ]),
      );

  // ------------------------------------------------------------------ conversas

  Widget _conversations() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: DataService.instance.myChats(),
        builder: (context, snap) {
          if (snap.hasError) {
            return const Center(
              child: Text('Não foi possível carregar as conversas.',
                  style: TextStyle(color: Colors.white70)),
            );
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator(color: _pink));
          }
          final uid = DataService.instance.uid;
          final chats = [...snap.data!.docs]
            ..removeWhere((doc) =>
                List<String>.from(doc.data()['hiddenFor'] ?? const []).contains(uid))
            ..sort((a, b) {
              final at = a.data()['lastMessageAt'];
              final bt = b.data()['lastMessageAt'];
              final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
              final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
              return bm.compareTo(am);
            });
          if (chats.isEmpty) return _empty();
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
            itemCount: chats.length,
            itemBuilder: (context, i) => _chatTile(chats[i]),
          );
        },
      );

  Widget _chatTile(QueryDocumentSnapshot<Map<String, dynamic>> chat) {
    final data = chat.data();
    final users = List<String>.from(data['users'] ?? const []);
    final other = users.firstWhere((id) => id != DataService.instance.uid, orElse: () => '');
    if (other.isEmpty) return const SizedBox.shrink();
    if (_onlyFavorites && !_favorites.contains(chat.id)) return const SizedBox.shrink();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(other).snapshots(),
      builder: (context, userSnap) {
        final p = userSnap.data?.data() ?? <String, dynamic>{};
        if (!userSnap.hasData || !userSnap.data!.exists || p['isActive'] == false) {
          return const SizedBox.shrink();
        }
        final name = (p['name'] ?? 'Novo match').toString();
        final photo = (p['photoUrl'] ?? '').toString();
        final q = _search.text.trim().toLowerCase();
        if (q.isNotEmpty && !name.toLowerCase().contains(q)) return const SizedBox.shrink();
        final online = p['isOnline'] == true;
        final vip = p['isVip'] == true;
        final verified = p['isVerified'] == true;
        final preview = (data['lastMessage'] ?? '').toString();
        final stamp = data['lastMessageAt'];
        final time = stamp is Timestamp ? _ago(stamp.toDate()) : '';
        final unread = _unread(data);
        final fav = _favorites.contains(chat.id);
        return _card(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ChatScreen(chatId: chat.id, otherName: name)),
          ),
          avatar: GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: other)),
            ),
            child: _avatar(photo: photo, crown: vip, online: online),
          ),
          name: name,
          verified: verified,
          vip: vip,
          preview: preview.isEmpty ? 'Comece uma conversa 💜' : preview,
          time: time,
          unread: unread,
          read: unread == 0 && preview.isNotEmpty,
          favorite: fav,
          onFavorite: () => _toggleFavorite(chat.id),
        );
      },
    );
  }

  Widget _card({
    required VoidCallback onTap,
    required Widget avatar,
    required String name,
    required bool verified,
    required bool vip,
    required String preview,
    required String time,
    required int unread,
    required bool read,
    required bool favorite,
    required VoidCallback onFavorite,
  }) =>
      Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(.72),
          borderRadius: BorderRadius.circular(34),
          border: Border.all(color: _purple.withOpacity(.85), width: 1.3),
          boxShadow: [
            BoxShadow(color: _purple.withOpacity(.32), blurRadius: 14),
            BoxShadow(color: _pink.withOpacity(.12), blurRadius: 20),
          ],
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(34),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 14, 10),
            child: Row(children: [
              avatar,
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Flexible(
                      child: Text(name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                    ),
                    if (vip) ...[
                      const SizedBox(width: 4),
                      const Icon(Icons.workspace_premium, color: _gold, size: 19),
                    ],
                    if (verified) ...[
                      const SizedBox(width: 5),
                      const Icon(Icons.verified, color: _violet, size: 20),
                    ],
                  ]),
                  const SizedBox(height: 5),
                  Text(preview,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _lilac, fontSize: 15)),
                ]),
              ),
              InkWell(
                onTap: onFavorite,
                customBorder: const CircleBorder(),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(favorite ? Icons.favorite : Icons.favorite_border,
                      color: favorite ? _pink : _purple, size: 34,
                      shadows: [Shadow(color: _purple.withOpacity(.8), blurRadius: 10)]),
                ),
              ),
              const SizedBox(width: 4),
              Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(time,
                    style: const TextStyle(
                        color: Color(0xFFE05CFF), fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                if (unread > 0)
                  Container(
                    constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      shape: unread > 99 ? BoxShape.rectangle : BoxShape.circle,
                      borderRadius: unread > 99 ? BorderRadius.circular(16) : null,
                      color: _pink,
                      boxShadow: [BoxShadow(color: _pink.withOpacity(.8), blurRadius: 10)],
                    ),
                    child: Text(unread > 99 ? '99+' : '$unread',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                  )
                else if (read)
                  const Icon(Icons.done_all, color: Color(0xFFE05CFF), size: 26)
                else
                  const SizedBox(height: 32),
              ]),
            ]),
          ),
        ),
      );

  Widget _avatar({required String photo, required bool crown, required bool online}) =>
      SizedBox(
        width: 74,
        height: 74,
        child: Stack(clipBehavior: Clip.none, children: [
          Container(
            width: 74,
            height: 74,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_pink, _purple],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [BoxShadow(color: _pink.withOpacity(.45), blurRadius: 12)],
            ),
            child: Container(
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black),
              padding: const EdgeInsets.all(2),
              child: CircleAvatar(
                backgroundColor: const Color(0xFF321846),
                backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                child: photo.isEmpty
                    ? const Icon(Icons.person, color: Colors.white70, size: 34)
                    : null,
              ),
            ),
          ),
          if (crown)
            const Positioned(
              left: -4,
              top: -14,
              child: Icon(Icons.workspace_premium, color: _gold, size: 32,
                  shadows: [Shadow(color: Color(0xFFFFA000), blurRadius: 8)]),
            ),
          if (online)
            Positioned(
              right: 0,
              bottom: 2,
              child: Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                  color: const Color(0xFF20E65A),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 2),
                  boxShadow: const [BoxShadow(color: Color(0xAA20E65A), blurRadius: 8)],
                ),
              ),
            ),
        ]),
      );

  Widget _empty() => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.forum_outlined, color: _purple.withOpacity(.85), size: 58),
            const SizedBox(height: 12),
            const Text('Suas conversas aparecerão aqui',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              'Toque em Descobrir para encontrar pessoas e enviar sua primeira mensagem.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, height: 1.4),
            ),
          ]),
        ),
      );
}
