# Corrigir login Google do LoveMix (DEVELOPER_ERROR / ApiException: 10)

## Diagnóstico confirmado no projeto

- `applicationId` e `namespace`: `com.example.lovemix`.
- Projeto Firebase: `lovemix-73849`.
- O `google-services.json` atual contém cliente OAuth WEB (tipo 3), mas não inclui cliente OAuth Android (tipo 1).
- O workflow antigo permitia gerar APK release com a chave debug temporária do runner quando não havia secrets de assinatura. O SHA-1 dessa chave pode mudar entre execuções e não corresponde ao OAuth Android cadastrado.

## Alterações preparadas

- Removido o fallback automático para assinatura debug no build release.
- Os workflows `lovemix-apk.yml` e `gerar-apk-do-zip.yml` agora bloqueiam release sem chave persistente.
- Os workflows exibem SHA-1 e SHA-256 do certificado usado para assinar o APK.

## Etapas obrigatórias no Firebase e GitHub

1. No GitHub, abra o repositório do LoveMix > Settings > Secrets and variables > Actions. Cadastre `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` e `ANDROID_KEY_PASSWORD`, usando a mesma chave que assinará os próximos APKs. Não coloque senhas nem o arquivo da chave em código, ZIP público ou conversa. Se já existe APK distribuído, preserve a chave original; não crie outra sem planejar a atualização dos usuários.
2. Execute o workflow de APK. No log da etapa de assinatura, copie SHA-1 e SHA-256.
3. No Firebase Console > projeto `lovemix-73849` > Configurações do projeto > Seus apps > app Android `com.example.lovemix`, adicione os fingerprints SHA-1 e SHA-256. Se o app Android não estiver cadastrado com esse applicationId, registre-o exatamente como `com.example.lovemix`.
4. Em Authentication > Sign-in method, confirme que Google está habilitado.
5. Baixe o novo `google-services.json` do app Android depois de salvar os fingerprints e substitua os arquivos `lovemix/google-services.json` e `lovemix/android/app/google-services.json` pelo mesmo arquivo atualizado. Ele deve incluir cliente OAuth Android para `com.example.lovemix`, além do cliente WEB.
6. Faça commit/push e gere novamente o APK pelo workflow. Instale e teste Entrar com Google.

## Limite importante

Não é possível fabricar o SHA-1 correto nem gerar um `google-services.json` válido sem a chave que realmente assina o APK e sem atualizar o cadastro no Firebase. O código foi preparado para impedir releases com chave debug descartável, mas as etapas Firebase/GitHub acima ainda são necessárias.

## Verificação automática (novo)

Os workflows `lovemix-apk.yml` e `gerar-apk-do-zip.yml` agora têm a etapa "Conferir se o SHA-1 da chave está no google-services.json". Ela não bloqueia o build, mas mostra um aviso se o `google-services.json` não tiver cliente OAuth Android ou se o SHA-1 que assina o APK não estiver nele.
