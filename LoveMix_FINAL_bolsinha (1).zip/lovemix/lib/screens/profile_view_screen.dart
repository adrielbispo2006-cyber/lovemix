import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/account_service.dart';
import '../services/data_service.dart';
import '../services/local_xp.dart';
import '../services/supabase_service.dart';
import '../widgets/bag_button.dart';
import '../widgets/full_photo.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';
import 'alliance_wall_screen.dart';
import 'chat_screen.dart';
import 'gifts_screen.dart';
import 'messages_screen.dart';
import 'post_interactions_screen.dart';
import 'profile_frames_screen.dart';
import 'vip_nickname_screen.dart';
import 'wallet_screen.dart';

const _violet = Color(0xFFB62CFF);
const _violet2 = Color(0xFF7A1FD6);
const _gold = Color(0xFFFFC83D);
const _bg = Color(0xFF05010A);
const _card = Color(0xFF0B0314);

/// Perfil LoveMix (layout novo): o mesmo layout para qualquer pessoa.
/// Se [userId] for o usuário logado, mostra "Editar Perfil".
class ProfileViewScreen extends StatefulWidget {
  const ProfileViewScreen({super.key, required this.userId});
  final String userId;
  @override
  State<ProfileViewScreen> createState() => _ProfileViewScreenState();
}

class _ProfileViewScreenState extends State<ProfileViewScreen> {
  int _tab = 0;
  bool _busy = false;
  String get _me => FirebaseAuth.instance.currentUser?.uid ?? '';
  bool get _mine => widget.userId.isNotEmpty && widget.userId == _me;
  DocumentReference<Map<String, dynamic>> get _ref =>
      FirebaseFirestore.instance.collection('users').doc(widget.userId);

  void _snack(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  static String _compact(num n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(n >= 10000000 ? 0 : 1).replaceAll('.0', '')}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(n >= 10000 ? 0 : 1).replaceAll('.0', '')}K';
    return '${n.toInt()}';
  }

  static String _flag(String country) {
    final c = country.toLowerCase().trim();
    const m = {
      'brasil': '🇧🇷', 'brazil': '🇧🇷', 'portugal': '🇵🇹', 'argentina': '🇦🇷',
      'estados unidos': '🇺🇸', 'eua': '🇺🇸', 'usa': '🇺🇸', 'espanha': '🇪🇸',
      'paraguai': '🇵🇾', 'uruguai': '🇺🇾', 'chile': '🇨🇱', 'méxico': '🇲🇽', 'mexico': '🇲🇽',
      'angola': '🇦🇴', 'moçambique': '🇲🇿', 'itália': '🇮🇹', 'italia': '🇮🇹',
    };
    return m[c] ?? '';
  }

  static IconData _interestIcon(String t) {
    final s = t.toLowerCase();
    if (s.contains('jogo') || s.contains('game')) return Icons.sports_esports;
    if (s.contains('mús') || s.contains('mus')) return Icons.music_note;
    if (s.contains('amiz')) return Icons.favorite;
    if (s.contains('viag')) return Icons.flight;
    if (s.contains('namor')) return Icons.favorite_border;
    if (s.contains('filme') || s.contains('série')) return Icons.movie;
    if (s.contains('espor') || s.contains('fut')) return Icons.sports_soccer;
    return Icons.star;
  }

  int? _age(Map<String, dynamic> p) {
    final b = p['birthday'];
    if (b is Timestamp) {
      final d = b.toDate();
      final now = DateTime.now();
      var a = now.year - d.year;
      if (now.month < d.month || (now.month == d.month && now.day < d.day)) a--;
      return a;
    }
    final a = p['age'];
    return a is num ? a.toInt() : null;
  }

  // ───────────────────────── ações ─────────────────────────
  Future<void> _message() async {
    if (_mine) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const Scaffold(body: SafeArea(child: MessagesScreen()))));
      return;
    }
    try {
      final id = await DataService.instance.openDirectChat(widget.userId);
      final snap = await _ref.get();
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
          builder: (_) => ChatScreen(chatId: id, otherName: (snap.data()?['name'] ?? 'Pessoa').toString())));
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        action: msg.toLowerCase().contains('siga')
            ? SnackBarAction(label: 'Seguir', onPressed: () async {
                try { await DataService.instance.toggleFollow(widget.userId); _snack('Agora toque em Enviar Mensagem.'); } catch (_) {}
              })
            : null,
      ));
    }
  }

  Future<void> _like() async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null || _mine) return;
    try {
      final ref = _ref.collection('profileLikes').doc(me.uid);
      final s = await ref.get();
      if (s.exists) {
        await ref.delete();
      } else {
        await ref.set({'uid': me.uid, 'createdAt': FieldValue.serverTimestamp()});
        _snack('Perfil curtido 💜');
      }
    } catch (e) {
      _snack('Não foi possível curtir agora.');
    }
  }

  Future<void> _publishPhoto() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Entre novamente para publicar.');
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 65, maxWidth: 1000, maxHeight: 1000);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length >= 5 * 1024 * 1024) throw Exception('Escolha uma foto válida de até 5 MB.');
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final png = picked.name.toLowerCase().endsWith('.png');
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'posts/${user.uid}/$id.${png ? 'png' : 'jpg'}',
        bytes: bytes,
        contentType: png ? 'image/png' : 'image/jpeg',
      );
      await _ref.collection('posts').doc(id).set({
        'photoUrl': url,
        'visibility': 'public',
        'createdAt': FieldValue.serverTimestamp(),
      });
      _snack('Foto publicada!');
    } catch (e) {
      _snack('Não foi possível publicar: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _changeAvatar() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login novamente.');
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 65, maxWidth: 720, maxHeight: 720);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 5 * 1024 * 1024) throw Exception('Escolha uma foto de até 5 MB.');
      final n = picked.name.toLowerCase();
      final type = n.endsWith('.png') ? 'image/png' : n.endsWith('.webp') ? 'image/webp' : 'image/jpeg';
      final ext = type == 'image/png' ? 'png' : type == 'image/webp' ? 'webp' : 'jpg';
      final url = await SupabaseService.instance.uploadPhoto(path: 'profiles/${user.uid}/profile.$ext', bytes: bytes, contentType: type);
      await DataService.instance.updateProfile({'photoUrl': '$url?v=${DateTime.now().millisecondsSinceEpoch}'});
      _snack('Foto de perfil atualizada!');
    } catch (e) {
      _snack('Não foi possível trocar a foto: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deletePost(String id, String url) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Remover foto?'),
        content: const Text('Ela some do seu perfil.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Remover')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _ref.collection('posts').doc(id).delete();
      try { await FirebaseFirestore.instance.collection('feed_posts').doc(id).delete(); } catch (_) {}
      try { await SupabaseService.instance.deletePublicUrl(url); } catch (_) {}
    } catch (e) {
      _snack('Não foi possível remover a foto.');
    }
  }

  Future<void> _edit(Map<String, dynamic> p) async {
    final name = TextEditingController(text: (p['name'] ?? '').toString());
    final bio = TextEditingController(text: (p['bio'] ?? '').toString());
    final city = TextEditingController(text: (p['city'] ?? '').toString());
    final country = TextEditingController(text: (p['country'] ?? '').toString());
    final interest = TextEditingController();
    final interests = List<String>.from(p['interests'] ?? const []);
    DateTime? birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: EdgeInsets.fromLTRB(20, 18, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Editar Perfil', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              TextField(controller: name, maxLength: 30, decoration: const InputDecoration(labelText: 'Nome')),
              TextField(controller: bio, maxLength: 300, maxLines: 3, decoration: const InputDecoration(labelText: 'Sobre mim')),
              Row(children: [
                Expanded(child: TextField(controller: city, decoration: const InputDecoration(labelText: 'Cidade'))),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: country, decoration: const InputDecoration(labelText: 'País'))),
              ]),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                icon: const Icon(Icons.cake_outlined),
                label: Text(birthday == null ? 'Data de nascimento' : '${birthday!.day.toString().padLeft(2, '0')}/${birthday!.month.toString().padLeft(2, '0')}/${birthday!.year}'),
                onPressed: () async {
                  final d = await showDatePicker(
                    context: ctx,
                    initialDate: birthday ?? DateTime(2000),
                    firstDate: DateTime(1940),
                    lastDate: DateTime.now().subtract(const Duration(days: 365 * 18)),
                  );
                  if (d != null) set(() => birthday = d);
                },
              ),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final i in interests)
                  InputChip(label: Text(i), onDeleted: () => set(() => interests.remove(i))),
              ]),
              Row(children: [
                Expanded(child: TextField(controller: interest, maxLength: 20, decoration: const InputDecoration(labelText: 'Novo interesse', counterText: ''))),
                IconButton(
                  icon: const Icon(Icons.add_circle, color: _violet),
                  onPressed: () {
                    final t = interest.text.trim();
                    if (t.isNotEmpty && !interests.contains(t) && interests.length < 12) set(() => interests.add(t));
                    interest.clear();
                  },
                ),
              ]),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: _violet),
                  onPressed: () async {
                    final n = name.text.trim();
                    if (n.length < 2) return;
                    try {
                      await DataService.instance.updateProfile({
                        'name': n,
                        'bio': bio.text.trim(),
                        'city': city.text.trim(),
                        'country': country.text.trim(),
                        'interests': interests,
                        if (birthday != null) 'birthday': Timestamp.fromDate(birthday!),
                      });
                      if (ctx.mounted) Navigator.pop(ctx);
                      _snack('Perfil atualizado!');
                    } catch (e) {
                      _snack('Não foi possível salvar o perfil.');
                    }
                  },
                  child: const Text('Salvar'),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> _moreMenu(Map<String, dynamic> p) async {
    final v = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: _card,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (_mine) ...[
            ListTile(leading: const Icon(Icons.copy), title: const Text('Copiar meu ID'), onTap: () => Navigator.pop(c, 'id')),
            ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('Trocar foto de perfil'), onTap: () => Navigator.pop(c, 'avatar')),
            ListTile(leading: const Icon(Icons.auto_awesome), title: const Text('Molduras'), onTap: () => Navigator.pop(c, 'frames')),
            ListTile(leading: const Icon(Icons.workspace_premium), title: const Text('Apelido VIP'), onTap: () => Navigator.pop(c, 'vip')),
            const Divider(height: 1, color: Colors.white12),
            ListTile(leading: const Icon(Icons.person_add_alt), title: const Text('Mudar de conta'), onTap: () => Navigator.pop(c, 'addAccount')),
            ListTile(leading: const Icon(Icons.logout), title: const Text('Sair da conta'), onTap: () => Navigator.pop(c, 'logout')),
            ListTile(leading: const Icon(Icons.delete_forever, color: Colors.redAccent), title: const Text('Apagar conta', style: TextStyle(color: Colors.redAccent)), onTap: () => Navigator.pop(c, 'deleteAccount')),
          ] else ...[
            ListTile(leading: const Icon(Icons.person_add_alt_1), title: const Text('Seguir / Deixar de seguir'), onTap: () => Navigator.pop(c, 'follow')),
            ListTile(leading: const Icon(Icons.favorite_border), title: const Text('Curtir perfil'), onTap: () => Navigator.pop(c, 'like')),
            ListTile(leading: const Icon(Icons.block), title: const Text('Bloquear'), onTap: () => Navigator.pop(c, 'block')),
            ListTile(leading: const Icon(Icons.flag_outlined), title: const Text('Denunciar'), onTap: () => Navigator.pop(c, 'report')),
          ],
        ]),
      ),
    );
    switch (v) {
      case 'id':
        final id = (p['publicId'] ?? '').toString();
        if (id.isNotEmpty) {
          await Clipboard.setData(ClipboardData(text: id));
          _snack('ID copiado!');
        }
      case 'avatar': await _changeAvatar();
      case 'frames': if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen()));
      case 'vip': if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen()));
      case 'addAccount': await _addAccount();
      case 'logout': await _logout();
      case 'deleteAccount': await _deleteAccount();
      case 'follow':
        try { final on = await DataService.instance.toggleFollow(widget.userId); _snack(on ? 'Você começou a seguir.' : 'Você deixou de seguir.'); } catch (_) { _snack('Não foi possível seguir agora.'); }
      case 'like': await _like();
      case 'block':
        try { await DataService.instance.blockUser(widget.userId); _snack('Pessoa bloqueada.'); } catch (_) { _snack('Não foi possível bloquear.'); }
      case 'report':
        try { await DataService.instance.reportUser(widget.userId, 'Perfil denunciado'); _snack('Denúncia enviada.'); } catch (_) { _snack('Não foi possível denunciar.'); }
    }
  }

  Future<void> _addAccount() async {
    if (mounted && await AccountService.confirmAddAccount(context)) {
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
      await AccountService.addAnotherAccount();
    }
  }

  Future<void> _logout() async {
    if (mounted && await AccountService.confirmSignOut(context)) {
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
      await AccountService.signOut();
    }
  }

  Future<void> _deleteAccount() async {
    if (mounted && await AccountService.deleteAccount(context)) {
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    }
  }

  Widget _accountActions() {
    Widget tile(IconData icon, String label, VoidCallback onTap, {Color color = Colors.white}) => Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                Icon(icon, color: color),
                const SizedBox(width: 14),
                Expanded(child: Text(label, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w700))),
                Icon(Icons.chevron_right, color: color.withOpacity(.6)),
              ]),
            ),
          ),
        );
    return Container(
      margin: const EdgeInsets.only(top: 18, bottom: 28),
      decoration: _neon(r: 20, glow: .2),
      child: Column(children: [
        tile(Icons.swap_horiz, 'Mudar de conta', _addAccount),
        const Divider(height: 1, color: Colors.white12),
        tile(Icons.logout, 'Sair da conta', _logout),
        const Divider(height: 1, color: Colors.white12),
        tile(Icons.delete_forever, 'Apagar conta', _deleteAccount, color: Colors.redAccent),
      ]),
    );
  }

  // ───────────────────────── widgets ─────────────────────────
  BoxDecoration _neon({double r = 22, Color? fill, double glow = .35}) => BoxDecoration(
        color: fill ?? _card.withOpacity(.88),
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: _violet.withOpacity(.95), width: 1.4),
        boxShadow: [BoxShadow(color: _violet.withOpacity(glow), blurRadius: 14)],
      );

  Widget _glowIcon(IconData i, double s, {double angle = 0}) => Transform.rotate(
        angle: angle,
        child: Icon(i, size: s, color: _violet.withOpacity(.9), shadows: const [Shadow(color: _violet, blurRadius: 18)]),
      );

  Widget _pill(IconData icon, String label, VoidCallback onTap, {bool primary = false, bool selected = false, Color? iconColor}) {
    final filled = primary || selected;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          height: 52,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            gradient: filled ? const LinearGradient(colors: [Color(0xFFC13BFF), _violet2]) : null,
            color: filled ? null : _card.withOpacity(.9),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _violet.withOpacity(.95), width: 1.3),
            boxShadow: [BoxShadow(color: _violet.withOpacity(filled ? .55 : .25), blurRadius: 12)],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 21, color: iconColor ?? Colors.white),
            const SizedBox(width: 7),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5))),
          ]),
        ),
      ),
    );
  }

  Widget _photosTab() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('posts').snapshots(),
        builder: (_, s) {
          final docs = (s.data?.docs ?? []).where((d) => _mine || (d.data()['visibility'] ?? 'public') == 'public').toList()
            ..sort((a, b) {
              final x = a.data()['createdAt'], y = b.data()['createdAt'];
              return (y is Timestamp ? y.millisecondsSinceEpoch : 0).compareTo(x is Timestamp ? x.millisecondsSinceEpoch : 0);
            });
          final tiles = <Widget>[
            if (_mine)
              GestureDetector(
                onTap: _publishPhoto,
                child: Container(
                  decoration: _neon(r: 16, glow: .3),
                  child: _busy
                      ? const Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)))
                      : const Icon(Icons.add_a_photo_outlined, color: _violet, size: 32),
                ),
              ),
            for (final d in docs)
              () {
                final url = (d.data()['photoUrl'] ?? '').toString();
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: d.id, photoUrl: url))),
                  onLongPress: _mine ? () => _deletePost(d.id, url) : null,
                  child: Container(
                    decoration: _neon(r: 16, glow: .3),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Stack(fit: StackFit.expand, children: [
                        CachedNetworkImage(imageUrl: url, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white38)),
                        const Positioned(right: 6, bottom: 6, child: Icon(Icons.favorite_border, color: Colors.white, size: 21, shadows: [Shadow(color: Colors.black, blurRadius: 6)])),
                      ]),
                    ),
                  ),
                );
              }(),
          ];
          if (tiles.isEmpty) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Nenhuma foto publicada ainda.', style: TextStyle(color: Colors.white60))));
          }
          return GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            children: tiles,
          );
        },
      );

  Widget _achievementsTab() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('achievements').snapshots(),
        builder: (_, s) {
          final docs = s.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Nenhuma conquista ainda.', style: TextStyle(color: Colors.white60))));
          }
          return Wrap(spacing: 8, runSpacing: 8, children: [
            for (final d in docs)
              Container(
                width: 160,
                padding: const EdgeInsets.all(10),
                decoration: _neon(r: 16, glow: .2),
                child: Column(children: [
                  Text((d.data()['emoji'] ?? '🏆').toString(), style: const TextStyle(fontSize: 26)),
                  Text((d.data()['title'] ?? d.data()['name'] ?? 'Conquista').toString(), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
                ]),
              ),
          ]);
        },
      );

  Widget _vipTab(bool vip) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: _neon(r: 18, glow: .25),
        child: Column(children: [
          const Text('👑', style: TextStyle(fontSize: 34)),
          Text(vip ? 'Membro VIP LoveMix' : 'Ainda não é VIP', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          if (!vip && _mine)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: _violet),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen())),
                child: const Text('Ver benefícios VIP'),
              ),
            ),
        ]),
      );

  Widget _about(Map<String, dynamic> p) {
    final bio = (p['bio'] ?? '').toString().trim();
    final interests = List<String>.from(p['interests'] ?? const []);
    final age = _age(p);
    final shown = interests.take(4).toList();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: _neon(r: 24, glow: .3),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(5),
            decoration: const BoxDecoration(color: _violet, shape: BoxShape.circle),
            child: const Icon(Icons.info_outline, size: 22, color: Colors.white),
          ),
          const SizedBox(width: 10),
          const Text('Sobre mim', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          if (age != null) ...[const Spacer(), Text('$age anos', style: const TextStyle(color: Colors.white70))],
        ]),
        const SizedBox(height: 8),
        Text(bio.isEmpty ? (_mine ? 'Toque em Editar Perfil para escrever sobre você.' : 'Esta pessoa ainda não escreveu nada.') : bio,
            style: const TextStyle(fontSize: 16, height: 1.35)),
        if (interests.isNotEmpty) ...[
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final t in shown)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: _violet.withOpacity(.9)), color: Colors.black26),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(_interestIcon(t), size: 17, color: const Color(0xFFD59BFF)),
                  const SizedBox(width: 6),
                  Text(t, style: const TextStyle(fontSize: 14)),
                ]),
              ),
            if (interests.length > 4)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: _violet.withOpacity(.9))),
                child: Text('+${interests.length - 4}'),
              ),
          ]),
        ],
      ]),
    );
  }

  Widget _visitorPhotos() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _ref.collection('posts').snapshots(),
        builder: (_, s) {
          final docs = (s.data?.docs ?? []).where((d) => (d.data()['visibility'] ?? 'public') == 'public').toList()
            ..sort((a, b) {
              final x = a.data()['createdAt'], y = b.data()['createdAt'];
              return (y is Timestamp ? y.millisecondsSinceEpoch : 0).compareTo(x is Timestamp ? x.millisecondsSinceEpoch : 0);
            });
          if (docs.isEmpty) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: Text('Nenhuma foto publicada ainda.', style: TextStyle(color: Colors.white60))));
          }
          return GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 4,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: .82,
            children: [
              for (final d in docs)
                () {
                  final url = (d.data()['photoUrl'] ?? '').toString();
                  return GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: d.id, photoUrl: url))),
                    child: Container(
                      decoration: _neon(r: 16, glow: .35),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: Stack(fit: StackFit.expand, children: [
                          CachedNetworkImage(imageUrl: url, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white38)),
                          Positioned(
                            right: 5, bottom: 5,
                            child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                              child: const Icon(Icons.favorite_border, color: Colors.white, size: 18),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  );
                }(),
            ],
          );
        },
      );

  // ───────────────────── novo layout (igual ao modelo) ─────────────────────
  bool _bioOpen = false;
  int _localXp = 0;

  @override
  void initState() {
    super.initState();
    if (_mine) LocalXp.get(_me).then((v) { if (mounted) setState(() => _localXp = v); });
  }

  late Future<int> _ownedFut = _loadOwned();

  Future<int> _loadOwned() async {
    try {
      final snap = await FirebaseFirestore.instance.collection('users').doc(widget.userId).get();
      final remote = (snap.data()?['ownedProfileFrames'] as List?)?.map((e) => e.toString()).toSet() ?? <String>{};
      final prefs = await SharedPreferences.getInstance();
      final local = prefs.getStringList('lovemix_frames_${widget.userId}_owned') ?? const <String>[];
      return <String>{'classic', ...remote, ...local}.length;
    } catch (_) {
      return 1;
    }
  }

  Widget _countOf(Query<Map<String, dynamic>> q, Widget Function(int n) builder) =>
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: q.snapshots(),
        builder: (_, s) => builder(s.data?.docs.length ?? 0),
      );

  Widget _img(String name, double w, {double? h}) =>
      Image.asset('assets/profile/$name.png', width: w, height: h, fit: BoxFit.contain, filterQuality: FilterQuality.medium);

  Widget _avatar(Map<String, dynamic> p, double k, bool vip, bool owner, bool verified) {
    final photo = (p['photoUrl'] ?? '').toString();
    final frame = (p['selectedProfileFrame'] ?? 'classic').toString();
    final custom = frame.isNotEmpty && frame != 'classic';
    final d = 392 * k;
    Widget face;
    if (custom) {
      face = ProfileFrameAvatar(photoUrl: photo, frameId: frame, size: math.max(60.0, 312 * k - 14));
    } else {
      face = Container(
        width: d + 28 * k,
        height: d + 28 * k,
        padding: EdgeInsets.all(8 * k),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(colors: [Color(0xFFFF4DE1), Color(0xFF8A2BFF), Color(0xFFD13BFF)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: _violet.withOpacity(.75), blurRadius: 34 * k, spreadRadius: 2 * k)],
        ),
        child: Container(
          padding: EdgeInsets.all(5 * k),
          decoration: const BoxDecoration(shape: BoxShape.circle, color: _bg),
          child: ClipOval(
            child: photo.isEmpty
                ? Container(color: _card, child: Icon(Icons.person, size: d * .5, color: Colors.white38))
                : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: _card, child: const Icon(Icons.person, color: Colors.white38))),
          ),
        ),
      );
    }
    return GestureDetector(onTap: () => photo.isEmpty ? null : showFullPhoto(context, photo), child: face);
  }

  Widget _header(Map<String, dynamic> p, double k, double fs(double v), bool owner, bool vip, bool verified) {
    final name = (p['name'] ?? 'Pessoa').toString();
    final pid = (p['publicId'] ?? '').toString();
    // Nível sobe com o uso do app: carisma (+1 por minuto aberto e presentes recebidos).
    final charisma = ((p['charisma'] as num?)?.toDouble() ?? 0) + (_mine ? _localXp : 0);
    final level = p['charismaLevel'] ?? p['level'] ?? (math.sqrt(charisma / 30).floor() + 1);
    final crown = vip || owner;
    return SizedBox(
      height: 590 * k,
      child: Stack(clipBehavior: Clip.none, children: [
        Positioned.fill(child: CustomPaint(painter: _SwirlPainter(k))),
        // logo LoveMix (script) + frase
        Positioned(left: 508 * k, top: 0, child: _img('logo_script', 578 * k)),
        // avatar
        Positioned(
          left: 262 * k - 220 * k,
          top: 300 * k - 220 * k,
          width: 440 * k,
          height: 440 * k,
          child: Center(child: _avatar(p, k, vip, owner, verified)),
        ),
        if (crown) Positioned(left: 78 * k, top: 18 * k, child: IgnorePointer(child: _img('crown_big', 178 * k))),
        if (verified)
          Positioned(
            left: 135 * k - 24 * k, top: 462 * k - 24 * k,
            child: Container(
              width: 48 * k, height: 48 * k,
              decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF7B5CFF), border: Border.all(color: _bg, width: 3 * k), boxShadow: [BoxShadow(color: _violet.withOpacity(.8), blurRadius: 10)]),
              child: Icon(Icons.check, color: Colors.white, size: 30 * k),
            ),
          ),
        if (_mine)
          Positioned(
            left: 380 * k - 46 * k, top: 462 * k - 46 * k,
            child: GestureDetector(
              onTap: _changeAvatar,
              child: Container(
                width: 92 * k, height: 92 * k,
                decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF0B0314), border: Border.all(color: _violet, width: 3 * k), boxShadow: [BoxShadow(color: _violet.withOpacity(.6), blurRadius: 12)]),
                child: _busy
                    ? Padding(padding: EdgeInsets.all(26 * k), child: const CircularProgressIndicator(strokeWidth: 2))
                    : Icon(Icons.photo_camera, color: Colors.white, size: 46 * k),
              ),
            ),
          ),
        // nome
        Positioned(
          left: 505 * k, right: 20 * k, top: 345 * k,
          child: Row(children: [
            if (crown) Padding(padding: EdgeInsets.only(right: 22 * k), child: _img('crown_small', 72 * k)),
            Flexible(child: VipNickname(name: name, isVip: (p['isVip'] == true || p['nicknameDecorationActive'] == true), styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: TextStyle(fontSize: fs(54), fontWeight: FontWeight.w800, height: 1.1))),
            if (verified) Padding(padding: EdgeInsets.only(left: 14 * k), child: Icon(Icons.verified, color: const Color(0xFF5B7CFF), size: fs(50))),
          ]),
        ),
        // ID
        Positioned(
          left: 512 * k, top: 424 * k,
          child: GestureDetector(
            onTap: () async {
              if (pid.isEmpty) return;
              await Clipboard.setData(ClipboardData(text: pid));
              _snack('ID copiado!');
            },
            child: Row(children: [
              Text('ID: ${pid.isEmpty ? '—' : pid}', style: TextStyle(fontSize: fs(33), color: Colors.white70)),
              SizedBox(width: 16 * k),
              Icon(Icons.copy_outlined, size: fs(34), color: Colors.white70),
            ]),
          ),
        ),
        // Lv + VIP
        Positioned(
          left: 510 * k, top: 488 * k,
          child: Row(children: [
            GestureDetector(
              onTap: () {
                final lv = level is num ? level.toInt() : (int.tryParse('$level') ?? 1);
                final need = 30 * lv * lv;
                _snack('Nível $lv • XP ${charisma.toInt()} / $need. Ganhe XP usando o app (+1 por minuto) e enviando presentes.');
              },
              child: Container(
              height: math.max(26.0, 52 * k),
              padding: EdgeInsets.only(left: 4 * k, right: 20 * k),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40 * k),
                gradient: const LinearGradient(colors: [Color(0xFF9B2CFF), Color(0xFF5B1FD0)]),
                border: Border.all(color: const Color(0xFFFF6BE6), width: 2 * k),
                boxShadow: [BoxShadow(color: _violet.withOpacity(.6), blurRadius: 10)],
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: math.max(22.0, 44 * k), height: math.max(22.0, 44 * k),
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFFF4DE1), Color(0xFFB62CFF)])),
                  child: Icon(Icons.workspace_premium, color: Colors.white, size: fs(30)),
                ),
                SizedBox(width: 10 * k),
                Text('Lv.$level', style: TextStyle(fontSize: fs(33), fontWeight: FontWeight.w800)),
              ]),
            )),
            if (vip) ...[
              SizedBox(width: 22 * k),
              GestureDetector(
                onTap: _mine ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen())) : null,
                child: Container(
                  height: math.max(26.0, 52 * k),
                  padding: EdgeInsets.symmetric(horizontal: 20 * k),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40 * k),
                    color: const Color(0xFF1A1006),
                    border: Border.all(color: _gold, width: 2 * k),
                    boxShadow: [BoxShadow(color: _gold.withOpacity(.35), blurRadius: 10)],
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    _img('crown_small', 40 * k),
                    SizedBox(width: 10 * k),
                    Text('VIP', style: TextStyle(fontSize: fs(33), fontWeight: FontWeight.w800, color: _gold)),
                  ]),
                ),
              ),
            ],
          ]),
        ),
        // Editar Perfil / Seguir
        Positioned(
          left: 845 * k, top: 436 * k, width: 218 * k, height: 68 * k,
          child: _mine
              ? _outlineBtn(k, fs, Icons.edit_outlined, 'Editar Perfil', () => _edit(p))
              : StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  stream: DataService.instance.followingStatus(widget.userId),
                  builder: (_, f) {
                    final on = f.data?.exists == true;
                    return _outlineBtn(k, fs, on ? Icons.check : Icons.person_add_alt_1, on ? 'Seguindo' : 'Seguir', () async {
                      try { await DataService.instance.toggleFollow(widget.userId); } catch (e) { _snack('Não foi possível seguir agora.'); }
                    }, filled: !on);
                  },
                ),
        ),
      ]),
    );
  }

  Widget _outlineBtn(double k, double fs(double v), IconData icon, String label, VoidCallback onTap, {bool filled = false}) => Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(40 * k),
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(40 * k),
              gradient: filled ? const LinearGradient(colors: [Color(0xFFC13BFF), _violet2]) : null,
              color: filled ? null : const Color(0xFF12041E),
              border: Border.all(color: const Color(0xFFD13BFF), width: 2.2 * k),
              boxShadow: [BoxShadow(color: _violet.withOpacity(.55), blurRadius: 12)],
            ),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 14 * k),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(icon, size: fs(36), color: Colors.white),
                  SizedBox(width: 10 * k),
                  Text(label, style: TextStyle(fontSize: fs(31), fontWeight: FontWeight.w700)),
                ]),
              ),
            ),
          ),
        ),
      );

  Widget _statCol(double k, double fs(double v), String icon, String value, String label) => Expanded(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _img(icon, 66 * k, h: 62 * k),
          SizedBox(height: 10 * k),
          FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: TextStyle(fontSize: fs(44), fontWeight: FontWeight.w800, height: 1.05))),
          FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: TextStyle(fontSize: fs(32), color: Colors.white70))),
        ]),
      );

  Widget _divider(double k) => Container(
        width: math.max(1.0, 2 * k), height: 120 * k,
        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, _violet.withOpacity(.9), Colors.transparent])),
      );

  Widget _stats(double k, double fs(double v), Map<String, dynamic> p) {
    final diamonds = (p['diamonds'] as num?) ?? 0;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8 * k),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _countOf(_ref.collection('profileLikes'), (n) => _statCol(k, fs, 'ic_heart', _compact(n), 'Curtidas')),
        _divider(k),
        _countOf(_ref.collection('followers'), (n) => _statCol(k, fs, 'ic_people', _compact(n), 'Seguidores')),
        _divider(k),
        _countOf(_ref.collection('following'), (n) => _statCol(k, fs, 'ic_star', _compact(n), 'Seguindo')),
        _divider(k),
        _statCol(k, fs, 'ic_diamond', _compact(diamonds), 'Diamantes'),
      ]),
    );
  }

  BoxDecoration _panel(double k, {bool glowRight = false}) => BoxDecoration(
        borderRadius: BorderRadius.circular(34 * k),
        gradient: LinearGradient(
          begin: Alignment.centerLeft, end: Alignment.centerRight,
          colors: glowRight ? [const Color(0xFF0B0314), const Color(0xFF2A0B4A)] : [const Color(0xFF0B0314), const Color(0xFF12041E)],
        ),
        border: Border.all(color: const Color(0xFFB62CFF).withOpacity(.9), width: 2.4 * k),
        boxShadow: [BoxShadow(color: _violet.withOpacity(.35), blurRadius: 16)],
      );

  Widget _bioCard(double k, double fs(double v), Map<String, dynamic> p) {
    final bio = (p['bio'] ?? '').toString().trim();
    final text = bio.isEmpty ? (_mine ? 'Toque em Editar Perfil para escrever sobre você.' : 'Esta pessoa ainda não escreveu nada.') : bio;
    return GestureDetector(
      onTap: () => setState(() => _bioOpen = !_bioOpen),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(34 * k, 24 * k, 30 * k, 24 * k),
        decoration: _panel(k),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('“', style: TextStyle(fontSize: fs(90), height: .8, fontWeight: FontWeight.w900, color: const Color(0xFFA64DFF))),
            SizedBox(width: 18 * k),
            Expanded(child: Padding(
              padding: EdgeInsets.only(top: 10 * k),
              child: Text(text, maxLines: _bioOpen ? 12 : 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: fs(38), height: 1.35)),
            )),
            Padding(
              padding: EdgeInsets.only(top: 50 * k),
              child: Icon(_bioOpen ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, size: fs(52), color: Colors.white70),
            ),
          ]),
          if (_bioOpen) ...[
            SizedBox(height: 12 * k),
            _aboutDetails(p),
          ],
        ]),
      ),
    );
  }

  Widget _aboutDetails(Map<String, dynamic> p) {
    final interests = List<String>.from(p['interests'] ?? const []);
    final age = _age(p);
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    final place = [if (city.isNotEmpty) city, if (country.isNotEmpty) country].join(' • ');
    final flag = _flag(country);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (age != null) Padding(padding: const EdgeInsets.only(bottom: 4), child: Row(children: [const Icon(Icons.cake_outlined, size: 18, color: _violet), const SizedBox(width: 8), Text('$age anos')])),
      if (place.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [const Icon(Icons.location_on, size: 18, color: _violet), const SizedBox(width: 8), Flexible(child: Text('$place $flag'))])),
      if (interests.isNotEmpty)
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final t in interests)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: _violet.withOpacity(.9)), color: Colors.black26),
              child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(_interestIcon(t), size: 16, color: const Color(0xFFD59BFF)), const SizedBox(width: 6), Text(t, style: const TextStyle(fontSize: 13.5))]),
            ),
        ]),
    ]);
  }

  Widget _tile(double k, double fs(double v), {required String icon, required String title, required Widget value, required String art, required double artW, required VoidCallback onTap, bool glow = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 206 * k,
        decoration: _panel(k, glowRight: true),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(32 * k),
          child: Stack(children: [
            Positioned(right: 2 * k, bottom: 2 * k, top: 8 * k, child: _img(art, artW * k)),
            Padding(
              padding: EdgeInsets.fromLTRB(30 * k, 26 * k, 14 * k, 18 * k),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  _img(icon, 54 * k, h: 54 * k),
                  SizedBox(width: 18 * k),
                  Flexible(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: fs(33), fontWeight: FontWeight.w600))),
                ]),
                const Spacer(),
                value,
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _coinValue(double k, double fs(double v), String coin, String text) => Row(children: [
        _img(coin, 56 * k, h: 56 * k),
        SizedBox(width: 20 * k),
        Flexible(child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(text, style: TextStyle(fontSize: fs(58), fontWeight: FontWeight.w800)))),
      ]);

  Widget _cards(double k, double fs(double v), Map<String, dynamic> p) {
    final myName = (p['name'] ?? '').toString();
    final gap = 26 * k;
    final gifts = _countOf(_ref.collection('receivedGifts'), (n) => _tile(k, fs,
        icon: 'ic_gift', title: _mine ? 'Meus Presentes' : 'Presentes', art: 'gift_art', artW: 186,
        value: _coinValue(k, fs, 'coin_dollar', _compact(n)),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: _mine ? '' : widget.userId)))));
    final ach = _countOf(_ref.collection('achievements'), (n) => _tile(k, fs,
        icon: 'ic_award', title: _mine ? 'Minhas Conquistas' : 'Conquistas', art: 'trophy_art', artW: 182,
        value: _coinValue(k, fs, 'coin_x', _compact(n)),
        onTap: () => setState(() => _tab = 1)));
    final frames = FutureBuilder<int>(
      future: _ownedFut,
      builder: (_, s) => _tile(k, fs,
          icon: 'ic_frame', title: _mine ? 'Molduras de Perfil' : 'Molduras', art: 'frame_art', artW: 240,
          value: _coinValue(k, fs, 'coin_star', _mine ? '${s.data ?? 1}' : '—'),
          onTap: () async {
            if (!_mine) return;
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen()));
            if (mounted) setState(() => _ownedFut = _loadOwned());
          }),
    );
    final alliance = StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('alliances').where('members', arrayContains: widget.userId).snapshots(),
      builder: (_, s) {
        final docs = (s.data?.docs ?? []).where((d) => d.data()['invitationStatus'] == 'accepted').toList();
        String line1 = 'Sem aliança';
        String line2 = _mine ? 'Toque para criar' : 'Membros: 0';
        if (docs.isNotEmpty) {
          final d = docs.first.data();
          final a = (d['creatorName'] ?? '').toString(), b = (d['invitedName'] ?? '').toString();
          line1 = (a == myName ? b : a).trim().isEmpty ? 'Aliança' : (a == myName ? b : a);
          final mem = (d['members'] as List?)?.length ?? 2;
          line2 = 'Membros: $mem';
        }
        return _tile(k, fs,
            icon: 'ic_team', title: _mine ? 'Minha Aliança' : 'Aliança', art: 'shield_art', artW: 168,
            value: Row(children: [
              Icon(Icons.favorite, color: const Color(0xFFA64DFF), size: fs(64)),
              SizedBox(width: 18 * k),
              Flexible(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(line1, maxLines: 1, style: TextStyle(fontSize: fs(46), fontWeight: FontWeight.w800, height: 1.05))),
                FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(line2, style: TextStyle(fontSize: fs(33), color: const Color(0xFFA64DFF)))),
              ])),
            ]),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (ctx) => Scaffold(
              backgroundColor: _bg,
              body: SafeArea(child: Column(children: [
                Align(alignment: Alignment.centerLeft, child: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(ctx))),
                const Expanded(child: AllianceWallScreen()),
              ])),
            ))));
      },
    );
    return Column(children: [
      Row(children: [Expanded(child: gifts), SizedBox(width: gap), Expanded(child: ach)]),
      SizedBox(height: gap),
      Row(children: [Expanded(child: frames), SizedBox(width: gap), Expanded(child: alliance)]),
    ]);
  }

  Widget _visitorActions(Map<String, dynamic> p) {
    final likesRef = _ref.collection('profileLikes');
    return Row(children: [
      Expanded(flex: 6, child: _pill(Icons.chat_bubble_outline, 'Enviar Mensagem', _message, primary: true)),
      const SizedBox(width: 8),
      Expanded(
        flex: 5,
        child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: likesRef.doc(_me.isEmpty ? '_' : _me).snapshots(),
          builder: (_, mine) {
            final liked = mine.data?.exists == true;
            return _pill(liked ? Icons.favorite : Icons.favorite_border, 'Curtir', _like, selected: liked, iconColor: const Color(0xFFFF6BE6));
          },
        ),
      ),
      const SizedBox(width: 8),
      SizedBox(width: 52, child: _pill(Icons.more_vert, '', () => _moreMenu(p))),
    ]);
  }

  Widget _sections(Map<String, dynamic> p, bool vip) => Column(children: [
        Row(children: [
          Expanded(child: _pill(Icons.photo_library_outlined, 'Fotos', () => setState(() => _tab = 0), selected: _tab == 0)),
          const SizedBox(width: 8),
          Expanded(child: _pill(Icons.star, 'Conquistas', () => setState(() => _tab = 1), selected: _tab == 1)),
          const SizedBox(width: 8),
          Expanded(child: _pill(Icons.workspace_premium, 'VIP', () => setState(() => _tab = 2), selected: _tab == 2)),
        ]),
        const SizedBox(height: 12),
        if (_tab == 0) (_mine ? _photosTab() : _visitorPhotos()) else if (_tab == 1) _achievementsTab() else _vipTab(vip),
      ]);

  @override
  Widget build(BuildContext context) {
    if (widget.userId.isEmpty) {
      return const Scaffold(backgroundColor: _bg, body: Center(child: Text('Perfil indisponível.')));
    }
    return Scaffold(
      backgroundColor: _bg,
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: _ref.snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Não foi possível carregar o perfil.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final p = snap.data!.data() ?? <String, dynamic>{};
          final owner = p['isAdmin'] == true;
          final vip = p['isVip'] == true || p['vip'] == true;
          final verified = p['isVerified'] == true || owner;
          return LayoutBuilder(builder: (context, c) {
            final k = c.maxWidth / 1086;
            double fs(double v) => math.max(v * k, 11.5);
            final top = MediaQuery.of(context).padding.top;
            return Stack(children: [
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(center: const Alignment(-.55, -.8), radius: 1.2, colors: [_violet.withOpacity(.30), _bg], stops: const [0, .8]),
                  ),
                ),
              ),
              ListView(
                padding: EdgeInsets.fromLTRB(0, top, 0, 28),
                children: [
                  _header(p, k, fs, owner, vip, verified),
                  SizedBox(height: 8 * k),
                  _stats(k, fs, p),
                  SizedBox(height: 28 * k),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 30 * k), child: _bioCard(k, fs, p)),
                  SizedBox(height: 28 * k),
                  Padding(padding: EdgeInsets.symmetric(horizontal: 30 * k), child: _cards(k, fs, p)),
                  const SizedBox(height: 16),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: math.max(30 * k, 12.0)),
                    child: Column(children: [
                      if (!_mine) ...[_visitorActions(p), const SizedBox(height: 12)],
                      _sections(p, vip),
                      if (_mine) _accountActions(),
                    ]),
                  ),
                ],
              ),
              if (Navigator.canPop(context))
                Positioned(left: 4, top: top + 2, child: IconButton(icon: const Icon(Icons.arrow_back, size: 26, shadows: [Shadow(color: Colors.black, blurRadius: 8)]), onPressed: () => Navigator.pop(context))),
              if (_mine) Positioned(right: 50, top: top + 10, child: const BagButton()),
              Positioned(right: 2, top: top + 2, child: IconButton(icon: const Icon(Icons.more_vert, shadows: [Shadow(color: Colors.black, blurRadius: 8)]), onPressed: () => _moreMenu(p))),
            ]);
          });
        },
      ),
    );
  }
}

/// Linhas de neon (ondas) do topo do perfil.
class _SwirlPainter extends CustomPainter {
  _SwirlPainter(this.k);
  final double k;
  @override
  void paint(Canvas canvas, Size size) {
    Paint stroke(Color c, double w, double blur) => Paint()
      ..color = c
      ..style = PaintingStyle.stroke
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, blur);
    final p1 = Path()
      ..moveTo(0, 520 * k)
      ..cubicTo(120 * k, 600 * k, 360 * k, 590 * k, 500 * k, 330 * k)
      ..cubicTo(540 * k, 250 * k, 640 * k, 250 * k, 760 * k, 270 * k);
    canvas.drawPath(p1, stroke(const Color(0xFFD13BFF).withOpacity(.55), 14 * k, 14 * k));
    canvas.drawPath(p1, stroke(const Color(0xFFFF6BE6), 3.2 * k, 1.2));
    final p2 = Path()
      ..moveTo(0, 560 * k)
      ..cubicTo(160 * k, 640 * k, 420 * k, 610 * k, 1086 * k, 600 * k);
    canvas.drawPath(p2, stroke(const Color(0xFF8A2BFF).withOpacity(.35), 10 * k, 12 * k));
    canvas.drawPath(p2, stroke(const Color(0xFFB62CFF).withOpacity(.8), 2.2 * k, 1));
    // brilhos
    final dot = Paint()..color = Colors.white.withOpacity(.8)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2);
    for (final o in [const Offset(60, 60), const Offset(440, 90), const Offset(40, 420), const Offset(490, 480)]) {
      canvas.drawCircle(Offset(o.dx * k, o.dy * k), 3.5 * k, dot);
    }
  }
  @override
  bool shouldRepaint(covariant _SwirlPainter old) => old.k != k;
}
