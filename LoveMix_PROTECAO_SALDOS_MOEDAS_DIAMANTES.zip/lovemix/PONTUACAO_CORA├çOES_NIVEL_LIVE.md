# Pontuação de corações e nível da Live

- Cada reação `heart` enviada por um espectador é exibida com animação e, ao ser recebida pelo anfitrião, soma 1 coração e 1 EXP.
- A cada 100 EXP, o nível sobe 1 nível (nível inicial 1).
- O placar é sincronizado para os participantes da sala em `rooms/{roomId}/liveStats/main`.
- Reações `like` (👍) continuam com animação, mas não somam pontos de coração.
- O placar não concede moedas nem diamantes.

## Publicação

O código do app e as regras `firestore.rules` foram atualizados. Para a sincronização do placar funcionar em aparelhos diferentes, publique as regras atualizadas do Firestore. Nenhuma Cloud Function foi adicionada ou alterada.
