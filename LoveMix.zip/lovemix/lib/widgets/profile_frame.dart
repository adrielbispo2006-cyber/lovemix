import 'package:cached_network_image/cached_network_image.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';

class ProfileFrameAvatar extends StatefulWidget {
  const ProfileFrameAvatar({super.key, required this.photoUrl, required this.frameId, this.size = 86});
  final String photoUrl;
  final String frameId;
  final double size;

  /// Molduras em imagem (arte real). id -> arquivo.
  static const Map<String, String> imageFrames = {
    'asas_reais': 'assets/frames/frame_01.webp',
    'gatinho_gamer': 'assets/frames/frame_02.webp',
    'coroa_louros': 'assets/frames/frame_03.webp',
    'neon_coracao': 'assets/frames/frame_04.webp',
    'rosa_negra_real': 'assets/frames/frame_05.webp',
    'orbita_amor': 'assets/frames/frame_06.webp',
    'vip_dourado': 'assets/frames/frame_07.webp',
    'jardim_roxo': 'assets/frames/frame_08.webp',
    'gatinha_neon': 'assets/frames/frame_09.webp',
    'rosas_rosa': 'assets/frames/frame_10.webp',
    'gotica_sombria': 'assets/frames/frame_11.webp',
    'chamas_reais': 'assets/frames/frame_12.webp',
    'laco_real': 'assets/frames/frame_13.webp',
    'galaxia_roxa': 'assets/frames/frame_14.webp',
    'asas_celestiais': 'assets/frames/frame_15.webp',
    'cadeado_amor': 'assets/frames/frame_16.webp',
    'ouro_alado': 'assets/frames/frame_17.webp',
    'coracoes_laco': 'assets/frames/frame_18.webp',
    'rosas_rubi': 'assets/frames/frame_19.webp',
    'borboletas_azuis': 'assets/frames/frame_20.webp',
    'anjo_halo': 'assets/frames/frame_21.webp',
    'borboletas_roxas': 'assets/frames/frame_22.webp',
    'dragao_verde': 'assets/frames/frame_23.webp',
    'gatinho_fofo': 'assets/frames/frame_24.webp',
    'correntes_prata': 'assets/frames/frame_25.webp',
    'leao_fogo': 'assets/frames/frame_26.webp',
    'rosas_prata': 'assets/frames/frame_27.webp',
    'estrelas_ouro': 'assets/frames/frame_28.webp',
    'realeza_gotas': 'assets/frames/frame_29.webp',
    'paraiso_tropical': 'assets/frames/frame_30.webp',
    'sakura': 'assets/frames/frame_31.webp',
    'gamer_neon': 'assets/frames/frame_32.webp',
    'amor_vermelho': 'assets/frames/frame_33.webp',
    'coroa_rubi': 'assets/frames/frame_34.webp',
    'hacker_verde': 'assets/frames/frame_35.webp',
    'borboletas_lilas': 'assets/frames/frame_36.webp',
    'inverno_gelo': 'assets/frames/frame_37.webp',
    'arco_iris': 'assets/frames/frame_38.webp',
    'rosas_poker': 'assets/frames/frame_39.webp',
    'lua_planetas': 'assets/frames/frame_40.webp',
    'asas_cristal': 'assets/frames/frame_41.webp',
  };


  @override
  State<ProfileFrameAvatar> createState() => _ProfileFrameAvatarState();
}

class _ProfileFrameAvatarState extends State<ProfileFrameAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final double _phase;

  // Tipo de movimento de cada moldura (as que não estão aqui usam 'pulse').
  static const Map<String, String> _motion = {
    'asas_reais': 'flap', 'ouro_alado': 'flap', 'anjo_halo': 'flap', 'asas_celestiais': 'flap', 'asas_cristal': 'flap',
    'borboletas_azuis': 'flutter', 'borboletas_roxas': 'flutter', 'borboletas_lilas': 'flutter', 'jardim_roxo': 'flutter',
    'chamas_reais': 'flame', 'leao_fogo': 'flame', 'dragao_verde': 'flame', 'hacker_verde': 'flame', 'gotica_sombria': 'flame',
    'gatinha_neon': 'bounce', 'gatinho_gamer': 'bounce', 'gatinho_fofo': 'bounce', 'gamer_neon': 'bounce',
    'cadeado_amor': 'sway', 'correntes_prata': 'sway', 'sakura': 'sway', 'paraiso_tropical': 'sway', 'inverno_gelo': 'sway',
    'orbita_amor': 'spin', 'galaxia_roxa': 'spin', 'estrelas_ouro': 'spin', 'lua_planetas': 'spin', 'arco_iris': 'spin',
  };

  @override
  void initState() {
    super.initState();
    _phase = math.Random().nextDouble();
    // Ciclo longo: a moldura fica parada e, de vez em quando, faz um movimento.
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 7), value: _phase);
    if (ProfileFrameAvatar.imageFrames.containsKey(widget.frameId)) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(covariant ProfileFrameAvatar old) {
    super.didUpdateWidget(old);
    final animate = ProfileFrameAvatar.imageFrames.containsKey(widget.frameId);
    if (animate && !_ctrl.isAnimating) _ctrl.repeat();
    if (!animate) _ctrl.stop();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  /// 0..1 durante o "gesto" (primeiros ~30% do ciclo), depois 0 (parada).
  double get _gesture {
    final t = _ctrl.value;
    if (t > .30) return 0;
    return math.sin(t / .30 * math.pi); // sobe e desce suave
  }

  Widget _animated(Widget child) {
    final g = _gesture;
    final t = _ctrl.value;
    final kind = _motion[widget.frameId] ?? 'pulse';
    double scale = 1, dx = 0, dy = 0, rot = 0;
    double scaleX = 1;
    switch (kind) {
      case 'flap':    // asas batem: abre e fecha na horizontal
        scaleX = 1 + .045 * math.sin(t / .30 * math.pi * 4) * g; scale = 1 + .02 * g; break;
      case 'flutter': // borboletas: tremem e balançam
        rot = .035 * math.sin(t / .30 * math.pi * 6) * g; dy = -2.5 * g; break;
      case 'flame':   // chamas: pulsa rápido
        scale = 1 + .03 * math.sin(t / .30 * math.pi * 5).abs() * g; dy = -1.5 * g; break;
      case 'bounce':  // gatinhos: pulinho
        dy = -5 * math.sin(t / .30 * math.pi * 2).abs() * g; scale = 1 + .015 * g; break;
      case 'sway':    // balança de um lado pro outro
        rot = .07 * math.sin(t / .30 * math.pi * 2) * g; break;
      case 'spin':    // gira de leve
        rot = .16 * g; break;
      default:        // coração batendo
        scale = 1 + .05 * math.sin(t / .30 * math.pi * 2).abs() * g; break;
    }
    return Transform(alignment: Alignment.center,
      transform: Matrix4.identity()..translate(dx, dy)..rotateZ(rot)..scale(scale * scaleX, scale),
      child: ColorFiltered(colorFilter: ColorFilter.mode(Colors.white.withOpacity(.16 * g), BlendMode.srcATop), child: child));
  }

  Widget _photo() => widget.photoUrl.isEmpty
      ? Container(color: const Color(0xFF21132E), child: const Center(child: Icon(Icons.person, color: Colors.white70, size: 42)))
      : CachedNetworkImage(imageUrl: widget.photoUrl, fit: BoxFit.cover,
          placeholder: (_, __) => const Center(child: CircularProgressIndicator(strokeWidth: 1)),
          errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white70, size: 42));

  static const Map<String, List<Color>> _palettes = {
    'neon': [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFF35D7FF)],
    'hearts': [Color(0xFFFF5A9E), Color(0xFFFF19B8), Color(0xFFFFB0D2)],
    'gold': [Color(0xFFFFE08A), Color(0xFFB87918), Color(0xFFFFF0B5)],
    'cosmic': [Color(0xFF39D9FF), Color(0xFF8D35FF), Color(0xFFFF19B8)],
    'royal_crown': [Color(0xFFFFD56A), Color(0xFF9D5B13), Color(0xFFFFF0A8)],
    'kitty': [Color(0xFFFF9DDE), Color(0xFF9B4DFF)],
    'butterfly': [Color(0xFFB65CFF), Color(0xFFFF65D4), Color(0xFF67DFFF)],
    'rose': [Color(0xFF40102F), Color(0xFFFF247F), Color(0xFF9B174D)],
    'headphones': [Color(0xFF9B55FF), Color(0xFFEF43D0), Color(0xFF55D9FF)],
    'pink_bow': [Color(0xFFFF78C8), Color(0xFFFF20A8)],
    'flame': [Color(0xFFFF4A32), Color(0xFFB324FF), Color(0xFFFF9B32)],
    'angel': [Color(0xFFFFE9FF), Color(0xFFB78AFF), Color(0xFFFFFFFF)],
    'love_wings': [Color(0xFFFF35C8), Color(0xFF8D35FF), Color(0xFFFFB6E8)],
    'flower': [Color(0xFFFF83C8), Color(0xFF9B55FF), Color(0xFFFFD66B)],
    'sparkle': [Color(0xFF9D75FF), Color(0xFF4DDFFF), Color(0xFFFFFFFF)],
    'diamond_heart': [Color(0xFF72E5FF), Color(0xFFB45BFF), Color(0xFFFF5FB8)],
    'broken_heart': [Color(0xFFFF4B8B), Color(0xFF6B24C9)],
    'royal_purple': [Color(0xFFB45BFF), Color(0xFF5B20A8), Color(0xFFFFD56A)],
    'couple': [Color(0xFFFF4DAD), Color(0xFF9B45E8), Color(0xFFFFA8C9)],
    'butterfly_royal': [Color(0xFF72E5FF), Color(0xFF9B45E8), Color(0xFFFFD56A)],
    'rose_gold': [Color(0xFFFFD56A), Color(0xFF9B174D), Color(0xFFFFF0B5)],
    'celestial': [Color(0xFFFFFFFF), Color(0xFFB45BFF), Color(0xFF72DFFF)],
    'royal_wings': [Color(0xFFFFE08A), Color(0xFF8D35FF), Color(0xFFFFF0B5)],
    'diamond_crown': [Color(0xFF72E5FF), Color(0xFFFFD56A), Color(0xFFFFFFFF)],
    'lovemix_deluxe': [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFFFFD56A)],
  };

  static const Map<String, String> _ornaments = {
    'hearts': '♥', 'gold': '👑', 'cosmic': '✦', 'royal_crown': '👑',
    'kitty': '🐱', 'butterfly': '🦋', 'rose': '🌹', 'headphones': '🎧',
    'pink_bow': '🎀', 'flame': '🔥', 'angel': '🪽', 'love_wings': '💞',
    'flower': '🌸', 'sparkle': '⭐', 'diamond_heart': '💎',
    'broken_heart': '💔', 'royal_purple': '👑', 'couple': '💕',
    'butterfly_royal': '🦋', 'rose_gold': '🌹', 'celestial': '😇',
    'royal_wings': '🪽', 'diamond_crown': '💎', 'lovemix_deluxe': '💖',
  };

  @override
  Widget build(BuildContext context) {
    final isDefault = widget.frameId.isEmpty || widget.frameId == 'classic';
    final imagePath = ProfileFrameAvatar.imageFrames[widget.frameId];
    if (imagePath != null) {
      // A arte tem o buraco do aro em 50% da largura da imagem.
      final box = widget.size + 14;
      final hole = box * 0.80;
      final canvas = hole / 0.5;
      return SizedBox(width: box, height: box, child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
        SizedBox(width: hole * 1.04, height: hole * 1.04,
          child: ClipOval(child: ColoredBox(color: const Color(0xFF21132E), child: _photo()))),
        IgnorePointer(child: RepaintBoundary(child: AnimatedBuilder(animation: _ctrl, builder: (context, child) => _animated(child!),
          child: SizedBox(width: canvas, height: canvas,
            child: Image.asset(imagePath, fit: BoxFit.contain, filterQuality: FilterQuality.medium, gaplessPlayback: true))))),
      ]));
    }
    final colors = _palettes[widget.frameId] ?? const [Color(0xFF8D35FF), Color(0xFFFF19B8)];
    final ornament = _ornaments[widget.frameId];
    final total = widget.size + (isDefault ? 0 : 14);
    return SizedBox(width: total, height: total, child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
      Container(width: total, height: total, padding: EdgeInsets.all(isDefault ? 1.5 : 5),
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: isDefault ? null : SweepGradient(colors: [...colors, colors.first]),
          border: isDefault ? Border.all(color: Colors.white24, width: 1.5) : null,
          boxShadow: isDefault ? null : [BoxShadow(color: colors.first.withOpacity(.48), blurRadius: 13, spreadRadius: 1)]),
        child: ClipOval(child: Container(color: const Color(0xFF21132E), child: widget.photoUrl.isEmpty
          ? const Icon(Icons.person, color: Colors.white70, size: 42)
          : CachedNetworkImage(imageUrl: widget.photoUrl, fit: BoxFit.cover,
              placeholder: (_, __) => const Center(child: CircularProgressIndicator(strokeWidth: 1)),
              errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white70, size: 42)))),
      ),
      if (!isDefault && ornament != null)
        Positioned(top: -5, right: -3, child: Text(ornament, style: TextStyle(fontSize: widget.size * .25,
          shadows: [Shadow(color: colors.first, blurRadius: 9)]))),
      if (widget.frameId == 'butterfly_royal') ...[
        Positioned(left: -4, top: widget.size * .12, child: Text('✦', style: TextStyle(color: colors.last, fontSize: widget.size * .22))),
        Positioned(bottom: -5, left: widget.size * .16, child: Text('🦋', style: TextStyle(fontSize: widget.size * .19))),
      ],
      if (widget.frameId == 'rose_gold')
        Positioned(bottom: -5, left: -2, child: Text('🌹', style: TextStyle(fontSize: widget.size * .23))),
      if (widget.frameId == 'celestial') ...[
        Positioned(top: -8, left: widget.size * .25, child: Text('☾', style: TextStyle(color: colors.first, fontSize: widget.size * .25))),
        Positioned(bottom: -4, right: widget.size * .12, child: Text('✧', style: TextStyle(color: colors.last, fontSize: widget.size * .22))),
      ],
      if (widget.frameId == 'royal_wings') ...[
        Positioned(left: -8, top: widget.size * .28, child: Text('❧', style: TextStyle(color: colors.first, fontSize: widget.size * .28))),
        Positioned(right: -8, top: widget.size * .28, child: Text('❧', style: TextStyle(color: colors.first, fontSize: widget.size * .28))),
      ],
      if (widget.frameId == 'diamond_crown')
        Positioned(bottom: -5, child: Text('💎', style: TextStyle(fontSize: widget.size * .2))),
      if (widget.frameId == 'lovemix_deluxe') ...[
        Positioned(left: -5, bottom: widget.size * .2, child: Text('💕', style: TextStyle(fontSize: widget.size * .19))),
        Positioned(right: -5, bottom: widget.size * .2, child: Text('✨', style: TextStyle(fontSize: widget.size * .19))),
      ],
      if (widget.frameId == 'angel' || widget.frameId == 'love_wings' || widget.frameId == 'royal_purple' ||
          widget.frameId == 'celestial' || widget.frameId == 'royal_wings' || widget.frameId == 'lovemix_deluxe')
        Positioned(bottom: -3, child: Text(widget.frameId == 'angel' ? '✨' : widget.frameId == 'love_wings' ? '💗' : '💜',
          style: TextStyle(fontSize: widget.size * .2))),
      if (widget.frameId == 'couple')
        Positioned(bottom: -3, right: 1, child: Text('♥', style: TextStyle(color: Colors.pinkAccent, fontSize: widget.size * .23))),
    ]));
  }
}
