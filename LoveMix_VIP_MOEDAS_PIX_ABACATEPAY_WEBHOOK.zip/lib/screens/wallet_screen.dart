import 'dart:convert';
import 'dart:typed_data';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/data_service.dart';

const _gold = Color(0xFFFF2DAB);
const _panel = Color(0xFF241333);

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});
  @override
  Widget build(BuildContext context) => const _BalanceTab();
}

class _BalanceTab extends StatefulWidget {
  const _BalanceTab();
  @override
  State<_BalanceTab> createState() => _BalanceTabState();
}

class _BalanceTabState extends State<_BalanceTab> {
  bool loading = false;
  Map<String, dynamic>? pix;
  String? orderId;
  String? selectedProduct;
  static const products = <Map<String, dynamic>>[
    {'id':'coins_1000','name':'1.000 moedas','amount':490,'coins':1000,'price':'R\$ 4,90'},
    {'id':'coins_2500','name':'2.500 moedas','amount':990,'coins':2500,'price':'R\$ 9,90'},
    {'id':'coins_6000','name':'6.000 moedas','amount':1990,'coins':6000,'price':'R\$ 19,90'},
    {'id':'vip_30d','name':'VIP por 30 dias + 2.000 moedas','amount':990,'coins':2000,'price':'R\$ 9,90'},
  ];

  Future<void> buy(Map<String, dynamic> product) async {
    if (loading) return;
    setState(() { loading = true; pix = null; orderId = null; selectedProduct = product['id'] as String; });
    try {
      final result = await FirebaseFunctions.instanceFor(region: 'us-central1')
          .httpsCallable('createLoveMixPix').call({'productId': product['id']});
      final data = Map<String, dynamic>.from(result.data as Map);
      if (!mounted) return;
      setState(() { pix = data; orderId = data['orderId']?.toString(); });
    } on FirebaseFunctionsException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Não foi possível gerar o Pix.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erro ao gerar Pix: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> checkPayment() async {
    final id = orderId;
    if (id == null || loading) return;
    setState(() => loading = true);
    try {
      final result = await FirebaseFunctions.instanceFor(region: 'us-central1')
          .httpsCallable('confirmLoveMixPix').call({'orderId': id});
      final paid = (result.data as Map)['paid'] == true;
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(paid ? 'Pagamento confirmado! Benefício liberado na sua conta.' : 'Pagamento ainda não identificado. Aguarde alguns instantes e tente novamente.')));
      if (paid) setState(() { pix = null; orderId = null; selectedProduct = null; });
    } on FirebaseFunctionsException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Não foi possível verificar o pagamento.')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: DataService.instance.myProfile(),
    builder: (context, snap) {
      final p = snap.data?.data() ?? {};
      return ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [Expanded(child: _currencyCard('Moedas', '${p['coins'] ?? 0}', '🪙')), const SizedBox(width: 10), Expanded(child: _currencyCard('Diamantes', '${p['diamonds'] ?? 0}', '💎'))]),
        const SizedBox(height: 12),
        const Card(color: _panel, child: ListTile(leading: Icon(Icons.chat_bubble, color: _gold), title: Text('Chat sempre grátis'), subtitle: Text('Conversar com seus matches não consome moedas.'))),
        const SizedBox(height: 18),
        const Text('Comprar moedas', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Pagamento via Pix. As moedas são adicionadas após a confirmação.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 10),
        ...products.where((x) => x['id'] != 'vip_30d').map(_productTile),
        const SizedBox(height: 20),
        const Text('Clube VIP', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Card(color: _panel, child: ListTile(leading: Text('👑', style: TextStyle(fontSize: 30)), title: Text('VIP por 30 dias'), subtitle: Text('Inclui 2.000 moedas de bônus e acesso aos recursos VIP.'))),
        _productTile(products.last),
        if (pix != null) _pixPanel(),
        const SizedBox(height: 18),
        const Text('Diamantes', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const Text('Diamantes são uma moeda especial para presentes e alianças premium.', style: TextStyle(color: Colors.white60)),
      ]);
    },
  );

  Widget _productTile(Map<String, dynamic> product) => Card(color: _panel, child: ListTile(
    leading: const Icon(Icons.monetization_on, color: Color(0xFFFFD56A), size: 30),
    title: Text(product['name'] as String), trailing: ElevatedButton(
      onPressed: loading ? null : () => buy(product),
      child: loading && selectedProduct == product['id'] ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Text(product['price'] as String),
    ),
  ));

  Widget _pixPanel() {
    final code = (pix?['brCode'] ?? '').toString();
    final rawImage = (pix?['brCodeBase64'] ?? '').toString();
    final base64Data = rawImage.contains(',') ? rawImage.split(',').last : rawImage;
    Uint8List? bytes;
    try { if (base64Data.isNotEmpty) bytes = base64Decode(base64Data); } catch (_) {}
    return Card(color: _panel, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      const Text('Pix gerado — pague para liberar', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      if (bytes != null) Padding(padding: const EdgeInsets.all(12), child: Image.memory(bytes, width: 210, height: 210, errorBuilder: (_, __, ___) => const SizedBox.shrink())),
      const Text('Pix copia e cola', style: TextStyle(color: Colors.white70)),
      SelectableText(code, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: code.isEmpty ? null : () { Clipboard.setData(ClipboardData(text: code)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Código Pix copiado!'))); }, icon: const Icon(Icons.copy), label: const Text('Copiar código Pix')),
      ElevatedButton(onPressed: loading ? null : checkPayment, child: loading ? const CircularProgressIndicator() : const Text('Já paguei — verificar')),
    ])));
  }

  Widget _currencyCard(String title, String amount, String emoji) => Card(color: _panel, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Text(emoji, style: const TextStyle(fontSize: 30)), Text(amount, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: _gold)), Text(title)])));
}
