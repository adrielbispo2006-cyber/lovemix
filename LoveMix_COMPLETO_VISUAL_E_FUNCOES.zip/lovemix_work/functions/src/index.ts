import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { getMessaging } from "firebase-admin/messaging";

initializeApp();
const db = getFirestore();



/** Concede a função de fundador somente à conta verificada definida no código.
 * O cliente não pode escolher o e-mail nem definir isAdmin diretamente.
 */
export const claimFounderAdmin = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta primeiro.");
  const email = String(request.auth.token.email ?? "").trim().toLowerCase();
  const emailVerified = request.auth.token.email_verified === true;
  if (email !== "adrielbispo3009@gmail.com" || !emailVerified) {
    throw new HttpsError("permission-denied", "Esta conta não está autorizada como administradora.");
  }
  const uid = request.auth.uid;
  await getAuth().setCustomUserClaims(uid, { admin: true, founder: true });
  await db.collection("users").doc(uid).set({
    uid, email, isAdmin: true, adminRole: "founder", adminGrantedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  return { success: true, role: "founder" };
});

/** Envia push para todos os dispositivos registrados do usuário destinatário. */
async function notifyUser(
  uid: string,
  title: string,
  body: string,
  data: Record<string, string>
): Promise<void> {
  const tokensSnapshot = await db.collection("users").doc(uid)
    .collection("fcmTokens").get();
  const tokens = tokensSnapshot.docs
    .map((doc) => ({ id: doc.id, token: String(doc.data().token ?? doc.id) }))
    .filter((item) => item.token.length > 0);
  if (tokens.length === 0) return;

  const response = await getMessaging().sendEachForMulticast({
    tokens: tokens.map((item) => item.token),
    notification: { title, body },
    data,
    android: {
      priority: "high",
      notification: { channelId: "lovemix_updates", sound: "default" }
    }
  });

  const removals: Promise<unknown>[] = [];
  response.responses.forEach((result, index) => {
    const code = result.error?.code ?? "";
    if (!result.success && (
      code.includes("registration-token-not-registered") ||
      code.includes("invalid-registration-token")
    )) {
      removals.push(tokensSnapshot.docs[index].ref.delete());
    }
  });
  await Promise.all(removals);
}

/** Notifica o destinatário quando alguém curte seu perfil. */
export const notifyOnLike = onDocumentCreated(
  "users/{fromUid}/likes/{targetUid}",
  async (event) => {
    const { fromUid, targetUid } = event.params;
    if (fromUid === targetUid) return;
    const sender = await db.collection("users").doc(fromUid).get();
    const name = String(sender.data()?.name ?? "Alguém");
    await notifyUser(targetUid, "Nova curtida ❤️", `${name} curtiu seu perfil.`, {
      type: "like", fromUid
    });
  }
);

/** Notifica o outro participante quando uma nova mensagem chega. */
export const notifyOnMessage = onDocumentCreated(
  "chats/{chatId}/messages/{messageId}",
  async (event) => {
    const message = event.data?.data();
    if (!message) return;
    const senderUid = String(message.senderId ?? "");
    const chat = await db.collection("chats").doc(event.params.chatId).get();
    const participants = (chat.data()?.users ?? []) as string[];
    const recipientUid = participants.find((participant) => participant !== senderUid);
    if (!recipientUid || !senderUid) return;
    const sender = await db.collection("users").doc(senderUid).get();
    const name = String(sender.data()?.name ?? "Nova mensagem");
    const rawText = String(message.text ?? "");
    const preview = rawText.length > 100 ? `${rawText.substring(0, 97)}...` : rawText;
    await notifyUser(recipientUid, `Mensagem de ${name}`, preview, {
      type: "message", chatId: event.params.chatId, fromUid: senderUid
    });
  }
);


/** Notifica os participantes de uma sala sobre mensagens e presentes recebidos. */
export const notifyOnRoomActivity = onDocumentCreated(
  "rooms/{roomId}/messages/{messageId}",
  async (event) => {
    const message = event.data?.data();
    if (!message) return;
    const senderUid = String(message.senderId ?? "");
    const room = await db.collection("rooms").doc(event.params.roomId).get();
    const members = (room.data()?.members ?? []) as string[];
    const recipients = members.filter((member) => member !== senderUid);
    if (!senderUid || recipients.length === 0) return;
    const sender = await db.collection("users").doc(senderUid).get();
    const senderName = String(sender.data()?.name ?? "Alguém");
    const isGift = message.type === "gift";
    const body = isGift
      ? `${senderName} enviou ${String(message.emoji ?? "🎁")} ${String(message.giftName ?? "um presente")}.`
      : `${senderName}: ${String(message.text ?? "Nova mensagem").substring(0, 100)}`;
    await Promise.all(recipients.map((uid) => notifyUser(
      uid,
      isGift ? "Você recebeu um presente 🎁" : `Nova mensagem em ${String(room.data()?.name ?? "uma sala")}`,
      body,
      { type: isGift ? "room_gift" : "room_message", roomId: event.params.roomId, fromUid: senderUid }
    )));
  }
);

/**
 * Server-side like operation. Creates a match only after reciprocal like.
 * Clients must call this callable instead of writing match documents directly.
 */
export const likeUser = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  const uid = request.auth.uid;
  const targetUid = String(request.data?.targetUid ?? "");
  if (!targetUid || targetUid === uid) {
    throw new HttpsError("invalid-argument", "Perfil de destino inválido.");
  }

  const targetRef = db.collection("users").doc(targetUid);
  const myLikeRef = db.collection("users").doc(uid).collection("likes").doc(targetUid);
  const theirLikeRef = db.collection("users").doc(targetUid).collection("likes").doc(uid);
  const matchUsers = [uid, targetUid].sort();
  const matchId = matchUsers.join("_");
  const matchRef = db.collection("matches").doc(matchId);
  let matched = false;

  await db.runTransaction(async (tx) => {
    const target = await tx.get(targetRef);
    if (!target.exists || target.data()?.isActive !== true) {
      throw new HttpsError("not-found", "Este perfil não está disponível.");
    }
    const blocked = await db.collection("users").doc(uid)
      .collection("blocked").doc(targetUid).get();
    const blockedByTarget = await db.collection("users").doc(targetUid)
      .collection("blocked").doc(uid).get();
    if (blocked.exists || blockedByTarget.exists) {
      throw new HttpsError("permission-denied", "Não é possível curtir este perfil.");
    }
    const reciprocal = await tx.get(theirLikeRef);
    tx.set(myLikeRef, { createdAt: FieldValue.serverTimestamp() });
    if (reciprocal.exists) {
      matched = true;
      tx.set(matchRef, {
        users: matchUsers,
        createdAt: FieldValue.serverTimestamp(),
        lastMessage: "",
        lastMessageAt: FieldValue.serverTimestamp()
      }, { merge: true });
      tx.set(db.collection("chats").doc(matchId), {
        users: matchUsers,
        lastMessage: "",
        lastMessageAt: FieldValue.serverTimestamp()
      }, { merge: true });
    }
  });
  return { success: true, matched, matchId: matched ? matchId : null };
});



/** Resgata tarefas com validação no servidor e proteção contra resgate repetido. */
export const claimDailyTask = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  const uid = request.auth.uid;
  const taskId = String(request.data?.taskId ?? "");
  const rewards: Record<string, number> = {
    daily_login: 30,
    complete_profile: 100,
    send_messages: 100,
    like_profiles: 50
  };
  const reward = rewards[taskId];
  if (!reward) throw new HttpsError("invalid-argument", "Tarefa inválida.");

  const userRef = db.collection("users").doc(uid);
  const userSnap = await userRef.get();
  if (!userSnap.exists) throw new HttpsError("not-found", "Perfil não encontrado.");
  const profile = userSnap.data() ?? {};

  if (taskId === "complete_profile") {
    if (!String(profile.photoUrl ?? "").trim() || !String(profile.bio ?? "").trim()) {
      throw new HttpsError("failed-precondition", "Adicione uma foto e uma bio para concluir esta tarefa.");
    }
  } else if (taskId === "send_messages") {
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
    const messages = await db.collectionGroup("messages")
      .where("senderId", "==", uid)
      .where("createdAt", ">=", Timestamp.fromDate(today))
      .limit(10).get();
    const completed = messages.size >= 10;
    if (!completed) throw new HttpsError("failed-precondition", "Envie 10 mensagens hoje para resgatar esta recompensa.");
  } else if (taskId === "like_profiles") {
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);
    const likes = await userRef.collection("likes")
      .where("createdAt", ">=", Timestamp.fromDate(today)).limit(5).get();
    const completed = likes.size >= 5;
    if (!completed) throw new HttpsError("failed-precondition", "Curta 5 perfis hoje para resgatar esta recompensa.");
  }

  const now = new Date();
  const dayKey = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, "0")}-${String(now.getUTCDate()).padStart(2, "0")}`;
  const claimKey = taskId === "complete_profile" ? taskId : `${dayKey}_${taskId}`;
  const claimRef = userRef.collection("taskClaims").doc(claimKey);
  await db.runTransaction(async (tx) => {
    const [claim, currentUser] = await Promise.all([tx.get(claimRef), tx.get(userRef)]);
    if (claim.exists) throw new HttpsError("already-exists", "Você já resgatou esta tarefa no período atual.");
    if (!currentUser.exists) throw new HttpsError("not-found", "Perfil não encontrado.");
    tx.set(claimRef, { taskId, reward, claimedAt: FieldValue.serverTimestamp() });
    tx.update(userRef, { coins: FieldValue.increment(reward) });
  });
  return { success: true, coins: reward };
});

/** Envia presentes/alianças usando preços definidos exclusivamente no servidor. */
export const sendStoreItem = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  const uid = request.auth.uid;
  const targetUid = String(request.data?.targetUid ?? "");
  const itemType = String(request.data?.itemType ?? "");
  if (!targetUid || targetUid === uid) {
    throw new HttpsError("invalid-argument", "Escolha outra pessoa para receber o item.");
  }

  const catalog: Record<string, { name: string; emoji: string; currency: "coins" | "diamonds"; cost: number; category: "gift" | "alliance" | "free" }> = {
    "gift:Rosa": { name: "Rosa", emoji: "🌹", currency: "coins", cost: 50, category: "gift" },
    "gift:Ursinho": { name: "Ursinho", emoji: "🧸", currency: "coins", cost: 100, category: "gift" },
    "gift:Coração": { name: "Coração", emoji: "❤️", currency: "coins", cost: 200, category: "gift" },
    "gift:Bolo": { name: "Bolo", emoji: "🎂", currency: "coins", cost: 300, category: "gift" },
    "gift:Buquê": { name: "Buquê", emoji: "💐", currency: "diamonds", cost: 15, category: "gift" },
    "gift:Coroa": { name: "Coroa", emoji: "👑", currency: "diamonds", cost: 50, category: "gift" },
    "gift:Diamante": { name: "Diamante", emoji: "💎", currency: "diamonds", cost: 100, category: "gift" },
    "gift:Carro de luxo": { name: "Carro de luxo", emoji: "🚗", currency: "diamonds", cost: 150, category: "gift" },
    "bff:Aliança BFF": { name: "Aliança BFF", emoji: "💜", currency: "coins", cost: 250, category: "alliance" },
    "siblings:Aliança Irmãos": { name: "Aliança Irmãos", emoji: "💙", currency: "coins", cost: 300, category: "alliance" },
    "couple:Aliança Casal": { name: "Aliança Casal", emoji: "❤️", currency: "diamonds", cost: 50, category: "alliance" },
    "free_bff:Aliança BFF grátis": { name: "Aliança BFF grátis", emoji: "💛", currency: "coins", cost: 0, category: "free" }
  };
  const item = catalog[`${itemType}:${String(request.data?.itemName ?? "")}`];
  if (!item) throw new HttpsError("invalid-argument", "Presente ou aliança não encontrado.");

  const senderRef = db.collection("users").doc(uid);
  const recipientRef = db.collection("users").doc(targetUid);
  const senderBlockRef = senderRef.collection("blocked").doc(targetUid);
  const recipientBlockRef = recipientRef.collection("blocked").doc(uid);
  const freeClaimRef = senderRef.collection("freeAllianceClaims").doc("bff");
  const deliveryRef = recipientRef.collection("receivedItems").doc();

  await db.runTransaction(async (tx) => {
    const [sender, recipient, senderBlock, recipientBlock, freeClaim] = await Promise.all([
      tx.get(senderRef), tx.get(recipientRef), tx.get(senderBlockRef),
      tx.get(recipientBlockRef), item.category === "free" ? tx.get(freeClaimRef) : Promise.resolve(null)
    ]);
    if (!sender.exists || !recipient.exists || recipient.data()?.isActive !== true) {
      throw new HttpsError("not-found", "A pessoa escolhida não está disponível.");
    }
    if (senderBlock.exists || recipientBlock.exists) {
      throw new HttpsError("permission-denied", "Não é possível enviar para esta pessoa.");
    }
    if (item.category === "free" && freeClaim?.exists) {
      throw new HttpsError("already-exists", "Sua aliança grátis já foi resgatada.");
    }
    const balance = Number(sender.data()?.[item.currency] ?? 0);
    if (balance < item.cost) {
      throw new HttpsError("failed-precondition", `Saldo insuficiente de ${item.currency === "coins" ? "moedas" : "diamantes"}.`);
    }
    if (item.cost > 0) tx.update(senderRef, { [item.currency]: FieldValue.increment(-item.cost) });
    if (item.category === "free") {
      tx.set(freeClaimRef, { claimedAt: FieldValue.serverTimestamp() });
    }
    tx.set(deliveryRef, {
      fromUid: uid,
      itemType,
      itemName: item.name,
      emoji: item.emoji,
      currency: item.currency,
      cost: item.cost,
      status: "received",
      createdAt: FieldValue.serverTimestamp()
    });
  });
  return { success: true, itemName: item.name, status: "received" };
});


/** Report review is intentionally admin-only and should be expanded with moderation workflow. */
export const closeReport = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  const admin = await db.collection("users").doc(request.auth.uid).get();
  if (admin.data()?.isAdmin !== true) {
    throw new HttpsError("permission-denied", "Acesso restrito.");
  }
  const reportId = String(request.data?.reportId ?? "");
  if (!reportId) throw new HttpsError("invalid-argument", "Denúncia inválida.");
  await db.collection("reports").doc(reportId).update({
    status: "reviewed",
    reviewedAt: FieldValue.serverTimestamp(),
    reviewedBy: request.auth.uid
  });
  return { success: true };
});
