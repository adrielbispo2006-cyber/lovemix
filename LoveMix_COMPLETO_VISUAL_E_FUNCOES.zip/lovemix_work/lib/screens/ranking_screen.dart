import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class RankingScreen extends StatelessWidget {
  const RankingScreen({super.key});

  static const pink = Color(0xFFFF2DAB);
  static const purple = Color(0xFF8B35FF);
  static const panel = Color(0xFF171022);

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users')
            .where('isActive', isEqualTo: true)
            .orderBy('coins', descending: true).limit(50).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Não foi possível carregar o ranking. Confira a conexão e as regras do Firestore.',
                textAlign: TextAlign.center),
            ));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator(color: pink));
          }
          final users = snapshot.data!.docs;
          users.sort((a, b) => ((b.data()['coins'] ?? 0) as num)
              .compareTo((a.data()['coins'] ?? 0) as num));
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF46105F), Color(0xFF191027), Color(0xFF351044)]),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: purple.withOpacity(.7)),
                ),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.emoji_events_rounded, color: Color(0xFFFFD76A), size: 38),
                  SizedBox(height: 8),
                  Text('Ranking LoveMix', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                  SizedBox(height: 4),
                  Text('Quem está brilhando na comunidade', style: TextStyle(color: Colors.white70)),
                ]),
              ),
              const SizedBox(height: 18),
              const Text('TOP USUÁRIOS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              const SizedBox(height: 10),
              if (users.isEmpty)
                const Padding(padding: EdgeInsets.all(24), child: Text('Ainda não há participantes no ranking.'))
              else
                ...List.generate(users.length, (i) {
                  final data = users[i].data();
                  final photo = (data['photoUrl'] ?? '').toString();
                  final name = (data['name'] ?? 'Pessoa LoveMix').toString();
                  final coins = (data['coins'] ?? 0) as num;
                  final isMe = users[i].id == myUid;
                  final medal = i == 0 ? '🥇' : i == 1 ? '🥈' : i == 2 ? '🥉' : '${i + 1}º';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 9),
                    decoration: BoxDecoration(
                      color: panel,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: isMe ? pink : const Color(0xFF49305C)),
                    ),
                    child: ListTile(
                      leading: SizedBox(width: 48, child: Center(
                        child: Text(medal, style: TextStyle(fontSize: i < 3 ? 25 : 15, fontWeight: FontWeight.bold)),
                      )),
                      title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(isMe ? 'Você • participante' : 'Participante LoveMix',
                        style: const TextStyle(color: Colors.white60, fontSize: 11)),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.monetization_on, color: Color(0xFFFFD76A), size: 18),
                        const SizedBox(width: 4),
                        Text(coins.toInt().toString(), style: const TextStyle(fontWeight: FontWeight.w900)),
                      ]),
                      leadingAndTrailingTextStyle: const TextStyle(color: Colors.white),
                      horizontalTitleGap: 10,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      // Avatar usa a foto pública cadastrada no perfil.
                      subtitleTextStyle: const TextStyle(color: Colors.white60),
                    ),
                  );
                }),
              const SizedBox(height: 8),
              const Text('O ranking é atualizado automaticamente conforme os saldos de moedas dos perfis.',
                style: TextStyle(color: Colors.white54, fontSize: 11)),
            ],
          );
        },
      ),
    );
  }
}
