import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class ProfileViewScreen extends StatelessWidget {
  const ProfileViewScreen({super.key, required this.userId});
  final String userId;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perfil')),
      body: FutureBuilder(
        future: FirebaseFirestore.instance.collection('users').doc(userId).get(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final p = snap.data!.data() ?? {};
          final photo = (p['photoUrl'] ?? '') as String;
          final birthday = (p['birthday'] as Timestamp?)?.toDate();
          final age = birthday == null ? null : ((DateTime.now().difference(birthday).inDays) / 365.2425).floor();
          final gender = (p['gender'] ?? '').toString();
          final genderLabel = {'woman': '♀ Mulher', 'man': '♂ Homem', 'non_binary': '⚧ Não binário', 'other': 'Outro', 'prefer_not': 'Prefere não informar'}[gender] ?? '';
          final currentUid = FirebaseAuth.instance.currentUser?.uid ?? '';
          final isOwner = currentUid == userId;
          return ListView(padding: const EdgeInsets.all(18), children: [
            ClipRRect(borderRadius: BorderRadius.circular(18), child: photo.isEmpty
                ? const SizedBox(height: 300, child: Icon(Icons.person, size: 100))
                : CachedNetworkImage(imageUrl: photo, height: 380, fit: BoxFit.cover)),
            const SizedBox(height: 16),
            Text((p['name'] ?? 'Pessoa').toString(), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(children: [if (age != null) Chip(avatar: const Icon(Icons.cake_outlined, size: 17), label: Text('$age anos')), if (genderLabel.isNotEmpty) Padding(padding: const EdgeInsets.only(left: 6), child: Chip(label: Text(genderLabel)))]),
            Text((p['bio'] ?? 'Ainda não escreveu uma bio.').toString()),
            const SizedBox(height: 18),
            const Text('Fotos publicadas', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: FirebaseFirestore.instance.collection('users').doc(userId).collection('posts').orderBy('createdAt', descending: true).snapshots(), builder: (context, postsSnap) {
              if (postsSnap.hasError) return const Text('As fotos não estão disponíveis para este perfil.');
              final posts = (postsSnap.data?.docs ?? []).where((d) { final v = d.data()['visibility'] ?? 'public'; return isOwner || v == 'public'; }).toList();
              if (posts.isEmpty) return const Text('Nenhuma foto pública publicada.');
              return GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: posts.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6), itemBuilder: (_, i) => ClipRRect(borderRadius: BorderRadius.circular(10), child: CachedNetworkImage(imageUrl: posts[i].data()['photoUrl'] ?? '', fit: BoxFit.cover)));
            }),
            const SizedBox(height: 18),
            ElevatedButton.icon(onPressed: () async {
              await DataService.instance.like(userId);
              if (context.mounted) Navigator.pop(context);
            }, icon: const Icon(Icons.favorite), label: const Text('Curtir perfil')),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                final reason = await showDialog<String>(
                  context: context,
                  builder: (ctx) => SimpleDialog(
                    title: const Text('Denunciar perfil'),
                    children: ['Perfil falso', 'Assédio ou discurso de ódio', 'Conteúdo impróprio', 'Outro']
                        .map((r) => SimpleDialogOption(
                          onPressed: () => Navigator.pop(ctx, r),
                          child: Text(r),
                        )).toList(),
                  ),
                );
                if (reason == null) return;
                try {
                  await DataService.instance.reportUser(userId, reason);
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Denúncia enviada para análise.')),
                  );
                } catch (_) {}
              },
              icon: const Icon(Icons.flag_outlined),
              label: const Text('Denunciar perfil'),
            ),
            OutlinedButton.icon(
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Bloquear usuário?'),
                    content: const Text('Este perfil não deverá mais aparecer para você.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bloquear')),
                    ],
                  ),
                );
                if (confirm != true) return;
                await DataService.instance.blockUser(userId);
                if (context.mounted) Navigator.pop(context);
              },
              icon: const Icon(Icons.block),
              label: const Text('Bloquear usuário'),
            ),
          ]);
        },
      ),
    );
  }
}
