import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class ChatRoomsScreen extends StatelessWidget {
  const ChatRoomsScreen({super.key});
  static const gold = Color(0xFFFF2DAB);

  Future<void> _newRoom(BuildContext context) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Criar sala de bate-papo'),
      content: TextField(controller: controller, maxLength: 40, decoration: const InputDecoration(hintText: 'Ex.: Amizades, Música, Conversas')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Criar'))],
    ));
    if (name == null || name.trim().isEmpty) return;
    try {
      final id = await DataService.instance.createRoom(name);
      if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => RoomChatScreen(roomId: id, roomName: name.trim())));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _newRoom(context),
        backgroundColor: const Color(0xFFFF2DAB),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Criar sala', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 14),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF40105E), Color(0xFF1B1230), Color(0xFF321044)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFB33CFF).withOpacity(.65)),
            boxShadow: [BoxShadow(color: const Color(0xFF9B27FF).withOpacity(.16), blurRadius: 20, offset: const Offset(0, 7))],
          ),
          child: const Row(children: [
            Icon(Icons.graphic_eq_rounded, color: Color(0xFFFF54C4), size: 34),
            SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Salas LoveMix', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white)),
              SizedBox(height: 4),
              Text('Entre, converse e conheça pessoas novas 💜', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
          child: Row(children: [
            const Text('Salas públicas', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: const Color(0xFF351044), borderRadius: BorderRadius.circular(20)), child: const Text('AO VIVO', style: TextStyle(color: Color(0xFFFF64C8), fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .8))),
          ]),
        ),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: DataService.instance.publicRooms(), builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Não foi possível carregar as salas.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB)));
          final rooms = snap.data!.docs;
          if (rooms.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.forum_outlined, size: 48, color: Color(0xFFB65BDB)), SizedBox(height: 12), Text('Ainda não há salas', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('Crie a primeira sala e comece uma conversa!', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60))])));
          return ListView.builder(padding: const EdgeInsets.fromLTRB(14, 4, 14, 90), itemCount: rooms.length, itemBuilder: (context, i) {
            final room = rooms[i].data(); final members = List<String>.from(room['members'] ?? []);
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF251333), Color(0xFF171022)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: const Color(0xFF65358B).withOpacity(.8)),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                leading: Container(width: 48, height: 48, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFFF2DAB), Color(0xFF793BFF)]), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.forum_rounded, color: Colors.white)),
                title: Text((room['name'] ?? 'Sala').toString(), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text('${members.length} participantes • ${(room['lastMessage'] ?? 'Entre para conversar').toString()}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 11))),
                trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFFFF54C4), size: 17),
                onTap: () async {
                  try { if (!members.contains(DataService.instance.uid)) await DataService.instance.joinRoom(rooms[i].id); if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => RoomChatScreen(roomId: rooms[i].id, roomName: (room['name'] ?? 'Sala').toString()))); }
                  catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
                },
              ),
            );
          });
        }))
      ]),
    );
  }
}

class RoomChatScreen extends StatefulWidget {
  final String roomId, roomName;
  const RoomChatScreen({super.key, required this.roomId, required this.roomName});
  @override State<RoomChatScreen> createState() => _RoomChatScreenState();
}

class _RoomChatScreenState extends State<RoomChatScreen> {
  final input = TextEditingController();
  static const gifts = [
    {'id':'heart','emoji':'❤️','name':'Coração'}, {'id':'rose','emoji':'🌹','name':'Rosa'},
    {'id':'gift','emoji':'🎁','name':'Presente'}, {'id':'diamond','emoji':'💎','name':'Diamante'},
    {'id':'bear','emoji':'🧸','name':'Ursinho'}, {'id':'star','emoji':'⭐','name':'Estrela'},
  ];
  @override void dispose() { input.dispose(); super.dispose(); }

  Future<void> _gift() async {
    final room = await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).get();
    final members = List<String>.from(room.data()?['members'] ?? []).where((id) => id != DataService.instance.uid).toList();
    if (members.isEmpty) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Convide alguém para a sala primeiro.'))); return; }
    final selected = await showDialog<Map<String,String>>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Enviar presente grátis'),
      content: SizedBox(width: double.maxFinite, child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'Presente'), items: gifts.map((g) => DropdownMenuItem(value: g['id'], child: Text('${g['emoji']} ${g['name']}'))).toList(), onChanged: (id) { if (id != null) giftChoice = id; }, value: giftChoice),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(decoration: const InputDecoration(labelText: 'Enviar para'), items: members.map((id) => DropdownMenuItem(value: id, child: FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(future: FirebaseFirestore.instance.collection('users').doc(id).get(), builder: (_, s) => Text((s.data?.data()?['name'] ?? 'Amigo').toString())))).toList(), onChanged: (id) => recipientChoice = id),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), ElevatedButton(onPressed: () { final g = gifts.firstWhere((e) => e['id'] == giftChoice); if (recipientChoice != null) Navigator.pop(ctx, {'id':g['id']!,'emoji':g['emoji']!,'name':g['name']!,'recipient':recipientChoice!}); }, child: const Text('Enviar'))],
    ));
    if (selected == null) return;
    try { await DataService.instance.sendRoomGift(widget.roomId, selected['recipient']!, selected['id']!, selected['emoji']!, selected['name']!); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }
  String giftChoice = 'heart'; String? recipientChoice;

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.roomName), actions: [IconButton(tooltip: 'Enviar presente', onPressed: _gift, icon: const Icon(Icons.card_giftcard, color: Color(0xFFFF2DAB))) ]),
    body: Column(children: [
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: DataService.instance.roomMessages(widget.roomId).orderBy('createdAt', descending: true).limit(100).snapshots(), builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        if (docs.isEmpty) return const Center(child: Text('Diga olá para começar a conversa!'));
        return ListView.builder(reverse: true, itemCount: docs.length, itemBuilder: (context, i) {
          final m = docs[i].data(); final mine = m['senderId'] == DataService.instance.uid; final isGift = m['type'] == 'gift';
          return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), padding: const EdgeInsets.all(12), constraints: const BoxConstraints(maxWidth: 300), decoration: BoxDecoration(color: isGift ? const Color(0xFF351044) : (mine ? const Color(0xFF45205F) : const Color(0xFF241333)), borderRadius: BorderRadius.circular(14), border: isGift ? Border.all(color: const Color(0xFFFF2DAB)) : null), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [if (!mine) FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(future: FirebaseFirestore.instance.collection('users').doc((m['senderId'] ?? '').toString()).get(), builder: (_, s) => Text((s.data?.data()?['name'] ?? 'Participante').toString(), style: const TextStyle(color: Color(0xFFFF2DAB), fontSize: 11))), Text((m['text'] ?? '').toString(), style: TextStyle(fontSize: isGift ? 19 : 15, fontWeight: isGift ? FontWeight.bold : FontWeight.normal))])));
        });
      })),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Row(children: [Expanded(child: TextField(controller: input, maxLength: 1000, decoration: const InputDecoration(counterText: '', hintText: 'Escreva na sala...'))), const SizedBox(width: 8), IconButton.filled(onPressed: () async { final text = input.text; input.clear(); await DataService.instance.sendRoomMessage(widget.roomId, text); }, icon: const Icon(Icons.send), color: Colors.black, style: IconButton.styleFrom(backgroundColor: const Color(0xFFFF2DAB))) ])))
    ]),
  );
}
