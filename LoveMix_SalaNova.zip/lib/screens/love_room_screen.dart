import 'dart:async';
import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zego_uikit_prebuilt_live_audio_room/zego_uikit_prebuilt_live_audio_room.dart';

import '../services/data_service.dart';
import '../services/zego_config.dart';
import '../widgets/profile_frame.dart';

/// Sala de voz do LoveMix: 10 assentos (2 fileiras de 5), painel de pessoas
/// fora do microfone, chat, presentes e o baú que solta a chuva de alianças.
class LoveRoomScreen extends StatefulWidget {
  const LoveRoomScreen({super.key, required this.roomId, required this.roomName});
  final String roomId;
  final String roomName;

  @override
  State<LoveRoomScreen> createState() => _LoveRoomScreenState();
}

class _LoveRoomScreenState extends State<LoveRoomScreen> {
  static const int seatCount = 10;
  static const int defaultChestTarget = 1000;
  static const pink = Color(0xFFFF2DAB);

  static const gifts = <Map<String, dynamic>>[
    {'id': 'rose', 'emoji': '🌹', 'name': 'Rosa', 'currency': 'coins', 'cost': 50},
    {'id': 'gift', 'emoji': '🎁', 'name': 'Presente', 'currency': 'coins', 'cost': 100},
    {'id': 'heart', 'emoji': '💗', 'name': 'Coração', 'currency': 'coins', 'cost': 200},
    {'id': 'crown', 'emoji': '👑', 'name': 'Coroa', 'currency': 'diamonds', 'cost': 50},
    {'id': 'diamond', 'emoji': '💎', 'name': 'Diamante', 'currency': 'diamonds', 'cost': 100},
    {'id': 'lamborghini', 'emoji': '🏎️', 'name': 'Lamborghini', 'currency': 'diamonds', 'cost': 5000},
    {'id': 'iphone18', 'emoji': '📱', 'name': 'iPhone 18', 'currency': 'coins', 'cost': 13000},
  ];

  final _input = TextEditingController();
  final Map<String, Future<Map<String, dynamic>>> _users = {};
  final Map<String, DateTime> _rainSeen = {};
  final Map<String, DateTime> _resultSeen = {};

  List<Map<String, dynamic>> _people = [];
  bool _showOffMic = true;
  bool _myMic = false;
  bool _left = false;
  bool _claiming = false;
  bool _voiceReady = false;
  String _myName = 'LoveMix';
  String? _enterError;

  String get _myUid => DataService.instance.uid;

  String get _safeUserId {
    final raw = FirebaseAuth.instance.currentUser?.uid ?? 'guest';
    return raw.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '_');
  }

  @override
  void initState() {
    super.initState();
    _enter();
  }

  @override
  void dispose() {
    _input.dispose();
    if (!_left) _cleanup(endIfHost: false);
    super.dispose();
  }

  // ---------------------------------------------------------------- entrada

  Future<void> _enter() async {
    try {
      final identity = await DataService.instance.liveIdentityDefaults();
      _myName = identity['displayName']!;
      await DataService.instance.joinRoom(widget.roomId);
      await DataService.instance.registerLiveParticipant(
        roomId: widget.roomId,
        publicId: identity['publicId']!,
        displayName: _myName,
      );
    } catch (e) {
      if (mounted) {
        setState(() => _enterError = e.toString().replaceFirst('Exception: ', ''));
      }
      return;
    }
    await _initVoice();
  }

  Future<void> _initVoice() async {
    try {
      await ZegoUIKit.instance.init(
        appID: ZegoConfig.appId,
        appSign: ZegoConfig.appSign,
      );
      await ZegoUIKit.instance.login(_safeUserId, _myName);
      await ZegoUIKit.instance.joinRoom(widget.roomId);
      if (mounted) setState(() => _voiceReady = true);
    } catch (e) {
      debugPrint('Falha ao iniciar o áudio da sala: $e');
    }
  }

  Future<void> _cleanup({required bool endIfHost}) async {
    try {
      await DataService.instance.leaveRoomSeat(widget.roomId);
    } catch (_) {}
    try {
      await DataService.instance.leaveLiveParticipant(widget.roomId);
    } catch (_) {}
    try {
      await ZegoUIKit.instance.turnMicrophoneOn(false);
      await ZegoUIKit.instance.leaveRoom();
    } catch (_) {}
    if (endIfHost) {
      try {
        await DataService.instance.endLiveRoom(widget.roomId);
      } catch (_) {}
    }
  }

  Future<void> _leave({required bool isHost}) async {
    if (_left) return;
    _left = true;
    await _cleanup(endIfHost: isHost);
  }

  // ----------------------------------------------------------------- helpers

  Future<Map<String, dynamic>> _user(String id) => _users.putIfAbsent(id, () async {
        try {
          final snap = await FirebaseFirestore.instance.collection('users').doc(id).get();
          return snap.data() ?? <String, dynamic>{};
        } catch (_) {
          return <String, dynamic>{};
        }
      });

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  String _clean(Object e) {
    if (e is FirebaseFunctionsException) return e.message ?? 'Algo deu errado.';
    return e.toString().replaceFirst('Exception: ', '');
  }

  // --------------------------------------------------------------- microfone

  Future<void> _setMic(bool on) async {
    if (on) {
      final status = await Permission.microphone.request();
      if (!status.isGranted) {
        _snack('Permita o microfone nas configurações do celular para falar.');
        return;
      }
    }
    try {
      await DataService.instance.setRoomSeatMic(widget.roomId, on);
    } catch (_) {}
    try {
      await ZegoUIKit.instance.turnMicrophoneOn(on);
    } catch (e) {
      debugPrint('Falha ao alternar microfone: $e');
    }
    if (mounted) setState(() => _myMic = on);
  }

  Future<void> _onSeatTap(int number, Map<String, dynamic>? seat) async {
    final seatedUid = (seat?['uid'] ?? '').toString();
    if (seatedUid.isNotEmpty && seatedUid != _myUid) {
      _snack('Esse assento já está ocupado.');
      return;
    }
    try {
      if (seatedUid == _myUid) {
        await showModalBottomSheet<void>(
          context: context,
          backgroundColor: const Color(0xFF1B1028),
          builder: (ctx) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                leading: Icon(_myMic ? Icons.mic_off : Icons.mic, color: const Color(0xFFD85BFF)),
                title: Text(_myMic ? 'Desligar microfone' : 'Ligar microfone'),
                onTap: () {
                  Navigator.pop(ctx);
                  _setMic(!_myMic);
                },
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: Color(0xFFFF5C8A)),
                title: const Text('Sair do microfone'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _setMic(false);
                  await DataService.instance.leaveRoomSeat(widget.roomId);
                },
              ),
            ]),
          ),
        );
        return;
      }
      await DataService.instance.takeRoomSeat(widget.roomId, number);
      await _setMic(true);
    } on FirebaseException catch (e) {
      _snack(e.code == 'permission-denied'
          ? 'O Firebase bloqueou o assento. Publique as regras atualizadas do Firestore.'
          : 'Não foi possível usar o assento (${e.code}).');
    } catch (e) {
      _snack(_clean(e));
    }
  }

  // ------------------------------------------------------------------- chat

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    _input.clear();
    try {
      await DataService.instance.sendRoomMessage(widget.roomId, text);
    } catch (e) {
      _snack('Não foi possível enviar: ${_clean(e)}');
    }
  }

  // --------------------------------------------------------------- presentes

  Future<void> _openGifts(String ownerId) async {
    final targets = _people.where((p) => p['uid'] != _myUid).toList()
      ..sort((a, b) =>
          (a['uid'] == ownerId ? 0 : 1).compareTo(b['uid'] == ownerId ? 0 : 1));
    if (targets.isEmpty) {
      _snack('Ainda não há mais ninguém na sala para receber presentes.');
      return;
    }
    String recipient = targets.first['uid'].toString();
    Map<String, dynamic> chosen = gifts[1];

    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: DataService.instance.myProfile(),
          builder: (ctx, profileSnap) {
            final profile = profileSnap.data?.data() ?? <String, dynamic>{};
            final coins = (profile['coins'] as num?)?.toInt() ?? 0;
            final diamonds = (profile['diamonds'] as num?)?.toInt() ?? 0;
            final balance = chosen['currency'] == 'coins' ? coins : diamonds;
            final canAfford = balance >= (chosen['cost'] as int);
            final toHost = recipient == ownerId;
            return SafeArea(
              child: Container(
                height: MediaQuery.of(ctx).size.height * .78,
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                decoration: const BoxDecoration(
                  color: Color(0xFF160D22),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                  border: Border(top: BorderSide(color: Color(0xFFFF4FCB), width: 1.5)),
                ),
                child: Column(children: [
                  Container(
                    width: 42, height: 4,
                    decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(8)),
                  ),
                  const SizedBox(height: 12),
                  const Text('LOVEMIX PRESENTES',
                      style: TextStyle(color: Color(0xFFFF65D5), fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text(
                    toHost
                        ? '🧰 Presentes para o anfitrião enchem o baú da sala!'
                        : 'Escolha quem vai receber',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 38,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: targets.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) {
                        final p = targets[i];
                        final id = p['uid'].toString();
                        final active = id == recipient;
                        final name = (p['displayName'] ?? 'Pessoa').toString();
                        return ChoiceChip(
                          selected: active,
                          selectedColor: const Color(0xFF63258D),
                          backgroundColor: const Color(0xFF281638),
                          label: Text(id == ownerId ? '👑 $name' : name,
                              style: const TextStyle(color: Colors.white, fontSize: 12)),
                          onSelected: (_) => setSheet(() => recipient = id),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: _pill('🪙', '$coins moedas')),
                    const SizedBox(width: 8),
                    Expanded(child: _pill('💎', '$diamonds diamantes')),
                  ]),
                  const SizedBox(height: 10),
                  Expanded(
                    child: GridView.builder(
                      itemCount: gifts.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: .94),
                      itemBuilder: (_, i) {
                        final g = gifts[i];
                        final active = g['id'] == chosen['id'];
                        return InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => setSheet(() => chosen = g),
                          child: Container(
                            decoration: BoxDecoration(
                              color: active ? const Color(0xFF4A1B60) : const Color(0xFF261633),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: active ? const Color(0xFFFF55C9) : const Color(0xFF58356A),
                                width: active ? 2 : 1),
                            ),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Text(g['emoji'] as String, style: const TextStyle(fontSize: 32)),
                              const SizedBox(height: 4),
                              Text(g['name'] as String,
                                  maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 3),
                              Text('${g['cost']} ${g['currency'] == 'coins' ? '🪙' : '💎'}',
                                  style: const TextStyle(color: Color(0xFFFFD66B), fontSize: 10, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    width: double.infinity, height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: canAfford ? pink : Colors.white24,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: canAfford
                          ? () => Navigator.pop(ctx, {'gift': chosen, 'recipient': recipient})
                          : null,
                      child: Text(
                        canAfford ? 'Enviar ${chosen['emoji']} ${chosen['name']}' : 'Saldo insuficiente',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    );
    if (picked == null) return;
    final gift = picked['gift'] as Map<String, dynamic>;
    try {
      await DataService.instance.sendRoomGift(
        widget.roomId,
        picked['recipient'].toString(),
        gift['id'] as String,
        gift['emoji'] as String,
        gift['name'] as String,
      );
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Widget _pill(String emoji, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        decoration: BoxDecoration(
          color: const Color(0xFF2B1A39),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF67417A)),
        ),
        child: Text('$emoji  $value',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
      );

  // -------------------------------------------------------------------- baú

  void _chestInfo(int points, int target) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('🧰', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 8),
            const Text('Baú da sala',
                style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('$points / $target pontos',
                style: const TextStyle(color: Color(0xFFFFD66B), fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            const Text(
              'Quando a galera manda muitos presentes para o anfitrião, o baú enche e solta '
              'uma chuva de alianças de amigos ou de namorados. Toque numa aliança antes de '
              'todo mundo: só UMA pessoa consegue pegar! 💍',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, height: 1.35),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _chestRow(int score, int points, int target) {
    final value = (points / target).clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.fromLTRB(8, 5, 14, 5),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF6A5410), Color(0xFF2E2508)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Text('👑', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 6),
            Text('$score',
                style: const TextStyle(color: Color(0xFFFFE27A), fontWeight: FontWeight.w900, fontSize: 17)),
          ]),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _chestInfo(points, target),
          child: Row(children: [
            const Text('🧰', style: TextStyle(fontSize: 34)),
            const SizedBox(width: 6),
            SizedBox(
              width: 96,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: value),
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: v,
                      minHeight: 9,
                      backgroundColor: const Color(0xFF1A0F2B),
                      valueColor: const AlwaysStoppedAnimation(Color(0xFFFFC83D)),
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text('$points/$target',
                    style: const TextStyle(color: Colors.white60, fontSize: 9)),
              ]),
            ),
          ]),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0x33FFFFFF),
            borderRadius: BorderRadius.circular(18),
          ),
          child: const Text('💍 Chuva de alianças',
              style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
        ),
      ]),
    );
  }

  // --------------------------------------------------------------- assentos

  Widget _seatsGrid(Map<int, Map<String, dynamic>> seats, String ownerId) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 0),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: seatCount,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 5, mainAxisSpacing: 8, crossAxisSpacing: 2, childAspectRatio: .86),
      itemBuilder: (_, i) => _seat(i + 1, seats[i + 1], ownerId),
    );
  }

  Widget _seat(int number, Map<String, dynamic>? seat, String ownerId) {
    final seatedUid = (seat?['uid'] ?? '').toString();
    final occupied = seatedUid.isNotEmpty;
    final mine = seatedUid == _myUid;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => _onSeatTap(number, seat),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        SizedBox(
          width: 62, height: 62,
          child: occupied
              ? FutureBuilder<Map<String, dynamic>>(
                  future: _user(seatedUid),
                  builder: (_, snap) {
                    final data = snap.data ?? <String, dynamic>{};
                    final micOn = seat?['micOn'] == true;
                    return Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: micOn
                              ? const [BoxShadow(color: Color(0x88FF35C8), blurRadius: 14, spreadRadius: 1)]
                              : null,
                        ),
                        child: ProfileFrameAvatar(
                          photoUrl: (data['photoUrl'] ?? '').toString(),
                          frameId: (data['selectedProfileFrame'] ?? 'classic').toString(),
                          size: 56,
                        ),
                      ),
                      if (seatedUid == ownerId)
                        const Positioned(top: -8, child: Text('👑', style: TextStyle(fontSize: 16))),
                      Positioned(
                        right: 0, bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: micOn ? const Color(0xFF1FBF72) : const Color(0xFF3A2A4A),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(micOn ? Icons.mic : Icons.mic_off, size: 11, color: Colors.white),
                        ),
                      ),
                    ]);
                  },
                )
              : Container(
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0x33FFFFFF)),
                  child: const Icon(Icons.weekend_rounded, color: Color(0xFFE8DDF5), size: 30),
                ),
        ),
        const SizedBox(height: 4),
        occupied
            ? FutureBuilder<Map<String, dynamic>>(
                future: _user(seatedUid),
                builder: (_, snap) => Text(
                  (snap.data?['name'] ?? '...').toString().split(' ').first,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: mine ? const Color(0xFFFF8AD8) : Colors.white,
                    fontSize: 11, fontWeight: FontWeight.w700),
                ),
              )
            : const Text('Entrar', style: TextStyle(color: Colors.white70, fontSize: 11)),
      ]),
    );
  }

  // ------------------------------------------------------- painel off-mic

  Widget _offMicPanel(Set<String> seatedUids) {
    final offMic = _people.where((p) => !seatedUids.contains(p['uid'])).toList();
    if (!_showOffMic) {
      return Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: ActionChip(
            backgroundColor: Colors.black,
            avatar: const Icon(Icons.people_alt_rounded, color: Colors.white70, size: 16),
            label: Text('Off-mic (${offMic.length})',
                style: const TextStyle(color: Colors.white, fontSize: 12)),
            onPressed: () => setState(() => _showOffMic = true),
          ),
        ),
      );
    }
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      padding: const EdgeInsets.fromLTRB(12, 10, 8, 12),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF2A2236)),
      ),
      child: Column(children: [
        Row(children: [
          const SizedBox(width: 28),
          Expanded(
            child: Text('Usuários Off-mic(${offMic.length})',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
          ),
          SizedBox(
            width: 28, height: 28,
            child: IconButton(
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.close, color: Colors.white, size: 22),
              onPressed: () => setState(() => _showOffMic = false),
            ),
          ),
        ]),
        const SizedBox(height: 8),
        SizedBox(
          height: 82,
          child: offMic.isEmpty
              ? const Center(
                  child: Text('Ninguém aguardando fora do microfone.',
                      style: TextStyle(color: Colors.white54, fontSize: 12)))
              : ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: offMic.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (_, i) {
                    final p = offMic[i];
                    final id = p['uid'].toString();
                    return SizedBox(
                      width: 66,
                      child: FutureBuilder<Map<String, dynamic>>(
                        future: _user(id),
                        builder: (_, snap) {
                          final data = snap.data ?? <String, dynamic>{};
                          return Column(mainAxisSize: MainAxisSize.min, children: [
                            ProfileFrameAvatar(
                              photoUrl: (data['photoUrl'] ?? '').toString(),
                              frameId: (data['selectedProfileFrame'] ?? 'classic').toString(),
                              size: 50,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              id == _myUid ? 'Você' : (p['displayName'] ?? 'Pessoa').toString(),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: id == _myUid ? const Color(0xFFFF8AD8) : Colors.white,
                                fontSize: 11, fontWeight: FontWeight.w600),
                            ),
                          ]);
                        },
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------------- chat

  Widget _tipCard() => Container(
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xCC0C0716),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF2B2140)),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Party Dicas:', style: TextStyle(color: Color(0xFF4FD6FF), fontSize: 15)),
          SizedBox(height: 4),
          Text(
            'Mande presentes ao anfitrião para encher o baú 🧰 e fazer chover alianças! '
            'Use fones de ouvido para evitar ecos.',
            style: TextStyle(color: Color(0xFF4FD6FF), fontSize: 13, height: 1.35),
          ),
        ]),
      );

  Widget _chatLine(Map<String, dynamic> m) {
    final type = (m['type'] ?? 'text').toString();
    final text = (m['text'] ?? '').toString();
    if (type == 'system') {
      return Container(
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: const Color(0xCC3A2A05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFFFC83D).withValues(alpha: .6)),
        ),
        child: Text(text,
            style: const TextStyle(color: Color(0xFFFFE27A), fontSize: 13, fontWeight: FontWeight.w700)),
      );
    }
    final sender = (m['senderId'] ?? '').toString();
    final isGift = type == 'gift';
    return FutureBuilder<Map<String, dynamic>>(
      future: _user(sender),
      builder: (_, snap) {
        final name = (snap.data?['name'] ?? 'Participante').toString();
        return Container(
          margin: const EdgeInsets.only(top: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xCC0C0716),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0xFF2B2140)),
          ),
          child: RichText(
            text: TextSpan(children: [
              TextSpan(
                text: isGift ? '$name enviou ' : '$name: ',
                style: const TextStyle(color: Color(0xFF4FD6FF), fontWeight: FontWeight.w900, fontSize: 14)),
              TextSpan(
                text: text,
                style: TextStyle(color: Colors.white, fontSize: isGift ? 16 : 14)),
            ]),
          ),
        );
      },
    );
  }

  Widget _chat() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.roomMessages(widget.roomId)
          .orderBy('createdAt', descending: true).limit(60).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return const Center(child: Text('Não foi possível carregar o chat.',
              style: TextStyle(color: Colors.white70)));
        }
        final docs = snap.data?.docs ?? [];
        return Stack(children: [
          ListView.builder(
            reverse: true,
            padding: const EdgeInsets.fromLTRB(12, 4, 70, 8),
            itemCount: docs.length + 1,
            itemBuilder: (_, i) =>
                i == docs.length ? _tipCard() : _chatLine(docs[i].data()),
          ),
          if (docs.isNotEmpty && docs.first.data()['type'] == 'gift')
            Positioned(left: 16, right: 70, top: 4, child: IgnorePointer(child: _giftToast(docs.first))),
        ]);
      },
    );
  }

  Widget _giftToast(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final g = doc.data();
    final created = (g['createdAt'] as Timestamp?)?.toDate();
    if (created != null && DateTime.now().difference(created).inSeconds > 20) {
      return const SizedBox.shrink();
    }
    return TweenAnimationBuilder<double>(
      key: ValueKey(doc.id),
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 2400),
      builder: (_, v, child) => Opacity(
        opacity: (1 - v).clamp(0.0, 1.0),
        child: Transform.translate(offset: Offset(0, -26 * v), child: child),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF4A176D), Color(0xFFB52DAB)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFFFD36A), width: 1.4),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text((g['emoji'] ?? '🎁').toString(), style: const TextStyle(fontSize: 32)),
          const SizedBox(width: 10),
          Flexible(
            child: Text('${g['giftName'] ?? 'Presente'} enviado!',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          ),
        ]),
      ),
    );
  }

  Widget _bottomBar(bool seated, String ownerId) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
      child: Row(children: [
        _roundBtn(
          icon: seated ? (_myMic ? Icons.mic : Icons.mic_off) : Icons.mic_none,
          active: seated && _myMic,
          onTap: () {
            if (!seated) {
              _snack('Toque em um assento "Entrar" para subir no microfone.');
            } else {
              _setMic(!_myMic);
            }
          },
        ),
        const SizedBox(width: 8),
        Expanded(
          child: TextField(
            controller: _input,
            minLines: 1, maxLines: 2,
            style: const TextStyle(color: Colors.white),
            onSubmitted: (_) => _send(),
            decoration: InputDecoration(
              hintText: 'Enviar uma mensagem..',
              hintStyle: const TextStyle(color: Colors.white54),
              filled: true,
              fillColor: const Color(0x33FFFFFF),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
              suffixIcon: IconButton(
                icon: const Icon(Icons.send_rounded, color: Color(0xFFFF65D5)),
                onPressed: _send,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        _roundBtn(icon: Icons.card_giftcard, active: true, onTap: () => _openGifts(ownerId)),
      ]),
    );
  }

  Widget _roundBtn({required IconData icon, required VoidCallback onTap, bool active = false}) =>
      Material(
        color: active ? const Color(0x66FF2DAB) : const Color(0x33FFFFFF),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(width: 46, height: 46, child: Icon(icon, color: Colors.white)),
        ),
      );

  // ------------------------------------------------------------- chuva de anel

  Widget _dropLayer() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.watchLatestDrop(widget.roomId),
      builder: (context, snap) {
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) return const SizedBox.shrink();
        final doc = docs.first;
        final d = doc.data();
        final created = (d['createdAt'] as Timestamp?)?.toDate();
        if (created == null) return const SizedBox.shrink();
        if (DateTime.now().difference(created).inSeconds > 120) return const SizedBox.shrink();
        final status = (d['status'] ?? '').toString();
        final ringName = (d['ringName'] ?? 'Aliança').toString();

        if (status == 'open') {
          if (!_rainSeen.containsKey(doc.id)) {
            _rainSeen[doc.id] = DateTime.now();
            Future<void>.delayed(const Duration(seconds: 23), () {
              if (mounted) setState(() {});
            });
          }
          if (DateTime.now().difference(_rainSeen[doc.id]!).inSeconds > 22) {
            return const SizedBox.shrink();
          }
          return _RingRain(
            label: 'Chuva de $ringName!',
            busy: _claiming,
            onTapRing: () => _claim(doc.id),
          );
        }

        if (status == 'claimed') {
          if (!_resultSeen.containsKey(doc.id)) {
            _resultSeen[doc.id] = DateTime.now();
            Future<void>.delayed(const Duration(seconds: 6), () {
              if (mounted) setState(() {});
            });
          }
          if (DateTime.now().difference(_resultSeen[doc.id]!).inSeconds > 5) {
            return const SizedBox.shrink();
          }
          final winner = (d['claimedBy'] ?? '').toString() == _myUid
              ? 'Você pegou'
              : '${d['claimedByName'] ?? 'Alguém'} pegou';
          return Align(
            alignment: const Alignment(0, -.35),
            child: IgnorePointer(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                decoration: BoxDecoration(
                  color: const Color(0xEE2A1140),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFFFD36A), width: 1.5),
                ),
                child: Text('💍 $winner a $ringName!',
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
              ),
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }

  Future<void> _claim(String dropId) async {
    if (_claiming) return;
    setState(() => _claiming = true);
    try {
      await DataService.instance.claimRoomDrop(widget.roomId, dropId);
      _snack('💍 Você foi o mais rápido e pegou a aliança! Veja em seus itens recebidos.');
    } catch (e) {
      _snack(_clean(e));
    } finally {
      if (mounted) setState(() => _claiming = false);
    }
  }

  // ------------------------------------------------------------------ menu

  void _menu(bool isHost, bool locked) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (isHost)
            ListTile(
              leading: Icon(locked ? Icons.lock_open : Icons.lock, color: const Color(0xFFD85BFF)),
              title: Text(locked ? 'Liberar entrada na sala' : 'Bloquear novas entradas'),
              onTap: () async {
                Navigator.pop(ctx);
                try {
                  await FirebaseFirestore.instance
                      .collection('rooms').doc(widget.roomId).update({'isLocked': !locked});
                } catch (e) {
                  _snack('Não foi possível alterar o bloqueio: ${_clean(e)}');
                }
              },
            ),
          ListTile(
            leading: const Icon(Icons.logout, color: Color(0xFFFF5C8A)),
            title: Text(isHost ? 'Encerrar sala' : 'Sair da sala'),
            onTap: () async {
              Navigator.pop(ctx);
              await _leave(isHost: isHost);
              if (mounted) Navigator.pop(context);
            },
          ),
        ]),
      ),
    );
  }

  // ----------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    if (_enterError != null) {
      return Scaffold(
        backgroundColor: const Color(0xFF12062A),
        appBar: AppBar(backgroundColor: Colors.transparent),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Text(_enterError!, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16)),
          ),
        ),
      );
    }

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).snapshots(),
      builder: (context, roomSnap) {
        final room = roomSnap.data?.data() ?? <String, dynamic>{};
        final ownerId = (room['ownerId'] ?? '').toString();
        final isHost = ownerId == _myUid;
        final locked = room['isLocked'] == true;
        final points = (room['chestPoints'] as num?)?.toInt() ?? 0;
        final target = (room['chestTarget'] as num?)?.toInt() ?? defaultChestTarget;
        final score = (room['giftScore'] as num?)?.toInt() ?? 0;
        final roomName = (room['name'] ?? widget.roomName).toString();

        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, _) async {
            if (didPop) return;
            await _leave(isHost: isHost);
            if (context.mounted) Navigator.pop(context);
          },
          child: Scaffold(
            resizeToAvoidBottomInset: true,
            body: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [Color(0xFF3A1070), Color(0xFF1A0838), Color(0xFF0E0420)],
                ),
              ),
              child: SafeArea(
                child: Stack(children: [
                  Column(children: [
                    // Cabeçalho
                    Padding(
                      padding: const EdgeInsets.fromLTRB(4, 4, 8, 0),
                      child: Row(children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () async {
                            await _leave(isHost: isHost);
                            if (context.mounted) Navigator.pop(context);
                          },
                        ),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(roomName,
                                maxLines: 1, overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                            FutureBuilder<Map<String, dynamic>>(
                              future: ownerId.isEmpty
                                  ? Future.value(<String, dynamic>{})
                                  : _user(ownerId),
                              builder: (context, ownerSnap) {
                                final ownerPublicId =
                                    (ownerSnap.data?['publicId'] ?? '').toString();
                                return GestureDetector(
                                  onTap: ownerPublicId.isEmpty
                                      ? null
                                      : () {
                                          Clipboard.setData(ClipboardData(text: ownerPublicId));
                                          _snack('ID copiado.');
                                        },
                                  child: Row(children: [
                                    Text('ID: ${ownerPublicId.isEmpty ? '...' : ownerPublicId}',
                                        style: const TextStyle(color: Colors.white60, fontSize: 11)),
                                    const SizedBox(width: 4),
                                    const Icon(Icons.copy_rounded, size: 11, color: Colors.white60),
                                    if (!_voiceReady) ...[
                                      const SizedBox(width: 8),
                                      const Text('conectando áudio…',
                                          style: TextStyle(color: Color(0xFFFFC83D), fontSize: 10)),
                                    ],
                                  ]),
                                );
                              },
                            ),
                          ]),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: const Color(0x33FFFFFF), borderRadius: BorderRadius.circular(18)),
                          child: Text('${_people.length}',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.more_horiz, color: Colors.white),
                          onPressed: () => _menu(isHost, locked),
                        ),
                      ]),
                    ),
                    _chestRow(score, points, target),
                    // Assentos + painel off-mic
                    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: DataService.instance.watchRoomSeats(widget.roomId),
                      builder: (context, seatSnap) {
                        final seats = <int, Map<String, dynamic>>{};
                        for (final doc in seatSnap.data?.docs ?? []) {
                          final n = (doc.data()['seatNumber'] as num?)?.toInt() ?? int.tryParse(doc.id) ?? 0;
                          if (n >= 1 && n <= seatCount) seats[n] = doc.data();
                        }
                        final seatedUids = seats.values.map((s) => (s['uid'] ?? '').toString()).toSet();
                        final seated = seatedUids.contains(_myUid);
                        // Se o assento foi liberado por fora, garante microfone desligado.
                        if (!seated && _myMic) {
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            if (mounted && _myMic) {
                              _myMic = false;
                              ZegoUIKit.instance.turnMicrophoneOn(false);
                              setState(() {});
                            }
                          });
                        }
                        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                          stream: DataService.instance.watchLiveParticipants(widget.roomId),
                          builder: (context, pSnap) {
                            _people = (pSnap.data?.docs ?? []).map((d) => d.data()).toList();
                            return Expanded(
                              child: Column(children: [
                                _seatsGrid(seats, ownerId),
                                _offMicPanel(seatedUids),
                                Expanded(child: _chat()),
                                _bottomBar(seated, ownerId),
                              ]),
                            );
                          },
                        );
                      },
                    ),
                  ]),
                  Positioned.fill(child: _dropLayer()),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Chuva de alianças: várias alianças caindo; tocar em qualquer uma tenta pegar.
class _RingRain extends StatefulWidget {
  const _RingRain({required this.label, required this.onTapRing, required this.busy});
  final String label;
  final VoidCallback onTapRing;
  final bool busy;

  @override
  State<_RingRain> createState() => _RingRainState();
}

class _RingSpec {
  _RingSpec(math.Random r)
      : x = .02 + r.nextDouble() * .86,
        phase = r.nextDouble(),
        speed = r.nextInt(3) == 0 ? 2 : 1,
        sway = 1 + r.nextInt(2),
        size = 34 + r.nextDouble() * 22;
  final double x;
  final double phase;
  final int speed;
  final int sway;
  final double size;
}

class _RingRainState extends State<_RingRain> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final List<_RingSpec> _rings;

  @override
  void initState() {
    super.initState();
    final r = math.Random();
    _rings = List.generate(16, (_) => _RingSpec(r));
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final w = box.maxWidth;
      final h = box.maxHeight;
      return AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Stack(children: [
            for (final ring in _rings)
              Positioned(
                left: ring.x * (w - 60) +
                    math.sin((_c.value * ring.sway + ring.phase) * 2 * math.pi) * 14,
                top: ((_c.value * ring.speed + ring.phase) % 1.0) * (h + 90) - 70,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: widget.busy ? null : widget.onTapRing,
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text('💍',
                        style: TextStyle(fontSize: ring.size, shadows: const [
                          Shadow(color: Color(0xCCFFD36A), blurRadius: 16),
                        ])),
                  ),
                ),
              ),
            Positioned(
              top: 64, left: 24, right: 24,
              child: IgnorePointer(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xDD2A1140),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFFFD36A)),
                  ),
                  child: Text('🧰 ${widget.label}  Toque numa aliança!',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                ),
              ),
            ),
          ]);
        },
      );
    });
  }
}
