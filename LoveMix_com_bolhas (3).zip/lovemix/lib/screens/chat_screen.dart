import 'dart:async';
import 'dart:math' as math;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'profile_view_screen.dart';
import 'call_screen.dart';
import 'gifts_screen.dart';
import '../services/data_service.dart';
import '../services/notification_service.dart';
import '../services/supabase_service.dart';
import '../services/translation_service.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';
import '../widgets/chat_bubble_skin.dart';
import '../data/chat_bubble_catalog.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  final _scroll = ScrollController();
  bool sendingImage = false;
  int _lastCount = -1;
  List<String> _members = [];
  final Map<String, Map<String, dynamic>> _u = {};
  final Map<String, StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>> _userSubs = {};
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _chatSub;
  String get _me => FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    NotificationService.instance.activeChatId = widget.chatId;
    // Perfis das pessoas da conversa (foto, moldura, VIP, online) em tempo real.
    final db = FirebaseFirestore.instance;
    _chatSub = db.collection('chats').doc(widget.chatId).snapshots().listen((snap) {
      final ids = List<String>.from(snap.data()?['users'] ?? const []);
      for (final id in ids) {
        if (_userSubs.containsKey(id)) continue;
        _userSubs[id] = db.collection('users').doc(id).snapshots().listen((d) {
          if (mounted) setState(() => _u[id] = d.data() ?? <String, dynamic>{});
        }, onError: (_) {});
      }
      if (mounted) setState(() => _members = ids);
    }, onError: (_) {});
  }

  @override
  void dispose() {
    if (NotificationService.instance.activeChatId == widget.chatId) {
      NotificationService.instance.activeChatId = null;
    }
    input.dispose();
    _scroll.dispose();
    _chatSub?.cancel();
    for (final sub in _userSubs.values) { sub.cancel(); }
    super.dispose();
  }

  Future<void> _send(String value) async {
    final text = value.trim();
    if (text.isEmpty) return;
    input.clear();
    try { await DataService.instance.sendMessage(widget.chatId, text); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', '')))); }
  }

  Future<void> _showTranslator({String initialText = ''}) async {
    final textController = TextEditingController(text: initialText);
    String source = 'en';
    String target = 'pt-BR';
    String? result;
    bool loading = false;
    String? error;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1B1028),
          title: const Row(children: [
            Icon(Icons.translate, color: Color(0xFFFF2DAB)),
            SizedBox(width: 9),
            Text('Tradutor LoveMix'),
          ]),
          content: SingleChildScrollView(child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: source,
                dropdownColor: const Color(0xFF241A31),
                decoration: const InputDecoration(labelText: 'Idioma original'),
                items: const [
                  DropdownMenuItem(value: 'en', child: Text('Inglês')),
                  DropdownMenuItem(value: 'es', child: Text('Espanhol')),
                  DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() { source = v; if (source == target) target = source == 'pt-BR' ? 'en' : 'pt-BR'; }); },
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: target,
                dropdownColor: const Color(0xFF241A31),
                decoration: const InputDecoration(labelText: 'Traduzir para'),
                items: const [
                  DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                  DropdownMenuItem(value: 'en', child: Text('Inglês')),
                  DropdownMenuItem(value: 'es', child: Text('Espanhol')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() => target = v); },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: textController,
                minLines: 2,
                maxLines: 5,
                maxLength: 450,
                decoration: const InputDecoration(
                  hintText: 'Digite uma palavra ou frase...',
                  border: OutlineInputBorder(),
                ),
              ),
              if (loading) const Center(child: Padding(
                padding: EdgeInsets.all(12),
                child: CircularProgressIndicator(color: Color(0xFFFF2DAB)),
              )),
              if (error != null) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(error!, style: const TextStyle(color: Colors.redAccent)),
              ),
              if (result != null) Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF321846),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SelectableText(result!, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ],
          )),
          actions: [
            TextButton(onPressed: loading ? null : () => Navigator.pop(dialogContext), child: const Text('Fechar')),
            FilledButton.icon(
              onPressed: loading ? null : () async {
                setDialogState(() { loading = true; error = null; result = null; });
                try {
                  final translated = await TranslationService.instance.translate(
                    text: textController.text,
                    sourceLanguage: source,
                    targetLanguage: target,
                  );
                  setDialogState(() => result = translated);
                } catch (e) {
                  setDialogState(() => error = e.toString().replaceFirst('Exception: ', ''));
                } finally {
                  setDialogState(() => loading = false);
                }
              },
              icon: const Icon(Icons.translate),
              label: const Text('Traduzir'),
            ),
          ],
        ),
      ),
    );
    textController.dispose();
  }

  Future<void> _sendPhoto() async {
    if (sendingImage) return;
    try {
      final source = await showModalBottomSheet<ImageSource>(
        context: context,
        backgroundColor: const Color(0xFF1B1028),
        builder: (sheetContext) => SafeArea(
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFFFF2DAB)),
              title: const Text('Escolher da galeria'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFFFF2DAB)),
              title: const Text('Tirar uma foto agora'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.camera),
            ),
          ]),
        ),
      );
      if (source == null || !mounted) return;
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 78,
        maxWidth: 1600,
      );
      if (picked == null || !mounted) return;
      setState(() => sendingImage = true);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Entre na sua conta novamente.');
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A foto selecionada está vazia.');
      if (bytes.length > 4 *  1024 * 1024) {
        throw Exception('A foto deve ter no máximo 4 MB para passar pela verificação de segurança.');
      }
      final fileName = '${DateTime.now().millisecondsSinceEpoch}_$uid.jpg';
      final storagePath = 'chats/${widget.chatId}/$uid/$fileName';
      final url = await SupabaseService.instance.uploadPhoto(
        path: storagePath,
        bytes: bytes,
        contentType: 'image/jpeg',
      );

      // Registra a mensagem diretamente no Firestore. A foto fica pendente
      // até o gatilho moderatePrivateChatImage concluir a análise automática.
      // Assim, o envio não depende da callable sendPrivateChatImage, que
      // estava retornando firebase_functions/not-found.
      final db = FirebaseFirestore.instance;
      final chatRef = db.collection('chats').doc(widget.chatId);
      final messageRef = chatRef.collection('messages').doc();
      final batch = db.batch();
      batch.set(messageRef, {
        'senderId': uid,
        'text': '📷 Foto',
        'imageUrl': url,
        'createdAt': FieldValue.serverTimestamp(),
        'type': 'image',
        'moderationStatus': 'pending',
      });
      batch.update(chatRef, {
        'lastMessage': '📷 Foto',
        'lastMessageAt': FieldValue.serverTimestamp(),
      });
      try {
        await batch.commit();
      } catch (_) {
        // Evita deixar no Storage uma foto órfã se o Firestore recusar a mensagem.
        try {
          await SupabaseService.instance.deleteFile(storagePath);
        } catch (_) {}
        rethrow;
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível enviar a foto: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sendingImage = false);
    }
  }


  Future<void> _deleteMessage(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final mine = data['senderId'] == FirebaseAuth.instance.currentUser?.uid;
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('Apagar mensagem', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
        ListTile(leading: const Icon(Icons.delete_outline, color: Colors.white70), title: const Text('Apagar somente para mim'), onTap: () => Navigator.pop(ctx, 'me')),
        if (mine) ListTile(leading: const Icon(Icons.delete_forever, color: Colors.redAccent), title: const Text('Apagar para todos'), subtitle: const Text('A mensagem será removida da conversa'), onTap: () => Navigator.pop(ctx, 'all')),
        ListTile(title: const Text('Cancelar'), onTap: () => Navigator.pop(ctx)),
      ])),
    );
    if (choice == null) return;
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      if (choice == 'me') {
        await doc.reference.update({'hiddenFor': FieldValue.arrayUnion([uid])});
      } else {
        final imageUrl = (data['imageUrl'] ?? '').toString();
        await doc.reference.delete();
        if (imageUrl.isNotEmpty) {
          try { final removed = await SupabaseService.instance.deletePublicUrl(imageUrl); if (!removed) await FirebaseStorage.instance.refFromURL(imageUrl).delete(); } catch (_) {}
        }
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mensagem apagada.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar: $e')));
    }
  }

  void _quickReactions() {
    const reactions = ['❤️','😍','🥰','😘','😂','🔥','💜','🌹','🎁','🧸','💎','👑'];
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => Padding(padding: const EdgeInsets.all(18), child: Wrap(
        spacing: 12, runSpacing: 12,
        children: reactions.map((emoji) => InkWell(
          onTap: () { Navigator.pop(ctx); _send(emoji); },
          child: Container(width: 52, height: 52, alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF321846), borderRadius: BorderRadius.circular(14)),
            child: Text(emoji, style: const TextStyle(fontSize: 27))),
        )).toList(),
      )));
  }

  Widget _allianceInvites(String uid) {
    final db = FirebaseFirestore.instance;
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: db.collection('chats').doc(widget.chatId).snapshots(),
      builder: (context, chatSnap) {
        final users = List<String>.from(chatSnap.data?.data()?['users'] ?? const []);
        final otherIds = users.where((id) => id != uid).toList();
        if (otherIds.isEmpty) return const SizedBox.shrink();
        final otherUid = otherIds.first;
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: db.collection('alliances').where('members', arrayContains: uid).snapshots(),
          builder: (context, allianceSnap) {
            if (!allianceSnap.hasData) return const SizedBox.shrink();
            final invites = allianceSnap.data!.docs.where((doc) {
              final data = doc.data();
              return data['createdBy'] == otherUid &&
                  data['invitedUid'] == uid &&
                  data['invitationStatus'] == 'pending';
            }).toList();
            if (invites.isEmpty) return const SizedBox.shrink();
            return Column(
              children: invites.map((doc) {
                final data = doc.data();
                final type = (data['relationshipType'] ?? 'Amigos').toString();
                final ring = (data['ringGiftName'] ?? 'Aliança').toString();
                final sender = (data['creatorName'] ?? widget.otherName).toString();
                final message = (data['message'] ?? '').toString().trim();
                final inviteDescription = switch (type) {
                  'Namorados' => 'formar um casal',
                  'BFF' => 'ser seu melhor amigo(a) (BFF)',
                  _ => 'ser seu amigo(a)',
                };
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(12, 10, 12, 5),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF42164F), Color(0xFF251033)]),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFFF65C8), width: 1.3),
                    boxShadow: [BoxShadow(color: const Color(0xFFFF2DAB).withOpacity(.18), blurRadius: 14)],
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Row(children: [
                      Icon(Icons.favorite, color: Color(0xFFFF72C6)),
                      SizedBox(width: 8),
                      Expanded(child: Text('CONVITE DE ALIANÇA', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1))),
                    ]),
                    const SizedBox(height: 8),
                    Text('$sender convidou você para $inviteDescription no LoveMix!',
                      style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 5),
                    Text('💍 $ring  •  $type', style: const TextStyle(color: Color(0xFFFFB7E4), fontWeight: FontWeight.w700)),
                    if (message.isNotEmpty) ...[
                      const SizedBox(height: 7),
                      Text(message, style: const TextStyle(color: Colors.white70)),
                    ],
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: OutlinedButton(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white70, side: const BorderSide(color: Colors.white38)),
                        onPressed: () async {
                          try {
                            await DataService.instance.respondAlliance(doc.id, false);
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Convite recusado.')));
                          } catch (e) {
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível responder: $e')));
                          }
                        },
                        child: const Text('Recusar'),
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE92D9B), foregroundColor: Colors.white),
                        onPressed: () async {
                          try {
                            await DataService.instance.respondAlliance(doc.id, true);
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Aliança aceita! Ela já aparece no mural. 💗')));
                          } catch (e) {
                            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível aceitar: $e')));
                          }
                        },
                        icon: const Icon(Icons.check_circle_outline),
                        label: const Text('Aceitar'),
                      )),
                    ]),
                  ]),
                );
              }).toList(),
            );
          },
        );
      },
    );
  }

  // ───────────────────── layout novo do chat (neon rosa + dourado) ─────────────────────
  static const _pink = Color(0xFFFF3DA5);
  static const _gold = Color(0xFFFFC83D);

  String _hhmm(dynamic ts) {
    if (ts is! Timestamp) return '';
    final d = ts.toDate();
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  String? get _otherUid {
    for (final id in _members) { if (id != _me) return id; }
    return null;
  }

  /// Avatar com a moldura escolhida (a arte cabe inteira no quadrado do avatar).
  Widget _avatarOf(String id, {required double d, bool goldRing = false}) {
    final u = _u[id] ?? const <String, dynamic>{};
    final photo = (u['photoUrl'] ?? '').toString();
    final frame = (u['selectedProfileFrame'] ?? 'classic').toString();
    final vip = u['isVip'] == true || u['vip'] == true || u['isAdmin'] == true;
    final custom = frame.isNotEmpty && frame != 'classic';
    final isImage = ProfileFrameAvatar.imageFrames.containsKey(frame);
    final slot = d + 20;
    final ring = goldRing ? _gold : _pink;
    Widget face;
    if (custom) {
      face = ProfileFrameAvatar(photoUrl: photo, frameId: frame, size: isImage ? math.max(18.0, slot / 1.6 - 14) : d - 14);
    } else {
      face = Container(
        width: d, height: d,
        padding: const EdgeInsets.all(2.5),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: ring, width: 2),
          boxShadow: [BoxShadow(color: ring.withOpacity(.65), blurRadius: 10)],
        ),
        child: ClipOval(
          child: photo.isEmpty
              ? Container(color: const Color(0xFF2A0A1E), child: const Icon(Icons.person, color: Colors.white54))
              : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: const Color(0xFF2A0A1E), child: const Icon(Icons.person, color: Colors.white54))),
        ),
      );
    }
    return SizedBox(
      width: slot, height: slot,
      child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
        face,
        if (vip && !custom)
          Positioned(top: 0, right: -2, child: IgnorePointer(child: Transform.rotate(angle: .35, child: Image.asset('assets/profile/crown_small.png', width: d * .5)))),
      ]),
    );
  }

  Widget _header(BuildContext context) {
    final other = _otherUid;
    final u = other == null ? const <String, dynamic>{} : (_u[other] ?? const <String, dynamic>{});
    final name = (u['name'] ?? u['displayName'] ?? widget.otherName).toString();
    final vip = u['isVip'] == true || u['vip'] == true;
    final verified = u['isVerified'] == true || u['isAdmin'] == true;
    final deco = u['nicknameDecorationActive'] == true || vip;
    final online = u['isOnline'] == true;
    return Container(
      padding: EdgeInsets.fromLTRB(2, MediaQuery.of(context).padding.top + 4, 4, 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.88),
        border: const Border(bottom: BorderSide(color: _pink, width: 2)),
        boxShadow: [BoxShadow(color: _pink.withOpacity(.55), blurRadius: 14)],
      ),
      child: Row(children: [
        IconButton(icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _pink), onPressed: () => Navigator.maybePop(context)),
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: other == null ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: other))),
          child: Stack(clipBehavior: Clip.none, children: [
            other == null ? const SizedBox(width: 64, height: 64, child: Icon(Icons.person, color: Colors.white54)) : _avatarOf(other, d: 46),
            if (online) Positioned(right: 10, bottom: 10, child: Container(width: 13, height: 13, decoration: BoxDecoration(color: const Color(0xFF22E05A), shape: BoxShape.circle, border: Border.all(color: Colors.black, width: 2)))),
          ]),
        ),
        const SizedBox(width: 4),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Flexible(child: VipNickname(name: name, isVip: deco, styleId: (u['vipNicknameStyle'] ?? 'royal_gold').toString(),
                textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white))),
            if (verified) const Padding(padding: EdgeInsets.only(left: 5), child: Icon(Icons.verified, color: Color(0xFFFF5BB8), size: 20)),
            if (vip) Container(
              margin: const EdgeInsets.only(left: 7),
              padding: const EdgeInsets.fromLTRB(5, 2, 9, 2),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: const LinearGradient(colors: [Color(0xFF9B2CFF), Color(0xFFE02FA6)]),
                border: Border.all(color: _gold, width: 1.2),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Image.asset('assets/profile/crown_small.png', width: 18),
                const SizedBox(width: 3),
                const Text('VIP', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
              ]),
            ),
          ]),
          Text(online ? 'Online agora' : 'Disponível para conversar', maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, color: Color(0xFFB7A9C4))),
        ])),
        IconButton(tooltip: 'Chamada de voz', onPressed: () => _startCall(video: false), icon: const Icon(Icons.call_outlined, color: _pink, size: 26)),
        IconButton(tooltip: 'Chamada de vídeo', onPressed: () => _startCall(video: true), icon: const Icon(Icons.videocam_outlined, color: _pink, size: 28)),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, color: _pink),
          color: const Color(0xFF1B0A16),
          onSelected: (v) {
            if (v == 'translate') _showTranslator();
            if (v == 'profile' && other != null) Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: other)));
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'translate', child: Text('Tradutor LoveMix')),
            PopupMenuItem(value: 'profile', child: Text('Ver perfil')),
          ],
        ),
      ]),
    );
  }

  Widget _notice() => Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(.55),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _gold.withOpacity(.55)),
        ),
        child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.shield_outlined, color: Color(0xFFFFC56E), size: 17),
          SizedBox(width: 8),
          Expanded(child: Text(
            'Assistente LoveMix: converse com respeito. Nudez ou conteúdo sexual +18 é proibido e quem insistir poderá ser banido.',
            style: TextStyle(color: Colors.white70, fontSize: 11, height: 1.3),
          )),
        ]),
      );

  Widget _bubble(QueryDocumentSnapshot<Map<String, dynamic>> doc, String? uid) {
    final m = doc.data();
    final mine = m['senderId'] == uid;
    final isGift = m['type'] == 'gift';
    final giftLabel = '${(m['giftEmoji'] ?? m['emoji'] ?? '🎁').toString()} ${(m['giftName'] ?? 'Presente').toString()}';
    final rawValue = (m['text'] ?? '').toString();
    final value = isGift
        ? (mine ? '🎁 Você enviou $giftLabel' : '🎁 Você recebeu $giftLabel')
        : (m['type'] == 'text' ? DataService.maskPrivateAdultText(rawValue) : rawValue);
    final isImage = m['type'] == 'image' && (m['imageUrl'] ?? '').toString().isNotEmpty;
    final time = _hhmm(m['createdAt']);
    final senderId = (m['senderId'] ?? '').toString();
    final accent = isGift ? _gold : (mine ? _gold : _pink);

    final timeRow = Row(mainAxisSize: MainAxisSize.min, children: [
      Text(time, style: TextStyle(fontSize: 11.5, color: mine ? const Color(0xFFFFE3A0) : const Color(0xFFFFB7E4))),
      if (mine) const Padding(padding: EdgeInsets.only(left: 3), child: Icon(Icons.done_all, size: 15, color: _gold)),
    ]);

    Widget content;
    if (isImage) {
      final url = (m['imageUrl'] ?? '').toString();
      content = Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
        GestureDetector(
          onTap: () => showDialog<void>(
            context: context,
            builder: (dialogContext) => Dialog(
              backgroundColor: const Color(0xFF100A19),
              child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Padding(padding: EdgeInsets.all(24), child: Text('Não foi possível carregar esta foto.')))),
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.network(url, width: 220, height: 240, fit: BoxFit.cover,
              loadingBuilder: (context, child, progress) => progress == null ? child : const SizedBox(width: 220, height: 180, child: Center(child: CircularProgressIndicator())),
              errorBuilder: (_, __, ___) => const SizedBox(width: 220, height: 100, child: Center(child: Text('Foto indisponível')))),
          ),
        ),
        const SizedBox(height: 4),
        timeRow,
      ]);
    } else {
      content = Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        if (senderId.isNotEmpty)
          Builder(builder: (context) {
            final sender = _u[senderId] ?? const <String, dynamic>{};
            final decorated = sender['nicknameDecorationActive'] == true || sender['isVip'] == true;
            if (!decorated) return const SizedBox.shrink();
            final senderName = (sender['name'] ?? sender['displayName'] ?? (mine ? 'Você' : widget.otherName)).toString();
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: VipNickname(name: senderName, isVip: true, styleId: (sender['vipNicknameStyle'] ?? 'royal_gold').toString(),
                  textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
            );
          }),
        Row(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
          Flexible(child: Text(value, style: TextStyle(color: Colors.white, fontSize: isGift ? 18 : 16.5, height: 1.25, fontWeight: isGift ? FontWeight.w800 : FontWeight.w500))),
          const SizedBox(width: 12),
          Padding(padding: const EdgeInsets.only(top: 10), child: timeRow),
        ]),
        if (!mine && !isGift && value.trim().isNotEmpty)
          GestureDetector(
            onTap: () => _showTranslator(initialText: value),
            child: const Padding(padding: EdgeInsets.only(top: 3), child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.translate, size: 13, color: Color(0xFFFFB7E4)),
              SizedBox(width: 4),
              Text('Traduzir', style: TextStyle(fontSize: 11, color: Color(0xFFFFB7E4))),
            ])),
          ),
      ]);
    }

    final plainBubble = GestureDetector(
      onLongPress: () => _deleteMessage(doc),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: isImage ? 8 : 18, vertical: isImage ? 8 : 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .66),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: mine ? const [Color(0xFF2E1D05), Color(0xFF140B02)] : const [Color(0xFF3B0F28), Color(0xFF1A0613)],
          ),
          borderRadius: BorderRadius.circular(isImage ? 22 : 28),
          border: Border.all(color: accent, width: isGift ? 2 : 1.6),
          boxShadow: [BoxShadow(color: accent.withOpacity(.38), blurRadius: 14)],
        ),
        child: content,
      ),
    );

    // Bolha comprada na loja: usa a bolha de quem escreveu a mensagem.
    final senderSkin = (isImage || isGift || senderId.isEmpty)
        ? null
        : chatBubbleById((_u[senderId] ?? const <String, dynamic>{})['selectedChatBubble']);
    Widget bubble = plainBubble;
    if (senderSkin != null) {
      final tc = senderSkin.textColor;
      bubble = GestureDetector(
        onLongPress: () => _deleteMessage(doc),
        child: ChatBubbleSkinBox(
          skin: senderSkin,
          maxWidth: MediaQuery.of(context).size.width * .72,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Row(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
              Flexible(child: Text(value, style: TextStyle(color: tc, fontSize: 16, height: 1.25, fontWeight: FontWeight.w600))),
              const SizedBox(width: 8),
              Text(time, style: TextStyle(fontSize: 10.5, color: tc.withOpacity(.7))),
            ]),
            if (!mine && value.trim().isNotEmpty)
              GestureDetector(
                onTap: () => _showTranslator(initialText: value),
                child: Padding(padding: const EdgeInsets.only(top: 3), child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.translate, size: 13, color: tc.withOpacity(.75)),
                  const SizedBox(width: 4),
                  Text('Traduzir', style: TextStyle(fontSize: 11, color: tc.withOpacity(.75))),
                ])),
              ),
          ]),
        ),
      );
    }

    final avatar = senderId.isEmpty ? const SizedBox(width: 66) : GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: senderId))),
      child: _avatarOf(senderId, d: 46, goldRing: mine),
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: mine ? [Flexible(child: bubble), const SizedBox(width: 2), avatar] : [avatar, const SizedBox(width: 2), Flexible(child: bubble)],
      ),
    );
  }

  Widget _inputBar() {
    final other = _otherUid;
    return Container(
      padding: EdgeInsets.fromLTRB(12, 10, 12, 10 + MediaQuery.of(context).padding.bottom),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.9),
        border: const Border(top: BorderSide(color: _pink, width: 2)),
        boxShadow: [BoxShadow(color: _pink.withOpacity(.5), blurRadius: 14, offset: const Offset(0, -2))],
      ),
      child: Row(children: [
        Expanded(child: Container(
          padding: const EdgeInsets.only(left: 6, right: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF14040E),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: _pink, width: 1.6),
            boxShadow: [BoxShadow(color: _pink.withOpacity(.3), blurRadius: 10)],
          ),
          child: Row(children: [
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.sentiment_satisfied_alt_outlined, color: Colors.white70, size: 28)),
            Expanded(child: TextField(
              controller: input, minLines: 1, maxLines: 4, textInputAction: TextInputAction.send, onSubmitted: _send,
              style: const TextStyle(fontSize: 16),
              decoration: const InputDecoration(hintText: 'Digite uma mensagem...', hintStyle: TextStyle(color: Colors.white38), border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, filled: false, isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 14)),
            )),
          ]),
        )),
        const SizedBox(width: 4),
        IconButton(
          tooltip: 'Enviar presente',
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: other ?? ''))),
          icon: const Icon(Icons.card_giftcard_outlined, color: _pink, size: 30),
        ),
        IconButton(
          tooltip: 'Enviar foto',
          onPressed: sendingImage ? null : _sendPhoto,
          icon: sendingImage
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.photo_library_outlined, color: _pink, size: 29),
        ),
        GestureDetector(
          onTap: () => _send(input.text),
          child: Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [Color(0xFFFF4DAF), Color(0xFFE0206E)]),
              boxShadow: [BoxShadow(color: _pink.withOpacity(.7), blurRadius: 14)],
            ),
            child: const Icon(Icons.send_rounded, color: Colors.white, size: 27),
          ),
        ),
      ]),
    );
  }

  @override Widget build(BuildContext context) {
    final service = DataService.instance;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        const Positioned.fill(child: _ChatBackdrop()),
        Column(children: [
          _header(context),
          if (uid != null) _allianceInvites(uid),
          Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
            stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
            builder: (context, snap) {
              if (snap.hasError) return const Center(child: Text('Não foi possível carregar as mensagens.'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs.where((d) {
                final data = d.data();
                final hidden = List<String>.from(data['hiddenFor'] ?? const []);
                if (hidden.contains(uid)) return false;
                // Mensagem +18 é removida: some da conversa (e é apagada se for minha).
                if (data['type'] == 'text' && DataService.containsAdultText((data['text'] ?? '').toString())) {
                  if (data['senderId'] == uid) { d.reference.delete().catchError((_) {}); }
                  return false;
                }
                // Sem depender de Cloud Functions: a foto aparece na hora. Só some se alguma
                // análise (opcional, no servidor) marcar como em revisão ou rejeitada.
                if (data['type'] == 'image' && (data['moderationStatus'] == 'pending_review' || data['moderationStatus'] == 'rejected')) return false;
                return true;
              }).toList();
              if (docs.length != _lastCount) {
                _lastCount = docs.length;
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
                });
              }
              return ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.fromLTRB(10, 12, 10, 14),
                itemCount: docs.length + 1,
                itemBuilder: (context, i) {
                  if (i == 0) return Column(children: [
                    _notice(),
                    if (docs.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('Diga oi e comece uma nova conversa! 💗'))),
                  ]);
                  return _bubble(docs[i - 1], uid);
                },
              );
            },
          )),
          _inputBar(),
        ]),
      ]),
    );
  }

  Future<void> _startCall({required bool video}) async {
    final ok = await requestCallPermissions(context, video: video);
    if (!ok || !mounted) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
      final chat = await chatRef.get();
      final users = List<String>.from(chat.data()?['users'] ?? const []);
      final calleeUid = users.firstWhere((id) => id != uid, orElse: () => '');
      if (calleeUid.isEmpty) throw Exception('Não foi possível encontrar a outra pessoa da conversa.');
      final me = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final otherUser = await FirebaseFirestore.instance.collection('users').doc(calleeUid).get();
      final callRef = chatRef.collection('calls').doc();
      await callRef.set({
        'callId': callRef.id,
        'callerUid': uid,
        'calleeUid': calleeUid,
        'callerName': (me.data()?['name'] ?? 'LoveMix').toString(),
        'callerPhotoUrl': (me.data()?['photoUrl'] ?? '').toString(),
        'calleePhotoUrl': (otherUser.data()?['photoUrl'] ?? '').toString(),
        'participants': [uid, calleeUid],
        'video': video,
        'status': 'ringing',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => CallScreen(callRef: callRef, video: video, isCaller: true),
      ));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível iniciar a chamada: $e')),
        );
      }
    }
  }
}

/// Fundo do chat: corações neon, brilhos, ondas douradas e a marca LoveMix.
class _ChatBackdrop extends StatelessWidget {
  const _ChatBackdrop();
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final w = c.maxWidth, h = c.maxHeight;
      return Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _BackdropPainter())),
        Positioned(left: w * .22, top: h * .30, width: w * .62, height: w * .58, child: CustomPaint(painter: _BigHeartPainter())),
        Positioned(left: w * .56, top: h * .24, width: w * .22, child: IgnorePointer(child: Image.asset('assets/profile/chat_crown_top.png', fit: BoxFit.contain))),
        Positioned(left: w * .37, top: h * .50, width: w * .40, child: IgnorePointer(child: Image.asset('assets/profile/chat_logo.png', fit: BoxFit.contain))),
        Positioned(left: w * .64, top: h * .545, width: w * .13, child: IgnorePointer(child: Image.asset('assets/profile/chat_loop.png', fit: BoxFit.contain))),
        Positioned(left: w * .37, bottom: 70, width: w * .26, child: IgnorePointer(child: Image.asset('assets/profile/chat_crown_bottom.png', fit: BoxFit.contain))),
      ]);
    });
  }
}

Path _heartPath(Rect r) {
  final w = r.width, h = r.height;
  return Path()
    ..moveTo(r.left + w / 2, r.top + h * .95)
    ..cubicTo(r.left - w * .18, r.top + h * .55, r.left + w * .02, r.top - h * .08, r.left + w / 2, r.top + h * .28)
    ..cubicTo(r.left + w * .98, r.top - h * .08, r.left + w * 1.18, r.top + h * .55, r.left + w / 2, r.top + h * .95)
    ..close();
}

class _BigHeartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final path = _heartPath(Rect.fromLTWH(s.width * .08, s.height * .08, s.width * .84, s.height * .8));
    final shader = const LinearGradient(colors: [Color(0xFFFF2D6F), Color(0xFFFF4DAF), Color(0xFFD1124F)], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(Offset.zero & s);
    canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 16..shader = shader..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));
    canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 9..shader = shader);
    canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFFFFB3D1));
  }
  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class _BackdropPainter extends CustomPainter {
  static const _hearts = <List<double>>[
    [.72, .06, 40, .1], [.30, .15, 46, -.1], [.10, .30, 40, .2], [.80, .30, 38, -.1], [.18, .45, 34, .15],
    [.60, .72, 36, 0], [.12, .64, 46, -.2], [.62, .88, 58, .1], [.90, .84, 30, 0], [.22, .93, 36, .1], [.84, .58, 30, .2],
  ];
  static const _sparks = <List<double>>[
    [.88, .03], [.45, .12], [.05, .20], [.50, .38], [.93, .45], [.30, .56], [.03, .78], [.45, .82], [.75, .95], [.12, .86], [.97, .70], [.55, .20],
  ];

  @override
  void paint(Canvas canvas, Size s) {
    // brilho rosado no fundo
    canvas.drawRect(Offset.zero & s, Paint()..shader = const RadialGradient(center: Alignment(.1, .1), radius: 1.0, colors: [Color(0x33FF2D6F), Colors.transparent]).createShader(Offset.zero & s));
    // corações neon
    for (final h in _hearts) {
      canvas.save();
      canvas.translate(h[0] * s.width, h[1] * s.height);
      canvas.rotate(h[3]);
      final r = Rect.fromCenter(center: Offset.zero, width: h[2], height: h[2] * .92);
      final p = _heartPath(r);
      canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = 5..color = const Color(0xFFFF2D6F).withOpacity(.65)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
      canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = const Color(0xFFFF5C9A));
      canvas.restore();
    }
    // brilhos
    final sp = Paint()..color = Colors.white.withOpacity(.85)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5);
    for (final k in _sparks) {
      final o = Offset(k[0] * s.width, k[1] * s.height);
      canvas.drawCircle(o, 2, sp);
      canvas.drawLine(o.translate(-6, 0), o.translate(6, 0), sp..strokeWidth = 1);
      canvas.drawLine(o.translate(0, -6), o.translate(0, 6), sp..strokeWidth = 1);
    }
    // ondas douradas
    final gold = const LinearGradient(colors: [Color(0xFFFFE08A), Color(0xFFFFB300), Color(0x00FFB300)]);
    void swirl(Offset a, Offset c1, Offset c2, Offset b, {double w = 3}) {
      final path = Path()..moveTo(a.dx, a.dy)..cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, b.dx, b.dy);
      final rect = Rect.fromPoints(a, b).inflate(20);
      canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = w + 5..shader = gold.createShader(rect)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
      canvas.drawPath(path, Paint()..style = PaintingStyle.stroke..strokeWidth = w..strokeCap = StrokeCap.round..shader = gold.createShader(rect));
    }
    final W = s.width, H = s.height;
    swirl(Offset(0, H * .26), Offset(W * .1, H * .30), Offset(W * .12, H * .36), Offset(W * .20, H * .40));
    swirl(Offset(0, H * .52), Offset(W * .12, H * .53), Offset(W * .20, H * .60), Offset(W * .25, H * .66));
    swirl(Offset(W, H * .58), Offset(W * .90, H * .60), Offset(W * .82, H * .66), Offset(W * .76, H * .72));
    swirl(Offset(W, H * .92), Offset(W * .85, H * .90), Offset(W * .70, H * .93), Offset(W * .58, H * .98), w: 4);
    swirl(Offset(W, H * .08), Offset(W * .92, H * .10), Offset(W * .86, H * .14), Offset(W * .80, H * .19));
  }
  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
