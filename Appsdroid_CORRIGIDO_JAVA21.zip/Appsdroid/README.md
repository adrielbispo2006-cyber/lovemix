# Appsdroid

Projeto Flutter para uma loja Android de jogos e aplicativos, com identidade visual roxa e preta.

## Área de publicação implementada nesta versão
- Seleção de arquivos APK (`.apk`) pelo seletor de arquivos do Android.
- Cópia do APK para a área privada do aplicativo.
- Seleção de ícone e até 8 capturas de tela pela galeria.
- Formulário com nome, categoria, versão e descrição, incluindo validação.
- Salvamento local das publicações e metadados com SharedPreferences.
- Exibição dos aplicativos publicados na aba Loja e pesquisa por nome/categoria.
- Persistência local depois de fechar e abrir o aplicativo.

## Limitação importante
Esta versão publica na loja local deste aparelho. Ela ainda NÃO envia os APKs para outros celulares. Para uma loja pública compartilhada, são necessários um backend e armazenamento online (por exemplo, Firebase Authentication, Firestore e Cloud Storage), configuração do projeto Firebase, regras de segurança, limites de tamanho e processo de análise/moderação. Não coloque chaves administrativas dentro do APK.

## Compilar
1. Envie o conteúdo do ZIP para a raiz do repositório GitHub.
2. Abra **Actions**.
3. Execute **Gerar APK Appsdroid** com **Run workflow**.
4. Baixe o artefato **Appsdroid-APK** quando a execução terminar.


## Aba Conta (protótipo local)
- Cadastro e login locais por e-mail e senha; a senha é armazenada como hash no armazenamento privado do app.
- Solicitação de conta de desenvolvedor com estado local de aguardando análise.
- Ação de sair da conta.
- Área administrativa permanece bloqueada até que a autorização seja validada por backend.

**Limite de segurança:** o cadastro/login e os pedidos nesta versão não são contas online e não sincronizam entre aparelhos. Não use este protótipo local como autenticação de produção. Para ativar contas reais e administração compartilhada, conecte Firebase Authentication, Cloud Firestore e Cloud Storage, configure as regras e atribua a função de administrador exclusivamente no servidor.
