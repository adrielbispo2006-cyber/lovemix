import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppCatalog.load();
  runApp(const GameMixApp());
}

const purple = Color(0xFF9B5CFF);
const bg = Color(0xFF100D16);
const panel = Color(0xFF211A2B);

class AppEntry {
  final String id, name, category, version, description, apkPath;
  final String iconPath;
  final List<String> screenshots;
  final DateTime createdAt;

  const AppEntry({required this.id, required this.name, required this.category,
    required this.version, required this.description, required this.apkPath,
    required this.iconPath, required this.screenshots, required this.createdAt});

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'category': category, 'version': version,
    'description': description, 'apkPath': apkPath, 'iconPath': iconPath,
    'screenshots': screenshots, 'createdAt': createdAt.toIso8601String(),
  };

  factory AppEntry.fromJson(Map<String, dynamic> json) => AppEntry(
    id: json['id'] as String, name: json['name'] as String,
    category: json['category'] as String, version: json['version'] as String,
    description: json['description'] as String, apkPath: json['apkPath'] as String,
    iconPath: (json['iconPath'] ?? '') as String,
    screenshots: List<String>.from(json['screenshots'] ?? const []),
    createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
  );
}

class AppCatalog {
  static final ValueNotifier<List<AppEntry>> apps = ValueNotifier([]);
  static const _key = 'appsdroid_local_apps_v1';

  static Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      apps.value = decoded.map((e) => AppEntry.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (_) {
      apps.value = [];
    }
  }

  static Future<void> add(AppEntry app) async {
    final updated = [app, ...apps.value];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(updated.map((e) => e.toJson()).toList()));
    apps.value = updated;
  }
}

class GameMixApp extends StatelessWidget {
  const GameMixApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Appsdroid', debugShowCheckedModeBanner: false,
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: purple, brightness: Brightness.dark),
      useMaterial3: true, appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0)),
    home: const StoreHome(),
  );
}

class StoreHome extends StatefulWidget {
  const StoreHome({super.key});
  @override
  State<StoreHome> createState() => _StoreHomeState();
}

class _StoreHomeState extends State<StoreHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Row(children: [
      Icon(Icons.videogame_asset_rounded, color: purple, size: 29), SizedBox(width: 8),
      Text('Appsdroid', style: TextStyle(fontWeight: FontWeight.w900)),
    ]), actions: [IconButton(tooltip: 'Pesquisar', onPressed: () => showSearch(context: context, delegate: AppSearch()), icon: const Icon(Icons.search))]),
    body: Stack(children: [
      Positioned.fill(child: IgnorePointer(child: Center(child: Opacity(opacity: .13,
        child: Image.asset('assets/appsdroid_wallpaper.png', fit: BoxFit.contain, width: MediaQuery.of(context).size.width * .88))))),
      IndexedStack(index: tab, children: const [DiscoverPage(), PublishPage(), AccountPage()]),
    ]),
    bottomNavigationBar: NavigationBar(backgroundColor: panel, selectedIndex: tab,
      indicatorColor: purple.withOpacity(.22), onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Loja'),
        NavigationDestination(icon: Icon(Icons.cloud_upload_outlined), selectedIcon: Icon(Icons.cloud_upload), label: 'Publicar'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Conta'),
      ]),
  );
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<List<AppEntry>>(
    valueListenable: AppCatalog.apps,
    builder: (context, apps, _) => ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF482078), Color(0xFF21152F)]), borderRadius: BorderRadius.circular(22)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('SEU UNIVERSO DIGITAL', style: TextStyle(letterSpacing: 1.5, color: Colors.white70, fontSize: 11)),
          SizedBox(height: 8), Text('Jogos e apps\nnum só lugar.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
          SizedBox(height: 8), Text('Descubra novidades na Appsdroid.', style: TextStyle(color: Colors.white70)),
        ])),
      const SizedBox(height: 24), const SectionTitle('Categorias'), const SizedBox(height: 12),
      const Wrap(spacing: 8, runSpacing: 8, children: [
        CategoryChip(icon: Icons.sports_esports, label: 'Jogos'), CategoryChip(icon: Icons.apps, label: 'Aplicativos'),
        CategoryChip(icon: Icons.school, label: 'Educação'), CategoryChip(icon: Icons.music_note, label: 'Música'),
        CategoryChip(icon: Icons.photo, label: 'Fotografia'),
      ]),
      const SizedBox(height: 24), SectionTitle(apps.isEmpty ? 'Em destaque' : 'Aplicativos publicados'),
      const SizedBox(height: 12),
      if (apps.isEmpty) const AppTile(name: 'Sua loja está pronta', category: 'Appsdroid', icon: Icons.gamepad,
        description: 'Os aplicativos que você publicar neste aparelho aparecerão aqui.'),
      ...apps.map((app) => AppTile.fromEntry(app)),
      const SizedBox(height: 12),
      const Text('As publicações desta versão ficam salvas neste aparelho. Para disponibilizar os apps para todos os usuários, é necessário conectar um servidor e armazenamento online.',
        style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
}

class PublishPage extends StatefulWidget {
  const PublishPage({super.key});
  @override
  State<PublishPage> createState() => _PublishPageState();
}

class _PublishPageState extends State<PublishPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _version = TextEditingController(text: '1.0.0');
  final _description = TextEditingController();
  final _picker = ImagePicker();
  String _category = 'Jogos';
  String? _apkPath, _apkName, _iconPath;
  final List<String> _screenshots = [];
  bool _saving = false;

  @override
  void dispose() { _name.dispose(); _version.dispose(); _description.dispose(); super.dispose(); }

  Future<String> _copyIntoApp(String source, String folder) async {
    final dir = await getApplicationDocumentsDirectory();
    final targetDir = Directory('${dir.path}/appsdroid/$folder');
    await targetDir.create(recursive: true);
    final ext = source.contains('.') ? source.substring(source.lastIndexOf('.')) : '';
    final target = '${targetDir.path}/${DateTime.now().microsecondsSinceEpoch}$ext';
    return (await File(source).copy(target)).path;
  }

  Future<void> _chooseApk() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['apk'], allowMultiple: false);
      if (result == null) return;
      final path = result.files.single.path;
      if (path == null) throw Exception('Não foi possível acessar o arquivo selecionado.');
      final saved = await _copyIntoApp(path, 'apks');
      if (!mounted) return;
      setState(() { _apkPath = saved; _apkName = result.files.single.name; });
      _message('APK selecionado com sucesso.');
    } catch (e) { _message('Falha ao selecionar APK: $e'); }
  }

  Future<void> _chooseIcon() async {
    try {
      final image = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (image == null) return;
      final saved = await _copyIntoApp(image.path, 'images');
      if (mounted) setState(() => _iconPath = saved);
    } catch (e) { _message('Não foi possível selecionar o ícone: $e'); }
  }

  Future<void> _chooseScreenshots() async {
    try {
      final images = await _picker.pickMultiImage(imageQuality: 85);
      if (images.isEmpty) return;
      final remaining = 8 - _screenshots.length;
      final selected = images.take(remaining < 0 ? 0 : remaining);
      final saved = <String>[];
      for (final image in selected) { saved.add(await _copyIntoApp(image.path, 'images')); }
      if (mounted) setState(() => _screenshots.addAll(saved));
    } catch (e) { _message('Não foi possível selecionar as imagens: $e'); }
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: panel));
  }

  Future<void> _publish() async {
    if (!_formKey.currentState!.validate()) return;
    if (_apkPath == null) { _message('Selecione o arquivo APK antes de publicar.'); return; }
    setState(() => _saving = true);
    try {
      final entry = AppEntry(id: DateTime.now().microsecondsSinceEpoch.toString(), name: _name.text.trim(),
        category: _category, version: _version.text.trim(), description: _description.text.trim(),
        apkPath: _apkPath!, iconPath: _iconPath ?? '', screenshots: List.of(_screenshots), createdAt: DateTime.now());
      await AppCatalog.add(entry);
      if (!mounted) return;
      setState(() { _name.clear(); _version.text = '1.0.0'; _description.clear(); _apkPath = null; _apkName = null; _iconPath = null; _screenshots.clear(); _category = 'Jogos'; });
      _message('Publicado na loja deste aparelho!');
      showDialog(context: context, builder: (_) => AlertDialog(
        title: const Text('Publicação salva!'),
        content: const Text('O aplicativo já aparece na aba Loja deste aparelho. Para outros usuários encontrarem e baixarem, ainda será necessário configurar o backend online.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Entendi'))],
      ));
    } catch (e) { _message('Erro ao salvar publicação: $e'); }
    finally { if (mounted) setState(() => _saving = false); }
  }

  @override
  Widget build(BuildContext context) => Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Área do desenvolvedor', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    const Text('Preencha os dados, escolha o APK e as imagens. A publicação será salva na loja local deste aparelho.', style: TextStyle(color: Colors.white70)),
    const SizedBox(height: 22),
    _ActionCard(icon: Icons.upload_file, title: 'Enviar arquivo APK', body: _apkName ?? 'Toque para selecionar um arquivo .apk', onTap: _chooseApk,
      trailing: _apkPath == null ? null : const Icon(Icons.check_circle, color: Colors.green)),
    _ActionCard(icon: Icons.image_outlined, title: 'Ícone do aplicativo', body: _iconPath == null ? 'Escolher imagem da galeria' : 'Ícone selecionado', onTap: _chooseIcon,
      leading: _iconPath == null ? null : ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(_iconPath!), width: 42, height: 42, fit: BoxFit.cover))),
    _ActionCard(icon: Icons.photo_library_outlined, title: 'Capturas de tela', body: '${_screenshots.length}/8 imagens selecionadas', onTap: _chooseScreenshots),
    if (_screenshots.isNotEmpty) SizedBox(height: 90, child: ListView(scrollDirection: Axis.horizontal, children: [
      for (final path in _screenshots) Padding(padding: const EdgeInsets.only(right: 8), child: Stack(children: [
        ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(path), width: 76, height: 84, fit: BoxFit.cover)),
        Positioned(right: 0, top: 0, child: InkWell(onTap: () => setState(() => _screenshots.remove(path)), child: const Icon(Icons.cancel, color: Colors.red))),
      ])),
    ])),
    const SizedBox(height: 12),
    TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nome do aplicativo', prefixIcon: Icon(Icons.apps), border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Informe o nome do aplicativo.' : null),
    const SizedBox(height: 12),
    DropdownButtonFormField<String>(value: _category, decoration: const InputDecoration(labelText: 'Categoria', prefixIcon: Icon(Icons.category_outlined), border: OutlineInputBorder()),
      items: const ['Jogos', 'Aplicativos', 'Educação', 'Música', 'Fotografia', 'Ferramentas', 'Entretenimento'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => _category = v ?? 'Jogos')),
    const SizedBox(height: 12),
    TextFormField(controller: _version, decoration: const InputDecoration(labelText: 'Versão (ex.: 1.0.0)', prefixIcon: Icon(Icons.tag), border: OutlineInputBorder()), validator: (v) => v == null || v.trim().isEmpty ? 'Informe a versão.' : null),
    const SizedBox(height: 12),
    TextFormField(controller: _description, minLines: 3, maxLines: 6, decoration: const InputDecoration(labelText: 'Descrição', alignLabelWithHint: true, prefixIcon: Icon(Icons.description_outlined), border: OutlineInputBorder()), validator: (v) => v == null || v.trim().length < 10 ? 'Escreva uma descrição com pelo menos 10 caracteres.' : null),
    const SizedBox(height: 18),
    FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(16)), onPressed: _saving ? null : _publish,
      icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.add),
      label: Text(_saving ? 'Salvando...' : 'Começar publicação')),
    const SizedBox(height: 12),
    const Text('Aviso: nesta etapa os dados e arquivos ficam no próprio celular. Não existe ainda envio para uma loja online compartilhada.', style: TextStyle(color: Colors.white54, fontSize: 12)),
  ]));
}

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  String? _name, _email;
  String _developerStatus = 'none';
  bool _loading = true;

  @override
  void initState() { super.initState(); _loadAccount(); }

  Future<void> _loadAccount() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _name = prefs.getString('appsdroid_account_name');
      _email = prefs.getString('appsdroid_account_email');
      _developerStatus = prefs.getString('appsdroid_developer_status') ?? 'none';
      _loading = false;
    });
  }

  void _notice(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), backgroundColor: panel));
  }

  Future<void> _showAccountDialog({bool register = false}) async {
    final name = TextEditingController(text: _name ?? '');
    final email = TextEditingController(text: _email ?? '');
    final password = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: Text(register ? 'Criar conta' : 'Entrar na conta'),
      content: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (register) ...[
          TextFormField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Seu nome'), validator: (v) => v == null || v.trim().length < 2 ? 'Informe seu nome.' : null),
          const SizedBox(height: 10),
        ],
        TextFormField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail'), validator: (v) => v == null || !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim()) ? 'Informe um e-mail válido.' : null),
        const SizedBox(height: 10),
        TextFormField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Senha'), validator: (v) => v == null || v.length < 6 ? 'Use pelo menos 6 caracteres.' : null),
        const SizedBox(height: 10),
        const Text('Modo local de demonstração: esta conta fica somente neste aparelho e não pode ser usada em outros celulares.', style: TextStyle(color: Colors.white60, fontSize: 12)),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancelar')),
        FilledButton(onPressed: () async {
          if (!formKey.currentState!.validate()) return;
          final prefs = await SharedPreferences.getInstance();
          final normalizedEmail = email.text.trim().toLowerCase();
          final key = 'appsdroid_user_${sha256.convert(utf8.encode(normalizedEmail))}_password';
          final hash = sha256.convert(utf8.encode(password.text)).toString();
          if (register) {
            if (prefs.containsKey(key)) { _notice('Este e-mail já possui uma conta neste aparelho.'); return; }
            await prefs.setString(key, hash);
            await prefs.setString('appsdroid_account_name', name.text.trim());
            await prefs.setString('appsdroid_account_email', normalizedEmail);
          } else {
            final savedHash = prefs.getString(key);
            if (savedHash == null || savedHash != hash) { _notice('E-mail ou senha incorretos neste aparelho.'); return; }
            await prefs.setString('appsdroid_account_email', normalizedEmail);
            await prefs.setString('appsdroid_account_name', prefs.getString('appsdroid_account_name') ?? normalizedEmail.split('@').first);
          }
          if (dialogContext.mounted) Navigator.pop(dialogContext, true);
        }, child: Text(register ? 'Criar conta' : 'Entrar'))],
    ));
    name.dispose(); email.dispose(); password.dispose();
    if (result == true) { await _loadAccount(); _notice(register ? 'Conta criada neste aparelho.' : 'Login realizado.'); }
  }

  Future<void> _requestDeveloper() async {
    if (_email == null) { _notice('Entre ou crie uma conta primeiro.'); return; }
    if (_developerStatus == 'pending') { _notice('Sua solicitação já está aguardando análise.'); return; }
    final accepted = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Conta de desenvolvedor'),
      content: const Text('Enviar uma solicitação para publicar aplicativos? Nesta versão local, o pedido será registrado somente neste aparelho; a análise compartilhada exige conexão com o servidor Appsdroid.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Agora não')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Solicitar acesso'))],
    ));
    if (accepted == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('appsdroid_developer_status', 'pending');
      if (mounted) setState(() => _developerStatus = 'pending');
      _notice('Solicitação registrada localmente.');
    }
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('appsdroid_account_name');
    await prefs.remove('appsdroid_account_email');
    if (!mounted) return;
    setState(() { _name = null; _email = null; });
    _notice('Você saiu da conta neste aparelho.');
  }

  String get _developerLabel => switch (_developerStatus) {
    'pending' => 'Solicitação enviada • aguardando análise',
    'approved' => 'Desenvolvedor aprovado',
    'rejected' => 'Solicitação recusada',
    _ => 'Solicite acesso para publicar aplicativos.',
  };

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final signedIn = _email != null;
    return ListView(padding: const EdgeInsets.all(18), children: [
      Center(child: CircleAvatar(radius: 38, backgroundColor: panel, child: Icon(signedIn ? Icons.person : Icons.person_outline, size: 42, color: purple))),
      const SizedBox(height: 12),
      Center(child: Text(signedIn ? (_name ?? 'Minha conta') : 'Minha conta', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
      if (signedIn) ...[const SizedBox(height: 4), Center(child: Text(_email!, style: const TextStyle(color: Colors.white60)))],
      const SizedBox(height: 20),
      _ActionCard(icon: signedIn ? Icons.account_circle : Icons.login, title: signedIn ? 'Conta conectada neste aparelho' : 'Entrar ou criar conta', body: signedIn ? 'Toque para ver as opções da sua conta.' : 'Cadastre-se ou entre com seu e-mail.', onTap: () {
        if (!signedIn) { _showAccountDialog(); } else {
          showModalBottomSheet(context: context, backgroundColor: panel, builder: (ctx) => SafeArea(child: Wrap(children: [
            ListTile(leading: const Icon(Icons.logout), title: const Text('Sair da conta'), onTap: () { Navigator.pop(ctx); _logout(); }),
            ListTile(leading: const Icon(Icons.lock_reset), title: const Text('Criar outra conta'), onTap: () { Navigator.pop(ctx); _showAccountDialog(register: true); }),
          ])));
        }
      }, trailing: signedIn ? const Icon(Icons.check_circle, color: Colors.green) : null),
      if (!signedIn) _ActionCard(icon: Icons.person_add_alt_1, title: 'Criar conta', body: 'Registre um perfil neste aparelho.', onTap: () => _showAccountDialog(register: true)),
      _ActionCard(icon: Icons.verified_user_outlined, title: 'Conta de desenvolvedor', body: signedIn ? _developerLabel : 'Entre na sua conta para solicitar acesso.', onTap: _requestDeveloper),
      _ActionCard(icon: Icons.admin_panel_settings_outlined, title: 'Administração', body: 'Acesso restrito a administradores autorizados no servidor.', onTap: () => showDialog(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Administração protegida'),
        content: const Text('O painel administrativo ainda precisa do backend Appsdroid. A autorização deve ser validada no servidor; por segurança, não é possível liberar privilégios de administrador apenas pelo aplicativo.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fechar'))],
      ))),
      const SizedBox(height: 12),
      const Text('Importante: cadastro, login e solicitação de desenvolvedor desta versão são armazenados somente neste celular. Para contas reais compartilhadas entre aparelhos, análise de pedidos e administração, falta conectar o Firebase Authentication, Firestore e Storage ao projeto.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]);
  }
}

class AppSearch extends SearchDelegate<String> {
  @override
  List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override
  Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override
  Widget buildResults(BuildContext context) => _results();
  @override
  Widget buildSuggestions(BuildContext context) => _results();
  Widget _results() => ValueListenableBuilder<List<AppEntry>>(valueListenable: AppCatalog.apps, builder: (context, apps, _) {
    final filtered = apps.where((a) => a.name.toLowerCase().contains(query.toLowerCase()) || a.category.toLowerCase().contains(query.toLowerCase())).toList();
    if (filtered.isEmpty) return const Center(child: Text('Nenhum aplicativo encontrado.'));
    return ListView(children: filtered.map((a) => AppTile.fromEntry(a)).toList());
  });
}

class SectionTitle extends StatelessWidget {
  final String title; const SectionTitle(this.title, {super.key});
  @override Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800));
}
class CategoryChip extends StatelessWidget {
  final IconData icon; final String label; const CategoryChip({required this.icon, required this.label, super.key});
  @override Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 18, color: purple), label: Text(label), backgroundColor: panel, side: BorderSide.none);
}
class AppTile extends StatelessWidget {
  final String name, category, description; final IconData icon; final String? iconPath; final String? version;
  const AppTile({required this.name, required this.category, required this.icon, required this.description, this.iconPath, this.version, super.key});
  factory AppTile.fromEntry(AppEntry app) => AppTile(name: app.name, category: '${app.category} • v${app.version}', icon: Icons.apps, description: app.description, iconPath: app.iconPath, version: app.version);
  @override Widget build(BuildContext context) => Card(color: panel, margin: const EdgeInsets.only(bottom: 10), child: ListTile(contentPadding: const EdgeInsets.all(12),
    leading: _fileExists(iconPath) ? ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(iconPath!), width: 52, height: 52, fit: BoxFit.cover)) : Container(width: 52, height: 52, decoration: BoxDecoration(color: purple.withOpacity(.18), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: purple, size: 28)),
    title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('$category\n$description'), isThreeLine: true,
    onTap: version == null ? null : () => showDialog(context: context, builder: (_) => AlertDialog(title: Text(name), content: Text('$description\n\nVersão: $version\n\nO APK foi armazenado neste aparelho. A distribuição online será ativada após configurar o servidor.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar'))]))));
}
bool _fileExists(String? path) => path != null && path.isNotEmpty && File(path).existsSync();

class _ActionCard extends StatelessWidget {
  final IconData icon; final String title, body; final VoidCallback onTap; final Widget? trailing, leading;
  const _ActionCard({required this.icon, required this.title, required this.body, required this.onTap, this.trailing, this.leading});
  @override Widget build(BuildContext context) => Card(color: panel, margin: const EdgeInsets.only(bottom: 12), child: ListTile(onTap: onTap,
    leading: leading ?? Icon(icon, color: purple, size: 29), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(body), trailing: trailing ?? const Icon(Icons.chevron_right)));
}
class _InfoCard extends StatelessWidget {
  final IconData icon; final String title, body; const _InfoCard({required this.icon, required this.title, required this.body});
  @override Widget build(BuildContext context) => Card(color: panel, margin: const EdgeInsets.only(bottom: 12), child: ListTile(leading: Icon(icon, color: purple, size: 29), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(body)));
}
