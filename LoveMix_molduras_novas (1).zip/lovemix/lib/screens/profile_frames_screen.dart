import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../widgets/profile_frame.dart';

class ProfileFramesScreen extends StatefulWidget {
  const ProfileFramesScreen({super.key});
  @override
  State<ProfileFramesScreen> createState() => _ProfileFramesScreenState();
}

class _ProfileFramesScreenState extends State<ProfileFramesScreen> {
  static const _pink = Color(0xFFFF19B8);
  static const _purple = Color(0xFF8D35FF);
  bool busy = false;
  bool localReady = false;
  bool localLoading = false;
  List<String> localOwned = ['classic'];
  String localSelected = 'classic';
  int localCoins = 200;
  String? localUid;

  String _key(String name) => 'lovemix_frames_${localUid ?? 'guest'}_$name';

  Future<void> _loadLocal(Map<String, dynamic> profile, String uid) async {
    if (localUid == uid && (localReady || localLoading)) return;
    localUid = uid;
    localLoading = true;
    final prefs = await SharedPreferences.getInstance();
    // Importa o saldo/perfil atual apenas na primeira abertura. Depois disso,
    // compras e molduras são mantidas exclusivamente no armazenamento local.
    if (!prefs.containsKey(_key('initialized'))) {
      await prefs.setStringList(_key('owned'), ['classic']);
      await prefs.setString(_key('selected'), 'classic');
      await prefs.setInt(_key('coins'), (profile['coins'] as num?)?.toInt() ?? 200);
      await prefs.setBool(_key('initialized'), true);
    }
    if (!mounted) return;
    setState(() {
      localLoading = false;
      localOwned = prefs.getStringList(_key('owned')) ?? ['classic'];
      localSelected = prefs.getString(_key('selected')) ?? 'classic';
      localCoins = prefs.getInt(_key('coins')) ?? 200;
      localReady = true;
    });
  }
  final items = const [
    {'id':'classic','name':'Clássica','description':'Moldura padrão do LoveMix','emoji':'💜','currency':'free','cost':0},
    {'id':'gatinha_neon','name':'Gatinha Neon','description':'Orelhinhas, bigodes e patinhas em neon','emoji':'🐱','currency':'coins','cost':500},
    {'id':'gatinho_gamer','name':'Gatinho Gamer','description':'Fones com orelhas de gato e patinha','emoji':'🎧','currency':'coins','cost':600},
    {'id':'orbita_amor','name':'Órbita do Amor','description':'Corações em órbita com brilho violeta','emoji':'💞','currency':'coins','cost':700},
    {'id':'neon_coracao','name':'Neon Coração','description':'Neon rosa com coroa pingando e corações','emoji':'💗','currency':'coins','cost':800},
    {'id':'galaxia_roxa','name':'Galáxia Roxa','description':'Planetas e anéis cósmicos luminosos','emoji':'🪐','currency':'coins','cost':900},
    {'id':'rosas_rosa','name':'Rosas Rosa','description':'Rosas rosa com corações dourados','emoji':'🌹','currency':'coins','cost':1000},
    {'id':'jardim_roxo','name':'Jardim Roxo','description':'Rosas roxas, folhas de ouro e correntes','emoji':'🌸','currency':'coins','cost':1200},
    {'id':'chamas_reais','name':'Chamas Reais','description':'Chamas violeta com coroa dourada','emoji':'🔥','currency':'coins','cost':1400},
    {'id':'laco_real','name':'Laço Real','description':'Fita roxa e dourada com laço e coroa','emoji':'🎀','currency':'coins','cost':1500},
    {'id':'rosa_negra_real','name':'Rosa Negra Real','description':'Coroa negra, rosas escuras e cristais','emoji':'🖤','currency':'coins','cost':1700},
    {'id':'gotica_sombria','name':'Gótica Sombria','description':'Correntes, cruz, rosas e chamas roxas','emoji':'⛓️','currency':'coins','cost':1800},
    {'id':'cadeado_amor','name':'Cadeado do Amor','description':'Correntes de prata com coração-cadeado','emoji':'🔒','currency':'coins','cost':2000},
    {'id':'coroa_louros','name':'Coroa de Louros','description':'Coroa, louros dourados e coração de cristal','emoji':'👑','currency':'coins','cost':2300},
    {'id':'asas_celestiais','name':'Asas Celestiais','description':'Asas violeta, coroa e coração dourado','emoji':'🪽','currency':'coins','cost':2600},
    {'id':'asas_reais','name':'Asas Reais','description':'Asas de ouro, coroa e coração de cristal','emoji':'💜','currency':'coins','cost':3000},
    {'id':'vip_dourado','name':'VIP Dourado','description':'Aro de pincel dourado com placa VIP','emoji':'⭐','currency':'coins','cost':3500},
    {'id':'ouro_alado','name':'Asas de Ouro','description':'Coroa dourada, asas de ouro e coração','emoji':'👑','currency':'coins','cost':3800},
    {'id':'coracoes_laco','name':'Corações e Laço','description':'Corações rosa brilhantes com laço pink','emoji':'🎀','currency':'coins','cost':700},
    {'id':'rosas_rubi','name':'Rosas Rubi','description':'Coroa prateada, rosas vermelhas e cristais','emoji':'🌹','currency':'coins','cost':1600},
    {'id':'borboletas_azuis','name':'Borboletas Azuis','description':'Rosas azuis, borboletas e coroa de gelo','emoji':'🦋','currency':'coins','cost':1900},
    {'id':'anjo_halo','name':'Anjo com Halo','description':'Asas brancas, halo dourado e coração','emoji':'😇','currency':'coins','cost':3200},
    {'id':'borboletas_roxas','name':'Borboletas Roxas','description':'Chamas violeta com borboletas neon','emoji':'🦋','currency':'coins','cost':1300},
    {'id':'dragao_verde','name':'Dragão Verde','description':'Dragão em chamas verdes com coroa','emoji':'🐲','currency':'coins','cost':3400},
    {'id':'gatinho_fofo','name':'Gatinho Fofo','description':'Orelhinhas, patinhas e gatinho sorridente','emoji':'🐱','currency':'coins','cost':650},
    {'id':'correntes_prata','name':'Correntes de Prata','description':'Correntes com coração-cadeado','emoji':'🔗','currency':'coins','cost':2100},
    {'id':'leao_fogo','name':'Leão de Fogo','description':'Leão dourado com chamas e coroa real','emoji':'🦁','currency':'coins','cost':3900},
    {'id':'rosas_prata','name':'Rosas de Prata','description':'Rosas prateadas, borboletas e coroa','emoji':'🤍','currency':'coins','cost':1500},
    {'id':'estrelas_ouro','name':'Estrelas de Ouro','description':'Estrelas douradas girando em órbita','emoji':'⭐','currency':'coins','cost':800},
    {'id':'realeza_gotas','name':'Realeza Roxa','description':'Coroa roxa pingando com corações','emoji':'💜','currency':'coins','cost':1750},
    {'id':'paraiso_tropical','name':'Paraíso Tropical','description':'Palmeira, hibisco e pássaros em neon','emoji':'🌴','currency':'coins','cost':1100},
    {'id':'sakura','name':'Sakura','description':'Flores de cerejeira com lanterna vermelha','emoji':'🌸','currency':'coins','cost':1250},
    {'id':'gamer_neon','name':'Gamer Neon','description':'Fones, controle e raios elétricos','emoji':'🎮','currency':'coins','cost':1450},
    {'id':'amor_vermelho','name':'Amor Vermelho','description':'Laço vermelho, rosas e corações','emoji':'❤️','currency':'coins','cost':900},
    {'id':'coroa_rubi','name':'Coroa Rubi','description':'Fita vermelha, louros e coroa dourada','emoji':'👑','currency':'coins','cost':2400},
    {'id':'hacker_verde','name':'Hacker Verde','description':'Capuz, caveira e chamas verdes','emoji':'💀','currency':'coins','cost':2200},
    {'id':'borboletas_lilas','name':'Borboletas Lilás','description':'Borboletas e rosas roxas luminosas','emoji':'🦋','currency':'coins','cost':1350},
    {'id':'inverno_gelo','name':'Inverno de Gelo','description':'Flocos de neve e boneco de neve','emoji':'⛄','currency':'coins','cost':950},
    {'id':'arco_iris','name':'Arco-Íris','description':'Aro arco-íris com corações coloridos','emoji':'🌈','currency':'coins','cost':1650},
    {'id':'rosas_poker','name':'Rosas e Pôquer','description':'Rosas vermelhas com carta de ás','emoji':'🃏','currency':'coins','cost':2000},
    {'id':'lua_planetas','name':'Lua e Planetas','description':'Lua, planetas e estrelas douradas','emoji':'🪐','currency':'coins','cost':1050},
    {'id':'asas_cristal','name':'Asas de Cristal','description':'Asas de gelo, coroa e coração de cristal','emoji':'💎','currency':'coins','cost':3700},
  ];

  Future<void> _buyOrEquip(Map<String, Object> item) async {
    if (busy || !localReady) return;
    final id = item['id'] as String;
    final currency = item['currency'] as String;
    final cost = (item['cost'] as num).toInt();
    final owned = List<String>.from(localOwned);
    setState(() => busy = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!owned.contains(id)) {
        if (currency == 'coins' && localCoins < cost) {
          throw Exception('Você não tem moedas suficientes.');
        }
        if (currency == 'coins') localCoins -= cost;
        owned.add(id);
        await prefs.setStringList(_key('owned'), owned);
        await prefs.setInt(_key('coins'), localCoins);
      }
      await prefs.setString(_key('selected'), id);
      // Publica somente a moldura equipada no perfil; o saldo e a compra
      // continuam no armazenamento local do aparelho.
      await FirebaseFirestore.instance.collection('users').doc(localUid).set(
        {'profileFrame': id, 'selectedProfileFrame': id}, SetOptions(merge: true));
      if (!mounted) return;
      setState(() {
        localOwned = owned;
        localSelected = id;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${item['name']} equipada no seu aparelho!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Molduras de perfil'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData || !snap.data!.exists) {
            return const Center(child: CircularProgressIndicator(color: _pink));
          }
          final data = snap.data!.data() ?? <String, dynamic>{};
          _loadLocal(data, uid);
          final owned = localOwned;
          final selected = localSelected;
          final photo = (data['photoUrl'] ?? '').toString();
          final coins = localCoins;
          if (!localReady) return const Center(child: CircularProgressIndicator(color: _pink));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF32104D), Color(0xFF12091E)]),
              border: Border.all(color: _purple.withOpacity(.7))),
              child: Column(children: [
                const Text('Sua moldura atual', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                ProfileFrameAvatar(photoUrl: photo, frameId: selected, size: 110),
                const SizedBox(height: 10),
                Text(items.firstWhere((e) => e['id'] == selected, orElse: () => items.first)['name'] as String,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('🪙 $coins moedas', style: const TextStyle(color: Color(0xFFFFD56A), fontWeight: FontWeight.bold)),
                  const SizedBox(width: 18),
                ]),
              ]),
            ),
            const SizedBox(height: 20),
            const SizedBox(height: 20),
            const Text('Loja de molduras' , style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Todas as molduras podem ser compradas com moedas da sua conta neste aparelho.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 12),
            ...([...items]..sort((a, b) => (a['cost'] as num).compareTo(b['cost'] as num))).map((item) {
              final id = item['id'] as String;
              final has = owned.contains(id);
              final active = selected == id;
              final currency = item['currency'] as String;
              final cost = item['cost'];
              return Container(margin: const EdgeInsets.only(bottom: 18), padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 24),
                decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: active ? _pink : _purple.withOpacity(.35))),
                child: Row(children: [
                  ProfileFrameAvatar(photoUrl: photo, frameId: id, size: 62),
                  const SizedBox(width: 13),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${item['emoji']} ${item['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(item['description'] as String, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    const SizedBox(height: 4),
                    Text(currency == 'free' ? 'Grátis' : '🪙 $cost moedas',
                      style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 12, fontWeight: FontWeight.bold)),
                  ])),
                  const SizedBox(width: 8),
                  SizedBox(width: 100, child: ElevatedButton(
                    onPressed: busy || active ? null : () => _buyOrEquip(item),
                    style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10)),
                    child: Text(active ? 'Ativa' : has ? 'Equipar' : 'Comprar', style: const TextStyle(fontSize: 12)),
                  )),
                ]),
              );
            }),
            if (busy) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: _pink))),
          ]);
        },
      ),
    );
  }
}
