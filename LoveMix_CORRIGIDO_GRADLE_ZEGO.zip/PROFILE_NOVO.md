# Perfil LoveMix — layout de apresentação e configuração

A tela **Perfil** agora apresenta uma prévia visual do perfil como as outras pessoas verão: foto de perfil circular com moldura neon, nome, símbolo de gênero, idade e localização na mesma linha (por exemplo, `22 anos • São Paulo-SP`), status online, interesses em etiquetas, bio e botões de Curtir/Mensagem ilustrativos.

Abaixo da prévia, a configuração permite alterar nome, biografia, data de nascimento, cidade/estado, país, gênero e interesses (incluindo interesses personalizados). As fotos publicadas são exibidas em uma galeria de três colunas e podem ser abertas em tela cheia.

A visualização pública do perfil usa o mesmo estilo e mostra a galeria de fotos publicadas. A idade é calculada pela data de nascimento, sem exibir a data completa. A localização usa cidade/estado e país; quando a cidade já contém a sigla do estado e o país é Brasil, a linha compacta usa somente a cidade/estado.

A privacidade foi separada em duas configurações: `profileVisibility` controla quem encontra o perfil; `postVisibility` é o padrão usado nas próximas publicações. Cada foto já publicada mantém sua própria opção de visibilidade (público, amigos/matches ou privado).

## Regras e implantação

A atualização acrescenta `postVisibility` aos campos de perfil que o próprio usuário pode atualizar. Publique as regras atualizadas antes de testar no Firebase:
- Firestore: `firestore.rules`
- Storage: `storage.rules`

As fotos de amigos usam os documentos `matches/{uid1_uid2}` criados pelo fluxo de match existente. A galeria pública consulta somente fotos públicas; quando há match, consulta também as fotos marcadas para amigos. Fotos privadas continuam visíveis somente para o titular.

A compilação e os testes no Firebase real precisam ser executados no GitHub Actions com as credenciais do projeto.

## Atualização do perfil do proprietário (Conecta)
- A tela de perfil do dono foi redesenhada com foto de capa horizontal e ação para trocar a imagem.
- Nome, idade, biografia (até 300 caracteres), interesses e galeria continuam ligados aos dados reais do Firebase.
- A galeria permite adicionar fotos, abrir publicações e remover imagens.
- O botão de visualização abre o perfil público, que também apresenta a foto de capa.
- A foto de capa é salva em `profileCoverUrl` no documento `users/{uid}` e no Storage em `profile_covers/{uid}/cover.*`.
- As regras do Firebase Storage foram atualizadas para permitir o envio e a remoção das fotos do próprio usuário.
