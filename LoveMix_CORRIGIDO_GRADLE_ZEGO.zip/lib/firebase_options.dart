// Configuração Firebase do LoveMix (Android).
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show TargetPlatform, defaultTargetPlatform, kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('LoveMix está configurado para Android.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('Plataforma Firebase não configurada para LoveMix.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAkPpjNO5CWBy8h0yoppXQBvye7Awr6R2Q',
    appId: '1:985069046748:android:2b92a5982fa7147bd55d19',
    messagingSenderId: '985069046748',
    projectId: 'lovemix-73849',
    storageBucket: 'lovemix-73849.firebasestorage.app',
  );
}
