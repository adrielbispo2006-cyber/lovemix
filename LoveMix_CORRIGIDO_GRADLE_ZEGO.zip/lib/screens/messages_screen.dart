import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return StreamBuilder(
      stream: service.myMatches(),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final matches = snap.data!.docs;
        return Column(
          children: [
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: const Color(0xFF241333),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF783A9C)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.chat_bubble, color: Color(0xFFFF2DAB)),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'CHAT GRÁTIS: converse sem gastar moedas e sem assinatura VIP.',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: matches.isEmpty
                  ? const Center(child: Text('Curta pessoas para criar combinações e começar a conversar grátis.'))
                  : ListView.builder(
            itemCount: matches.length,
            itemBuilder: (context, i) {
            final m = matches[i].data();
            final users = List<String>.from(m['users'] ?? []);
            final other = users.firstWhere((u) => u != service.uid, orElse: () => '');
            return FutureBuilder(
              future: FirebaseFirestore.instance.collection('users').doc(other).get(),
              builder: (context, userSnap) {
                final p = userSnap.data?.data() ?? {};
                return ListTile(
                  leading: const CircleAvatar(backgroundColor: Color(0xFF45205F), child: Icon(Icons.person)),
                  title: Text((p['name'] ?? 'Novo match').toString()),
                  subtitle: Text((m['lastMessage'] ?? 'Vocês combinaram!').toString(), maxLines: 1),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(chatId: matches[i].id, otherName: (p['name'] ?? 'LoveMix').toString()))),
                );
              },
            );
          },
        ),
            ),
          ],
        );
      },
    );
  }
}
