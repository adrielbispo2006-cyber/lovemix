import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/data_service.dart';

const _pink = Color(0xFFFF2DAB);
const _purple = Color(0xFF8B35FF);
const _gold = Color(0xFFFFD45C);
const _panel = Color(0xFF171022);

class AllianceWallScreen extends StatefulWidget {
  const AllianceWallScreen({super.key});
  @override
  State<AllianceWallScreen> createState() => _AllianceWallScreenState();
}

class _AllianceWallScreenState extends State<AllianceWallScreen> {
  bool _creating = false;

  Future<void> _newAlliance() async {
    final id = TextEditingController();
    final note = TextEditingController();
    String kind = 'Namorados';
    DateTime date = DateTime.now();
    await showDialog<void>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('Criar aliança 💍'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Convide alguém pelo ID público LM-... para formar uma aliança.'),
          const SizedBox(height: 12),
          TextField(controller: id, textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(labelText: 'ID da pessoa (LM-...)')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: kind, decoration: const InputDecoration(labelText: 'Tipo de aliança'),
            items: const ['Namorados', 'BFF', 'Amigos', 'Irmãos'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) => setDialogState(() => kind = v ?? kind)),
          const SizedBox(height: 12),
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.calendar_month, color: _gold),
            title: const Text('Data de início'), subtitle: Text(DateFormat('dd/MM/yyyy').format(date)),
            onTap: () async { final picked = await showDatePicker(context: context, initialDate: date,
              firstDate: DateTime(2000), lastDate: DateTime(2100), builder: (c, child) => Theme(data: ThemeData.dark(), child: child!));
              if (picked != null) setDialogState(() => date = picked); }),
          TextField(controller: note, maxLength: 100, decoration: const InputDecoration(labelText: 'Mensagem (opcional)', hintText: 'Nossa amizade é especial!')),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
          ElevatedButton(onPressed: _creating ? null : () async {
            setDialogState(() {});
            setState(() => _creating = true);
            try {
              await DataService.instance.createAllianceByPublicId(id.text, kind, date, note.text);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (mounted) ScaffoldMessenger.of(this.context).showSnackBar(const SnackBar(content: Text('Convite de aliança enviado! 💍')));
            } catch (e) {
              if (mounted) ScaffoldMessenger.of(this.context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
            } finally { if (mounted) setState(() => _creating = false); }
          }, child: const Text('Enviar convite'))],
      ),
    ));
    id.dispose(); note.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 8), child: Row(children: [
        const Expanded(child: Text('Mural de Aliança', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800))),
        IconButton(onPressed: _newAlliance, tooltip: 'Criar aliança', icon: const Icon(Icons.add_circle, color: _pink, size: 30)),
      ])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: Text(
        'Celebre suas conexões: amor, amizade, BFF e família.',
        style: TextStyle(color: Colors.white.withValues(alpha: .65)), textAlign: TextAlign.center)),
      const SizedBox(height: 8),
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: service.myAlliances(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('Não foi possível carregar o mural.'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: _pink));
          final docs = snapshot.data!.docs.toList()
            ..sort((a, b) => ((b.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0)
              .compareTo((a.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0));
          if (docs.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(
            mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.favorite, size: 64, color: _purple), const SizedBox(height: 12),
              const Text('Seu mural ainda está vazio', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6), const Text('Crie sua primeira aliança e convide alguém especial.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
              const SizedBox(height: 16), ElevatedButton.icon(onPressed: _newAlliance, icon: const Icon(Icons.add), label: const Text('Criar aliança')),
            ])));
          return ListView.builder(padding: const EdgeInsets.fromLTRB(14, 8, 14, 24), itemCount: docs.length,
            itemBuilder: (context, i) => _AllianceCard(doc: docs[i]));
        },
      )),
    ]);
  }
}

class _AllianceCard extends StatelessWidget {
  const _AllianceCard({required this.doc});
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;

  @override
  Widget build(BuildContext context) {
    final d = doc.data();
    final me = DataService.instance.uid;
    final partnerId = (d['members'] as List? ?? []).cast<String>().firstWhere((v) => v != me, orElse: () => '');
    final isInvited = d['invitedUid'] == me;
    final pending = d['invitationStatus'] == 'pending';
    final kind = (d['relationshipType'] ?? 'Amigos').toString();
    final start = d['startDate'] is Timestamp ? (d['startDate'] as Timestamp).toDate() : DateTime.now();
    final status = pending ? 'Convite pendente' : (d['status'] == 'planned' ? 'Planejada' : 'Ativa');
    final statusColor = pending ? _gold : (d['status'] == 'planned' ? const Color(0xFF42A5F5) : const Color(0xFF42D392));
    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: partnerId.isEmpty ? null : FirebaseFirestore.instance.collection('users').doc(partnerId).get(),
      builder: (context, userSnap) {
        final p = userSnap.data?.data() ?? {};
        final name = (p['name'] ?? 'Pessoa do LoveMix').toString();
        final photo = (p['photoUrl'] ?? '').toString();
        return Card(color: _panel, margin: const EdgeInsets.only(bottom: 16), clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: pending ? _gold : _gold.withValues(alpha: .75), width: 1.5)),
          child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _avatar((d['creatorPhotoUrl'] ?? '').toString(), (d['creatorName'] ?? 'Você').toString()),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 9), child: Icon(Icons.favorite, color: _pink, size: 22)),
              _avatar(photo, name), const Spacer(), const Icon(Icons.link, color: _gold, size: 30),
            ]),
            const SizedBox(height: 12),
            Text('${d['creatorName'] ?? 'Você'} & $name', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 7),
            Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
              _pill(_kindEmoji(kind) + ' ' + kind, _purple), _pill(status, statusColor),
            ]),
            const SizedBox(height: 8),
            Text(pending ? (isInvited ? 'Você recebeu um convite de aliança.' : 'Aguardando a outra pessoa aceitar.') : 'Desde: ${DateFormat('dd/MM/yyyy').format(start)}',
              style: const TextStyle(color: Colors.white70)),
            if ((d['message'] ?? '').toString().isNotEmpty) ...[
              const SizedBox(height: 8), Text('“${d['message']}”', style: const TextStyle(color: Colors.white60, fontStyle: FontStyle.italic)),
            ],
            if (pending && isInvited) ...[
              const SizedBox(height: 12), Row(children: [
                Expanded(child: OutlinedButton(onPressed: () => DataService.instance.respondAlliance(doc.id, false), child: const Text('Recusar'))),
                const SizedBox(width: 10), Expanded(child: ElevatedButton(onPressed: () => DataService.instance.respondAlliance(doc.id, true), child: const Text('Aceitar 💍'))),
              ]),
            ],
          ])),
        );
      },
    );
  }

  Widget _avatar(String url, String name) => Container(width: 76, height: 76, padding: const EdgeInsets.all(2),
    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _gold, width: 2)),
    child: ClipOval(child: url.isEmpty ? Container(color: Colors.white10, child: const Icon(Icons.person, size: 38, color: Colors.white70))
      : CachedNetworkImage(imageUrl: url, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.person))));

  Widget _pill(String label, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
    decoration: BoxDecoration(color: color.withValues(alpha: .22), borderRadius: BorderRadius.circular(20), border: Border.all(color: color)),
    child: Text(label, style: TextStyle(color: color == _gold ? _gold : Colors.white, fontWeight: FontWeight.w700, fontSize: 12)));

  String _kindEmoji(String kind) => switch (kind) { 'Namorados' => '❤️', 'BFF' => '💜', 'Irmãos' => '💛', _ => '💙' };
}
