import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PostInteractionsScreen extends StatefulWidget {
  const PostInteractionsScreen({super.key, required this.ownerId, required this.postId, required this.photoUrl});
  final String ownerId;
  final String postId;
  final String photoUrl;

  @override
  State<PostInteractionsScreen> createState() => _PostInteractionsScreenState();
}

class _PostInteractionsScreenState extends State<PostInteractionsScreen> {
  static const pink = Color(0xFFFF19B8);
  final commentController = TextEditingController();
  final db = FirebaseFirestore.instance;
  String get myId => FirebaseAuth.instance.currentUser?.uid ?? '';
  DocumentReference<Map<String, dynamic>> get post => db.collection('users').doc(widget.ownerId).collection('posts').doc(widget.postId);
  CollectionReference<Map<String, dynamic>> get likes => post.collection('likes');
  CollectionReference<Map<String, dynamic>> get comments => post.collection('comments');

  @override
  void dispose() { commentController.dispose(); super.dispose(); }

  Future<void> _toggleLike(bool liked) async {
    if (myId.isEmpty) return;
    final ref = likes.doc(myId);
    if (liked) {
      await ref.delete();
    } else {
      await ref.set({'uid': myId, 'createdAt': FieldValue.serverTimestamp()});
      if (widget.ownerId != myId) {
        await db.collection('users').doc(widget.ownerId).collection('notifications').add({
          'type': 'post_like', 'fromUid': myId, 'postId': widget.postId,
          'createdAt': FieldValue.serverTimestamp(), 'read': false,
        });
      }
    }
  }

  Future<void> _sendComment() async {
    final text = commentController.text.trim();
    if (text.isEmpty || myId.isEmpty) return;
    final userDoc = await db.collection('users').doc(myId).get();
    final name = (userDoc.data()?['name'] ?? 'Usuário').toString();
    await comments.add({'uid': myId, 'name': name, 'text': text, 'createdAt': FieldValue.serverTimestamp()});
    commentController.clear();
    if (widget.ownerId != myId) {
      await db.collection('users').doc(widget.ownerId).collection('notifications').add({
        'type': 'post_comment', 'fromUid': myId, 'postId': widget.postId,
        'comment': text, 'createdAt': FieldValue.serverTimestamp(), 'read': false,
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    appBar: AppBar(backgroundColor: Colors.black, title: const Text('Publicação')),
    body: Column(children: [
      Expanded(child: Center(child: InteractiveViewer(child: Image.network(widget.photoUrl, fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, size: 60))))),
      Container(color: const Color(0xFF171022), padding: const EdgeInsets.fromLTRB(14, 12, 14, 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: likes.doc(myId).snapshots(),
          builder: (context, ownLike) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: likes.snapshots(),
            builder: (context, count) {
              final liked = ownLike.data?.exists == true;
              final total = count.data?.docs.length ?? 0;
              return Row(children: [
                IconButton(onPressed: () => _toggleLike(liked), icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? pink : Colors.white, size: 29)),
                Text('$total curtidas', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(width: 18),
                const Icon(Icons.chat_bubble_outline, color: Colors.white70, size: 20),
                const SizedBox(width: 6),
                StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: comments.snapshots(), builder: (_, c) => Text('${c.data?.docs.length ?? 0} comentários')),
              ]);
            },
          ),
        ),
        const Divider(color: Colors.white24),
        SizedBox(height: 150, child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: comments.orderBy('createdAt', descending: true).limit(50).snapshots(),
          builder: (context, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: pink));
            if (snap.data!.docs.isEmpty) return const Center(child: Text('Seja a primeira pessoa a comentar!', style: TextStyle(color: Colors.white60)));
            return ListView(children: snap.data!.docs.map((doc) {
              final c = doc.data();
              return Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: RichText(text: TextSpan(style: const TextStyle(color: Colors.white), children: [
                TextSpan(text: '${c['name'] ?? 'Usuário'}: ', style: const TextStyle(fontWeight: FontWeight.bold)),
                TextSpan(text: (c['text'] ?? '').toString()),
              ])));
            }).toList());
          },
        )),
        Row(children: [
          Expanded(child: TextField(controller: commentController, maxLength: 500, decoration: const InputDecoration(counterText: '', hintText: 'Escreva um comentário...'))),
          IconButton(onPressed: _sendComment, icon: const Icon(Icons.send, color: pink)),
        ]),
      ])),
    ]),
  );
}
