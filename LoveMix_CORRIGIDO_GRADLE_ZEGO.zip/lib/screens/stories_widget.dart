import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../services/data_service.dart';

const _storyPink = Color(0xFFFF19B8);
const _storyPurple = Color(0xFF8D35FF);

class StoriesStrip extends StatefulWidget {
  const StoriesStrip({super.key});
  @override
  State<StoriesStrip> createState() => _StoriesStripState();
}

class _StoriesStripState extends State<StoriesStrip> {
  bool uploading = false;
  Future<void> _addStory() async {
    if (uploading) return;
    final choice = await showModalBottomSheet<String>(context: context, backgroundColor: const Color(0xFF171022), builder: (ctx) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.photo, color: _storyPink), title: const Text('Story com foto'), onTap: () => Navigator.pop(ctx, 'image')),
      ListTile(leading: const Icon(Icons.videocam, color: _storyPink), title: const Text('Story com vídeo'), onTap: () => Navigator.pop(ctx, 'video')),
    ])));
    if (choice == null) return;
    try {
      final picker = ImagePicker();
      final XFile? file = choice == 'image'
          ? await picker.pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1440)
          : await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 30));
      if (file == null) return;
      setState(() => uploading = true);
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final ext = choice == 'image' ? 'jpg' : 'mp4';
      final ref = FirebaseStorage.instance.ref('stories/$uid/${DateTime.now().millisecondsSinceEpoch}.$ext');
      await ref.putFile(File(file.path), SettableMetadata(contentType: choice == 'image' ? 'image/jpeg' : 'video/mp4'));
      final url = await ref.getDownloadURL();
      final profile = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      await FirebaseFirestore.instance.collection('stories').add({
        'ownerId': uid, 'name': profile.data()?['name'] ?? 'Pessoa',
        'photoUrl': profile.data()?['photoUrl'] ?? '', 'mediaUrl': url,
        'mediaType': choice, 'createdAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Story publicado por 24 horas!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível publicar: $e')));
    } finally { if (mounted) setState(() => uploading = false); }
  }

  @override
  Widget build(BuildContext context) => SizedBox(height: 104, child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('stories').where('expiresAt', isGreaterThan: Timestamp.now()).orderBy('expiresAt').snapshots(),
    builder: (context, snap) {
      final docs = snap.data?.docs ?? [];
      final grouped = <String, List<QueryDocumentSnapshot<Map<String, dynamic>>>>{};
      for (final d in docs) { final id = (d.data()['ownerId'] ?? '').toString(); if (id.isNotEmpty) (grouped[id] ??= []).add(d); }
      return ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
        _bubble('Seu story', '', own: true, onTap: _addStory),
        ...grouped.entries.where((e) => e.key != FirebaseAuth.instance.currentUser?.uid).map((entry) {
          final first = entry.value.first.data();
          return _bubble((first['name'] ?? 'Pessoa').toString(), (first['photoUrl'] ?? '').toString(), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StoryViewer(stories: entry.value))));
        }),
      ]);
    },
  ));

  Widget _bubble(String name, String photo, {bool own = false, required VoidCallback onTap}) => GestureDetector(onTap: onTap, child: SizedBox(width: 76, child: Column(children: [
    Container(width: 66, height: 66, padding: const EdgeInsets.all(2), decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _storyPink, width: 2), gradient: const LinearGradient(colors: [_storyPink, _storyPurple])), child: ClipOval(child: photo.isEmpty ? Container(color: const Color(0xFF241333), child: Icon(own ? Icons.add : Icons.person, color: Colors.white, size: 28)) : Image.network(photo, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.person)))),
    const SizedBox(height: 4), Text(uploading && own ? 'Enviando...' : name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
  ])));
}

class StoryViewer extends StatefulWidget {
  const StoryViewer({super.key, required this.stories});
  final List<QueryDocumentSnapshot<Map<String, dynamic>>> stories;
  @override
  State<StoryViewer> createState() => _StoryViewerState();
}
class _StoryViewerState extends State<StoryViewer> {
  int index = 0;
  VideoPlayerController? video;
  @override
  void initState() { super.initState(); _loadVideo(); }
  Future<void> _loadVideo() async {
    await video?.dispose(); video = null;
    final data = widget.stories[index].data();
    if (data['mediaType'] == 'video') {
      final controller = VideoPlayerController.networkUrl(Uri.parse(data['mediaUrl']));
      video = controller; await controller.initialize(); await controller.setLooping(true); await controller.play();
      if (mounted) setState(() {});
    }
  }
  void _next() { if (index + 1 >= widget.stories.length) { Navigator.pop(context); return; } setState(() => index++); _loadVideo(); }
  @override
  void dispose() { video?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final data = widget.stories[index].data(); final isVideo = data['mediaType'] == 'video';
    return Scaffold(backgroundColor: Colors.black, body: SafeArea(child: Stack(fit: StackFit.expand, children: [
      Center(child: isVideo ? (video?.value.isInitialized == true ? AspectRatio(aspectRatio: video!.value.aspectRatio, child: VideoPlayer(video!)) : const CircularProgressIndicator()) : Image.network((data['mediaUrl'] ?? '').toString(), fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white))),
      Positioned(top: 12, left: 12, right: 12, child: Row(children: [Expanded(child: LinearProgressIndicator(value: (index + 1) / widget.stories.length, color: _storyPink, backgroundColor: Colors.white24)), const SizedBox(width: 12), IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, color: Colors.white))])),
      Positioned(top: 54, left: 16, child: Text((data['name'] ?? 'Story').toString(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      Positioned.fill(top: 90, child: GestureDetector(behavior: HitTestBehavior.translucent, onTap: _next)),
    ])));
  }
}
