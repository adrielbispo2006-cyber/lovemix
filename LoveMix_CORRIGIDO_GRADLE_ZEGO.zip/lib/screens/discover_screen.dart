import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'profile_view_screen.dart';
import 'stories_widget.dart';
import 'alliance_wall_screen.dart';
import '../widgets/profile_frame.dart';

const _gold = Color(0xFFFF2DAB);
const _panel = Color(0xFF171022);

/// Tela de descoberta com visual familiar de aplicativo de namoro:
/// stories no topo e cartões de perfil com foto, localização e ações.
class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});
  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  final search = TextEditingController();
  String tab = 'Descobrir';
  String countryFilter = 'Mundo todo';

  @override
  void initState() {
    super.initState();
    DataService.instance.ensurePublicId().catchError((_) {});
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: service.discoverUsers(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Não foi possível carregar pessoas agora.'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator(color: _gold));
        }
        final all = snapshot.data!.docs.where((d) {
          final p = d.data();
          return d.id != service.uid &&
              p['isActive'] != false &&
              p['profileVisibility'] != 'private' &&
              p['profileVisibility'] != 'friends';
        }).toList();
        final countries = all.map((d) => (d.data()['country'] ?? '').toString().trim())
            .where((v) => v.isNotEmpty).toSet().toList()..sort();
        final term = search.text.trim().toLowerCase();
        final visible = all.where((d) {
          final p = d.data();
          if (tab == 'Online' && p['isOnline'] != true) return false;
          if (tab == 'Novos' && p['createdAt'] is Timestamp) {
            final created = (p['createdAt'] as Timestamp).toDate();
            if (DateTime.now().difference(created).inDays > 30) return false;
          }
          if (countryFilter != 'Mundo todo' &&
              (p['country'] ?? '').toString().toLowerCase() != countryFilter.toLowerCase()) return false;
          if (term.isEmpty) return true;
          if (term.startsWith('lm-')) {
            return (p['publicId'] ?? '').toString().toLowerCase() == term;
          }
          return ['name', 'city', 'country'].any(
            (k) => (p[k] ?? '').toString().toLowerCase().contains(term));
        }).toList();
        if (tab == 'Novos') {
          visible.sort((a, b) {
            final ad = a.data()['createdAt']; final bd = b.data()['createdAt'];
            final at = ad is Timestamp ? ad.millisecondsSinceEpoch : 0;
            final bt = bd is Timestamp ? bd.millisecondsSinceEpoch : 0;
            return bt.compareTo(at);
          });
        }

        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: TextField(
                  controller: search,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'Buscar nome, cidade ou ID (LM-...)',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: search.text.isEmpty ? null : IconButton(
                      onPressed: () { search.clear(); setState(() {}); },
                      icon: const Icon(Icons.close)),
                  ),
                )),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  tooltip: 'Filtrar por país',
                  icon: const Icon(Icons.tune, color: _gold),
                  onSelected: (v) => setState(() => countryFilter = v),
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'Mundo todo', child: Text('🌎 Mundo todo')),
                    ...countries.map((c) => PopupMenuItem(value: c, child: Text(c))),
                  ],
                ),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: SingleChildScrollView(scrollDirection: Axis.horizontal,
                  child: Row(children: [
                    _topTab('Descobrir'), _topTab('Online'), _topTab('Novos'), _topTab('💍 Mural'),
                  ]))),
                if (countryFilter != 'Mundo todo')
                  TextButton(onPressed: () => setState(() => countryFilter = 'Mundo todo'),
                    child: const Text('Mundo todo', style: TextStyle(color: _gold, fontSize: 12))),
              ]),
            ]),
          ),
          if (tab != '💍 Mural') const StoriesStrip(),
          Expanded(child: tab == '💍 Mural'
            ? const AllianceWallScreen()
            : term.startsWith('lm-')
            ? FutureBuilder<QuerySnapshot<Map<String, dynamic>>>(
                future: service.findUserByPublicId(search.text.trim()),
                builder: (context, idSnapshot) {
                  if (idSnapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator(color: _gold));
                  }
                  final matches = (idSnapshot.data?.docs ?? []).where((d) =>
                    d.id != service.uid && d.data()['isActive'] != false &&
                    d.data()['profileVisibility'] == 'public').toList();
                  if (matches.isEmpty) return const Center(child: Padding(
                    padding: EdgeInsets.all(24), child: Text('Nenhum perfil público encontrado com esse ID.')));
                  return ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 18),
                    children: matches.map(_profileCard).toList());
                })
            : visible.isEmpty
              ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Nenhuma pessoa encontrada. Tente outro filtro.')))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 18),
                  itemCount: visible.length,
                  itemBuilder: (context, i) => _profileCard(visible[i]),
                )),
        ]);
      },
    );
  }

  Widget _topTab(String label) {
    final selected = tab == label;
    return Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(
      label: Text(label), selected: selected,
      onSelected: (_) => setState(() => tab = label),
      selectedColor: _gold, backgroundColor: _panel,
      labelStyle: TextStyle(color: selected ? Colors.black : Colors.white70, fontWeight: FontWeight.w600),
      side: BorderSide(color: selected ? _gold : Colors.white12),
    ));
  }

  Widget _story(QueryDocumentSnapshot<Map<String, dynamic>>? doc, String name, {bool own = false}) {
    final p = doc?.data() ?? {};
    final photo = (p['photoUrl'] ?? '').toString();
    return GestureDetector(
      onTap: () {
        if (doc != null) Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id)));
        else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Publique uma foto no seu perfil para criar seu story.')));
      },
      child: SizedBox(width: 76, child: Column(children: [
        Container(width: 66, height: 66, padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: _gold, width: 2)),
          child: ClipOval(child: photo.isEmpty
            ? Container(color: _panel, child: Icon(own ? Icons.add : Icons.person, color: _gold, size: 30))
            : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                errorWidget: (_, __, ___) => const Icon(Icons.person, color: _gold)))),
        const SizedBox(height: 5),
        Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
      ])),
    );
  }

  int _calculateAge(DateTime birthday) {
    final now = DateTime.now();
    var age = now.year - birthday.year;
    if (now.month < birthday.month || (now.month == birthday.month && now.day < birthday.day)) age--;
    return age;
  }

  Widget _profileCard(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final p = doc.data();
    final birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
    final age = birthday == null ? '' : '${_calculateAge(birthday)} anos';
    final photo = (p['photoUrl'] ?? '').toString();
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    final place = city.isEmpty ? country : country.isEmpty ? city :
        (country.toLowerCase() == 'brasil' && city.contains('-') ? city : '$city • $country');
    final bio = (p['bio'] ?? '').toString().trim();

    return Card(
      color: _panel, margin: const EdgeInsets.only(bottom: 18), clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFF5A4823))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id))),
          child: Stack(children: [
            SizedBox(width: double.infinity, height: 430,
              child: photo.isEmpty
                ? Container(color: const Color(0xFF252016), child: const Icon(Icons.person, size: 110, color: Colors.white24))
                : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => Container(color: _panel, child: const Icon(Icons.person, size: 100))),
            ),
            Positioned(right: 14, top: 12, child: ProfileFrameAvatar(
              photoUrl: photo,
              frameId: (p['selectedProfileFrame'] ?? 'classic').toString(),
              size: 48,
            )),
            Positioned(left: 12, top: 12, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(30)),
              child: Row(children: [Icon(Icons.circle, size: 9, color: p['isOnline'] == true ? Colors.greenAccent : Colors.white38), const SizedBox(width: 6), Text(p['isOnline'] == true ? 'Online' : 'Perfil', style: const TextStyle(fontSize: 12))]),
            )),
            Positioned(left: 0, right: 0, bottom: 0, child: Container(
              padding: const EdgeInsets.fromLTRB(16, 42, 16, 14),
              decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87, Colors.black])),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(child: Text((p['name'] ?? 'Pessoa').toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold))),
                  if ((p['gender'] ?? '').toString() == 'woman') const Text(' ♀', style: TextStyle(color: _gold, fontSize: 19)),
                  if ((p['gender'] ?? '').toString() == 'man') const Text(' ♂', style: TextStyle(color: _gold, fontSize: 19)),
                ]),
                if (age.isNotEmpty || place.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text([if (age.isNotEmpty) age, if (place.isNotEmpty) place].join(' • '), style: const TextStyle(color: Colors.white70))),
                if (bio.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Text(bio, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white))),
              ]),
            )),
          ]),
        ),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8), child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _actionButton(Icons.close, Colors.white70, () async { await DataService.instance.pass(doc.id); }),
            _actionButton(Icons.favorite, Colors.pinkAccent, () async {
              try {
                final matched = await DataService.instance.like(doc.id);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(matched ? 'Deu match! 💛' : 'Curtida enviada!')));
              } catch (_) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar a curtida.')));
              }
            }, large: true),
            _actionButton(Icons.star, _gold, () async {
              try {
                await DataService.instance.like(doc.id);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Curtida especial enviada!')));
              } catch (_) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar.')));
              }
            }),
          ],
        )),
      ]),
    );
  }

  Widget _actionButton(IconData icon, Color color, VoidCallback onTap, {bool large = false}) =>
      IconButton.filledTonal(
        onPressed: onTap, icon: Icon(icon, color: color, size: large ? 29 : 23),
        style: IconButton.styleFrom(backgroundColor: const Color(0xFF292318), fixedSize: Size(large ? 58 : 48, large ? 58 : 48)),
      );
}
