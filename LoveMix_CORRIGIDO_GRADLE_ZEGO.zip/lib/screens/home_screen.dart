import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'discover_screen.dart';
import 'messages_screen.dart';
import 'profile_screen.dart';
import 'wallet_screen.dart';
import 'chat_rooms_screen.dart';
import 'ranking_screen.dart';
import 'resources_screen.dart';
import 'stories_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  static const panel = Color(0xFF171022);
  int index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    DataService.instance.setOnlineStatus(true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DataService.instance.setOnlineStatus(true);
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      DataService.instance.setOnlineStatus(false);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    DataService.instance.setOnlineStatus(false);
    super.dispose();
  }

  void open(int page) => setState(() => index = page);

  @override
  Widget build(BuildContext context) {
    final pages = [
      _LoveMixFeed(onDiscover: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()))),
      const ChatRoomsScreen(),
      const SizedBox.shrink(),
      const MessagesScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      appBar: index == 0 ? AppBar(
        title: const Row(mainAxisSize: MainAxisSize.min, children: [
          Text('LoveMix', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: pink, fontStyle: FontStyle.italic)),
          Text('💗', style: TextStyle(fontSize: 18)),
        ]),
        actions: [
          IconButton(tooltip: 'Recursos incríveis', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ResourcesScreen())), icon: const Icon(Icons.auto_awesome, color: Color(0xFFE45BFF))),
          IconButton(tooltip: 'Ranking', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RankingScreen())), icon: const Icon(Icons.emoji_events, color: Color(0xFFFFD65C))),
          IconButton(tooltip: 'Notificações', onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Você está em dia com suas novidades!'))), icon: const Icon(Icons.notifications_none)),
          const SizedBox(width: 4),
        ],
      ) : null,
      body: IndexedStack(index: index == 2 ? 0 : index, children: [
        pages[0], pages[1], const SizedBox.shrink(), pages[3], pages[4],
      ]),
            bottomNavigationBar: NavigationBar(
        height: 68,
        backgroundColor: const Color(0xFF100A19),
        indicatorColor: const Color(0xFF49205F),
        selectedIndex: index,
        onDestinationSelected: (v) {
          if (v == 2) {
            _createRoom(context);
          } else {
            open(v);
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: pink), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), selectedIcon: Icon(Icons.graphic_eq, color: pink), label: 'Salas'),
          NavigationDestination(icon: Icon(Icons.add_circle, color: pink, size: 34), label: ''),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble, color: pink), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: pink), label: 'Perfil'),
        ],
      ),
    );
  }

  Future<void> _createRoom(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();
    final password = TextEditingController();
    bool isPublic = true;
    String category = 'Amizades';
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context, isScrollControlled: true, backgroundColor: panel,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Criar sua sala 👑', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: name, maxLength: 40, decoration: const InputDecoration(hintText: 'Nome da sala')),
          TextField(controller: description, maxLength: 120, decoration: const InputDecoration(hintText: 'Descrição (opcional)')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'Categoria'),
            items: const ['Amizades', 'Namoro', 'Música', 'Jogos', 'Conversas'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) { if (v != null) setSheet(() => category = v); },
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: isPublic,
            activeColor: pink,
            title: Text(isPublic ? 'Sala pública' : 'Sala privada'),
            subtitle: Text(isPublic ? 'Qualquer pessoa pode entrar' : 'Sala privada, não aparece na lista pública'),
            onChanged: (v) => setSheet(() => isPublic = v),
          ),
          if (!isPublic) ...[
            const SizedBox(height: 8),
            TextField(controller: password, obscureText: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Senha da sala', hintText: 'Crie uma senha para compartilhar')),
          ],
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(ctx, {
            'name': name.text.trim(), 'description': description.text.trim(),
            'category': category, 'isPublic': isPublic, 'password': password.text.trim(),
          }), child: const Text('Criar Sala ✨'))),
        ]),
      )),
    );
    if (result == null || (result['name'] as String).isEmpty) return;
    try {
      final roomName = result['name'] as String;
      final id = await DataService.instance.createRoom(
        roomName,
        isPublic: result['isPublic'] as bool,
        category: result['category'] as String,
        description: result['description'] as String,
        password: result['password'] as String,
      );
      if (!mounted) return;
      open(1);
      Navigator.push(context, MaterialPageRoute(builder: (_) => RoomChatScreen(roomId: id, roomName: roomName)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
}

class _LoveMixFeed extends StatelessWidget {
  const _LoveMixFeed({required this.onDiscover});
  final VoidCallback onDiscover;
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.only(bottom: 22),
    children: [
      const StoriesStrip(),
      const Padding(padding: EdgeInsets.fromLTRB(16, 5, 16, 10), child: Row(children: [
        Text('Salas em Destaque 🔥', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        Spacer(), Text('AO VIVO', style: TextStyle(color: pink, fontSize: 11, fontWeight: FontWeight.w900)),
      ])),
      StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
        stream: DataService.instance.publicRooms(),
        builder: (context, snap) {
          if (!snap.hasData) return const SizedBox(height: 130, child: Center(child: CircularProgressIndicator(color: pink)));
          final rooms = snap.data!.docs;
          if (rooms.isEmpty) return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: _featured('Resenha da Noite 💜', 'Seja a primeira pessoa a criar uma sala', '🎙️', 'Criar', () => _goRooms(context)),
          );
          return Column(children: rooms.take(3).map((doc) {
            final room = doc.data();
            final members = List<String>.from(room['members'] ?? []);
            return Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
              child: _featured((room['name'] ?? 'Sala LoveMix').toString(),
                '${members.length} pessoas na sala', '🎧', 'Entrar', () async {
                  try {
                    if (!members.contains(DataService.instance.uid)) await DataService.instance.joinRoom(doc.id);
                    if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => RoomChatScreen(roomId: doc.id, roomName: (room['name'] ?? 'Sala').toString())));
                  } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'))); }
                }),
            );
          }).toList());
        },
      ),
      const Padding(padding: EdgeInsets.fromLTRB(16, 9, 16, 10), child: Row(children: [
        Text('Categorias', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        Spacer(), Text('Explore', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(children: [
        _category('💗', 'Namoro', () => _goDiscover(context)),
        _category('👥', 'Amizades', () => _goDiscover(context)),
        _category('🎮', 'Jogos', () => _goRooms(context)),
        _category('🎵', 'Música', () => _goRooms(context)),
      ])),
      const SizedBox(height: 16),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Container(
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF351052), Color(0xFF171022)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: purple)),
        child: ListTile(
          leading: const Icon(Icons.people_alt, color: pink, size: 30),
          title: const Text('Conheça pessoas do mundo todo', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: const Text('Descubra perfis, curta e faça novas conexões', style: TextStyle(color: Colors.white70, fontSize: 11)),
          trailing: const Icon(Icons.arrow_forward_ios, color: pink, size: 16),
          onTap: onDiscover,
        ),
      )),
      const SizedBox(height: 14),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Row(children: [
        Expanded(child: _quick('🏆', 'Ranking', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RankingScreen())))),
        const SizedBox(width: 10),
        Expanded(child: _quick('🎁', 'Presentes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())))),
      ])),
    ],
  );

  static Widget _story(String name, String url, {bool own = false}) => Container(
    width: 72, margin: const EdgeInsets.symmetric(horizontal: 5), child: Column(children: [
      Container(width: 64, height: 64, padding: const EdgeInsets.all(2), decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: pink, width: 2), gradient: const LinearGradient(colors: [pink, purple])),
        child: CircleAvatar(backgroundColor: const Color(0xFF241333), backgroundImage: url.isNotEmpty ? NetworkImage(url) : null, child: url.isEmpty ? Icon(own ? Icons.add : Icons.person, color: Colors.white) : null)),
      const SizedBox(height: 4), Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
    ]),
  );

  static Widget _featured(String title, String subtitle, String emoji, String action, VoidCallback onTap) => Container(
    height: 112, decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF33105D), Color(0xFF101426), Color(0xFF4B0755)]),
      border: Border.all(color: purple.withOpacity(.8)),
    ),
    child: Stack(children: [
      Positioned(right: 18, top: 14, child: Text(emoji, style: const TextStyle(fontSize: 46))),
      Positioned(left: 14, top: 12, child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: pink, borderRadius: BorderRadius.circular(20)), child: const Text('● AO VIVO', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900)))),
      Positioned(left: 14, bottom: 13, right: 12, child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
          Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ])),
        FilledButton(onPressed: onTap, style: FilledButton.styleFrom(backgroundColor: pink, padding: const EdgeInsets.symmetric(horizontal: 18)), child: Text(action)),
      ])),
    ]),
  );

  static Widget _category(String emoji, String label, VoidCallback onTap) => Expanded(child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(
      height: 78, decoration: BoxDecoration(color: const Color(0xFF1C1229), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF3C2456))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 25)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]),
    )),
  ));

  static Widget _quick(String emoji, String title, VoidCallback onTap) => InkWell(onTap: onTap, child: Container(
    padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: const Color(0xFF1A1028), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF4C2869))),
    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 22)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
  ));

  static void _goDiscover(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()));
  static void _goRooms(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RoomsRoute()));
}

class _DiscoverRoute extends StatelessWidget {
  const _DiscoverRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Descobrir pessoas')), body: DiscoverScreen());
}
class _RoomsRoute extends StatelessWidget {
  const _RoomsRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Salas LoveMix')), body: ChatRoomsScreen());
}
