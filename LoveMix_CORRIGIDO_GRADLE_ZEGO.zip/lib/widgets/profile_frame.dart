import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class ProfileFrameAvatar extends StatelessWidget {
  const ProfileFrameAvatar({super.key, required this.photoUrl, required this.frameId, this.size = 86});
  final String photoUrl;
  final String frameId;
  final double size;

  @override
  Widget build(BuildContext context) {
    final colors = _colors(frameId);
    final isDefault = frameId.isEmpty || frameId == 'classic';
    return Container(
      width: size + (isDefault ? 0 : 12),
      height: size + (isDefault ? 0 : 12),
      padding: EdgeInsets.all(isDefault ? 0 : 5),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: isDefault ? null : LinearGradient(colors: colors),
        border: isDefault ? Border.all(color: Colors.white24, width: 1.5) : null,
        boxShadow: isDefault ? null : [BoxShadow(color: colors.first.withOpacity(.42), blurRadius: 13, spreadRadius: 1)],
      ),
      child: Stack(alignment: Alignment.center, children: [
        ClipOval(
          child: SizedBox(
            width: size,
            height: size,
            child: photoUrl.isEmpty
                ? Container(color: const Color(0xFF21132E), child: const Icon(Icons.person, color: Colors.white70, size: 42))
                : CachedNetworkImage(
                    imageUrl: photoUrl,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => Container(color: const Color(0xFF21132E)),
                    errorWidget: (_, __, ___) => Container(color: const Color(0xFF21132E), child: const Icon(Icons.person, color: Colors.white70, size: 42)),
                  ),
          ),
        ),
        if (frameId == 'hearts')
          const Positioned(top: 0, right: 2, child: Text('♥', style: TextStyle(color: Colors.white, fontSize: 16, shadows: [Shadow(color: Colors.pink, blurRadius: 7)]))),
        if (frameId == 'gold')
          const Positioned(top: -1, child: Icon(Icons.workspace_premium, color: Color(0xFFFFD56A), size: 23)),
        if (frameId == 'cosmic')
          const Positioned(bottom: -1, right: 0, child: Icon(Icons.auto_awesome, color: Colors.white, size: 18)),
      ]),
    );
  }

  static List<Color> _colors(String id) {
    switch (id) {
      case 'neon': return const [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFF35D7FF)];
      case 'hearts': return const [Color(0xFFFF5A9E), Color(0xFFFF19B8), Color(0xFFFFB0D2)];
      case 'gold': return const [Color(0xFFFFE08A), Color(0xFFB87918), Color(0xFFFFF0B5)];
      case 'cosmic': return const [Color(0xFF39D9FF), Color(0xFF8D35FF), Color(0xFFFF19B8)];
      default: return const [Color(0xFF8D35FF), Color(0xFFFF19B8)];
    }
  }
}
