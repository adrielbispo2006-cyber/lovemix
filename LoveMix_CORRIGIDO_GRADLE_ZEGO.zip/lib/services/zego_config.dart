/// Configuração ZEGOCLOUD do LoveMix.
/// Para produção, migre AppSign para autenticação por token emitido no servidor.
class ZegoConfig {
  static const int appId = 2116602891;
  static const String appSign =
      '7f6e3bdeeea14e029ce86e6f5110cafd59ac32041a79fd8108f56fc154499fff';
}
