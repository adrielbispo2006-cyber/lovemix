import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';
import 'package:flutter/material.dart';
import 'app.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LoveMixBootstrap());
}

/// Inicializa o Firebase depois de montar a interface. Assim, uma falha de
/// configuração não deixa o usuário olhando para uma tela preta sem explicação.
class LoveMixBootstrap extends StatefulWidget {
  const LoveMixBootstrap({super.key});

  @override
  State<LoveMixBootstrap> createState() => _LoveMixBootstrapState();
}

class _LoveMixBootstrapState extends State<LoveMixBootstrap> {
  Object? _startupError;
  bool _ready = false;
  bool _starting = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    if (_starting) return;
    setState(() {
      _starting = true;
      _startupError = null;
    });

    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      }

      FirebaseAuth.instance.authStateChanges().listen((user) {
        if (user != null) {
          // Notificações são opcionais para abrir o app. Uma falha nelas
          // não deve impedir a exibição das telas principais.
          NotificationService.instance.initializeForUser(user).catchError((_) {});
        }
      });

      if (!mounted) return;
      setState(() {
        _ready = true;
        _starting = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _startupError = error;
        _starting = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return const LoveMixApp();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: Scaffold(
        backgroundColor: const Color(0xFF090806),
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: _startupError == null
                  ? const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.favorite, color: Color(0xFFFF2DAB), size: 64),
                        SizedBox(height: 16),
                        Text(
                          'LoveMix',
                          style: TextStyle(
                            color: Color(0xFFFF2DAB),
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        CircularProgressIndicator(color: Color(0xFFFF2DAB)),
                        SizedBox(height: 12),
                        Text('Iniciando aplicativo...', textAlign: TextAlign.center),
                      ],
                    )
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.warning_amber_rounded,
                            color: Color(0xFFFF2DAB), size: 56),
                        const SizedBox(height: 16),
                        const Text(
                          'Não foi possível iniciar o LoveMix',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Color(0xFFFF2DAB),
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'O Firebase não conseguiu inicializar. Confira a configuração do aplicativo Android e tente novamente.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        SelectableText(
                          _startupError.toString(),
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70, fontSize: 12),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: _starting ? null : _initialize,
                          child: const Text('Tentar novamente'),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
