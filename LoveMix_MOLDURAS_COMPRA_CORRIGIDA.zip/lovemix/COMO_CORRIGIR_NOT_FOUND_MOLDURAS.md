# Corrigir NOT_FOUND na compra de molduras

O aplicativo chama a Cloud Function `purchaseProfileFrame`, implementada em `functions/src/index.ts`, que valida o saldo no servidor e grava a moldura no inventário. O erro `NOT_FOUND` normalmente aparece quando essa função ainda não foi publicada no projeto Firebase, ou quando o documento `users/{uid}` não existe.

## Publicar pelo GitHub Actions

1. No Firebase Console do projeto `lovemix-73849`, abra Configurações do projeto > Contas de serviço e gere uma chave privada para uma conta de serviço com permissão de implantação de Cloud Functions.
2. No GitHub, abra o repositório do LoveMix > Settings > Secrets and variables > Actions.
3. Crie o secret `FIREBASE_SERVICE_ACCOUNT_LOVEMIX_73849` e cole o JSON inteiro da chave. Não compartilhe esse JSON no chat nem no código.
4. Abra Actions > **Publicar compra de molduras LoveMix** > Run workflow.
5. Aguarde o workflow terminar com sucesso. Ele publica apenas `purchaseProfileFrame` no projeto `lovemix-73849`.
6. Gere e instale um APK novo para usar as novas molduras e mensagens de erro mais claras.

## Compra segura

- A função valida a autenticação, verifica o saldo e desconta moedas/diamantes em uma transação do Firestore.
- O aplicativo não desconta saldo localmente e não concede molduras pagas sem validação do servidor.
- A função usa a região `us-central1`, igual à chamada feita pelo aplicativo.
- Se continuar aparecendo `Perfil não encontrado`, confira se existe `users/{UID atual}` no Firestore. Não crie o saldo manualmente para contornar a validação.

As seis novas molduras VIP adicionadas são Borboleta Real, Rosa de Ouro, Celestial VIP, Asas da Realeza, Coroa de Diamantes e LoveMix Deluxe. Os preços são conferidos tanto no catálogo do aplicativo quanto na Cloud Function.
