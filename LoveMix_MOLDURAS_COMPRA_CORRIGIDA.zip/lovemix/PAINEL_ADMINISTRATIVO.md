# Painel administrativo LoveMix

Esta atualização adiciona um painel administrativo protegido por Firebase Authentication custom claim `admin`.

## O que foi adicionado
- A tela de perfil reconhece a claim `admin` e mostra o botão do painel.
- O painel consulta usuários por Cloud Function, sem liberar leitura administrativa diretamente no aplicativo.
- Ações administrativas no servidor permitem adicionar/remover moedas e conceder/remover VIP.
- As alterações são registradas em `adminAuditLogs`.

## Publicação necessária
1. Confirme no Firebase Authentication que a conta correta tem a custom claim `admin: true`.
2. Na pasta `functions`, instale dependências e compile: `npm install` e `npm run build`.
3. Na raiz do projeto, publique as funções: `firebase deploy --only functions:adminListLoveMixUsers,functions:adminUpdateLoveMixUser`.
4. Gere e instale uma nova versão Android do aplicativo.

A conta precisa atualizar o token após a claim ser concedida (sair e entrar novamente também funciona). As funções verificam a claim no servidor; esconder o botão no aplicativo não é usado como proteção.

**Importante:** não inclua `service-account.json`, chaves privadas ou segredos da AbacatePay no ZIP do aplicativo. Guarde credenciais administrativas apenas em ambiente seguro. A ativação no projeto Firebase real depende da publicação das funções e da confirmação da claim na conta correta.
