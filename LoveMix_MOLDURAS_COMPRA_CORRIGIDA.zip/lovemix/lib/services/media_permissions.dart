import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

/// Solicita permissao em runtime antes de inicializar/entrar no Zego.
class MediaPermissions {
  static Future<bool> request(
    BuildContext context, {
    bool camera = false,
    bool microphone = true,
  }) async {
    final permissions = <Permission>[
      if (camera) Permission.camera,
      if (microphone) Permission.microphone,
    ];
    if (permissions.isEmpty) return true;

    var result = await permissions.request();
    if (result.values.every((status) => status.isGranted)) return true;
    if (!context.mounted) return false;

    final permanentlyBlocked = result.values.any(
      (status) => status.isPermanentlyDenied || status.isRestricted,
    );
    final requested = [
      if (camera) 'camera',
      if (microphone) 'microfone',
    ].join(' e ');

    final openSettings = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Permissao necessaria'),
        content: Text(
          permanentlyBlocked
              ? 'Libere o acesso a $requested nas configuracoes do Android para usar esta funcao.'
              : 'O LoveMix precisa de acesso a $requested para continuar.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Agora nao'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(permanentlyBlocked ? 'Abrir configuracoes' : 'Tentar novamente'),
          ),
        ],
      ),
    );
    if (openSettings != true || !context.mounted) return false;

    if (permanentlyBlocked) {
      await openAppSettings();
      for (final permission in permissions) {
        final status = await permission.status;
        if (!status.isGranted) return false;
      }
      return true;
    }

    result = await permissions.request();
    return result.values.every((status) => status.isGranted);
  }
}
