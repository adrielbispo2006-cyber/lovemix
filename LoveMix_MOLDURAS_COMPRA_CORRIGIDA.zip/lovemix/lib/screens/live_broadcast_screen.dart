import 'dart:async';
import 'dart:math' as math;
import '../data/gift_catalog.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:zego_uikit/zego_uikit.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zego_uikit_prebuilt_live_audio_room/zego_uikit_prebuilt_live_audio_room.dart';

import '../services/data_service.dart';
import '../services/zego_config.dart';
import '../services/media_permissions.dart';

/// Tela de live no padrão de celular:
/// topo com AO VIVO + espectadores + convidar + fechar; vídeo ocupando a tela
/// (live em dupla empilha o convidado em cima); comentários em balões na
/// esquerda; embaixo a barra de comentário e os ícones de coração, curtida e presente.
class LiveBroadcastScreen extends StatefulWidget {
  const LiveBroadcastScreen({super.key, required this.roomId, required this.roomName});
  final String roomId;
  final String roomName;

  @override
  State<LiveBroadcastScreen> createState() => _LiveBroadcastScreenState();
}

class _Heart {
  _Heart(this.id, this.emoji, this.dx);
  final int id;
  final String emoji;
  final double dx;
}

class _LiveBroadcastScreenState extends State<LiveBroadcastScreen> {
  static const pink = Color(0xFFFF2DAB);

  static const gifts = kRoomGifts;

  final _input = TextEditingController();
  final _focus = FocusNode();
  final Map<String, Future<Map<String, dynamic>>> _users = {};
  final List<_Heart> _hearts = [];
  final math.Random _rnd = math.Random();

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _reactSub;
  List<Map<String, dynamic>> _people = [];
  bool _firstReactionSnapshot = true;
  bool _isHost = false;
  String _ownerId = '';
  bool _voiceReady = false;
  bool _roomMembershipReady = false;
  bool _publishing = false;
  bool _micOn = true;
  bool _frontCamera = true;
  bool _left = false;
  bool _inviteDialogOpen = false;
  bool _endedHandled = false;
  int _heartSeq = 0;
  DateTime _lastReact = DateTime.fromMillisecondsSinceEpoch(0);
  String _myName = 'LoveMix';
  String? _enterError;

  String get _myUid => DataService.instance.uid;
  String _zegoId(String uid) => uid.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '_');

  CollectionReference<Map<String, dynamic>> get _guests =>
      FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).collection('guests');
  CollectionReference<Map<String, dynamic>> get _reactions =>
      FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).collection('reactions');

  @override
  void initState() {
    super.initState();
    _enter();
  }

  @override
  void dispose() {
    _reactSub?.cancel();
    _input.dispose();
    _focus.dispose();
    if (!_left) _cleanup(endIfHost: false);
    super.dispose();
  }

  // ---------------------------------------------------------------- entrada

  Future<void> _enter() async {
    try {
      final identity = await DataService.instance.liveIdentityDefaults();
      _myName = identity['displayName']!;
      await DataService.instance.joinRoom(widget.roomId);
      _roomMembershipReady = true;
      final room = await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).get();
      _ownerId = (room.data()?['ownerId'] ?? '').toString();
      _isHost = _ownerId == _myUid;
      await DataService.instance.registerLiveParticipant(
        roomId: widget.roomId,
        publicId: identity['publicId']!,
        displayName: _myName,
      );
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) {
        setState(() => _enterError = e.toString().replaceFirst('Exception: ', ''));
      }
      return;
    }
    _listenReactions();
    await _initVideo();
  }

  Future<void> _initVideo() async {
    // O anfitriao libera CAMERA e RECORD_AUDIO antes do login/join no Zego.
    // Espectadores nao precisam dessas permissoes para apenas assistir.
    if (_isHost) {
      if (!mounted) return;
      final allowed = await MediaPermissions.request(
        context,
        camera: true,
        microphone: true,
      );
      if (!allowed || !mounted) {
        if (mounted) _snack('Permita camera e microfone para iniciar a transmissao.');
        return;
      }
    }
    try {
      await ZegoUIKit.instance.init(appID: ZegoConfig.appId, appSign: ZegoConfig.appSign);
      ZegoUIKit.instance.login(_zegoId(_myUid), _myName);
      await ZegoUIKit.instance.joinRoom(widget.roomId);
      if (mounted) setState(() => _voiceReady = true);
      if (_isHost) await _startPublishing();
    } catch (e) {
      debugPrint('Falha ao iniciar a live: $e');
    }
  }

  Future<bool> _startPublishing() async {
    final cam = await Permission.camera.request();
    final mic = await Permission.microphone.request();
    if (!cam.isGranted || !mic.isGranted) {
      _snack('Permita câmera e microfone nas configurações do celular.');
      return false;
    }
    try {
      await ZegoUIKit.instance.useFrontFacingCamera(true);
      ZegoUIKit.instance.turnCameraOn(true);
      ZegoUIKit.instance.turnMicrophoneOn(true);
      if (mounted) {
        setState(() {
          _publishing = true;
          _micOn = true;
          _frontCamera = true;
        });
      }
      return true;
    } catch (e) {
      debugPrint('Falha ao publicar vídeo: $e');
      return false;
    }
  }

  Future<void> _stopPublishing() async {
    try {
      ZegoUIKit.instance.turnCameraOn(false);
      ZegoUIKit.instance.turnMicrophoneOn(false);
    } catch (_) {}
    if (mounted) setState(() => _publishing = false);
  }

  Future<void> _cleanup({required bool endIfHost}) async {
    _reactSub?.cancel();
    try {
      ZegoUIKit.instance.turnCameraOn(false);
      ZegoUIKit.instance.turnMicrophoneOn(false);
      await ZegoUIKit.instance.leaveRoom();
    } catch (_) {}
    try {
      await DataService.instance.leaveLiveParticipant(widget.roomId);
    } catch (_) {}
    if (!_isHost) {
      try {
        final mine = await _guests.doc(_myUid).get();
        if (mine.exists && mine.data()?['status'] == 'accepted') {
          await _guests.doc(_myUid).update({'status': 'left'});
        }
      } catch (_) {}
    }
    if (endIfHost) {
      try {
        await DataService.instance.endLiveRoom(widget.roomId);
      } catch (_) {}
    }
  }

  Future<void> _leave() async {
    if (_left) return;
    _left = true;
    await _cleanup(endIfHost: _isHost);
  }

  Future<void> _close() async {
    if (_isHost) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF21132F),
          title: const Text('Encerrar live?'),
          content: const Text('A transmissão termina para todos que estão assistindo.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Continuar')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE53935)),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Encerrar'),
            ),
          ],
        ),
      );
      if (ok != true) return;
    }
    await _leave();
    if (mounted) Navigator.pop(context);
  }

  // ---------------------------------------------------------------- helpers

  Future<Map<String, dynamic>> _user(String id) => _users.putIfAbsent(id, () async {
        try {
          final snap = await FirebaseFirestore.instance.collection('users').doc(id).get();
          return snap.data() ?? <String, dynamic>{};
        } catch (_) {
          return <String, dynamic>{};
        }
      });

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  String _clean(Object e) {
    if (e is FirebaseFunctionsException) return e.message ?? 'Algo deu errado.';
    return e.toString().replaceFirst('Exception: ', '');
  }

  // ------------------------------------------------------------- reações

  void _listenReactions() {
    _reactSub = _reactions
        .orderBy('createdAt', descending: true)
        .limit(15)
        .snapshots()
        .listen((snap) {
      if (_firstReactionSnapshot) {
        _firstReactionSnapshot = false;
        return;
      }
      for (final change in snap.docChanges) {
        if (change.type != DocumentChangeType.added) continue;
        final d = change.doc.data();
        if (d == null || d['uid'] == _myUid) continue;
        _spawnHeart(d['type'] == 'like' ? '👍' : '❤️');
      }
    }, onError: (_) {});
  }

  void _spawnHeart(String emoji) {
    if (!mounted) return;
    setState(() {
      _hearts.add(_Heart(_heartSeq++, emoji, _rnd.nextDouble() * 46));
      if (_hearts.length > 30) _hearts.removeAt(0);
    });
  }

  Future<void> _react(String type) async {
    _spawnHeart(type == 'like' ? '👍' : '❤️');
    final now = DateTime.now();
    if (now.difference(_lastReact).inMilliseconds < 400) return; // evita spam no banco
    _lastReact = now;
    try {
      await _reactions.add({
        'uid': _myUid,
        'type': type,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  // ------------------------------------------------------------ comentários

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    _input.clear();
    try {
      await DataService.instance.sendRoomMessage(widget.roomId, text);
    } catch (e) {
      _snack('Não foi possível enviar: ${_clean(e)}');
    }
  }

  // ----------------------------------------------------------------- convites

  Future<void> _openInvite(Map<String, dynamic>? activeGuest) async {
    if (activeGuest != null) {
      final name = (activeGuest['name'] ?? 'convidado').toString();
      final remove = await showModalBottomSheet<bool>(
        context: context,
        backgroundColor: const Color(0xFF1B1028),
        builder: (ctx) => SafeArea(
          child: ListTile(
            leading: const Icon(Icons.person_remove, color: Color(0xFFFF5C8A)),
            title: Text('Remover $name da live'),
            onTap: () => Navigator.pop(ctx, true),
          ),
        ),
      );
      if (remove == true) {
        try {
          await _guests.doc(activeGuest['uid'].toString()).set({
            'uid': activeGuest['uid'],
            'status': 'ended',
            'invitedAt': FieldValue.serverTimestamp(),
          });
        } catch (e) {
          _snack(_clean(e));
        }
      }
      return;
    }

    final candidates = _people.where((p) => p['uid'] != _myUid).toList();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF160D22),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(ctx).size.height * .55,
          child: Column(children: [
            const SizedBox(height: 14),
            const Text('Convidar para a live',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            const Text('Quem aceitar aparece no vídeo ao lado de você',
                style: TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 8),
            Expanded(
              child: candidates.isEmpty
                  ? const Center(
                      child: Text('Ninguém está assistindo ainda.',
                          style: TextStyle(color: Colors.white54)))
                  : ListView.builder(
                      itemCount: candidates.length,
                      itemBuilder: (_, i) {
                        final p = candidates[i];
                        final id = p['uid'].toString();
                        return ListTile(
                          leading: const CircleAvatar(
                            backgroundColor: Color(0xFF7027A5),
                            child: Icon(Icons.person, color: Colors.white)),
                          title: Text((p['displayName'] ?? 'Pessoa').toString()),
                          subtitle: Text((p['publicId'] ?? '').toString(),
                              style: const TextStyle(fontSize: 11, color: Colors.white54)),
                          trailing: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: pink),
                            onPressed: () async {
                              Navigator.pop(ctx);
                              try {
                                await _guests.doc(id).set({
                                  'uid': id,
                                  'status': 'invited',
                                  'invitedAt': FieldValue.serverTimestamp(),
                                });
                                _snack('Convite enviado para ${p['displayName'] ?? 'a pessoa'}.');
                              } catch (e) {
                                _snack('Não foi possível convidar: ${_clean(e)}');
                              }
                            },
                            child: const Text('Convidar', style: TextStyle(color: Colors.white)),
                          ),
                        );
                      },
                    ),
            ),
          ]),
        ),
      ),
    );
  }

  void _showInviteDialog() {
    if (_inviteDialogOpen) return;
    _inviteDialogOpen = true;
    showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF21132F),
        title: const Text('Você foi convidado! 🎥'),
        content: const Text('O anfitrião quer você ao vivo com ele. Câmera e microfone serão ligados.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Agora não')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: pink),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Entrar na live', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    ).then((accepted) async {
      _inviteDialogOpen = false;
      try {
        if (accepted == true) {
          final ok = await _startPublishing();
          await _guests.doc(_myUid).update({'status': ok ? 'accepted' : 'declined'});
        } else {
          await _guests.doc(_myUid).update({'status': 'declined'});
        }
      } catch (e) {
        _snack(_clean(e));
      }
    });
  }

  // Mantém câmera/microfone coerentes com o status do meu convite.
  void _syncGuestState(String? myStatus) {
    if (_isHost) return;
    if (myStatus == 'invited' && !_inviteDialogOpen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showInviteDialog();
      });
    }
    if (myStatus != 'accepted' && _publishing) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _stopPublishing());
    }
    if (myStatus != 'invited' && _inviteDialogOpen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _inviteDialogOpen) {
          Navigator.of(context, rootNavigator: true).maybePop();
        }
      });
    }
  }

  // ---------------------------------------------------------------- presentes

  Future<void> _openGifts() async {
    final targets = _people.where((p) => p['uid'] != _myUid || (_myUid == _ownerId)).toList()
      ..sort((a, b) =>
          (a['uid'] == _ownerId ? 0 : 1).compareTo(b['uid'] == _ownerId ? 0 : 1));
    if (targets.isEmpty) {
      _snack('Ainda não há ninguém para receber presentes.');
      return;
    }
    String recipient = targets.first['uid'].toString();
    Map<String, dynamic> chosen = gifts[0];

    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: DataService.instance.myProfile(),
          builder: (ctx, profileSnap) {
            final profile = profileSnap.data?.data() ?? <String, dynamic>{};
            final coins = (profile['coins'] as num?)?.toInt() ?? 0;
            final diamonds = (profile['diamonds'] as num?)?.toInt() ?? 0;
            final balance = chosen['currency'] == 'coins' ? coins : diamonds;
            final canAfford = balance >= (chosen['cost'] as int);
            return SafeArea(
              child: Container(
                height: MediaQuery.of(ctx).size.height * .72,
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                decoration: const BoxDecoration(
                  color: Color(0xFF160D22),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                  border: Border(top: BorderSide(color: Color(0xFFFF4FCB), width: 1.5)),
                ),
                child: Column(children: [
                  Container(
                    width: 42, height: 4,
                    decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(8)),
                  ),
                  const SizedBox(height: 12),
                  const Text('LOVEMIX PRESENTES',
                      style: TextStyle(color: Color(0xFFFF65D5), fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 38,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: targets.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) {
                        final id = targets[i]['uid'].toString();
                        final name = (targets[i]['displayName'] ?? 'Pessoa').toString();
                        return ChoiceChip(
                          selected: id == recipient,
                          selectedColor: const Color(0xFF63258D),
                          backgroundColor: const Color(0xFF281638),
                          label: Text(id == _myUid ? '👑 Você' : (id == _ownerId ? '🎥 $name' : name),
                              style: const TextStyle(color: Colors.white, fontSize: 12)),
                          onSelected: (_) => setSheet(() => recipient = id),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text('🪙 $coins moedas   💎 $diamonds diamantes',
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  const SizedBox(height: 10),
                  Expanded(
                    child: GridView.builder(
                      itemCount: gifts.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: .94),
                      itemBuilder: (_, i) {
                        final g = gifts[i];
                        final active = g['id'] == chosen['id'];
                        return InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => setSheet(() => chosen = g),
                          child: Container(
                            decoration: BoxDecoration(
                              color: active ? const Color(0xFF4A1B60) : const Color(0xFF261633),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: active ? const Color(0xFFFF55C9) : const Color(0xFF58356A),
                                width: active ? 2 : 1),
                            ),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Text(g['emoji'] as String, style: const TextStyle(fontSize: 32)),
                              const SizedBox(height: 4),
                              Text(g['name'] as String,
                                  maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 3),
                              Text('${g['cost']} ${g['currency'] == 'coins' ? '🪙' : '💎'}',
                                  style: const TextStyle(color: Color(0xFFFFD66B), fontSize: 10, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    width: double.infinity, height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: canAfford ? pink : Colors.white24,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: canAfford
                          ? () => Navigator.pop(ctx, {'gift': chosen, 'recipient': recipient})
                          : null,
                      child: Text(
                        canAfford ? 'Enviar ${chosen['emoji']} ${chosen['name']}' : 'Saldo insuficiente',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    );
    if (picked == null) return;
    final gift = picked['gift'] as Map<String, dynamic>;
    try {
      await DataService.instance.sendRoomGift(
        widget.roomId,
        picked['recipient'].toString(),
        gift['id'] as String,
        gift['emoji'] as String,
        gift['name'] as String,
      );
    } catch (e) {
      _snack(_clean(e));
    }
  }

  // ------------------------------------------------------------------ vídeo

  Widget _videoTile(String uid, String label) {
    final isMe = uid == _myUid;
    return StreamBuilder<List<ZegoUIKitUser>>(
      stream: ZegoUIKit.instance.getUserListStream(),
      builder: (context, _) {
        final user = isMe
            ? ZegoUIKit.instance.getLocalUser()
            : ZegoUIKit.instance.getUser(_zegoId(uid));
        Widget content;
        if (!_voiceReady || user.id.isEmpty) {
          content = const Center(child: CircularProgressIndicator(color: pink));
        } else {
          content = ZegoAudioVideoView(user: user);
        }
        return Stack(fit: StackFit.expand, children: [
          Container(color: const Color(0xFF0B0418), child: content),
          Positioned(
            left: 12, bottom: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.black45, borderRadius: BorderRadius.circular(10)),
              child: Text(label,
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
            ),
          ),
        ]);
      },
    );
  }

  Widget _videoLayer(Map<String, dynamic>? acceptedGuest) {
    final hostLabel = _isHost ? 'Você' : 'Anfitrião';
    if (acceptedGuest == null) {
      return _ownerId.isEmpty
          ? const Center(child: CircularProgressIndicator(color: pink))
          : _videoTile(_ownerId, hostLabel);
    }
    // Live em dupla: convidado empilhado em cima, anfitrião embaixo.
    final guestId = acceptedGuest['uid'].toString();
    final guestLabel = guestId == _myUid ? 'Você' : (acceptedGuest['name'] ?? 'Convidado').toString();
    return Column(children: [
      Expanded(child: _videoTile(guestId, guestLabel)),
      Container(height: 2, color: pink),
      Expanded(child: _videoTile(_ownerId, hostLabel)),
    ]);
  }

  // ---------------------------------------------------------------- partes UI

  Future<void> _manageLiveParticipants() async {
    if (!_isHost) return;
    final roomSnap = await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).get();
    final admins = List<String>.from(roomSnap.data()?['roomAdmins'] ?? const []);
    final people = _people.where((p) => (p['uid'] ?? '').toString() != _myUid).toList();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF1B1028), isScrollControlled: true,
      builder: (ctx) => SafeArea(child: SizedBox(height: MediaQuery.of(ctx).size.height * .62,
        child: Column(children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('Gerenciar participantes',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
          Expanded(child: people.isEmpty
            ? const Center(child: Text('Nenhum participante para gerenciar.', style: TextStyle(color: Colors.white70)))
            : ListView.builder(itemCount: people.length, itemBuilder: (_, i) {
              final person = people[i]; final id = (person['uid'] ?? '').toString();
              final name = (person['displayName'] ?? 'Participante').toString();
              final isAdmin = admins.contains(id);
              return ListTile(
                title: Text(name, style: const TextStyle(color: Colors.white)),
                subtitle: Text(isAdmin ? 'Administrador da sala' : 'Espectador', style: const TextStyle(color: Colors.white60)),
                trailing: PopupMenuButton<String>(
                  color: const Color(0xFF30203F),
                  onSelected: (action) async {
                    Navigator.pop(ctx);
                    try {
                      if (action == 'admin') {
                        await DataService.instance.setRoomAdmin(widget.roomId, id, !isAdmin);
                        _snack(isAdmin ? '$name não é mais administrador.' : '$name agora é administrador.');
                      } else {
                        final ok = await showDialog<bool>(context: context, builder: (dctx) => AlertDialog(
                          backgroundColor: const Color(0xFF241331),
                          title: const Text('Expulsar participante?', style: TextStyle(color: Colors.white)),
                          content: Text('Deseja remover $name desta live?', style: const TextStyle(color: Colors.white70)),
                          actions: [TextButton(onPressed: () => Navigator.pop(dctx, false), child: const Text('Cancelar')),
                            TextButton(onPressed: () => Navigator.pop(dctx, true), child: const Text('Expulsar'))],
                        ));
                        if (ok == true) { await DataService.instance.kickRoomMember(widget.roomId, id); _snack('$name foi removido da sala.'); }
                      }
                    } catch (e) { _snack('Não foi possível concluir: $e'); }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'admin', child: Text(isAdmin ? 'Remover administrador' : 'Tornar administrador')),
                    const PopupMenuItem(value: 'kick', child: Text('Expulsar da sala')),
                  ],
                ),
              );
            })),
        ]))),
    );
  }

  Widget _topBar(int viewers, Map<String, dynamic>? activeGuest, int liveCoins) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 0),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(8)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 7, height: 7,
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
            const SizedBox(width: 5),
            const Text('AO VIVO',
                style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900, letterSpacing: .5)),
          ]),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.black45, borderRadius: BorderRadius.circular(8)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.remove_red_eye_outlined, color: Colors.white, size: 14),
            const SizedBox(width: 5),
            Text('$viewers',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
          ]),
        ),
        if (_isHost) ...[
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xCC171020),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFFFD66B).withOpacity(.65)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.monetization_on, color: Color(0xFFFFD66B), size: 13),
              const SizedBox(width: 3),
              Text('$liveCoins', style: const TextStyle(color: Color(0xFFFFE29A), fontSize: 11, fontWeight: FontWeight.w900)),
            ]),
          ),
        ],
        const Spacer(),
        if (_isHost) ...[
          _topBtn(Icons.admin_panel_settings, _manageLiveParticipants),
          const SizedBox(width: 6),
          _topBtn(
            activeGuest == null ? Icons.person_add_alt_1 : Icons.group,
            () => _openInvite(activeGuest),
          ),
        ],
        const SizedBox(width: 6),
        _topBtn(Icons.close, _close),
      ]),
    );
  }

  Widget _topBtn(IconData icon, VoidCallback onTap) => Material(
        color: Colors.black45,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(width: 40, height: 40, child: Icon(icon, color: Colors.white, size: 22)),
        ),
      );

  Widget _commentBubble(Map<String, dynamic> m) {
    final type = (m['type'] ?? 'text').toString();
    final text = (m['text'] ?? '').toString();
    if (type == 'system') {
      return _bubble(const Color(0xAA3A2A05),
          Text(text, style: const TextStyle(color: Color(0xFFFFE27A), fontSize: 13, fontWeight: FontWeight.w700)));
    }
    final sender = (m['senderId'] ?? '').toString();
    final isGift = type == 'gift';
    return FutureBuilder<Map<String, dynamic>>(
      future: _user(sender),
      builder: (_, snap) {
        final name = (snap.data?['name'] ?? 'Participante').toString().split(' ').first;
        return _bubble(
          Colors.black45,
          RichText(
            text: TextSpan(children: [
              TextSpan(
                text: '$name  ',
                style: const TextStyle(color: Color(0xFFFFB3E6), fontWeight: FontWeight.w800, fontSize: 13)),
              TextSpan(
                text: isGift ? 'enviou $text' : text,
                style: TextStyle(color: Colors.white, fontSize: isGift ? 15 : 13)),
            ]),
          ),
        );
      },
    );
  }

  Widget _bubble(Color color, Widget child) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.only(top: 5),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(16)),
          child: child,
        ),
      );

  Widget _giftToast(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final g = doc.data();
    final created = (g['createdAt'] as Timestamp?)?.toDate();
    if (created != null && DateTime.now().difference(created).inSeconds > 15) {
      return const SizedBox.shrink();
    }
    return TweenAnimationBuilder<double>(
      key: ValueKey(doc.id),
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 2600),
      builder: (_, v, child) => Opacity(
        opacity: (1 - v * v).clamp(0.0, 1.0),
        child: Transform.scale(scale: .8 + .4 * math.sin(v * math.pi), child: child),
      ),
      child: Text((g['emoji'] ?? '🎁').toString(), style: const TextStyle(fontSize: 90)),
    );
  }

  Widget _comments() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.roomMessages(widget.roomId)
          .orderBy('createdAt', descending: true).limit(30).snapshots(),
      builder: (context, snap) {
        final docs = snap.data?.docs ?? [];
        final recent = docs.take(8).toList();
        return Stack(children: [
          Positioned(
            left: 12, bottom: 4,
            width: MediaQuery.of(context).size.width * .68,
            height: 270,
            child: ShaderMask(
              shaderCallback: (rect) => const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.white, Colors.white],
                stops: [0, .25, 1],
              ).createShader(rect),
              blendMode: BlendMode.dstIn,
              child: ListView.builder(
                reverse: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: recent.length,
                itemBuilder: (_, i) => _commentBubble(recent[i].data()),
              ),
            ),
          ),
          if (docs.isNotEmpty && docs.first.data()['type'] == 'gift')
            Align(alignment: const Alignment(0, -.2), child: IgnorePointer(child: _giftToast(docs.first))),
        ]);
      },
    );
  }

  Widget _heartsLayer() {
    return Positioned(
      right: 14, bottom: 6, width: 90, height: 300,
      child: IgnorePointer(
        child: Stack(clipBehavior: Clip.none, children: [
          for (final h in _hearts)
            Positioned(
              key: ValueKey(h.id),
              right: h.dx, bottom: 0,
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: const Duration(milliseconds: 2300),
                onEnd: () {
                  if (mounted) setState(() => _hearts.removeWhere((x) => x.id == h.id));
                },
                builder: (_, v, child) => Opacity(
                  opacity: (1 - v).clamp(0.0, 1.0),
                  child: Transform.translate(
                    offset: Offset(math.sin(v * 6 + h.id) * 12, -270 * v),
                    child: Transform.scale(scale: .7 + .5 * (1 - v), child: child),
                  ),
                ),
                child: Text(h.emoji, style: const TextStyle(fontSize: 30)),
              ),
            ),
        ]),
      ),
    );
  }

  Widget _sideControls() {
    if (!_publishing) return const SizedBox.shrink();
    return Positioned(
      right: 10, bottom: 330,
      child: Column(children: [
        _topBtn(_micOn ? Icons.mic : Icons.mic_off, () async {
          final next = !_micOn;
          try {
            ZegoUIKit.instance.turnMicrophoneOn(next);
            if (mounted) setState(() => _micOn = next);
          } catch (_) {}
        }),
        const SizedBox(height: 8),
        _topBtn(Icons.cameraswitch_rounded, () async {
          try {
            final next = !_frontCamera;
            await ZegoUIKit.instance.useFrontFacingCamera(next);
            if (mounted) setState(() => _frontCamera = next);
          } catch (_) {
            _snack('Não foi possível trocar a câmera.');
          }
        }),
      ]),
    );
  }

  Widget _bottomBar() {
    return Padding(
      padding: EdgeInsets.fromLTRB(10, 6, 10, 10 + MediaQuery.of(context).viewInsets.bottom),
      child: Row(children: [
        Expanded(
          child: TextField(
            controller: _input,
            focusNode: _focus,
            minLines: 1, maxLines: 2,
            style: const TextStyle(color: Colors.white),
            onSubmitted: (_) => _send(),
            decoration: InputDecoration(
              hintText: 'Adicionar comentário...',
              hintStyle: const TextStyle(color: Colors.white70),
              filled: true,
              fillColor: Colors.black45,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: BorderSide.none),
              suffixIcon: IconButton(
                icon: const Icon(Icons.send_rounded, color: Color(0xFFFF65D5)),
                onPressed: _send,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        // Reações são exclusivas dos espectadores; o anfitrião não pode reagir.
        if (!_isHost) ...[
          _actionBtn('❤️', () => _react('heart')),
          const SizedBox(width: 6),
          _actionBtn('👍', () => _react('like')),
        ],
        const SizedBox(width: 6),
        Material(
          color: pink,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: _openGifts,
            child: const SizedBox(width: 44, height: 44, child: Icon(Icons.card_giftcard, color: Colors.white)),
          ),
        ),
      ]),
    );
  }

  Widget _actionBtn(String emoji, VoidCallback onTap) => Material(
        color: Colors.black45,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(
            width: 44, height: 44,
            child: Center(child: Text(emoji, style: const TextStyle(fontSize: 22)))),
        ),
      );

  // ------------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    if (_enterError != null) {
      return Scaffold(
        backgroundColor: const Color(0xFF12062A),
        appBar: AppBar(backgroundColor: Colors.transparent),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Text(_enterError!, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16)),
          ),
        ),
      );
    }

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        await _close();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        resizeToAvoidBottomInset: false,
        body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).snapshots(),
          builder: (context, roomSnap) {
            final room = roomSnap.data?.data();
            if (_roomMembershipReady && room != null &&
                !List<String>.from(room['members'] ?? const []).contains(_myUid) && !_left) {
              WidgetsBinding.instance.addPostFrameCallback((_) async {
                if (!mounted || _left) return;
                _left = true;
                await _cleanup(endIfHost: false);
                if (mounted) { _snack('Você foi removido desta sala pelo anfitrião.'); Navigator.pop(context); }
              });
            }
            // Live encerrada pelo anfitrião: avisa quem está assistindo e sai.
            if (room != null && room['isLive'] == false && !_isHost && !_endedHandled && _ownerId.isNotEmpty) {
              _endedHandled = true;
              WidgetsBinding.instance.addPostFrameCallback((_) async {
                _snack('A live foi encerrada pelo anfitrião.');
                await _leave();
                if (mounted) Navigator.pop(context);
              });
            }
            return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _guests.snapshots(),
              builder: (context, guestSnap) {
                Map<String, dynamic>? accepted;
                Map<String, dynamic>? invited;
                String? myStatus;
                for (final doc in guestSnap.data?.docs ?? []) {
                  final d = doc.data();
                  if (doc.id == _myUid) myStatus = (d['status'] ?? '').toString();
                  if (d['status'] == 'accepted') accepted = {...d, 'uid': doc.id};
                  if (d['status'] == 'invited') invited = {...d, 'uid': doc.id};
                }
                _syncGuestState(myStatus);
                final active = accepted ?? invited;

                return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: DataService.instance.watchLiveParticipants(widget.roomId),
                  builder: (context, pSnap) {
                    _people = (pSnap.data?.docs ?? []).map((d) => d.data()).toList();
                    final viewers = _people.where((p) => p['uid'] != _ownerId).length;
                    // Nome do convidado para os rótulos.
                    Map<String, dynamic>? withName(Map<String, dynamic>? g) {
                      if (g == null) return null;
                      final match = _people.where((p) => p['uid'] == g['uid']);
                      return {...g, 'name': match.isEmpty ? 'Convidado' : match.first['displayName']};
                    }

                    return Stack(children: [
                      Positioned.fill(child: _videoLayer(withName(accepted))),
                      // Degradês para dar leitura ao texto sobre o vídeo.
                      Positioned(
                        top: 0, left: 0, right: 0, height: 140,
                        child: IgnorePointer(
                          child: Container(
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                                colors: [Color(0xAA000000), Colors.transparent]),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0, left: 0, right: 0, height: 320,
                        child: IgnorePointer(
                          child: Container(
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.bottomCenter, end: Alignment.topCenter,
                                colors: [Color(0xCC000000), Colors.transparent]),
                            ),
                          ),
                        ),
                      ),
                      SafeArea(
                        child: Column(children: [
                          _topBar(viewers, withName(active), (room?['liveCoinEarnings'] as num?)?.toInt() ?? 0),
                          Expanded(
                            child: Stack(children: [
                              _comments(),
                              _heartsLayer(),
                              _sideControls(),
                            ]),
                          ),
                          _bottomBar(),
                        ]),
                      ),
                    ]);
                  },
                );
              },
            );
          },
        ),
      ),
    );
  }
}
