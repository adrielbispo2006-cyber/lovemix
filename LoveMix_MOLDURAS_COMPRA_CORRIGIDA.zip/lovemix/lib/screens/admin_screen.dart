import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  bool loading = true;
  bool allowed = false;
  String? error;
  List<Map<String, dynamic>> users = [];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    setState(() { loading = true; error = null; });
    try {
      final token = await FirebaseAuth.instance.currentUser?.getIdTokenResult(true);
      if (token?.claims?['admin'] != true) {
        setState(() { allowed = false; loading = false; });
        return;
      }
      final result = await FirebaseFunctions.instance.httpsCallable('adminListLoveMixUsers').call();
      final raw = (result.data as Map)['users'] as List? ?? [];
      users = raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
      setState(() { allowed = true; loading = false; });
    } catch (e) {
      setState(() { error = e.toString(); loading = false; });
    }
  }

  Future<void> _manage(Map<String, dynamic> user) async {
    final coins = TextEditingController(text: '0');
    final vipDays = TextEditingController(text: '0');
    bool removeVip = false;
    final submit = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setDialog) => AlertDialog(
        title: Text('Gerenciar ${(user['name'] ?? 'usuário').toString()}'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('UID: ${user['uid']}'),
          TextField(controller: coins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Adicionar/remover moedas', hintText: 'Ex.: 500 ou -100')),
          TextField(controller: vipDays, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Dias de VIP para adicionar')),
          CheckboxListTile(value: removeVip, onChanged: (v) => setDialog(() => removeVip = v ?? false), title: const Text('Remover VIP'), contentPadding: EdgeInsets.zero),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Aplicar'))],
      ),
    ));
    if (submit != true) return;
    final coinDelta = int.tryParse(coins.text.trim());
    final days = int.tryParse(vipDays.text.trim());
    coins.dispose(); vipDays.dispose();
    if (coinDelta == null || days == null || days < 0 || days > 365 || (removeVip && days > 0)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Confira os valores informados.')));
      return;
    }
    try {
      await FirebaseFunctions.instance.httpsCallable('adminUpdateLoveMixUser').call({
        'uid': user['uid'], 'coinDelta': coinDelta, 'vipDays': days, 'removeVip': removeVip,
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Conta atualizada com sucesso.')));
      await _loadUsers();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível atualizar: $e')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Painel Administrativo'), actions: [IconButton(onPressed: _loadUsers, icon: const Icon(Icons.refresh))]),
    body: loading ? const Center(child: CircularProgressIndicator()) : !allowed
      ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error ?? 'Esta conta não possui permissão de administrador.')))
      : error != null ? Center(child: Text(error!)) : RefreshIndicator(
        onRefresh: _loadUsers,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(child: ListTile(leading: const Icon(Icons.people), title: const Text('Usuários carregados'), trailing: Text('${users.length}'))),
          const SizedBox(height: 12),
          const Text('Gerenciar contas', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ...users.map((u) => Card(child: ListTile(
            leading: CircleAvatar(child: Icon(u['isVip'] == true ? Icons.workspace_premium : Icons.person)),
            title: Text((u['name'] ?? 'Sem nome').toString()),
            subtitle: Text('🪙 ${u['coins'] ?? 0} moedas • ${u['isVip'] == true ? 'VIP' : 'Sem VIP'}\n${u['uid']}'),
            isThreeLine: true,
            trailing: IconButton(icon: const Icon(Icons.edit), onPressed: () => _manage(u)),
          ))),
        ]),
      ),
  );
}
