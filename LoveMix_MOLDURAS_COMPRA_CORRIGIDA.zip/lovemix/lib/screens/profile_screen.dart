import 'dart:async';
import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import 'admin_screen.dart';
import 'post_interactions_screen.dart';
import 'profile_view_screen.dart';
import '../widgets/profile_frame.dart';
import '../widgets/full_photo.dart';
import 'vip_nickname_screen.dart';
import '../widgets/vip_nickname.dart';

const _pink = Color(0xFFFF19B8);
const _purple = Color(0xFF8D35FF);
const _panel = Color(0xFF171022);
const _muted = Color(0xFFB9AFC7);

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    DataService.instance.ensurePublicId().catchError((_) {});
    _syncPublicPostsToFeed();
    _refreshAdminClaim();
  }


  Future<void> _refreshAdminClaim() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // A função do servidor só autoriza o e-mail fundador verificado.
      // Assim o botão aparece após o servidor conceder a custom claim.
      if (user.email?.trim().toLowerCase() == 'adrielbispo3009@gmail.com') {
        try {
          await FirebaseFunctions.instance
              .httpsCallable('claimFounderAdmin')
              .call();
        } catch (_) {
          // Se a função ainda não foi publicada, mantém o perfil funcionando.
        }
      }

      final token = await user.getIdTokenResult(true);
      if (mounted) setState(() => _isAdminClaim = token.claims?['admin'] == true);
    } catch (_) {}
  }

  /// Garante que fotos públicas já existentes na galeria também apareçam em
  /// "Publicações da comunidade" (ex.: fotos postadas antes dessa ligação).
  Future<void> _syncPublicPostsToFeed() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;
      final db = FirebaseFirestore.instance;
      final mine = await db.collection('users').doc(user.uid).collection('posts')
          .where('visibility', isEqualTo: 'public').limit(60).get();
      if (mine.docs.isEmpty) return;
      final me = await db.collection('users').doc(user.uid).get();
      for (final d in mine.docs) {
        final url = (d.data()['photoUrl'] ?? '').toString();
        if (url.isEmpty) continue;
        final feedRef = db.collection('feed_posts').doc(d.id);
        if ((await feedRef.get()).exists) continue;
        await feedRef.set({
          'ownerId': user.uid,
          'name': (me.data()?['name'] ?? 'Pessoa').toString(),
          'photoUrl': (me.data()?['photoUrl'] ?? '').toString(),
          'imageUrl': url,
          'text': '',
          'createdAt': d.data()['createdAt'] ?? FieldValue.serverTimestamp(),
        });
      }
    } catch (_) {}
  }

  final name = TextEditingController();
  final bio = TextEditingController();
  final city = TextEditingController();
  final country = TextEditingController();
  final customInterest = TextEditingController();

  bool loaded = false;
  bool saving = false;
  Timer? _autoSaveTimer;
  Timer? _nameSaveTimer;
  String _lastSavedName = '';
  bool profileSaved = false;
  bool _isAdminClaim = false;
  String gender = '';
  String profileVisibility = 'public';
  String postVisibility = 'public';
  DateTime? birthday;
  List<String> interests = [];

  static const interestOptions = [
    'Amizades', 'Namoro', 'Música', 'Games', 'Viagens', 'Séries',
    'Filmes', 'Esportes', 'Leitura', 'Tecnologia', 'Pets', 'Culinária',
    'Fotografia', 'Dança', 'Academia', 'Natureza',
  ];

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _nameSaveTimer?.cancel();
    _saveNameNow();
    name.dispose();
    bio.dispose();
    city.dispose();
    country.dispose();
    customInterest.dispose();
    super.dispose();
  }

  int? _age(DateTime? date) {
    if (date == null) return null;
    final now = DateTime.now();
    var result = now.year - date.year;
    if (now.month < date.month || (now.month == date.month && now.day < date.day)) {
      result--;
    }
    return result;
  }

  String get _place {
    final c = city.text.trim();
    final countryName = country.text.trim();
    if (c.isEmpty) return countryName;
    if (countryName.isEmpty) return c;
    // When the state abbreviation is already part of the city (São Paulo-SP),
    // avoid repeating the Brazilian state/country in the compact profile line.
    if (countryName.toLowerCase() == 'brasil' && c.contains('-')) return c;
    return '$c • $countryName';
  }

  String get _genderSymbol => const {
    'woman': '♀', 'man': '♂', 'non_binary': '⚧', 'other': '✦',
  }[gender] ?? '';

  Future<void> pickBirthday() async {
    final now = DateTime.now();
    final lastAllowed = DateTime(now.year - 18, now.month, now.day);
    final selected = birthday != null && !birthday!.isAfter(lastAllowed)
        ? birthday!
        : DateTime(now.year - 25, now.month, now.day);
    final picked = await showDatePicker(
      context: context,
      initialDate: selected,
      firstDate: DateTime(1900),
      lastDate: lastAllowed,
      helpText: 'Data de nascimento (somente maiores de 18 anos)',
    );
    if (picked != null && mounted) {
      setState(() {
        birthday = picked;
        profileSaved = false;
      });
      // A data de nascimento fica salva imediatamente, sem depender do
      // botão geral do perfil. A idade é recalculada a partir dela.
      try {
        await DataService.instance.updateProfile({
          'birthday': Timestamp.fromDate(picked),
          'age': _age(picked),
        });
        if (mounted) {
          _message('Idade salva automaticamente!');
          _scheduleAutoSave();
        }
      } catch (e) {
        if (mounted) _message('Não foi possível salvar a idade: $e');
      }
    }
  }

  /// Usa o GPS apenas para descobrir cidade/estado e país.
  /// A latitude/longitude exata não é salva no perfil público.
  Future<void> _useCurrentLocation() async {
    if (saving) return;
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _message('Ative a localização do celular e tente novamente.');
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        _message('Permita o acesso à localização para preencher sua cidade.');
        return;
      }
      if (permission == LocationPermission.deniedForever) {
        _message('A localização está bloqueada. Ative a permissão nas configurações do aplicativo.');
        await Geolocator.openAppSettings();
        return;
      }

      if (mounted) setState(() => saving = true);
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.medium,
          timeLimit: Duration(seconds: 20),
        ),
      );
      final places = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (places.isEmpty) throw Exception('Não encontrei a cidade desta localização.');
      final place = places.first;
      final locality = (place.locality?.trim().isNotEmpty == true)
          ? place.locality!.trim()
          : (place.subAdministrativeArea?.trim().isNotEmpty == true)
              ? place.subAdministrativeArea!.trim()
              : (place.administrativeArea?.trim() ?? '').trim();
      final state = (place.administrativeArea ?? '').trim();
      final countryName = (place.country ?? '').trim();
      if (locality.isEmpty && countryName.isEmpty) {
        throw Exception('Não foi possível identificar sua cidade. Preencha manualmente.');
      }
      final cityValue = locality.isEmpty
          ? state
          : (state.isNotEmpty && state.toLowerCase() != locality.toLowerCase()
              ? '$locality-$state'
              : locality);
      if (!mounted) return;
      setState(() {
        if (cityValue.isNotEmpty) city.text = cityValue;
        if (countryName.isNotEmpty) country.text = countryName;
        profileSaved = false;
      });
      _scheduleAutoSave();
      _message('Localização preenchida! Salvando seu perfil...');
    } catch (e) {
      if (mounted) {
        _message('Não consegui obter sua localização: ${e.toString().replaceFirst('Exception: ', '')}');
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> publishPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Entre novamente para publicar.');
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 65,
        maxWidth: 1000,
        maxHeight: 1000,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length >= 5 * 1024 * 1024) {
        throw Exception('Escolha uma foto válida de até 5 MB.');
      }
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final isPng = picked.name.toLowerCase().endsWith('.png');
      final type = isPng ? 'image/png' : 'image/jpeg';
      final ext = isPng ? 'png' : 'jpg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'posts/${user.uid}/$id.$ext', bytes: bytes, contentType: type,
      );
      final db = FirebaseFirestore.instance;
      final inCommunity = postVisibility == 'public';
      final batch = db.batch();
      // Foto na galeria do perfil.
      batch.set(db.collection('users').doc(user.uid).collection('posts').doc(id), {
        'photoUrl': url,
        'visibility': postVisibility,
        'createdAt': FieldValue.serverTimestamp(),
      });
      // Fotos públicas também aparecem em "Publicações da comunidade" (Início).
      // O feed usa o mesmo id da foto e é gravado no mesmo lote: ou salva nos
      // dois lugares, ou em nenhum (e o erro aparece, sem falhar em silêncio).
      if (inCommunity) {
        final me = await db.collection('users').doc(user.uid).get();
        batch.set(db.collection('feed_posts').doc(id), {
          'ownerId': user.uid,
          'name': (me.data()?['name'] ?? 'Pessoa').toString(),
          'photoUrl': (me.data()?['photoUrl'] ?? '').toString(),
          'imageUrl': url,
          'text': '',
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
      await batch.commit();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(inCommunity
              ? 'Foto publicada no seu perfil e na comunidade!'
              : 'Foto publicada no seu perfil!')),
        );
      }
    } on FirebaseException catch (e) {
      final message = switch (e.code) {
        'object-not-found' => 'O Firebase não localizou o arquivo após o envio. Confira se o bucket Storage do projeto lovemix-73849 está ativo e se as regras foram publicadas.',
        'unauthorized' || 'permission-denied' => 'O Firebase bloqueou a publicação. Verifique as regras do ${e.plugin == 'firebase_storage' ? 'Storage' : 'Firestore'}.',
        _ => 'Não foi possível publicar a foto (${e.code}).',
      };
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível publicar: ${e.toString().replaceFirst('Exception: ', '')}')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }


  Future<void> pickCoverPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login novamente para alterar a capa.');
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery, imageQuality: 75, maxWidth: 1600, maxHeight: 1200,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length >= 8 * 1024 * 1024) {
        throw Exception('Escolha uma imagem válida de até 8 MB.');
      }
      final isPng = picked.name.toLowerCase().endsWith('.png');
      final ext = isPng ? 'png' : 'jpg';
      final type = isPng ? 'image/png' : 'image/jpeg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'covers/${user.uid}/cover.$ext', bytes: bytes, contentType: type,
      );
      await DataService.instance.updateProfile({'profileCoverUrl': url});
      if (mounted) _message('Foto de capa atualizada! 💜');
    } on FirebaseException catch (e) {
      final message = switch (e.code) {
        'object-not-found' => 'O Firebase não localizou o arquivo após o envio. Confira se o bucket Storage do projeto lovemix-73849 está ativo e se as regras foram publicadas.',
        'unauthorized' || 'permission-denied' => 'O Firebase bloqueou a gravação. Publique as regras do Storage e do Firestore.',
        _ => 'Não foi possível atualizar a capa (${e.code}).',
      };
      if (mounted) _message(message);
    } catch (e) {
      if (mounted) _message('Não foi possível atualizar a capa: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  /// Lápis da foto de perfil: o usuário pode trocar a foto quando quiser.
  Future<void> changePhotoMenu() async {
    if (saving) return;
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: const Color(0xFF171022),
      builder: (ctx) => SafeArea(child: Wrap(children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(18, 16, 18, 6),
          child: Text('Alterar foto de perfil',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ),
        ListTile(
          leading: const Icon(Icons.photo_library_outlined, color: Color(0xFFFF2DAB)),
          title: const Text('Escolher da galeria'),
          onTap: () => Navigator.pop(ctx, ImageSource.gallery),
        ),
        ListTile(
          leading: const Icon(Icons.photo_camera_outlined, color: Color(0xFFFF2DAB)),
          title: const Text('Tirar uma foto agora'),
          onTap: () => Navigator.pop(ctx, ImageSource.camera),
        ),
      ])),
    );
    if (source == null) return;
    await pickPhoto(source);
  }

  Future<void> pickPhoto([ImageSource source = ImageSource.gallery]) async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login novamente para alterar sua foto.');
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 65,
        maxWidth: 720,
        maxHeight: 720,
      );
      if (picked == null) return;
      final Uint8List bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A imagem selecionada está vazia.');
      if (bytes.length > 5 * 1024 * 1024) {
        throw Exception('A foto ficou muito grande. Escolha outra imagem.');
      }
      final lowerPath = picked.name.toLowerCase();
      final contentType = lowerPath.endsWith('.png')
          ? 'image/png'
          : lowerPath.endsWith('.webp') ? 'image/webp' : 'image/jpeg';
      final extension = contentType == 'image/png'
          ? 'png' : contentType == 'image/webp' ? 'webp' : 'jpg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'profiles/${user.uid}/profile.$extension',
        bytes: bytes, contentType: contentType,
      );
      await DataService.instance.updateProfile({'photoUrl': '$url?v=${DateTime.now().millisecondsSinceEpoch}'});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Foto de perfil atualizada!')),
        );
      }
    } on FirebaseException catch (e) {
      final message = e.code == 'unauthorized'
          ? 'O Firebase Storage bloqueou o envio. Verifique as regras do Storage.'
          : e.code == 'canceled' ? 'Envio cancelado.' : 'Falha no envio da foto (${e.code}). Tente novamente.';
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  // Salva o nome imediatamente (sem exigir data de nascimento ou outros campos).
  void _scheduleNameSave() {
    if (!loaded || !mounted) return;
    _nameSaveTimer?.cancel();
    _nameSaveTimer = Timer(const Duration(milliseconds: 400), _saveNameNow);
  }

  Future<void> _saveNameNow() async {
    final value = name.text.trim();
    if (!loaded || value.isEmpty || value == _lastSavedName) return;
    _lastSavedName = value;
    try {
      await DataService.instance.updateProfile({'name': value});
    } catch (_) {
      _lastSavedName = '';
    }
  }

  void _scheduleAutoSave() {
    if (!loaded || !mounted) return;
    _autoSaveTimer?.cancel();
    if (mounted) setState(() => profileSaved = false);
    _autoSaveTimer = Timer(const Duration(milliseconds: 900), () {
      if (mounted) _saveProfile(showMessage: false);
    });
  }

  Future<void> _saveProfile({bool showMessage = true}) async {
    if (saving) {
      if (!showMessage && mounted) {
        _autoSaveTimer?.cancel();
        _autoSaveTimer = Timer(const Duration(milliseconds: 900), () {
          if (mounted) _saveProfile(showMessage: false);
        });
      }
      return;
    }
    if (name.text.trim().isEmpty) {
      if (showMessage) _message('Digite seu nome.');
      return;
    }
    final age = _age(birthday);
    if (birthday == null || age == null) {
      if (showMessage) _message('Adicione sua data de nascimento para mostrar sua idade no perfil.');
      return;
    }
    if (age < 18) {
      if (showMessage) _message('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }
    setState(() {
      saving = true;
      profileSaved = false;
    });
    try {
      await DataService.instance.updateProfile({
        'name': name.text.trim(),
        'bio': bio.text.trim(),
        'city': city.text.trim(),
        'country': country.text.trim(),
        'gender': gender,
        'birthday': Timestamp.fromDate(birthday!),
        'age': age,
        'interests': interests,
        'profileVisibility': profileVisibility,
        'postVisibility': postVisibility,
      }).timeout(const Duration(seconds: 20));
      if (mounted) {
        setState(() => profileSaved = true);
        if (showMessage) _message('Perfil salvo com sucesso!');
      }
    } on TimeoutException {
      if (mounted) {
        _message('Ainda não consegui confirmar o salvamento. Verifique sua conexão.');
      }
    } catch (e) {
      if (mounted) _message('Não foi possível salvar o perfil: $e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  void _addCustomInterest() {
    final value = customInterest.text.trim();
    if (value.isEmpty) return;
    if (!interests.any((e) => e.toLowerCase() == value.toLowerCase())) {
      setState(() {
        interests.add(value);
        profileSaved = false;
      });
      _scheduleAutoSave();
    }
    customInterest.clear();
    FocusScope.of(context).unfocus();
  }

  void _openPhoto(String postId, String url) {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => PostInteractionsScreen(ownerId: userId, postId: postId, photoUrl: url)));
  }

  Future<void> _deletePost(String postId, String url) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remover foto?'),
        content: const Text('Essa foto será removida da sua galeria.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Remover')),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      await FirebaseFirestore.instance.collection('users').doc(uid).collection('posts').doc(postId).delete();
      try { await FirebaseFirestore.instance.collection('feed_posts').doc(postId).delete(); } catch (_) {}
      if (url.isNotEmpty) {
        try { final removed = await SupabaseService.instance.deletePublicUrl(url); if (!removed) await FirebaseStorage.instance.refFromURL(url).delete(); } catch (_) {}
      }
      if (mounted) _message('Foto removida da galeria.');
    } catch (e) {
      if (mounted) _message('Não foi possível remover a foto: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.myProfile(),
      builder: (context, snap) {
        final p = snap.data?.data() ?? <String, dynamic>{};
        if (!loaded && p.isNotEmpty) {
          name.text = (p['name'] ?? '').toString();
          _lastSavedName = name.text.trim();
          bio.text = (p['bio'] ?? '').toString();
          city.text = (p['city'] ?? '').toString();
          country.text = (p['country'] ?? '').toString();
          gender = (p['gender'] ?? '').toString();
          profileVisibility = (p['profileVisibility'] ?? 'public').toString();
          postVisibility = (p['postVisibility'] ?? 'public').toString();
          birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
          interests = List<String>.from(p['interests'] ?? const []);
          loaded = true;
        }
        final photo = (p['photoUrl'] ?? '').toString();
        final cover = (p['profileCoverUrl'] ?? '').toString();
        final user = FirebaseAuth.instance.currentUser;
        if (user == null) return const Center(child: Text('Entre na sua conta para editar o perfil.'));

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: [
            const Text('Conecta', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            const Text('Veja como as pessoas enxergam você no LoveMix.', style: TextStyle(color: _muted)),
            const SizedBox(height: 16),
            _profilePreview(cover.isNotEmpty ? cover : photo, p),
            const SizedBox(height: 12),
            Card(color: _panel, child: ListTile(
              leading: const Icon(Icons.workspace_premium, color: Color(0xFFFFD56A), size: 28),
              title: const Text('Nick VIP decorado', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Coroas, cruzes e efeitos coloridos exclusivos para VIP.'),
              trailing: const Icon(Icons.chevron_right, color: _pink),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen())),
            )),
            if ((p['publicId'] ?? '').toString().isNotEmpty)
              Card(
                color: _panel,
                child: ListTile(
                  leading: const Icon(Icons.badge_outlined, color: _pink),
                  title: const Text('Meu ID LoveMix', style: TextStyle(fontSize: 12, color: _muted)),
                  subtitle: SelectableText((p['publicId'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  trailing: IconButton(
                    tooltip: 'Copiar ID',
                    icon: const Icon(Icons.copy, color: _pink),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: (p['publicId'] ?? '').toString()));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ID copiado!')));
                    },
                  ),
                ),
              ),
            const SizedBox(height: 20),
            _sectionHeader(Icons.edit_rounded, 'Nome e idade', 'Essas informações aparecem no seu perfil público.'),
            const SizedBox(height: 12),
            _formCard([
              TextField(
                controller: name,
                textCapitalization: TextCapitalization.words,
                onChanged: (_) {
                  setState(() {});
                  _scheduleNameSave();
                  _scheduleAutoSave();
                },
                onSubmitted: (_) => _saveNameNow(),
                decoration: const InputDecoration(labelText: 'Nome que será exibido', prefixIcon: Icon(Icons.person_outline)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bio,
                maxLines: 3,
                maxLength: 300,
                onChanged: (_) => _scheduleAutoSave(),
                decoration: const InputDecoration(labelText: 'Sobre mim', hintText: 'Conte um pouco sobre você... ', prefixIcon: Icon(Icons.favorite_border)),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: pickBirthday,
                icon: const Icon(Icons.cake_outlined),
                label: Text(birthday == null ? 'Adicionar data de nascimento (18+)' : 'Nascimento: ${birthday!.day.toString().padLeft(2, '0')}/${birthday!.month.toString().padLeft(2, '0')}/${birthday!.year}  •  ${_age(birthday)} anos'),
              ),
              const SizedBox(height: 12),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Expanded(child: TextField(
                  controller: city,
                  textCapitalization: TextCapitalization.words,
                  onChanged: (_) => _scheduleAutoSave(),
                  decoration: const InputDecoration(labelText: 'Cidade / Estado', hintText: 'Ex.: São Paulo-SP', prefixIcon: Icon(Icons.location_city)),
                )),
                const SizedBox(width: 8),
                Padding(
                  padding: const EdgeInsets.only(bottom: 2),
                  child: IconButton.filled(
                    tooltip: 'Usar minha localização atual',
                    onPressed: saving ? null : _useCurrentLocation,
                    icon: const Icon(Icons.my_location_rounded),
                    style: IconButton.styleFrom(
                      backgroundColor: _pink,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(50, 50),
                    ),
                  ),
                ),
              ]),
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'Toque no localizador para preencher cidade e estado pelo GPS. Sua localização exata não aparece no perfil.',
                  style: TextStyle(color: _muted, fontSize: 11),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: country,
                textCapitalization: TextCapitalization.words,
                onChanged: (_) => _scheduleAutoSave(),
                decoration: const InputDecoration(labelText: 'País', hintText: 'Ex.: Brasil', prefixIcon: Icon(Icons.public)),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: gender.isEmpty ? null : gender,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Gênero', prefixIcon: Icon(Icons.wc_outlined)),
                items: const [
                  DropdownMenuItem(value: 'woman', child: Text('♀ Mulher')),
                  DropdownMenuItem(value: 'man', child: Text('♂ Homem')),
                  DropdownMenuItem(value: 'non_binary', child: Text('⚧ Não binário')),
                  DropdownMenuItem(value: 'other', child: Text('✦ Outro')),
                  DropdownMenuItem(value: 'prefer_not', child: Text('Prefiro não informar')),
                ],
                onChanged: (v) {
                  setState(() {
                    gender = v ?? '';
                    profileSaved = false;
                  });
                  _scheduleAutoSave();
                },
              ),
            ]),
            const SizedBox(height: 18),
            _sectionHeader(Icons.auto_awesome, 'Interesses', 'Adicione e remova os assuntos que combinam com você.'),
            const SizedBox(height: 10),
            _formCard([
              Wrap(
                spacing: 8,
                runSpacing: 2,
                children: interestOptions.map((item) {
                  final selected = interests.contains(item);
                  return FilterChip(
                    label: Text(item),
                    selected: selected,
                    showCheckmark: false,
                    selectedColor: _purple.withOpacity(.35),
                    backgroundColor: const Color(0xFF100A19),
                    side: BorderSide(color: selected ? _pink : Colors.white24),
                    labelStyle: TextStyle(color: selected ? Colors.white : Colors.white70, fontWeight: selected ? FontWeight.bold : FontWeight.normal),
                    onSelected: (value) {
                      setState(() {
                        if (value) { interests.add(item); } else { interests.remove(item); }
                        profileSaved = false;
                      });
                      _scheduleAutoSave();
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(
                  controller: customInterest,
                  textCapitalization: TextCapitalization.sentences,
                  onSubmitted: (_) => _addCustomInterest(),
                  decoration: const InputDecoration(hintText: 'Adicionar outro interesse', prefixIcon: Icon(Icons.add)),
                )),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _addCustomInterest, icon: const Icon(Icons.add), style: IconButton.styleFrom(backgroundColor: _pink)),
              ]),
              if (interests.any((e) => !interestOptions.contains(e))) ...[
                const SizedBox(height: 10),
                Wrap(spacing: 8, children: interests.where((e) => !interestOptions.contains(e)).map((e) => InputChip(
                  label: Text(e), onDeleted: () {
                    setState(() {
                      interests.remove(e);
                      profileSaved = false;
                    });
                    _scheduleAutoSave();
                  },
                  backgroundColor: _purple.withOpacity(.25), side: const BorderSide(color: _purple),
                )).toList()),
              ],
            ]),
            const SizedBox(height: 18),
            _sectionHeader(Icons.visibility_outlined, 'Privacidade', 'Controle quem encontra seu perfil e quem vê cada publicação.'),
            const SizedBox(height: 10),
            _formCard([
              DropdownButtonFormField<String>(
                value: profileVisibility,
                decoration: const InputDecoration(labelText: 'Quem pode encontrar seu perfil?', prefixIcon: Icon(Icons.person_search_outlined)),
                items: const [
                  DropdownMenuItem(value: 'public', child: Text('🌎 Público — todos podem encontrar')),
                  DropdownMenuItem(value: 'friends', child: Text('👥 Amigos — somente conexões')),
                  DropdownMenuItem(value: 'private', child: Text('🔒 Privado — somente você')),
                ],
                onChanged: (v) {
                  setState(() {
                    profileVisibility = v ?? 'public';
                    profileSaved = false;
                  });
                  _scheduleAutoSave();
                },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: postVisibility,
                decoration: const InputDecoration(labelText: 'Privacidade padrão das próximas fotos', prefixIcon: Icon(Icons.photo_library_outlined)),
                items: const [
                  DropdownMenuItem(value: 'public', child: Text('🌎 Público')),
                  DropdownMenuItem(value: 'friends', child: Text('👥 Apenas amigos / matches')),
                  DropdownMenuItem(value: 'private', child: Text('🔒 Somente eu')),
                ],
                onChanged: (v) {
                  setState(() {
                    postVisibility = v ?? 'public';
                    profileSaved = false;
                  });
                  _scheduleAutoSave();
                },
              ),
              const SizedBox(height: 8),
              const Text('A privacidade padrão é aplicada às novas fotos publicadas. Cada publicação mantém a opção escolhida no momento do envio.', style: TextStyle(color: _muted, fontSize: 12)),
            ]),
            const SizedBox(height: 16),
            const SizedBox(height: 24),
            _sectionHeader(Icons.photo_library_outlined, 'Galeria de fotos', 'Gerencie as fotos que aparecem no seu perfil público.'),
            const SizedBox(height: 8),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance.collection('users').doc(user.uid)
                  .collection('posts').snapshots(),
              builder: (context, postsSnap) {
                if (postsSnap.hasError) return const Text('Não foi possível carregar suas fotos.', style: TextStyle(color: Colors.white70));
                if (!postsSnap.hasData) return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator(color: _pink)));
                final posts = [...postsSnap.data!.docs];
                posts.sort((a, b) {
                  final at = a.data()['createdAt'];
                  final bt = b.data()['createdAt'];
                  final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
                  final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
                  return bm.compareTo(am);
                });
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('Fotos (${posts.length})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const Spacer(),
                    TextButton.icon(onPressed: saving ? null : publishPhoto, icon: const Icon(Icons.add_a_photo_outlined), label: const Text('Adicionar fotos')),
                  ]),
                  if (posts.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 18),
                      decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
                      child: const Column(children: [
                        Icon(Icons.add_photo_alternate_outlined, size: 38, color: _purple),
                        SizedBox(height: 8),
                        Text('Você ainda não publicou fotos.', style: TextStyle(color: Colors.white70)),
                        Text('Toque em Publicar para adicionar a primeira.', style: TextStyle(color: _muted, fontSize: 12)),
                      ]),
                    )
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: posts.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 7, mainAxisSpacing: 7),
                      itemBuilder: (_, i) {
                        final post = posts[i].data();
                        final url = (post['photoUrl'] ?? '').toString();
                        final privacy = (post['visibility'] ?? 'public').toString();
                        return GestureDetector(
                          onTap: url.isEmpty ? null : () => _openPhoto(posts[i].id, url),
                          child: Stack(fit: StackFit.expand, children: [
                            ClipRRect(borderRadius: BorderRadius.circular(12), child: url.isEmpty
                                ? const ColoredBox(color: _panel, child: Icon(Icons.broken_image))
                                : CachedNetworkImage(imageUrl: url, fit: BoxFit.cover, memCacheWidth: 360, memCacheHeight: 360, placeholder: (_, __) => const ColoredBox(color: _panel), errorWidget: (_, __, ___) => const ColoredBox(color: _panel, child: Icon(Icons.broken_image)))),
                            Positioned(right: 5, top: 5, child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(color: Color(0xB3000000), shape: BoxShape.circle),
                              child: Icon(privacy == 'private' ? Icons.lock : privacy == 'friends' ? Icons.group : Icons.public, size: 13, color: Colors.white),
                            )),
                            Positioned(left: 3, top: 3, child: Material(
                              color: const Color(0xB3000000), shape: const CircleBorder(),
                              child: InkWell(onTap: () => _deletePost(posts[i].id, url),
                                customBorder: const CircleBorder(),
                                child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.delete_outline, size: 15, color: Colors.white))),
                            )),
                          ]),
                        );
                      },
                    ),
                ]);
              },
            ),
            const SizedBox(height: 18),
            if (_isAdminClaim)
              OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())), icon: const Icon(Icons.admin_panel_settings), label: const Text('Painel administrativo')),
            OutlinedButton.icon(
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Excluir conta?'),
                    content: const Text('A exclusão é permanente. Talvez seja necessário entrar novamente antes de confirmar.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir')),
                    ],
                  ),
                );
                if (confirm != true) return;
                try {
                  await DataService.instance.deleteMyAccount();
                } on FirebaseAuthException catch (e) {
                  if (mounted) _message(e.code == 'requires-recent-login'
                      ? 'Por segurança, saia e entre novamente antes de excluir a conta.'
                      : 'Não foi possível excluir a conta.');
                }
              },
              icon: const Icon(Icons.delete_forever), label: const Text('Excluir minha conta'),
            ),
            OutlinedButton.icon(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout), label: const Text('Sair da conta')),
          ],
        );
      },
    );
  }

  Widget _profilePreview(String cover, Map<String, dynamic> profile) {
    final age = _age(birthday);
    final displayName = name.text.trim().isEmpty ? 'Seu nome' : name.text.trim();
    final isOnline = profile['isOnline'] == true;
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF090909),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _purple.withOpacity(.75), width: 1.3),
        boxShadow: [BoxShadow(color: _purple.withOpacity(.16), blurRadius: 18)],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Stack(children: [
          cover.isEmpty
              ? Container(
                  width: double.infinity, height: 270,
                  decoration: const BoxDecoration(gradient: LinearGradient(
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xFF29113D), Color(0xFF100A19), Color(0xFF050505)],
                  )),
                  child: const Icon(Icons.add_a_photo_outlined, size: 62, color: Colors.white38),
                )
              : FullProfilePhoto(url: cover),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Colors.transparent, Colors.transparent, Colors.black.withOpacity(.55)]),
          ))),
          Positioned(left: 12, bottom: 12, child: Text(
            cover.isEmpty ? 'Adicione sua foto de capa' : 'Foto de capa',
            style: const TextStyle(color: Colors.white70, fontSize: 12, shadows: [Shadow(color: Colors.black, blurRadius: 5)]),
          )),
          Positioned(right: 12, bottom: 10, child: Material(
            color: Colors.black54, shape: const CircleBorder(),
            child: IconButton(onPressed: saving ? null : pickCoverPhoto,
              tooltip: 'Editar foto de capa', icon: const Icon(Icons.edit, color: Colors.white)),
          )),
          Positioned(left: 14, top: 12, child: Row(children: [
            const Icon(Icons.circle, size: 9, color: Colors.greenAccent),
            const SizedBox(width: 5),
            Text(isOnline ? 'Online' : 'LoveMix', style: const TextStyle(color: Colors.white, fontSize: 12, shadows: [Shadow(color: Colors.black, blurRadius: 5)])),
          ])),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Stack(clipBehavior: Clip.none, children: [
              GestureDetector(
                onTap: () => showFullPhoto(context, (profile['photoUrl'] ?? '').toString()),
                child: ProfileFrameAvatar(photoUrl: (profile['photoUrl'] ?? '').toString(), frameId: (profile['selectedProfileFrame'] ?? 'classic').toString(), size: 78),
              ),
              Positioned(right: -4, bottom: -4, child: Material(
                color: const Color(0xFFFF2DAB), shape: const CircleBorder(side: BorderSide(color: Color(0xFF090909), width: 2)),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: saving ? null : changePhotoMenu,
                  child: const SizedBox(width: 30, height: 30, child: Icon(Icons.edit, color: Colors.white, size: 16)),
                ),
              )),
            ])),
            const SizedBox(height: 12),
            VipNickname(name: '$displayName${age == null ? '' : ', $age'}', isVip: profile['isVip'] == true,
              styleId: (profile['vipNicknameStyle'] ?? 'royal_gold').toString(),
              textStyle: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Colors.white)),
            const SizedBox(height: 9),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: const Color(0xFF2A1A08),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFFFC857).withOpacity(.8)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.auto_awesome, color: Color(0xFFFFD76A), size: 17),
                const SizedBox(width: 6),
                Text('Carisma ${((profile['charisma'] as num?)?.toInt() ?? 0)}',
                  style: const TextStyle(color: Color(0xFFFFD76A), fontWeight: FontWeight.w800, fontSize: 12)),
              ]),
            ),
            if (_place.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3),
              child: Text(_place, style: const TextStyle(color: Colors.white60, fontSize: 13))),
            if (interests.isNotEmpty) ...[
              const SizedBox(height: 12),
              Wrap(spacing: 7, runSpacing: 7, children: interests.map((item) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                decoration: BoxDecoration(color: const Color(0xFF25202B), borderRadius: BorderRadius.circular(18), border: Border.all(color: _purple.withOpacity(.7))),
                child: Text(item, style: const TextStyle(color: Colors.white, fontSize: 12)),
              )).toList()),
            ],
            if (bio.text.trim().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12),
              child: Text(bio.text.trim(), maxLines: 4, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, height: 1.35))),
          ]),
        ),
      ]),
    );
  }

  Widget _previewButton(String label, Color color, {bool outlined = false}) => Container(
    height: 43,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: outlined ? Colors.transparent : color,
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: color, width: 1.5),
    ),
    child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
  );

  Widget _sectionHeader(IconData icon, String title, String subtitle) => Row(children: [
    Container(width: 39, height: 39, decoration: BoxDecoration(color: _purple.withOpacity(.2), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: _pink)),
    const SizedBox(width: 10),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      Text(subtitle, style: const TextStyle(color: _muted, fontSize: 11)),
    ])),
  ]);

  Widget _formCard(List<Widget> children) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF4B2867))),
    child: Column(children: children),
  );
}
