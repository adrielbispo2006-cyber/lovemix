import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'profile_view_screen.dart';
import 'call_screen.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import '../services/translation_service.dart';
import '../widgets/profile_frame.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  bool sendingImage = false;
  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _send(String value) async {
    final text = value.trim();
    if (text.isEmpty) return;
    input.clear();
    try { await DataService.instance.sendMessage(widget.chatId, text); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível enviar: $e'))); }
  }

  Future<void> _showTranslator({String initialText = ''}) async {
    final textController = TextEditingController(text: initialText);
    String source = 'en';
    String target = 'pt-BR';
    String? result;
    bool loading = false;
    String? error;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF1B1028),
          title: const Row(children: [
            Icon(Icons.translate, color: Color(0xFFFF2DAB)),
            SizedBox(width: 9),
            Text('Tradutor LoveMix'),
          ]),
          content: SingleChildScrollView(child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: source,
                dropdownColor: const Color(0xFF241A31),
                decoration: const InputDecoration(labelText: 'Idioma original'),
                items: const [
                  DropdownMenuItem(value: 'en', child: Text('Inglês')),
                  DropdownMenuItem(value: 'es', child: Text('Espanhol')),
                  DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() { source = v; if (source == target) target = source == 'pt-BR' ? 'en' : 'pt-BR'; }); },
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: target,
                dropdownColor: const Color(0xFF241A31),
                decoration: const InputDecoration(labelText: 'Traduzir para'),
                items: const [
                  DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                  DropdownMenuItem(value: 'en', child: Text('Inglês')),
                  DropdownMenuItem(value: 'es', child: Text('Espanhol')),
                ],
                onChanged: (v) { if (v != null) setDialogState(() => target = v); },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: textController,
                minLines: 2,
                maxLines: 5,
                maxLength: 450,
                decoration: const InputDecoration(
                  hintText: 'Digite uma palavra ou frase...',
                  border: OutlineInputBorder(),
                ),
              ),
              if (loading) const Center(child: Padding(
                padding: EdgeInsets.all(12),
                child: CircularProgressIndicator(color: Color(0xFFFF2DAB)),
              )),
              if (error != null) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(error!, style: const TextStyle(color: Colors.redAccent)),
              ),
              if (result != null) Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF321846),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SelectableText(result!, style: const TextStyle(color: Colors.white, fontSize: 16)),
              ),
            ],
          )),
          actions: [
            TextButton(onPressed: loading ? null : () => Navigator.pop(dialogContext), child: const Text('Fechar')),
            FilledButton.icon(
              onPressed: loading ? null : () async {
                setDialogState(() { loading = true; error = null; result = null; });
                try {
                  final translated = await TranslationService.instance.translate(
                    text: textController.text,
                    sourceLanguage: source,
                    targetLanguage: target,
                  );
                  setDialogState(() => result = translated);
                } catch (e) {
                  setDialogState(() => error = e.toString().replaceFirst('Exception: ', ''));
                } finally {
                  setDialogState(() => loading = false);
                }
              },
              icon: const Icon(Icons.translate),
              label: const Text('Traduzir'),
            ),
          ],
        ),
      ),
    );
    textController.dispose();
  }

  Future<void> _sendPhoto() async {
    if (sendingImage) return;
    try {
      final source = await showModalBottomSheet<ImageSource>(
        context: context,
        backgroundColor: const Color(0xFF1B1028),
        builder: (sheetContext) => SafeArea(
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFFFF2DAB)),
              title: const Text('Escolher da galeria'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFFFF2DAB)),
              title: const Text('Tirar uma foto agora'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.camera),
            ),
          ]),
        ),
      );
      if (source == null || !mounted) return;
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 78,
        maxWidth: 1600,
      );
      if (picked == null || !mounted) return;
      setState(() => sendingImage = true);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Entre na sua conta novamente.');
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A foto selecionada está vazia.');
      if (bytes.length > 4 *  1024 * 1024) {
        throw Exception('A foto deve ter no máximo 4 MB para passar pela verificação de segurança.');
      }
      // Não chamar checkPrivateChatImage aqui: instalações que ainda não
      // publicaram essa callable retornam firebase_functions/not-found e
      // impedem qualquer envio. A imagem fica pendente no Firestore e só
      // aparece após a Cloud Function moderatePrivateChatImage aprová-la.
      final fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'chats/${widget.chatId}/$uid/$fileName',
        bytes: bytes, contentType: 'image/jpeg',
      );
      await DataService.instance.messages(widget.chatId).add({
        'senderId': uid,
        'text': '📷 Foto',
        'imageUrl': url,
        'type': 'image',
        'moderationStatus': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível enviar a foto: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sendingImage = false);
    }
  }


  Future<void> _deleteMessage(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final mine = data['senderId'] == FirebaseAuth.instance.currentUser?.uid;
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('Apagar mensagem', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
        ListTile(leading: const Icon(Icons.delete_outline, color: Colors.white70), title: const Text('Apagar somente para mim'), onTap: () => Navigator.pop(ctx, 'me')),
        if (mine) ListTile(leading: const Icon(Icons.delete_forever, color: Colors.redAccent), title: const Text('Apagar para todos'), subtitle: const Text('A mensagem será removida da conversa'), onTap: () => Navigator.pop(ctx, 'all')),
        ListTile(title: const Text('Cancelar'), onTap: () => Navigator.pop(ctx)),
      ])),
    );
    if (choice == null) return;
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      if (choice == 'me') {
        await doc.reference.update({'hiddenFor': FieldValue.arrayUnion([uid])});
      } else {
        final imageUrl = (data['imageUrl'] ?? '').toString();
        await doc.reference.delete();
        if (imageUrl.isNotEmpty) {
          try { final removed = await SupabaseService.instance.deletePublicUrl(imageUrl); if (!removed) await FirebaseStorage.instance.refFromURL(imageUrl).delete(); } catch (_) {}
        }
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mensagem apagada.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar: $e')));
    }
  }

  void _quickReactions() {
    const reactions = ['❤️','😍','🥰','😘','😂','🔥','💜','🌹','🎁','🧸','💎','👑'];
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => Padding(padding: const EdgeInsets.all(18), child: Wrap(
        spacing: 12, runSpacing: 12,
        children: reactions.map((emoji) => InkWell(
          onTap: () { Navigator.pop(ctx); _send(emoji); },
          child: Container(width: 52, height: 52, alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF321846), borderRadius: BorderRadius.circular(14)),
            child: Text(emoji, style: const TextStyle(fontSize: 27))),
        )).toList(),
      )));
  }

  @override Widget build(BuildContext context) {
    final service = DataService.instance;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId).snapshots(),
            builder: (context, snap) {
              final ids = List<String>.from(snap.data?.data()?['users'] ?? const []);
              final others = ids.where((id) => id != uid).toList();
              final other = others.isEmpty ? null : others.first;
              if (other == null) return const CircleAvatar(radius: 18, child: Icon(Icons.person));
              return FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
                future: FirebaseFirestore.instance.collection('users').doc(other).get(),
                builder: (context, userSnap) {
                  final userData = userSnap.data?.data() ?? <String, dynamic>{};
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ProfileViewScreen(userId: other),
                    )),
                    child: ProfileFrameAvatar(photoUrl: (userData['photoUrl'] ?? '').toString(),
                      frameId: (userData['selectedProfileFrame'] ?? 'classic').toString(), size: 34),
                  );
                });
            },
          ),
          const SizedBox(width: 9),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.otherName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const Text('Disponível para conversar', style: TextStyle(fontSize: 10, color: Color(0xFFB7A9C4))),
          ]),
        ]),
        actions: [
          IconButton(tooltip: 'Tradutor', onPressed: () => _showTranslator(), icon: const Icon(Icons.translate, color: Color(0xFFFF2DAB))),
          IconButton(tooltip: 'Chamada de voz', onPressed: () => _startCall(video: false), icon: const Icon(Icons.call, color: Color(0xFFFF2DAB))),
          IconButton(tooltip: 'Chamada de vídeo', onPressed: () => _startCall(video: true), icon: const Icon(Icons.videocam, color: Color(0xFFFF2DAB))),
        ],
      ),
      body: Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
          stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Não foi possível carregar as mensagens.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs.where((d) {
              final data = d.data();
              final hidden = List<String>.from(data['hiddenFor'] ?? const []);
              if (hidden.contains(uid)) return false;
              // Imagens só aparecem após aprovação do moderador no servidor.
              if (data['type'] == 'image' && data['moderationStatus'] != 'approved') return false;
              return true;
            }).toList();
            if (docs.isEmpty) return const Center(child: Text('Diga oi e comece uma nova conversa! 💗'));
            return ListView.builder(padding: const EdgeInsets.all(14), itemCount: docs.length,
              itemBuilder: (context, i) {
                final m = docs[i].data();
                final mine = m['senderId'] == uid;
                final value = (m['text'] ?? '').toString();
                final isGift = m['type'] == 'gift';
                final isImage = m['type'] == 'image' && (m['imageUrl'] ?? '').toString().isNotEmpty;
                return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: GestureDetector(
                    onLongPress: () => _deleteMessage(docs[i]),
                    child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                    constraints: const BoxConstraints(maxWidth: 290),
                    decoration: BoxDecoration(
                      gradient: mine ? const LinearGradient(colors: [Color(0xFF8B22D4), Color(0xFF541A91)]) : null,
                      color: mine ? null : const Color(0xFF241A31),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(17), topRight: const Radius.circular(17),
                        bottomLeft: Radius.circular(mine ? 17 : 4), bottomRight: Radius.circular(mine ? 4 : 17)),
                      border: isGift ? Border.all(color: const Color(0xFFFF2DAB)) : null,
                    ),
                    child: isImage
                        ? GestureDetector(
                            onTap: () => showDialog<void>(
                              context: context,
                              builder: (dialogContext) => Dialog(
                                backgroundColor: const Color(0xFF100A19),
                                child: InteractiveViewer(
                                  child: Image.network(
                                    (m['imageUrl'] ?? '').toString(),
                                    fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => const Padding(
                                      padding: EdgeInsets.all(24),
                                      child: Text('Não foi possível carregar esta foto.'),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                (m['imageUrl'] ?? '').toString(),
                                width: 230,
                                height: 250,
                                fit: BoxFit.cover,
                                loadingBuilder: (context, child, progress) => progress == null
                                    ? child
                                    : const SizedBox(
                                        width: 230, height: 180,
                                        child: Center(child: CircularProgressIndicator()),
                                      ),
                                errorBuilder: (_, __, ___) => const SizedBox(
                                  width: 230, height: 100,
                                  child: Center(child: Text('Foto indisponível')),
                                ),
                              ),
                            ),
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(value, style: TextStyle(color: Colors.white, fontSize: isGift ? 20 : 15)),
                              if (!isGift && value.trim().isNotEmpty) Align(
                                alignment: Alignment.centerRight,
                                child: TextButton.icon(
                                  style: TextButton.styleFrom(
                                    foregroundColor: const Color(0xFFFFB4DF),
                                    visualDensity: VisualDensity.compact,
                                    padding: const EdgeInsets.only(top: 5, left: 4, right: 4),
                                  ),
                                  onPressed: () => _showTranslator(initialText: value),
                                  icon: const Icon(Icons.translate, size: 15),
                                  label: const Text('Traduzir', style: TextStyle(fontSize: 11)),
                                ),
                              ),
                            ],
                          ),
                  ),
                  ),
                );
              });
          },
        )),
        SafeArea(top: false, child: Container(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
          decoration: const BoxDecoration(color: Color(0xFF100A19), border: Border(top: BorderSide(color: Color(0xFF422052)))),
          child: Row(children: [
            IconButton(
              tooltip: 'Enviar foto',
              onPressed: sendingImage ? null : _sendPhoto,
              icon: sendingImage
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.photo_library_outlined, color: Color(0xFFFF2DAB)),
            ),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white70)),
            Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, textInputAction: TextInputAction.send, onSubmitted: _send,
              decoration: InputDecoration(hintText: 'Envie uma mensagem...', isDense: true,
                filled: true, fillColor: const Color(0xFF21162D), contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.card_giftcard, color: Color(0xFFFF2DAB))),
            IconButton(onPressed: () => _send(input.text), icon: const Icon(Icons.send_rounded, color: Color(0xFFFF2DAB))),
          ]),
        )),
      ]),
    );
  }

  Future<void> _startCall({required bool video}) async {
    final ok = await requestCallPermissions(context, video: video);
    if (!ok || !mounted) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
      final chat = await chatRef.get();
      final users = List<String>.from(chat.data()?['users'] ?? const []);
      final calleeUid = users.firstWhere((id) => id != uid, orElse: () => '');
      if (calleeUid.isEmpty) throw Exception('Não foi possível encontrar a outra pessoa da conversa.');
      final me = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final otherUser = await FirebaseFirestore.instance.collection('users').doc(calleeUid).get();
      final callRef = chatRef.collection('calls').doc();
      await callRef.set({
        'callId': callRef.id,
        'callerUid': uid,
        'calleeUid': calleeUid,
        'callerName': (me.data()?['name'] ?? 'LoveMix').toString(),
        'callerPhotoUrl': (me.data()?['photoUrl'] ?? '').toString(),
        'calleePhotoUrl': (otherUser.data()?['photoUrl'] ?? '').toString(),
        'participants': [uid, calleeUid],
        'video': video,
        'status': 'ringing',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => CallScreen(callRef: callRef, video: video, isCaller: true),
      ));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível iniciar a chamada: $e')),
        );
      }
    }
  }
}
