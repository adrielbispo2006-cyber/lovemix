# Correção do envio de fotos no PV

A tela do chat chamava `checkPrivateChatImage` antes de enviar a foto. Quando essa callable não estava publicada no Firebase, o app recebia `firebase_functions/not-found` e interrompia o envio.

A tela agora envia a imagem para o Supabase Storage e cria a mensagem no Firestore com `moderationStatus: pending`. A foto permanece oculta até a Cloud Function `moderatePrivateChatImage` analisar a imagem e atualizar o status para `approved`. Assim, não é necessário que a callable `checkPrivateChatImage` esteja publicada para iniciar o envio.

## Publicar as funções necessárias

No terminal, dentro da pasta `lovemix` do projeto:

```bash
cd functions
npm install
cd ..
npm --prefix functions run build
firebase deploy --only functions
```

O projeto Firebase selecionado deve ser `lovemix-73849`. A função `moderatePrivateChatImage` usa Google Cloud Vision; habilite a API Cloud Vision e o faturamento/conta de cobrança exigidos pelo Google Cloud para que a análise funcione. Se a função não for publicada ou a análise falhar, a mensagem fica pendente e a imagem não é exibida.

## Armazenamento

O bucket Supabase `lovemix-photos` precisa existir e permitir upload autenticado pelo app. O código usa o caminho `chats/{chatId}/{uid}/{arquivo}.jpg` e gera URL pública para a imagem ser carregada pelo destinatário.
