import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/data_service.dart';
import 'admin_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final name = TextEditingController();
  final bio = TextEditingController();
  final city = TextEditingController();
  bool loaded = false;
  bool saving = false;

  Future<void> pickPhoto() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 900, maxHeight: 900);
    if (picked == null) return;
    setState(() => saving = true);
    try {
      final uid = DataService.instance.uid;
      final ref = FirebaseStorage.instance.ref('profile_photos/$uid/main.jpg');
      await ref.putFile(File(picked.path));
      final url = await ref.getDownloadURL();
      await DataService.instance.updateProfile({'photoUrl': url});
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Foto atualizada.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Erro ao enviar foto.')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  @override
  void dispose() { name.dispose(); bio.dispose(); city.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: DataService.instance.myProfile(),
      builder: (context, snap) {
        final p = snap.data?.data() ?? {};
        if (!loaded && p.isNotEmpty) {
          name.text = (p['name'] ?? '').toString();
          bio.text = (p['bio'] ?? '').toString();
          city.text = (p['city'] ?? '').toString();
          loaded = true;
        }
        final photo = (p['photoUrl'] ?? '') as String;
        return ListView(padding: const EdgeInsets.all(18), children: [
          Center(
            child: Stack(children: [
              CircleAvatar(radius: 58, backgroundColor: const Color(0xFF443719),
                backgroundImage: photo.isEmpty ? null : NetworkImage(photo),
                child: photo.isEmpty ? const Icon(Icons.person, size: 55) : null),
              Positioned(right: 0, bottom: 0, child: IconButton.filled(
                onPressed: saving ? null : pickPhoto, icon: const Icon(Icons.camera_alt))),
            ]),
          ),
          const SizedBox(height: 20),
          const Text('Editar perfil', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
          const SizedBox(height: 12),
          TextField(controller: bio, maxLines: 3, decoration: const InputDecoration(labelText: 'Bio')),
          const SizedBox(height: 12),
          TextField(controller: city, decoration: const InputDecoration(labelText: 'Cidade')),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: () async {
            await DataService.instance.updateProfile({'name': name.text.trim(), 'bio': bio.text.trim(), 'city': city.text.trim()});
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Perfil salvo.')));
          }, child: const Text('Salvar perfil')),
          const SizedBox(height: 10),
          if (p['isAdmin'] == true)
            OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())),
              icon: const Icon(Icons.admin_panel_settings), label: const Text('Painel administrativo')),
          OutlinedButton.icon(
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Excluir conta?'),
                  content: const Text('A exclusão é permanente. Talvez seja necessário entrar novamente antes de confirmar.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir')),
                  ],
                ),
              );
              if (confirm != true) return;
              try {
                await DataService.instance.deleteMyAccount();
              } on FirebaseAuthException catch (e) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(e.code == 'requires-recent-login'
                    ? 'Por segurança, saia e entre novamente antes de excluir a conta.'
                    : 'Não foi possível excluir a conta.')),
                );
              }
            },
            icon: const Icon(Icons.delete_forever),
            label: const Text('Excluir minha conta'),
          ),
          OutlinedButton.icon(onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout), label: const Text('Sair da conta')),
        ]);
      },
    );
  }
}
