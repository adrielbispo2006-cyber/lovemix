import 'package:flutter/material.dart';

void main() => runApp(const GameMixApp());

const purple = Color(0xFF9B5CFF);
const bg = Color(0xFF100D16);
const panel = Color(0xFF211A2B);

class GameMixApp extends StatelessWidget {
  const GameMixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Appsdroid',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0),
      ),
      home: const StoreHome(),
    );
  }
}

class StoreHome extends StatefulWidget {
  const StoreHome({super.key});
  @override
  State<StoreHome> createState() => _StoreHomeState();
}

class _StoreHomeState extends State<StoreHome> {
  int tab = 0;
  final pages = const [DiscoverPage(), PublishPage(), AccountPage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.videogame_asset_rounded, color: purple, size: 29),
          SizedBox(width: 8),
          Text('Appsdroid', style: TextStyle(fontWeight: FontWeight.w900)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Pesquisar',
            onPressed: () => showSearch(context: context, delegate: AppSearch()),
            icon: const Icon(Icons.search),
          ),
        ],
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: Center(
                child: Opacity(
                  opacity: 0.13,
                  child: Image.asset(
                    'assets/appsdroid_wallpaper.png',
                    fit: BoxFit.contain,
                    width: MediaQuery.of(context).size.width * 0.88,
                  ),
                ),
              ),
            ),
          ),
          pages[tab],
        ],
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        selectedIndex: tab,
        indicatorColor: purple.withOpacity(.22),
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Loja'),
          NavigationDestination(icon: Icon(Icons.cloud_upload_outlined), selectedIcon: Icon(Icons.cloud_upload), label: 'Publicar'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Conta'),
        ],
      ),
    );
  }
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF482078), Color(0xFF21152F)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SEU UNIVERSO DIGITAL', style: TextStyle(letterSpacing: 1.5, color: Colors.white70, fontSize: 11)),
            SizedBox(height: 8),
            Text('Jogos e apps\\nnum só lugar.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
            SizedBox(height: 8),
            Text('Descubra novidades na Appsdroid.', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 24),
        const SectionTitle('Categorias'),
        const SizedBox(height: 12),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          CategoryChip(icon: Icons.sports_esports, label: 'Jogos'),
          CategoryChip(icon: Icons.apps, label: 'Aplicativos'),
          CategoryChip(icon: Icons.school, label: 'Educação'),
          CategoryChip(icon: Icons.music_note, label: 'Música'),
          CategoryChip(icon: Icons.photo, label: 'Fotografia'),
        ]),
        const SizedBox(height: 24),
        const SectionTitle('Em destaque'),
        const SizedBox(height: 12),
        const AppTile(name: 'Seu próximo jogo favorito', category: 'Jogos • Em breve', icon: Icons.gamepad, description: 'Os aplicativos publicados e aprovados aparecerão aqui.'),
        const AppTile(name: 'Novos aplicativos', category: 'Aplicativos • Em breve', icon: Icons.apps, description: 'Explore ferramentas e novidades da comunidade.'),
        const SizedBox(height: 16),
        const Text('Esta é uma versão inicial demonstrativa. Os downloads reais serão ativados após configurar o servidor e o armazenamento.', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ],
    );
  }
}

class PublishPage extends StatelessWidget {
  const PublishPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('Área do desenvolvedor', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('Prepare sua publicação. Nesta versão inicial, o formulário é demonstrativo; o envio de APK será conectado ao Firebase/backend na próxima etapa.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 22),
        const _InfoCard(icon: Icons.upload_file, title: 'Enviar arquivo APK', body: 'Selecione o pacote Android do seu aplicativo.'),
        const _InfoCard(icon: Icons.image_outlined, title: 'Ícone e imagens', body: 'Adicione imagens para apresentar seu app.'),
        const _InfoCard(icon: Icons.description_outlined, title: 'Descrição e versão', body: 'Informe nome, categoria, versão e descrição.'),
        const SizedBox(height: 12),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(16)),
          onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(
            title: Text('Publicação ainda não ativada'),
            content: Text('O envio real precisa de autenticação, armazenamento seguro e análise de arquivos no servidor.'),
          )),
          icon: const Icon(Icons.add),
          label: const Text('Começar publicação'),
        ),
      ],
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const CircleAvatar(radius: 38, backgroundColor: panel, child: Icon(Icons.person, size: 42, color: purple)),
      const SizedBox(height: 12),
      const Center(child: Text('Minha conta', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
      const SizedBox(height: 20),
      const _InfoCard(icon: Icons.login, title: 'Entrar ou criar conta', body: 'Cadastro de usuários será conectado ao Firebase Authentication.'),
      const _InfoCard(icon: Icons.verified_user_outlined, title: 'Conta de desenvolvedor', body: 'Solicite acesso para publicar aplicativos.'),
      const _InfoCard(icon: Icons.admin_panel_settings_outlined, title: 'Administração', body: 'A aprovação de publicações será restrita ao administrador autorizado no servidor.'),
    ],
  );
}

class AppSearch extends SearchDelegate<String> {
  @override
  List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override
  Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override
  Widget buildResults(BuildContext context) => Center(child: Text('Busca por: $query'));
  @override
  Widget buildSuggestions(BuildContext context) => const Center(child: Text('Pesquise jogos e aplicativos'));
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800));
}

class CategoryChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const CategoryChip({required this.icon, required this.label, super.key});
  @override
  Widget build(BuildContext context) => Chip(
    avatar: Icon(icon, size: 18, color: purple),
    label: Text(label),
    backgroundColor: panel,
    side: BorderSide.none,
  );
}

class AppTile extends StatelessWidget {
  final String name, category, description;
  final IconData icon;
  const AppTile({required this.name, required this.category, required this.icon, required this.description, super.key});
  @override
  Widget build(BuildContext context) => Card(
    color: panel,
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      contentPadding: const EdgeInsets.all(12),
      leading: Container(width: 52, height: 52, decoration: BoxDecoration(color: purple.withOpacity(.18), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: purple, size: 28)),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('$category\\n$description'),
      isThreeLine: true,
    ),
  );
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title, body;
  const _InfoCard({required this.icon, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Card(
    color: panel,
    margin: const EdgeInsets.only(bottom: 12),
    child: ListTile(
      leading: Icon(icon, color: purple, size: 29),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(body),
    ),
  );
}
