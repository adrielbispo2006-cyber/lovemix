# Appsdroid

Projeto inicial Flutter para uma loja Android de jogos e aplicativos, com identidade visual roxa e preta.

## O que já existe
- Tela inicial e categorias.
- Pesquisa visual.
- Área de desenvolvedor/publicação demonstrativa.
- Área de conta e administração demonstrativa.
- Workflow GitHub Actions para compilar APK e publicar artefato com SHA-1/SHA-256.

## Importante
Este ZIP é uma base inicial funcional de interface, não uma loja pronta para produção. Login, upload real de APK, banco de dados, moderação, avaliações e downloads ainda precisam de backend/Firebase e regras de segurança. Não coloque credenciais administrativas dentro do aplicativo.

## Como compilar
1. Crie um repositório GitHub e envie o conteúdo deste ZIP.
2. Abra Actions.
3. Selecione **Gerar APK Appsdroid** e toque em **Run workflow**.
4. Quando terminar, baixe o artefato **Appsdroid-APK** na execução.

É necessário que o repositório contenha a pasta `.github/workflows/main.yml`.
