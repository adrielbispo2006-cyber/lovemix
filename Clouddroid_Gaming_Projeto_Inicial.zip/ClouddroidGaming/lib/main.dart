import 'package:flutter/material.dart';

void main() => runApp(const ClouddroidApp());

const purple = Color(0xFF9B5CFF);
const background = Color(0xFF090811);
const panel = Color(0xFF171322);

class ClouddroidApp extends StatelessWidget {
  const ClouddroidApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Clouddroid Gaming',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

class Game {
  final String title;
  final String category;
  final String platform;
  const Game(this.title, this.category, this.platform);
}

const games = <Game>[
  Game('Grand Theft Auto', 'Ação e mundo aberto', 'PC / Console'),
  Game('Free Fire', 'Battle royale', 'Android'),
  Game('The Last of Us Part I', 'Ação e aventura', 'PC / Console'),
  Game('The Last of Us Part II', 'Ação e aventura', 'Console'),
  Game('Resident Evil 0', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil 2 Remake', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil 3 Remake', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil 4 Remake', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil 5', 'Terror e ação', 'PC / Console'),
  Game('Resident Evil 6', 'Terror e ação', 'PC / Console'),
  Game('Resident Evil 7', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil Village', 'Terror e sobrevivência', 'PC / Console'),
  Game('Resident Evil Requiem', 'Terror e sobrevivência', 'A confirmar'),
  Game('Red Dead Redemption 2', 'Ação e mundo aberto', 'PC / Console'),
  Game('God of War Ragnarök', 'Ação e aventura', 'PC / Console'),
  Game('Spider-Man: Miles Morales', 'Ação e aventura', 'PC / Console'),
  Game('Elden Ring', 'RPG e ação', 'PC / Console'),
  Game('Cyberpunk 2077', 'RPG e mundo aberto', 'PC / Console'),
  Game('Hogwarts Legacy', 'Aventura', 'PC / Console'),
  Game('Call of Duty', 'Tiro', 'PC / Console'),
  Game('PUBG', 'Battle royale', 'PC / Console / Mobile'),
  Game('Dying Light 2', 'Ação e sobrevivência', 'PC / Console'),
  Game('Days Gone', 'Ação e sobrevivência', 'PC / Console'),
  Game('Forza Horizon 5', 'Corrida', 'PC / Console'),
  Game('Need for Speed', 'Corrida', 'PC / Console'),
  Game('EA Sports FC', 'Esportes', 'PC / Console'),
  Game('F1', 'Corrida', 'PC / Console'),
  Game('Minecraft', 'Sandbox', 'PC / Console / Mobile'),
  Game('The Sims 4', 'Simulação', 'PC / Console'),
  Game('Terraria', 'Aventura e sandbox', 'PC / Console / Mobile'),
  Game('Mortal Kombat 1', 'Luta', 'PC / Console'),
  Game('Tekken 8', 'Luta', 'PC / Console'),
  Game('Street Fighter 6', 'Luta', 'PC / Console'),
  Game('Assassin’s Creed Shadows', 'Ação e aventura', 'PC / Console'),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  String query = '';
  String category = 'Todos';

  List<String> get categories => ['Todos', ...{
    for (final game in games) game.category
  }.toList()..sort()];

  @override
  Widget build(BuildContext context) {
    final filtered = games.where((g) {
      final matchesQuery = g.title.toLowerCase().contains(query.toLowerCase());
      final matchesCategory = category == 'Todos' || g.category == category;
      return matchesQuery && matchesCategory;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: background,
        title: const Row(
          children: [
            Icon(Icons.cloud_outlined, color: purple, size: 30),
            SizedBox(width: 9),
            Text('CLOUDDROID', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Perfil',
            onPressed: () => _info('Perfil', 'A área de conta será conectada ao serviço de autenticação na próxima etapa.'),
            icon: const Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      body: tab == 0
          ? _catalog(filtered)
          : tab == 1
              ? const TranslatorScreen()
              : const AccountScreen(),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        indicatorColor: purple.withValues(alpha: .22),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Jogos'),
          NavigationDestination(icon: Icon(Icons.translate), label: 'Tradutor'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Conta'),
        ],
      ),
    );
  }

  Widget _catalog(List<Game> filtered) {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  colors: [Color(0xFF38205E), Color(0xFF171126), Color(0xFF10101A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(color: purple.withValues(alpha: .45)),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SEU PRÓXIMO JOGO COMEÇA AQUI', style: TextStyle(color: Color(0xFFD9C4FF), fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text('Jogue na nuvem.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
                  SizedBox(height: 5),
                  Text('Um catálogo para acessar pelo celular. O streaming será ativado quando um servidor compatível estiver conectado.', style: TextStyle(color: Colors.white70, height: 1.35)),
                  SizedBox(height: 14),
                  Row(children: [Icon(Icons.cloud_queue, color: purple), SizedBox(width: 7), Text('Plataforma em construção', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))]),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: InputDecoration(
                hintText: 'Buscar jogo...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: panel,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 45,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              scrollDirection: Axis.horizontal,
              children: categories.map((c) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(c),
                  selected: category == c,
                  onSelected: (_) => setState(() => category = c),
                  selectedColor: purple.withValues(alpha: .35),
                ),
              )).toList(),
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final game = filtered[index];
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _gameInfo(game),
                  child: Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: panel,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.white.withValues(alpha: .07)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 43,
                          width: 43,
                          decoration: BoxDecoration(color: purple.withValues(alpha: .18), borderRadius: BorderRadius.circular(13)),
                          child: const Icon(Icons.videogame_asset_rounded, color: Color(0xFFC7A4FF), size: 25),
                        ),
                        const Spacer(),
                        Text(game.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                        const SizedBox(height: 4),
                        Text(game.category, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                        const SizedBox(height: 9),
                        const Row(children: [
                          Icon(Icons.lock_clock_outlined, color: Colors.orangeAccent, size: 14),
                          SizedBox(width: 4),
                          Expanded(child: Text('Aguardando servidor', style: TextStyle(color: Colors.orangeAccent, fontSize: 10, fontWeight: FontWeight.w600))),
                        ]),
                      ],
                    ),
                  ),
                );
              },
              childCount: filtered.length,
            ),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.18,
            ),
          ),
        ),
      ],
    );
  }

  void _gameInfo(Game game) {
    showModalBottomSheet(
      context: context,
      backgroundColor: panel,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 8, 22, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(game.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('${game.category} • ${game.platform}', style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 15),
            const Text('Este título está no catálogo planejado. Para jogar, ainda é necessário conectar um provedor de cloud gaming, verificar a compatibilidade e garantir a licença/cópia do jogo.'),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.notifications_active_outlined),
              label: const Text('Entendi'),
            ),
          ],
        ),
      ),
    );
  }

  void _info(String title, String message) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: panel,
      title: Text(title),
      content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Fechar'))],
    ));
  }
}

class TranslatorScreen extends StatelessWidget {
  const TranslatorScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      const Icon(Icons.translate_rounded, color: purple, size: 52),
      const SizedBox(height: 14),
      const Text('Tradutor Gamer', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const Text('Objetivo: ajudar a jogar em português brasileiro, inclusive quando o jogo não oferece tradução oficial.', style: TextStyle(color: Colors.white70, height: 1.4)),
      const SizedBox(height: 20),
      _feature(Icons.subtitles, 'Legendas em português', 'Depende do suporte do jogo e da fonte de legendas.'),
      _feature(Icons.menu_book_outlined, 'Menus e textos', 'Pode exigir pacote de tradução compatível.'),
      _feature(Icons.groups_outlined, 'Traduções da comunidade', 'Importar apenas arquivos permitidos pelos termos do jogo.'),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
        child: const Text('O tradutor ainda é uma área de interface. Tradução automática em tempo real requer integração técnica própria e não funciona em todos os jogos.', style: TextStyle(color: Colors.orangeAccent)),
      ),
    ],
  );

  Widget _feature(IconData icon, String title, String detail) => ListTile(
    contentPadding: EdgeInsets.zero,
    leading: CircleAvatar(backgroundColor: purple.withValues(alpha: .18), child: Icon(icon, color: purple)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(detail, style: const TextStyle(color: Colors.white60)),
  );
}

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: const [
      CircleAvatar(radius: 38, backgroundColor: Color(0xFF38205E), child: Icon(Icons.person, size: 42, color: Color(0xFFC7A4FF))),
      SizedBox(height: 16),
      Center(child: Text('Sua conta Clouddroid', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
      SizedBox(height: 8),
      Text('O cadastro e o login serão conectados ao backend na próxima etapa.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
      SizedBox(height: 24),
      Card(color: panel, child: ListTile(leading: Icon(Icons.shield_outlined, color: purple), title: Text('Privacidade e segurança'), subtitle: Text('Configurações serão disponibilizadas na integração.'))),
      Card(color: panel, child: ListTile(leading: Icon(Icons.help_outline, color: purple), title: Text('Ajuda'), subtitle: Text('Clouddroid Gaming • versão inicial'))),
    ],
  );
}
