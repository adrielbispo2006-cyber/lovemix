# Reconexão automática do LoveMix

As telas de chamadas 1:1, salas de voz e lives agora exibem o estado de conexão informado pelo ZEGO.

- Durante uma oscilação, o app mostra “Tentando reconectar...”.
- Quando a conexão volta, o aviso desaparece ao receber o estado de reconexão bem-sucedida.
- Se o SDK informar falha de reconexão, o app orienta a verificar a internet.
- O ZEGO Express faz tentativas internas de reconexão de sala e dos fluxos de áudio/vídeo. O período padrão documentado é de até 20 minutos; após esse limite, pode ser necessário entrar novamente na sala.

A reconexão depende de a rede voltar e de o serviço ZEGO conseguir restabelecer a sessão. O código não promete continuidade se o Wi-Fi ou os dados móveis permanecerem indisponíveis.
