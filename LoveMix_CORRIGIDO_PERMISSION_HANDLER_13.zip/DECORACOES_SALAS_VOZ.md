# Papéis de parede das salas de voz LoveMix

Foram adicionados quatro temas de sala compartilhados via documento Firestore `rooms/{roomId}`:

- `royal`: Realeza, roxo e dourado
- `galaxy`: Galáxia, azul/roxo e estrelas
- `luxury`: Luxo, preto e dourado
- `romantic`: Romântica, rosa e roxo

O dono da sala escolhe em Mais > Papel de parede da sala. A escolha é salva em `wallpaperType` e os participantes recebem a atualização pelo stream da sala. Também continuam disponíveis Original LoveMix, Baú mágico roxo, Neon roxo e rosa e imagem personalizada.

**Importante:** publique as regras atualizadas do Firestore junto com o APK para aceitar os novos valores de `wallpaperType`.

## Tema Sala Luxo LoveMix

Foi incluído o tema `love_luxury`, selecionável pelo dono em Mais > Papel de parede da sala. Ele adiciona letreiro LoveMix com coroa e corações, moldura neon, sofás laterais, plantas decorativas, palco circular e baú central. Os assentos, avatares, microfones, chat, presentes e controles continuam sendo componentes reais do aplicativo e ficam por cima da decoração. A seleção é salva no Firestore e sincronizada para todos os participantes.

Publique também `firestore.rules` atualizado para permitir `wallpaperType: love_luxury`.
