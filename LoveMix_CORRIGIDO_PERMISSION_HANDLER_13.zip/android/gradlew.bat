@echo off
set GRADLE_VERSION=8.14.3
set GRADLE_HOME=%USERPROFILE%\.gradle\lovemix-gradle\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Execute este projeto em ambiente com Gradle instalado ou use GitHub Actions.
  exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%~dp0" %*
