package com.example.lovemix

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
