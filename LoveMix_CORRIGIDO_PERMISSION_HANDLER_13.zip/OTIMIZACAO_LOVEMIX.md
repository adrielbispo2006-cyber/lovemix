# Otimização do LoveMix

## Alterações aplicadas
- Baú decorativo convertido de PNG para WebP, preservando o desenho e reduzindo o peso do recurso empacotado.
- Imagens do baú passam a solicitar dimensões de decodificação menores nos pontos em que são exibidas em miniatura, reduzindo pressão de memória.
- Miniaturas das fotos do perfil usam cache de imagem e limite de decodificação de 360 px.
- Arquivos-fonte dos ícones de lançamento redimensionados para 1024 px e salvos com compressão PNG otimizada.
- Upload de papel de parede da sala limitado a 1280 px, qualidade 76 e 4 MB para reduzir tráfego e armazenamento.
- Corrigidas duas sequências de escape literais acidentais em `lib/main.dart` e `lib/app.dart` que impediam a leitura normal do código Dart.

## Preservado
- Tema roxo/preto e decoração Sala Luxo.
- Funcionalidades e telas existentes, dependências, Firebase, Supabase e Zego.
- Ícones do aplicativo.

## Verificação
- ZIP e integridade dos arquivos verificados.
- O ambiente de edição não possui Flutter/Dart instalado; portanto `flutter pub get`, análise estática e compilação APK não puderam ser executados aqui. Execute esses passos no ambiente de build antes de publicar.
