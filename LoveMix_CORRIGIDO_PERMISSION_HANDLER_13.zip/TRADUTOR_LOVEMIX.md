# Tradutor LoveMix

Foi adicionado um tradutor às conversas individuais:

- Ícone de tradução no topo do chat para abrir o tradutor independente.
- Ação **Traduzir** em cada mensagem de texto.
- Idiomas de origem: inglês, espanhol e português.
- Idiomas de destino: português, inglês e espanhol.
- Resultado exibido na conversa sem alterar nem reenviar a mensagem original.

A tradução usa o serviço online MyMemory e requer conexão com a internet. O texto digitado ou selecionado para tradução é enviado ao provedor externo para processamento. O serviço limita cada solicitação a 450 caracteres e pode aplicar limites de uso.
