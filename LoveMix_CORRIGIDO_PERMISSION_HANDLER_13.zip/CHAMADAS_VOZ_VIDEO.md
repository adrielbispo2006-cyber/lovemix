# Chamadas de voz e vídeo LoveMix

## O que foi implementado
- Convite de chamada individual salvo em `chats/{chatId}/calls/{callId}`.
- Convite recebido em tempo real enquanto o LoveMix está aberto, mesmo fora da conversa.
- Tela de chamada recebida com opções **Atender** e **Recusar**.
- Tela **Chamando...** para quem iniciou.
- Tempo limite de 30 segundos; se ninguém atender, o convite passa para `missed`.
- Se a pessoa recusar, quem ligou recebe o aviso de chamada recusada.
- A sala ZEGOCLOUD usa um ID exclusivo por ligação.
- Cronômetro começa quando o estado muda para `accepted`.
- Encerrar pela tela de espera ou sair da tela de chamada encerra o registro para os dois.
- As mensagens repetidas “Chamada iniciada...” não são mais enviadas ao chat.

## Obrigatório publicar as regras do Firestore
As chamadas usam a subcoleção `calls` dentro de cada conversa. Publique o arquivo `firestore.rules` deste ZIP no Firebase Console > Firestore Database > Rules, ou pelo terminal na raiz do projeto:

```bash
firebase deploy --only firestore:rules
```

## Verificações no painel ZEGOCLOUD
Confirme que o projeto com App ID `2116602891` está ativo e que o AppSign configurado no projeto corresponde ao mesmo projeto. O AppSign atual está no arquivo `lib/services/zego_config.dart`.

## Teste recomendado
1. Instale o APK em dois celulares, com duas contas diferentes.
2. Abra o LoveMix nos dois aparelhos e entre na mesma conversa.
3. No primeiro aparelho, toque no telefone.
4. No segundo, aceite a chamada; confira o áudio e o cronômetro.
5. Repita com o botão de vídeo e permita a câmera.
6. Teste recusar e deixar tocar por 30 segundos.

## Limitação importante
O convite em tempo real é recebido enquanto o aplicativo está aberto e autenticado. Para tocar como uma ligação telefônica mesmo com o aplicativo encerrado ou em segundo plano, ainda é necessário configurar notificações push de chamada (FCM) e o tratamento de abertura da chamada ao tocar na notificação.


## Atualização: câmera e foto na chamada de voz
- Na chamada de vídeo, a barra de controles padrão da ZEGOCLOUD mantém o botão de câmera para cada participante desligar e ligar a própria câmera durante a ligação. Desligar a câmera não encerra o áudio nem a chamada.
- Na chamada de voz, o app inicia com a câmera desligada e usa o avatar circular personalizado com as fotos de perfil dos dois participantes.
- Os campos `callerPhotoUrl` e `calleePhotoUrl` são gravados no documento da chamada para que ambos os aparelhos exibam a foto correta.


Atualização de interface: nas chamadas de vídeo, a configuração inicia a câmera e a barra padrão da ZEGOCLOUD oferece o controle para cada participante desligar/ligar sua própria câmera. Nas chamadas de voz, o avatar circular usa a foto de perfil do participante quando disponível.
