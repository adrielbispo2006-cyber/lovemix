# Correção do conflito ZEGO / file_picker

- Atualizado `file_picker` de `^8.1.7` para `^13.1.0`, atendendo à versão mínima exigida pelo `zego_uikit` usado neste projeto.
- Migrado o seletor de música dos stories para `FilePicker.pickFile()` e leitura por `PlatformFile.readAsBytes()`, removendo os parâmetros `allowMultiple` e `withData` que não existem mais na API v13.
- Mantidas a seleção de áudio, a validação de extensão e o limite de 10 MB.

Após enviar os arquivos ao GitHub, execute novamente o workflow. A compilação ainda precisa ser confirmada pelo GitHub Actions; este ambiente não possui Flutter instalado.
