# Atualização de notificações LoveMix

Esta atualização adiciona uma central de notificações no sino da tela inicial.

## O que foi incluído
- Contador rosa de notificações não lidas no sino.
- Notificações na central quando outra pessoa curte ou comenta um story.
- Notificações quando outra pessoa curte ou comenta uma publicação da Comunidade (`feed_posts`).
- O autor não recebe notificação por curtir/comentar o próprio conteúdo.
- Ao abrir a notificação, ela é marcada como lida e o app abre o story ou a publicação correspondente.
- Notificações push para dispositivos com token FCM registrado.

## Etapa necessária no Firebase
As notificações automáticas são criadas pelas Cloud Functions. Depois de enviar o projeto ao GitHub, também é necessário publicar as Functions no projeto Firebase:

```bash
cd functions
npm install
npm run build
firebase deploy --only functions
```

As regras atuais do Firestore já permitem que cada usuário leia e marque como lidas somente as notificações da própria conta. Se as regras forem alteradas no futuro, preserve essa restrição.

## Observação de teste
A compilação Flutter/APK não foi executada neste ambiente. Teste no Firebase após publicar as Cloud Functions: use duas contas, publique um story ou uma foto na Comunidade na primeira conta e curta/comente pela segunda.
