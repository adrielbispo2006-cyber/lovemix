import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';
import 'profile_frames_screen.dart';

class VipNicknameScreen extends StatelessWidget {
  const VipNicknameScreen({super.key});

  // Molduras especiais VIP (mesmos ids da loja de molduras).
  static const vipFrames = <Map<String, Object>>[
    {'id': 'gold', 'name': 'Dourada VIP', 'emoji': '👑', 'cost': 50},
    {'id': 'royal_crown', 'name': 'Rainha Real', 'emoji': '👑', 'cost': 80},
    {'id': 'royal_purple', 'name': 'Realeza Roxa', 'emoji': '💜', 'cost': 75},
    {'id': 'cosmic', 'name': 'Galáxia', 'emoji': '🌌', 'cost': 100},
    {'id': 'flame', 'name': 'Chamas', 'emoji': '🔥', 'cost': 70},
    {'id': 'angel', 'name': 'Asas de Anjo', 'emoji': '🪽', 'cost': 90},
    {'id': 'love_wings', 'name': 'Asas LoveMix', 'emoji': '💞', 'cost': 120},
    {'id': 'diamond_heart', 'name': 'Coração de Diamante', 'emoji': '💎', 'cost': 110},
    {'id': 'butterfly_royal', 'name': 'Borboleta Real', 'emoji': '🦋', 'cost': 130},
    {'id': 'rose_gold', 'name': 'Rosa de Ouro', 'emoji': '🌹', 'cost': 140},
    {'id': 'celestial', 'name': 'Celestial VIP', 'emoji': '😇', 'cost': 150},
    {'id': 'royal_wings', 'name': 'Asas da Realeza', 'emoji': '🪽', 'cost': 160},
    {'id': 'diamond_crown', 'name': 'Coroa de Diamantes', 'emoji': '💎', 'cost': 180},
    {'id': 'lovemix_deluxe', 'name': 'LoveMix Deluxe', 'emoji': '💖', 'cost': 200},
  ];

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Área VIP'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          final data = snap.data?.data() ?? <String, dynamic>{};
          final isVip = data['isVip'] == true;
          final selected = (data['vipNicknameStyle'] ?? 'royal_gold').toString();
          final name = (data['name'] ?? 'Seu nome').toString();
          final photo = (data['photoUrl'] ?? '').toString();
          final owned = List<String>.from(data['ownedProfileFrames'] ?? const ['classic']);
          final equipped = (data['profileFrame'] ?? data['selectedProfileFrame'] ?? 'classic').toString();
          return ListView(padding: const EdgeInsets.all(16), children: [
            const Text('Molduras VIP',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFFFFD56A))),
            const SizedBox(height: 4),
            const Text('Escolha uma moldura VIP ou abra a coleção completa logo abaixo.',
                style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: .78,
              children: vipFrames.map((f) {
                final id = f['id'] as String;
                final has = owned.contains(id);
                return InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen())),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF171022),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: equipped == id ? const Color(0xFFFF19B8) : const Color(0xFF58356A)),
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      ProfileFrameAvatar(photoUrl: photo, frameId: id, size: 62),
                      const SizedBox(height: 8),
                      Text('${f['emoji']} ${f['name']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 2),
                      Text(has ? 'Você tem' : '${f['cost']} 💎',
                          style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 11, fontWeight: FontWeight.w800)),
                    ]),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            Card(
              color: const Color(0xFF171022),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: const BorderSide(color: Color(0xFF8D35FF), width: 1),
              ),
              child: ListTile(
                leading: const Icon(Icons.auto_awesome, color: Color(0xFFFF19B8), size: 30),
                title: const Text('Ver todas as molduras',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                subtitle: const Text('Acesse a coleção completa, compre e equipe suas molduras aqui na área VIP.',
                    style: TextStyle(color: Colors.white60)),
                trailing: const Icon(Icons.chevron_right, color: Color(0xFFFF19B8)),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfileFramesScreen()),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text('Decoração do nick',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white)),
            const SizedBox(height: 8),
            if (!isVip)
              const Text('As decorações de nick são exclusivas para membros VIP 👑',
                  style: TextStyle(color: Colors.white70, fontSize: 15))
            else ...[
              const Text('Escolha sua decoração VIP', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 12),
              ...VipNickname.styles.entries.map((entry) => Card(
                    color: const Color(0xFF171022),
                    child: ListTile(
                      leading: const Icon(Icons.workspace_premium, color: Color(0xFFFFD56A)),
                      title: VipNickname(name: name, isVip: true, styleId: entry.key),
                      subtitle: Text(entry.value['label'] as String, style: const TextStyle(color: Colors.white54)),
                      trailing: selected == entry.key
                          ? const Icon(Icons.check_circle, color: Color(0xFFFF19B8))
                          : const Icon(Icons.chevron_right),
                      onTap: () async {
                        await FirebaseFirestore.instance
                            .collection('users')
                            .doc(uid)
                            .set({'vipNicknameStyle': entry.key}, SetOptions(merge: true));
                        if (context.mounted) {
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(content: Text('Nick VIP atualizado!')));
                        }
                      },
                    ),
                  )),
            ],
          ]);
        },
      ),
    );
  }
}
