
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'community_post_detail_screen.dart';
import 'stories_widget.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  static const pink = Color(0xFFFF19B8);
  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';

  Stream<QuerySnapshot<Map<String, dynamic>>> get _stream =>
      FirebaseFirestore.instance
          .collection('users')
          .doc(_uid)
          .collection('notifications')
          .orderBy('createdAt', descending: true)
          .limit(100)
          .snapshots();

  IconData _icon(String type) {
    if (type.contains('like')) return Icons.favorite;
    if (type.contains('comment')) return Icons.chat_bubble;
    return Icons.notifications;
  }

  String _message(Map<String, dynamic> data) {
    final name = (data['fromName'] ?? 'Alguém').toString();
    switch ((data['type'] ?? '').toString()) {
      case 'story_like':
        return '$name curtiu seu story.';
      case 'story_comment':
        return '$name comentou no seu story: ${(data['comment'] ?? '').toString()}';
      case 'post_like':
        return '$name curtiu sua publicação da comunidade.';
      case 'post_comment':
        return '$name comentou na sua publicação: ${(data['comment'] ?? '').toString()}';
      default:
        return (data['body'] ?? 'Você tem uma nova notificação.').toString();
    }
  }

  Future<void> _open(BuildContext context, QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final type = (data['type'] ?? '').toString();
    await doc.reference.update({'read': true});
    if (!context.mounted) return;

    if (type == 'story_like' || type == 'story_comment') {
      final storyId = (data['storyId'] ?? '').toString();
      if (storyId.isEmpty) return;
      final db = FirebaseFirestore.instance;
      final story = await db.collection('stories').doc(storyId).get();
      if (!story.exists || !context.mounted) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Este story já expirou ou foi removido.')),
          );
        }
        return;
      }
      final ownerId = (story.data()?['ownerId'] ?? '').toString();
      final active = await db
          .collection('stories')
          .where('expiresAt', isGreaterThan: Timestamp.now())
          .orderBy('expiresAt')
          .get();
      final ownerStories = active.docs
          .where((item) => (item.data()['ownerId'] ?? '') == ownerId)
          .toList();
      if (ownerStories.isEmpty || !context.mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => StoryViewer(stories: ownerStories),
      ));
      return;
    }

    if (type == 'post_like' || type == 'post_comment') {
      final postId = (data['postId'] ?? '').toString();
      if (postId.isEmpty) return;
      final post = await FirebaseFirestore.instance
          .collection('feed_posts').doc(postId).get();
      if (!post.exists || !context.mounted) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Esta publicação não está mais disponível.')),
          );
        }
        return;
      }
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => CommunityPostDetailScreen(postId: postId),
      ));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF09040E),
    appBar: AppBar(
      backgroundColor: const Color(0xFF16091B),
      title: const Text('Notificações'),
      actions: [
        TextButton(
          onPressed: () async {
            final batch = FirebaseFirestore.instance.batch();
            final docs = await FirebaseFirestore.instance
                .collection('users').doc(_uid).collection('notifications')
                .where('read', isEqualTo: false).get();
            for (final d in docs.docs) {
              batch.update(d.reference, {'read': true});
            }
            await batch.commit();
          },
          child: const Text('Ler todas', style: TextStyle(color: pink)),
        ),
      ],
    ),
    body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('Não foi possível carregar as notificações.'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator(color: pink));
        }
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.notifications_none, size: 54, color: Colors.white38),
              SizedBox(height: 12),
              Text('Você ainda não tem notificações.', style: TextStyle(color: Colors.white70)),
            ]),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: docs.length,
          separatorBuilder: (_, __) => const Divider(color: Colors.white12),
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data();
            final read = data['read'] == true;
            final type = (data['type'] ?? '').toString();
            final isStory = type.startsWith('story_');
            return ListTile(
              onTap: () => _open(context, doc),
              leading: CircleAvatar(
                backgroundColor: pink.withOpacity(.16),
                child: Icon(_icon(type), color: pink),
              ),
              title: Text(
                _message(data),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: read ? FontWeight.normal : FontWeight.bold,
                ),
              ),
              subtitle: Text(
                isStory ? 'Story' : 'Comunidade',
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
              trailing: read
                  ? const Icon(Icons.done, color: Colors.white30, size: 18)
                  : Container(
                      width: 9,
                      height: 9,
                      decoration: const BoxDecoration(color: pink, shape: BoxShape.circle),
                    ),
            );
          },
        );
      },
    ),
  );
}
