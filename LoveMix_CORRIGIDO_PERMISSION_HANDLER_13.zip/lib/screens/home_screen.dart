import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import 'discover_screen.dart';
import 'messages_screen.dart';
import 'profile_screen.dart';
import 'wallet_screen.dart';
import 'chat_rooms_screen.dart';
import 'love_room_screen.dart';
import 'live_broadcast_screen.dart';
import 'ranking_screen.dart';
import 'resources_screen.dart';
import 'stories_widget.dart';
import 'notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  static const panel = Color(0xFF171022);
  int index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    DataService.instance.setOnlineStatus(true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DataService.instance.setOnlineStatus(true);
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      DataService.instance.setOnlineStatus(false);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    DataService.instance.setOnlineStatus(false);
    super.dispose();
  }

  void open(int page) => setState(() => index = page);

  @override
  Widget build(BuildContext context) {
    final pages = [
      _LoveMixFeed(onDiscover: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()))),
      const ChatRoomsScreen(),
      const SizedBox.shrink(),
      const MessagesScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      appBar: index == 0 ? AppBar(
        title: const Row(mainAxisSize: MainAxisSize.min, children: [
          Text('LoveMix', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: pink, fontStyle: FontStyle.italic)),
          Text('💗', style: TextStyle(fontSize: 18)),
        ]),
        actions: [
          IconButton(tooltip: 'Recursos incríveis', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ResourcesScreen())), icon: const Icon(Icons.auto_awesome, color: Color(0xFFE45BFF))),
          IconButton(tooltip: 'Ranking', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RankingScreen())), icon: const Icon(Icons.emoji_events, color: Color(0xFFFFD65C))),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .doc(FirebaseAuth.instance.currentUser?.uid ?? '')
                .collection('notifications')
                .snapshots(),
            builder: (context, snapshot) {
              final unread = snapshot.data?.docs
                      .where((d) => d.data()['read'] != true)
                      .length ??
                  0;
              return IconButton(
                tooltip: 'Notificações',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                ),
                icon: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    const Icon(Icons.notifications_none),
                    if (unread > 0)
                      Positioned(
                        right: -7,
                        top: -5,
                        child: Container(
                          constraints: const BoxConstraints(minWidth: 17, minHeight: 17),
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                          decoration: const BoxDecoration(
                            color: Color(0xFFFF1744),
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            unread > 99 ? '99+' : '$unread',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(width: 4),
        ],
      ) : null,
      body: IndexedStack(index: index == 2 ? 0 : index, children: [
        pages[0], pages[1], const SizedBox.shrink(), pages[3], pages[4],
      ]),
            bottomNavigationBar: NavigationBar(
        height: 68,
        backgroundColor: const Color(0xFF100A19),
        indicatorColor: const Color(0xFF49205F),
        selectedIndex: index,
        onDestinationSelected: (v) {
          if (v == 2) {
            _createRoom(context);
          } else {
            open(v);
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: pink), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), selectedIcon: Icon(Icons.graphic_eq, color: pink), label: 'Salas'),
          NavigationDestination(icon: Icon(Icons.add_circle, color: pink, size: 34), label: ''),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble, color: pink), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: pink), label: 'Perfil'),
        ],
      ),
    );
  }

  Future<void> _createRoom(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();
    final password = TextEditingController();
    bool isPublic = true;
    String category = 'Amizades';
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context, isScrollControlled: true, backgroundColor: panel,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Criar sua sala 👑', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: name, maxLength: 40, decoration: const InputDecoration(hintText: 'Nome da sala')),
          TextField(controller: description, maxLength: 120, decoration: const InputDecoration(hintText: 'Descrição (opcional)')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'Categoria'),
            items: const ['Amizades', 'Namoro', 'Música', 'Jogos', 'Conversas'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) { if (v != null) setSheet(() => category = v); },
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: isPublic,
            activeColor: pink,
            title: Text(isPublic ? 'Sala pública' : 'Sala privada'),
            subtitle: Text(isPublic ? 'Qualquer pessoa pode entrar' : 'Sala privada, não aparece na lista pública'),
            onChanged: (v) => setSheet(() => isPublic = v),
          ),
          if (!isPublic) ...[
            const SizedBox(height: 8),
            TextField(controller: password, obscureText: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Senha da sala', hintText: 'Crie uma senha para compartilhar')),
          ],
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(ctx, {
            'name': name.text.trim(), 'description': description.text.trim(),
            'category': category, 'isPublic': isPublic, 'password': password.text.trim(),
          }), child: const Text('Criar Sala ✨'))),
        ]),
      )),
    );
    if (result == null || (result['name'] as String).isEmpty) return;
    try {
      final roomName = result['name'] as String;
      final id = await DataService.instance.createRoom(
        roomName,
        isPublic: result['isPublic'] as bool,
        category: result['category'] as String,
        description: result['description'] as String,
        password: result['password'] as String,
        isLive: true,
        mediaMode: 'audio',
      );
      if (!mounted) return;
      open(1);
      Navigator.push(context, MaterialPageRoute(builder: (_) => LoveRoomScreen(roomId: id, roomName: roomName)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
}


class _LoveMixFeed extends StatefulWidget {
  const _LoveMixFeed({required this.onDiscover});
  final VoidCallback onDiscover;
  @override
  State<_LoveMixFeed> createState() => _LoveMixFeedState();
}

class _LoveMixFeedState extends State<_LoveMixFeed> {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  final _message = TextEditingController();
  bool _publishing = false;
  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db = FirebaseFirestore.instance;

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  Future<void> _publish({bool withPhoto = false}) async {
    if (_publishing) return;
    XFile? photo;
    if (withPhoto) {
      photo = await ImagePicker().pickImage(
        source: ImageSource.gallery, imageQuality: 82, maxWidth: 1440,
      );
      if (photo == null) return;
    }
    final text = _message.text.trim();
    if (text.isEmpty && photo == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escreva uma mensagem ou escolha uma foto.')),
      );
      return;
    }
    setState(() => _publishing = true);
    try {
      final profile = await _db.collection('users').doc(_uid).get();
      String photoUrl = '';
      if (photo != null) {
        final bytes = await photo.readAsBytes();
        if (bytes.length > 5 * 1024 * 1024) {
          throw Exception('A foto deve ter no máximo 5 MB.');
        }
        final ext = photo.name.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
        photoUrl = await SupabaseService.instance.uploadPhoto(
          path: 'feed_posts/$_uid/${DateTime.now().millisecondsSinceEpoch}.$ext',
          bytes: bytes,
          contentType: ext == 'png' ? 'image/png' : 'image/jpeg',
        );
      }
      await _db.collection('feed_posts').add({
        'ownerId': _uid,
        'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
        'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
        'imageUrl': photoUrl,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });
      _message.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Publicação compartilhada!')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível publicar: $e')),
      );
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  Future<void> _deletePost(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF21132E),
        title: const Text('Apagar publicação?'),
        content: const Text('Essa publicação será removida do feed.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final imageUrl = (doc.data()['imageUrl'] ?? '').toString();
      // Se a publicação veio da galeria do perfil (mesmo id), remove de lá
      // também; assim a foto não fica quebrada no perfil nem volta ao feed.
      final owner = (doc.data()['ownerId'] ?? '').toString();
      final batch = _db.batch();
      batch.delete(doc.reference);
      if (owner.isNotEmpty) {
        batch.delete(_db.collection('users').doc(owner).collection('posts').doc(doc.id));
      }
      await batch.commit();
      if (imageUrl.isNotEmpty) {
        await SupabaseService.instance.deletePublicUrl(imageUrl);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível apagar: $e')),
      );
    }
  }

  CollectionReference<Map<String, dynamic>> _postLikes(String postId) =>
      _db.collection('feed_posts').doc(postId).collection('likes');
  CollectionReference<Map<String, dynamic>> _postComments(String postId) =>
      _db.collection('feed_posts').doc(postId).collection('comments');

  Future<void> _toggleCommunityLike(String postId) async {
    if (_uid.isEmpty) return;
    final ref = _postLikes(postId).doc(_uid);
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (snap.exists) {
          tx.delete(ref);
        } else {
          tx.set(ref, {'uid': _uid, 'createdAt': FieldValue.serverTimestamp()});
        }
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível curtir: $e')),
      );
    }
  }

  Future<void> _openCommunityComments(String postId) async {
    final controller = TextEditingController();
    Future<void> send(StateSetter setSheet) async {
      final text = controller.text.trim();
      if (text.isEmpty || _uid.isEmpty) return;
      try {
        final profile = await _db.collection('users').doc(_uid).get();
        await _postComments(postId).add({
          'uid': _uid,
          'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
          'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
          'text': text,
          'createdAt': FieldValue.serverTimestamp(),
        });
        controller.clear();
        setSheet(() {});
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível comentar: $e')),
        );
      }
    }
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF171022),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (sheetContext) => StatefulBuilder(builder: (ctx, setSheet) =>
        Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SizedBox(height: MediaQuery.of(ctx).size.height * .65, child: Column(children: [
            const Padding(padding: EdgeInsets.all(16), child: Text('Comentários da comunidade', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
            Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _postComments(postId).orderBy('createdAt', descending: true).limit(100).snapshots(),
              builder: (ctx, snap) {
                if (snap.hasError) return const Center(child: Text('Não foi possível carregar os comentários.'));
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                if (snap.data!.docs.isEmpty) return const Center(child: Text('Seja a primeira pessoa a comentar!'));
                return ListView(children: snap.data!.docs.map((doc) {
                  final c = doc.data();
                  return ListTile(
                    leading: CircleAvatar(backgroundImage: (c['photoUrl'] ?? '').toString().isNotEmpty ? NetworkImage(c['photoUrl']) : null, child: (c['photoUrl'] ?? '').toString().isEmpty ? const Icon(Icons.person) : null),
                    title: Text((c['name'] ?? 'Pessoa').toString(), style: const TextStyle(color: Color(0xFFFF8BD5), fontWeight: FontWeight.bold)),
                    subtitle: Text((c['text'] ?? '').toString()),
                    trailing: c['uid'] == _uid ? IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white54), onPressed: () => doc.reference.delete()) : null,
                  );
                }).toList());
              },
            )),
            Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 14), child: Row(children: [
              Expanded(child: TextField(controller: controller, maxLength: 300, buildCounter: (_, {required currentLength, required isFocused, maxLength}) => null, decoration: const InputDecoration(hintText: 'Escreva um comentário...'))),
              IconButton(onPressed: () => send(setSheet), icon: const Icon(Icons.send, color: pink)),
            ])),
          ])),
        ),
      ),
    );
    controller.dispose();
  }

  Widget _communityInteractions(String postId) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Row(children: [
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postLikes(postId).snapshots(),
        builder: (context, snap) {
          final liked = snap.data?.docs.any((d) => d.id == _uid) ?? false;
          final count = snap.data?.docs.length ?? 0;
          return Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(visualDensity: VisualDensity.compact, onPressed: () => _toggleCommunityLike(postId),
              icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.redAccent : Colors.white70, size: 25)),
            Text('$count curtidas', style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ]);
        },
      ),
      const SizedBox(width: 12),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postComments(postId).snapshots(),
        builder: (context, snap) => TextButton.icon(
          onPressed: () => _openCommunityComments(postId),
          icon: const Icon(Icons.mode_comment_outlined, color: Colors.white70, size: 20),
          label: Text('${snap.data?.docs.length ?? 0} comentários', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ),
      ),
    ]),
  );

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.only(bottom: 22),
    children: [
      const StoriesStrip(),
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 10, 16, 8),
        child: Text('Categorias', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      ),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(children: [
        _category('💗', 'Namoro', () => _goDiscover(context)),
        _category('👥', 'Amizades', () => _goDiscover(context)),
        _category('🎮', 'Jogos', () => _goRooms(context)),
        _category('🎵', 'Música', () => _goRooms(context)),
      ])),
      const SizedBox(height: 16),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF351052), Color(0xFF171022)]),
          borderRadius: BorderRadius.circular(18), border: Border.all(color: purple),
        ),
        child: ListTile(
          leading: const Icon(Icons.people_alt, color: pink, size: 30),
          title: const Text('Conheça pessoas do mundo todo', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: const Text('Descubra perfis, curta e faça novas conexões', style: TextStyle(color: Colors.white70, fontSize: 11)),
          trailing: const Icon(Icons.arrow_forward_ios, color: pink, size: 16),
          onTap: widget.onDiscover,
        ),
      )),
      const SizedBox(height: 14),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Row(children: [
        Expanded(child: _quick('🏆', 'Ranking', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RankingScreen())))),
        const SizedBox(width: 10),
        Expanded(child: _quick('🎁', 'Presentes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())))),
      ])),
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 24, 16, 10),
        child: Text('Publicações da comunidade', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      ),
      _composer(),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _db.collection('feed_posts').orderBy('createdAt', descending: true).limit(60).snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Padding(
            padding: EdgeInsets.all(20),
            child: Text('Não foi possível carregar as publicações. Verifique as regras do Firestore.', style: TextStyle(color: Colors.white60)),
          );
          if (!snap.hasData) return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator(color: pink)),
          );
          if (snap.data!.docs.isEmpty) return const Padding(
            padding: EdgeInsets.all(22),
            child: Center(child: Text('Ainda não há publicações. Seja a primeira pessoa a compartilhar algo!')),
          );
          return Column(children: snap.data!.docs.map(_postCard).toList());
        },
      ),
    ],
  );

  Widget _composer() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4C2869))),
    child: Column(children: [
      TextField(
        controller: _message, minLines: 1, maxLines: 5, maxLength: 1000,
        decoration: const InputDecoration(
          hintText: 'O que você quer compartilhar?',
          counterText: '', border: InputBorder.none, filled: false,
        ),
      ),
      Row(children: [
        TextButton.icon(
          onPressed: _publishing ? null : () => _publish(withPhoto: true),
          icon: const Icon(Icons.photo_library_outlined, color: pink),
          label: const Text('Foto', style: TextStyle(color: pink)),
        ),
        const Spacer(),
        FilledButton(
          onPressed: _publishing ? null : () => _publish(),
          style: FilledButton.styleFrom(backgroundColor: pink),
          child: _publishing
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Text('Publicar'),
        ),
      ]),
    ]),
  );

  Widget _postCard(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final p = doc.data();
    final image = (p['imageUrl'] ?? '').toString();
    final text = (p['text'] ?? '').toString();
    final owner = (p['ownerId'] ?? '').toString();
    final avatar = (p['photoUrl'] ?? '').toString();
    final ts = p['createdAt'];
    final when = ts is Timestamp ? _ago(ts) : 'agora';
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 6, 14, 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF3C2456))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            radius: 20, backgroundColor: const Color(0xFF351052),
            backgroundImage: avatar.isNotEmpty ? NetworkImage(avatar) : null,
            child: avatar.isEmpty ? const Icon(Icons.person, color: Colors.white70) : null,
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text((p['name'] ?? 'Pessoa').toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(when, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ])),
          if (owner == _uid) IconButton(
            tooltip: 'Apagar publicação',
            onPressed: () => _deletePost(doc),
            icon: const Icon(Icons.delete_outline, color: Colors.white70),
          ),
        ]),
        if (text.isNotEmpty) Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 4),
          child: Text(text, style: const TextStyle(fontSize: 14)),
        ),
        if (image.isNotEmpty) ...[
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(image, width: double.infinity, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox(height: 120, child: Center(child: Icon(Icons.broken_image)))),
          ),
        ],
        _communityInteractions(doc.id),
      ]),
    );
  }

  String _ago(Timestamp timestamp) {
    final d = DateTime.now().difference(timestamp.toDate());
    if (d.inMinutes < 1) return 'agora';
    if (d.inHours < 1) return 'há ${d.inMinutes} min';
    if (d.inDays < 1) return 'há ${d.inHours} h';
    return 'há ${d.inDays} d';
  }

  static Widget _category(String emoji, String label, VoidCallback onTap) => Expanded(child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(
      height: 78, decoration: BoxDecoration(color: const Color(0xFF1C1229), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF3C2456))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 25)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]),
    )),
  ));

  static Widget _quick(String emoji, String title, VoidCallback onTap) => InkWell(onTap: onTap, child: Container(
    padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: const Color(0xFF1A1028), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF4C2869))),
    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 22)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
  ));

  static void _goDiscover(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()));
  static void _goRooms(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RoomsRoute()));
}

class _DiscoverRoute extends StatelessWidget {
  const _DiscoverRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Descobrir pessoas')), body: DiscoverScreen());
}
class _RoomsRoute extends StatelessWidget {
  const _RoomsRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Salas LoveMix')), body: ChatRoomsScreen());
}
