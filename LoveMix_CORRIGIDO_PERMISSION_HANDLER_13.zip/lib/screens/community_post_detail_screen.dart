
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class CommunityPostDetailScreen extends StatefulWidget {
  const CommunityPostDetailScreen({super.key, required this.postId});
  final String postId;

  @override
  State<CommunityPostDetailScreen> createState() => _CommunityPostDetailScreenState();
}

class _CommunityPostDetailScreenState extends State<CommunityPostDetailScreen> {
  static const pink = Color(0xFFFF19B8);
  final db = FirebaseFirestore.instance;
  final controller = TextEditingController();
  String get uid => FirebaseAuth.instance.currentUser?.uid ?? '';
  DocumentReference<Map<String, dynamic>> get post =>
      db.collection('feed_posts').doc(widget.postId);
  CollectionReference<Map<String, dynamic>> get likes =>
      post.collection('likes');
  CollectionReference<Map<String, dynamic>> get comments =>
      post.collection('comments');

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _toggleLike(bool liked) async {
    if (uid.isEmpty) return;
    final ref = likes.doc(uid);
    if (liked) {
      await ref.delete();
    } else {
      await ref.set({'uid': uid, 'createdAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> _sendComment() async {
    final text = controller.text.trim();
    if (text.isEmpty || uid.isEmpty) return;
    final profile = await db.collection('users').doc(uid).get();
    await comments.add({
      'uid': uid,
      'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
      'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
    controller.clear();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF09040E),
    appBar: AppBar(title: const Text('Publicação da comunidade')),
    body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: post.snapshots(),
      builder: (context, postSnap) {
        if (!postSnap.hasData) {
          return const Center(child: CircularProgressIndicator(color: pink));
        }
        if (!postSnap.data!.exists) {
          return const Center(child: Text('Esta publicação não está mais disponível.'));
        }
        final data = postSnap.data!.data()!;
        final imageUrl = (data['imageUrl'] ?? '').toString();
        final text = (data['text'] ?? '').toString();
        return Column(children: [
          Expanded(child: ListView(padding: const EdgeInsets.all(14), children: [
            Text((data['name'] ?? 'Pessoa').toString(),
              style: const TextStyle(color: pink, fontWeight: FontWeight.bold, fontSize: 17)),
            if (text.isNotEmpty) Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 16)),
            ),
            if (imageUrl.isNotEmpty) ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.network(imageUrl, fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white54, size: 60)),
            ),
            const SizedBox(height: 12),
            StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: likes.doc(uid).snapshots(),
              builder: (context, ownLike) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: likes.snapshots(),
                builder: (context, likeSnap) {
                  final liked = ownLike.data?.exists == true;
                  final count = likeSnap.data?.docs.length ?? 0;
                  return Row(children: [
                    IconButton(
                      onPressed: () => _toggleLike(liked),
                      icon: Icon(liked ? Icons.favorite : Icons.favorite_border,
                        color: liked ? Colors.redAccent : Colors.white, size: 29),
                    ),
                    Text('$count curtidas', style: const TextStyle(color: Colors.white)),
                    const SizedBox(width: 18),
                    const Icon(Icons.chat_bubble_outline, color: Colors.white70),
                    const SizedBox(width: 6),
                    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: comments.snapshots(),
                      builder: (_, c) => Text('${c.data?.docs.length ?? 0} comentários',
                        style: const TextStyle(color: Colors.white)),
                    ),
                  ]);
                },
              ),
            ),
            const Divider(color: Colors.white24),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: comments.orderBy('createdAt', descending: true).limit(100).snapshots(),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: pink));
                if (snap.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(20),
                    child: Text('Seja a primeira pessoa a comentar!',
                      style: TextStyle(color: Colors.white60)),
                  );
                }
                return Column(children: snap.data!.docs.map((doc) {
                  final c = doc.data();
                  return ListTile(
                    dense: true,
                    title: Text((c['name'] ?? 'Pessoa').toString(),
                      style: const TextStyle(color: pink, fontWeight: FontWeight.bold)),
                    subtitle: Text((c['text'] ?? '').toString(),
                      style: const TextStyle(color: Colors.white)),
                  );
                }).toList());
              },
            ),
          ])),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              child: Row(children: [
                Expanded(child: TextField(
                  controller: controller,
                  maxLength: 300,
                  decoration: const InputDecoration(counterText: '', hintText: 'Escreva um comentário...'),
                )),
                IconButton(onPressed: _sendComment,
                  icon: const Icon(Icons.send, color: pink)),
              ]),
            ),
          ),
        ]);
      },
    ),
  );
}
