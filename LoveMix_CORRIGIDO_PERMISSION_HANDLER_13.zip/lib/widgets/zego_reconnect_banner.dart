import 'package:flutter/material.dart';
import 'package:zego_uikit/zego_uikit.dart';

/// Exibe o estado de reconexão informado pelo ZEGO.
/// O SDK já tenta recuperar a sala e os fluxos automaticamente após oscilações.
class ZegoReconnectBanner extends StatelessWidget {
  const ZegoReconnectBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ZegoUIKitRoomState>(
      valueListenable: ZegoUIKit.instance.getRoomStateStream(),
      builder: (context, state, _) {
        final reason = state.reason.name.toLowerCase();
        final reconnecting = reason == 'reconnecting' || reason == 'logining';
        final failed = reason == 'reconnectfailed' || reason == 'loginfailed';
        if (!reconnecting && !failed) return const SizedBox.shrink();

        final message = failed
            ? 'Conexão perdida. Verifique sua internet.'
            : 'Conexão instável. Tentando reconectar...';
        return IgnorePointer(
          child: Center(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 24),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xEE21132F),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: failed ? const Color(0xFFFF8A80) : const Color(0xFFFF2DAB),
                ),
                boxShadow: const [
                  BoxShadow(color: Color(0x66000000), blurRadius: 14),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (reconnecting)
                    const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Color(0xFFFF7AD5),
                      ),
                    )
                  else
                    const Icon(Icons.wifi_off, color: Color(0xFFFF8A80), size: 18),
                  const SizedBox(width: 9),
                  Flexible(
                    child: Text(
                      message,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
