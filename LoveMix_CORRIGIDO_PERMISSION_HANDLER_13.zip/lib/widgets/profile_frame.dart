import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class ProfileFrameAvatar extends StatelessWidget {
  const ProfileFrameAvatar({super.key, required this.photoUrl, required this.frameId, this.size = 86});
  final String photoUrl;
  final String frameId;
  final double size;

  static const Map<String, List<Color>> _palettes = {
    'neon': [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFF35D7FF)],
    'hearts': [Color(0xFFFF5A9E), Color(0xFFFF19B8), Color(0xFFFFB0D2)],
    'gold': [Color(0xFFFFE08A), Color(0xFFB87918), Color(0xFFFFF0B5)],
    'cosmic': [Color(0xFF39D9FF), Color(0xFF8D35FF), Color(0xFFFF19B8)],
    'royal_crown': [Color(0xFFFFD56A), Color(0xFF9D5B13), Color(0xFFFFF0A8)],
    'kitty': [Color(0xFFFF9DDE), Color(0xFF9B4DFF)],
    'butterfly': [Color(0xFFB65CFF), Color(0xFFFF65D4), Color(0xFF67DFFF)],
    'rose': [Color(0xFF40102F), Color(0xFFFF247F), Color(0xFF9B174D)],
    'headphones': [Color(0xFF9B55FF), Color(0xFFEF43D0), Color(0xFF55D9FF)],
    'pink_bow': [Color(0xFFFF78C8), Color(0xFFFF20A8)],
    'flame': [Color(0xFFFF4A32), Color(0xFFB324FF), Color(0xFFFF9B32)],
    'angel': [Color(0xFFFFE9FF), Color(0xFFB78AFF), Color(0xFFFFFFFF)],
    'love_wings': [Color(0xFFFF35C8), Color(0xFF8D35FF), Color(0xFFFFB6E8)],
    'flower': [Color(0xFFFF83C8), Color(0xFF9B55FF), Color(0xFFFFD66B)],
    'sparkle': [Color(0xFF9D75FF), Color(0xFF4DDFFF), Color(0xFFFFFFFF)],
    'diamond_heart': [Color(0xFF72E5FF), Color(0xFFB45BFF), Color(0xFFFF5FB8)],
    'broken_heart': [Color(0xFFFF4B8B), Color(0xFF6B24C9)],
    'royal_purple': [Color(0xFFB45BFF), Color(0xFF5B20A8), Color(0xFFFFD56A)],
    'couple': [Color(0xFFFF4DAD), Color(0xFF9B45E8), Color(0xFFFFA8C9)],
    'butterfly_royal': [Color(0xFF72E5FF), Color(0xFF9B45E8), Color(0xFFFFD56A)],
    'rose_gold': [Color(0xFFFFD56A), Color(0xFF9B174D), Color(0xFFFFF0B5)],
    'celestial': [Color(0xFFFFFFFF), Color(0xFFB45BFF), Color(0xFF72DFFF)],
    'royal_wings': [Color(0xFFFFE08A), Color(0xFF8D35FF), Color(0xFFFFF0B5)],
    'diamond_crown': [Color(0xFF72E5FF), Color(0xFFFFD56A), Color(0xFFFFFFFF)],
    'lovemix_deluxe': [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFFFFD56A)],
  };

  static const Map<String, String> _ornaments = {
    'hearts': '♥', 'gold': '👑', 'cosmic': '✦', 'royal_crown': '👑',
    'kitty': '🐱', 'butterfly': '🦋', 'rose': '🌹', 'headphones': '🎧',
    'pink_bow': '🎀', 'flame': '🔥', 'angel': '🪽', 'love_wings': '💞',
    'flower': '🌸', 'sparkle': '⭐', 'diamond_heart': '💎',
    'broken_heart': '💔', 'royal_purple': '👑', 'couple': '💕',
    'butterfly_royal': '🦋', 'rose_gold': '🌹', 'celestial': '😇',
    'royal_wings': '🪽', 'diamond_crown': '💎', 'lovemix_deluxe': '💖',
  };

  @override
  Widget build(BuildContext context) {
    final isDefault = frameId.isEmpty || frameId == 'classic';
    final colors = _palettes[frameId] ?? const [Color(0xFF8D35FF), Color(0xFFFF19B8)];
    final ornament = _ornaments[frameId];
    final total = size + (isDefault ? 0 : 14);
    return SizedBox(width: total, height: total, child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
      Container(width: total, height: total, padding: EdgeInsets.all(isDefault ? 1.5 : 5),
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: isDefault ? null : SweepGradient(colors: [...colors, colors.first]),
          border: isDefault ? Border.all(color: Colors.white24, width: 1.5) : null,
          boxShadow: isDefault ? null : [BoxShadow(color: colors.first.withOpacity(.48), blurRadius: 13, spreadRadius: 1)]),
        child: ClipOval(child: Container(color: const Color(0xFF21132E), child: photoUrl.isEmpty
          ? const Icon(Icons.person, color: Colors.white70, size: 42)
          : CachedNetworkImage(imageUrl: photoUrl, fit: BoxFit.cover,
              placeholder: (_, __) => const Center(child: CircularProgressIndicator(strokeWidth: 1)),
              errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white70, size: 42)))),
      ),
      if (!isDefault && ornament != null)
        Positioned(top: -5, right: -3, child: Text(ornament, style: TextStyle(fontSize: size * .25,
          shadows: [Shadow(color: colors.first, blurRadius: 9)]))),
      if (frameId == 'butterfly_royal') ...[
        Positioned(left: -4, top: size * .12, child: Text('✦', style: TextStyle(color: colors.last, fontSize: size * .22))),
        Positioned(bottom: -5, left: size * .16, child: Text('🦋', style: TextStyle(fontSize: size * .19))),
      ],
      if (frameId == 'rose_gold')
        Positioned(bottom: -5, left: -2, child: Text('🌹', style: TextStyle(fontSize: size * .23))),
      if (frameId == 'celestial') ...[
        Positioned(top: -8, left: size * .25, child: Text('☾', style: TextStyle(color: colors.first, fontSize: size * .25))),
        Positioned(bottom: -4, right: size * .12, child: Text('✧', style: TextStyle(color: colors.last, fontSize: size * .22))),
      ],
      if (frameId == 'royal_wings') ...[
        Positioned(left: -8, top: size * .28, child: Text('❧', style: TextStyle(color: colors.first, fontSize: size * .28))),
        Positioned(right: -8, top: size * .28, child: Text('❧', style: TextStyle(color: colors.first, fontSize: size * .28))),
      ],
      if (frameId == 'diamond_crown')
        Positioned(bottom: -5, child: Text('💎', style: TextStyle(fontSize: size * .2))),
      if (frameId == 'lovemix_deluxe') ...[
        Positioned(left: -5, bottom: size * .2, child: Text('💕', style: TextStyle(fontSize: size * .19))),
        Positioned(right: -5, bottom: size * .2, child: Text('✨', style: TextStyle(fontSize: size * .19))),
      ],
      if (frameId == 'angel' || frameId == 'love_wings' || frameId == 'royal_purple' ||
          frameId == 'celestial' || frameId == 'royal_wings' || frameId == 'lovemix_deluxe')
        Positioned(bottom: -3, child: Text(frameId == 'angel' ? '✨' : frameId == 'love_wings' ? '💗' : '💜',
          style: TextStyle(fontSize: size * .2))),
      if (frameId == 'couple')
        Positioned(bottom: -3, right: 1, child: Text('♥', style: TextStyle(color: Colors.pinkAccent, fontSize: size * .23))),
    ]));
  }
}
