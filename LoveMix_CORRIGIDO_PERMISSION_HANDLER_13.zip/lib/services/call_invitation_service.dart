import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../app.dart';
import '../screens/call_screen.dart';

class CallInvitationService {
  CallInvitationService._();
  static final instance = CallInvitationService._();

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _subscription;
  final Set<String> _handled = <String>{};

  void startForUser(User user) {
    _subscription?.cancel();
    _handled.clear();
    _subscription = FirebaseFirestore.instance
        .collectionGroup('calls')
        .where('calleeUid', isEqualTo: user.uid)
        .snapshots()
        .listen((snapshot) {
      for (final doc in snapshot.docs) {
        final data = doc.data();
        if (data['status'] != 'ringing' || _handled.contains(doc.reference.path)) continue;
        final createdAt = data['createdAt'];
        if (createdAt is Timestamp &&
            DateTime.now().difference(createdAt.toDate()).inSeconds > 35) continue;
        _handled.add(doc.reference.path);
        _showIncoming(doc.reference, data);
      }
    }, onError: (error) {
      debugPrint('Erro no serviço de chamadas: $error');
    });
  }

  Future<void> stop() async {
    await _subscription?.cancel();
    _subscription = null;
    _handled.clear();
  }

  Future<void> _showIncoming(
      DocumentReference<Map<String, dynamic>> callRef,
      Map<String, dynamic> data) async {
    final navigator = rootNavigatorKey.currentState;
    final context = navigator?.context;
    if (navigator == null || context == null) return;
    final video = data['video'] == true;
    final callerName = (data['callerName'] ?? 'Alguém').toString();
    final answer = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF21132E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: Text(video ? 'Chamada de vídeo' : 'Chamada de voz',
            style: const TextStyle(color: Colors.white)),
        content: Text('$callerName está ligando para você.',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Recusar', style: TextStyle(color: Colors.redAccent)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF2DAB)),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Atender'),
          ),
        ],
      ),
    );
    try {
      if (answer == true) {
        await callRef.update({
          'status': 'accepted',
          'acceptedAt': FieldValue.serverTimestamp(),
        });
        final current = rootNavigatorKey.currentState;
        if (current != null) {
          current.push(MaterialPageRoute(
            builder: (_) => CallScreen(callRef: callRef, video: video),
          ));
        }
      } else {
        await callRef.update({
          'status': 'rejected',
          'endedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (error) {
      final currentContext = rootNavigatorKey.currentState?.context;
      if (currentContext != null) {
        ScaffoldMessenger.of(currentContext).showSnackBar(
          SnackBar(content: Text('Não foi possível responder à chamada: $error')),
        );
      }
    }
  }
}
