import 'dart:convert';
import 'package:http/http.dart' as http;

/// Tradução online pelo serviço MyMemory. O texto é enviado ao provedor
/// para tradução; não é salvo no Firestore por este serviço.
class TranslationService {
  TranslationService._();
  static final instance = TranslationService._();

  Future<String> translate({
    required String text,
    required String sourceLanguage,
    required String targetLanguage,
  }) async {
    final value = text.trim();
    if (value.isEmpty) throw Exception('Digite uma palavra ou frase.');
    if (value.length > 450) {
      throw Exception('Traduza textos com até 450 caracteres por vez.');
    }
    final uri = Uri.https('api.mymemory.translated.net', '/get', {
      'q': value,
      'langpair': '$sourceLanguage|$targetLanguage',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) {
      throw Exception('O serviço de tradução está indisponível. Tente novamente.');
    }
    final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final status = data['responseStatus'];
    final translated = (data['responseData']?['translatedText'] ?? '').toString();
    if (status != 200 || translated.isEmpty) {
      throw Exception('Não foi possível traduzir esse texto.');
    }
    return translated
        .replaceAll('&#39;', "'")
        .replaceAll('&quot;', '"')
        .replaceAll('&amp;', '&')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>');
  }
}
