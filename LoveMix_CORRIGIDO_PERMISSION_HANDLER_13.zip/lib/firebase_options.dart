// Configuração Firebase do LoveMix (Android/iOS).
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show TargetPlatform, defaultTargetPlatform, kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('LoveMix está configurado para Android.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError('Plataforma Firebase não configurada para LoveMix.');
    }
  }

  // O ID do app iOS é exclusivo e deve vir do Firebase Console.
  // No GitHub Actions, configure o secret FIREBASE_IOS_APP_ID.
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAkPpjNO5CWBy8h0yoppXQBvye7Awr6R2Q',
    appId: String.fromEnvironment('FIREBASE_IOS_APP_ID'),
    messagingSenderId: '985069046748',
    projectId: 'lovemix-73849',
    storageBucket: 'lovemix-73849.firebasestorage.app',
    iosBundleId: String.fromEnvironment('IOS_BUNDLE_ID'),
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAkPpjNO5CWBy8h0yoppXQBvye7Awr6R2Q',
    appId: '1:985069046748:android:2b92a5982fa7147bd55d19',
    messagingSenderId: '985069046748',
    projectId: 'lovemix-73849',
    storageBucket: 'lovemix-73849.firebasestorage.app',
  );
}
