# Proteção automática de imagens nas conversas privadas

## O que foi implementado

- Antes de enviar uma foto no PV, o aplicativo chama a função segura `checkPrivateChatImage`.
- A função usa Google Cloud Vision SafeSearch no servidor para identificar possível conteúdo adulto ou sugestivo.
- Se a imagem for classificada como conteúdo adulto provável ou conteúdo sugestivo muito provável, o envio é recusado e uma ocorrência é registrada em `reports`.
- Se a análise não funcionar, o envio é bloqueado (falha fechada); a foto não é liberada sem verificação.
- Mensagens de imagem são criadas com `moderationStatus: pending` e ficam invisíveis para os participantes.
- O gatilho `moderatePrivateChatImage` analisa novamente a imagem. Se estiver dentro das regras, marca como `approved`; se for inadequada, apaga a mensagem e registra a ocorrência.
- O remetente recebe uma notificação quando uma imagem é bloqueada/removida.
- As regras do Firestore impedem o aplicativo de criar mensagens de imagem já aprovadas ou alterar o estado de moderação.

## Implantação necessária

Esta proteção depende do backend Firebase; editar apenas o APK não é suficiente.

1. No Google Cloud Console do mesmo projeto Firebase, habilite **Cloud Vision API**.
2. Na pasta do projeto, instale as dependências das funções: `cd functions && npm install`.
3. Compile e implante as funções: `npm run build` e depois `firebase deploy --only functions`.
4. Implante também as regras: `firebase deploy --only firestore:rules`.
5. Gere e publique um novo APK.

O projeto precisa estar autenticado no Firebase CLI e selecionado para o projeto Firebase correto antes da implantação.

## Limitações importantes

A análise automática estima se uma imagem contém nudez/conteúdo adulto; ela não consegue determinar se houve consentimento entre as pessoas. Por isso, a política aplicada aqui bloqueia imagens classificadas como inadequadas no PV, mesmo que o remetente diga que houve consentimento. A classificação automática pode errar; denúncias e revisão humana continuam importantes.

A verificação do servidor depende de a Cloud Vision API estar habilitada e acessível pela conta de execução das Cloud Functions. Enquanto a verificação estiver indisponível, novas fotos não são liberadas. Imagens antigas enviadas antes desta atualização não são reprocessadas automaticamente.
