# Correção do conflito ZEGO / permission_handler

O workflow falhou porque `zego_uikit_prebuilt_live_audio_room 3.16.12` exige `permission_handler 13.0.2`, enquanto a combinação das outras dependências do projeto está configurada para `permission_handler 12.0.1`.

Para manter a linha de dependências compatível sem forçar uma atualização do Android Gradle Plugin/compileSdk neste projeto, o pacote de sala de áudio foi fixado exatamente em `3.16.11`, cuja changelog não inclui a migração para `permission_handler 13.0.2`. A dependência direta `permission_handler: ^12.0.1` foi mantida.

Após extrair este ZIP, execute `flutter pub get` no GitHub Actions. A resolução de dependências e a compilação ainda precisam ser confirmadas pelo workflow; este ambiente não tem Flutter instalado.
