# LoveMix — Flutter + Firebase

Projeto inicial funcional do LoveMix, com tema preto/dourado e estrutura para Android/iOS.

## Requisitos
- Flutter SDK estável (Dart 3.3+)
- Android Studio e/ou Xcode
- Conta Google e projeto Firebase

## 1. Instalar dependências
```bash
flutter pub get
```

## 2. Configurar Firebase
Instale a Firebase CLI e o FlutterFire CLI:
```bash
npm install -g firebase-tools
firebase login
dart pub global activate flutterfire_cli
```
A configuração atual do projeto já está conectada a `lib/firebase_options.dart`, e `lib/main.dart` já inicializa o Firebase com `DefaultFirebaseOptions.currentPlatform`. Se for usar outro projeto Firebase, execute na raiz:
```bash
flutterfire configure
```
Isso atualiza `lib/firebase_options.dart` para o seu projeto. Não publique credenciais privadas nem compartilhe o `google-services.json`.

No Firebase Console, habilite:
- Authentication > Sign-in method > Email/Password
- Firestore Database
- Storage

## 3. Publicar regras
Copie `firestore.rules` para Firestore > Rules e `storage.rules` para Storage > Rules.
As regras fornecidas são uma base inicial. Antes de produção, endureça as regras de atualização de perfil, campos financeiros, administração e validação de participantes.
A foto de capa grava o endereço em `users/{uid}.profileCoverUrl`; publique também a regra de atualização do Firestore incluída nesta versão.

## 4. Executar
```bash
flutter run
```

## 5. Gerar APK
```bash
flutter build apk --release
```
O APK será criado em `build/app/outputs/flutter-apk/app-release.apk`.

## Modelo de dados
- `users/{uid}`: perfil público, dados básicos e flags.
- `users/{uid}/likes/{targetUid}`: curtidas enviadas.
- `matches/{uid1_uid2}`: combinações.
- `chats/{uid1_uid2}/messages/{messageId}`: mensagens.

## Importante antes de publicar
Este é um MVP de código-fonte, não um serviço pronto para produção. Para lançamento real:
1. Implementar moderação, denúncia/bloqueio e fluxo de exclusão de conta.
2. Validar idade e consentimento de forma adequada; não confiar apenas na data informada.
3. Mover operações privilegiadas para Cloud Functions e usar Firebase Custom Claims para administradores.
4. Nunca permitir que o cliente altere `coins`, `diamonds`, `isVip` ou `isAdmin`.
5. Integrar compras reais via Google Play Billing / App Store, com recibos validados no servidor.
6. Rever LGPD, política de privacidade, termos de uso e segurança de dados.
7. Adicionar índices Firestore quando o Console solicitar.

## Observações
- O botão de curtida grava uma curtida; a combinação só é criada quando existe curtida recíproca.
- A tela de moedas/VIP apresenta os planos de referência, mas não cobra valores nem concede benefícios.
- O painel administrativo é demonstrativo. Não habilite `isAdmin` pelo aplicativo; configure acesso com processo seguro no backend.


## Chat grátis
O chat não tem cobrança por mensagem, não consome moedas e não exige assinatura VIP.
Na versão inicial, a conversa é liberada quando os dois usuários se curtem e formam um match.


## Arquivos adicionais incluídos nesta revisão
- `firebase.json` e `firestore.indexes.json`: configuração de deploy e índice da lista de matches.
- `functions/`: Cloud Functions TypeScript para curtir com match no servidor e revisar denúncias.
- Denúncia e bloqueio de perfis, além da ação de excluir conta, foram adicionados à interface.
- Regras Firestore reforçadas para impedir alteração pelo cliente dos campos `coins`, `diamonds`, `isVip` e `isAdmin`; leitura de perfis limitada conforme visibilidade pública/amigos/privada.

## Tarefas, presentes e alianças
As funções `claimDailyTask` e `sendStoreItem` validam recompensas e preços no servidor. Tarefas de mensagens e curtidas exigem a quantidade mínima concluída no dia; completar perfil exige foto e bio. O bônus de boas-vindas de 100 moedas é concedido somente na criação do perfil. Presentes e alianças são entregues na subcoleção privada `users/{uid}/receivedItems`. A aliança BFF grátis pode ser resgatada uma única vez por conta. Compras de moeda real continuam desativadas até a integração de faturamento da loja.

## Implantar as Cloud Functions
```bash
cd functions
npm install
npm run build
cd ..
firebase deploy --only firestore:rules,firestore:indexes,storage,functions
```

## Atenção: atualização necessária no aplicativo
A função `likeUser` no backend deve ser chamada pelo Flutter para criar matches, em vez de gravar documentos `matches` diretamente. Para isso, adicione `cloud_functions` ao `pubspec.yaml` e substitua a implementação do método `like` em `DataService` por uma chamada callable. A versão cliente antiga não cria matches com as regras reforçadas. A implantação de produção exige testes, política de privacidade e revisão de segurança.

## Animação de entrada
Ao iniciar, o LoveMix mostra uma tela de abertura com o coração e o nome entrando com efeitos de fade, zoom e movimento vertical. Depois de aproximadamente 1,9 segundo, abre o login ou a tela inicial conforme o estado de autenticação.


## Ajustes desta revisão
- O botão X agora registra que o perfil foi ignorado; ele não envia uma curtida.
- As ações de estrela e coração enviam curtida e mostram quando ocorre um match.
- O envio de mensagem atualiza apenas o chat criado pelo match; não tenta alterar o documento `matches`, que é protegido pelas regras.
- Foi criada a coleção privada `users/{uid}/passed/{targetUid}` nas regras do Firestore.

## Criar os projetos nativos Android/iOS
Os diretórios nativos não podem conter os identificadores e certificados do seu aplicativo sem os dados do seu projeto. Na raiz do projeto, execute:
```bash
flutter create . --platforms=android,ios
```
Se for publicar apenas para Android:
```bash
flutter create . --platforms=android
```
Depois configure Firebase:
```bash
flutterfire configure
```
Habilite Email/Senha no Firebase Authentication e crie Firestore e Storage. Para usar o login social Google, é necessário configurar os provedores e os arquivos/IDs OAuth do seu projeto; essa integração não é ativada apenas por adicionar um botão.

## O que ainda depende das suas contas/decisões
Não existe um código universal que substitua os identificadores Firebase, certificados Android, credenciais OAuth ou contas de pagamento. Também não há como gerar uma compra real sem configurar Google Play Billing/App Store e validação no servidor. O projeto é uma base de MVP e ainda precisa de testes em aparelho, revisão de segurança/LGPD e moderação antes de ser publicado.


## Presença online
A tela inicial marca o usuário como online quando o app está em primeiro plano e como offline quando vai para segundo plano/é fechado. Os perfis exibem “Online agora” quando `isOnline` está verdadeiro. Em celulares, o sistema pode encerrar o processo sem avisar; por isso o estado pode demorar a atualizar em casos de queda de rede ou encerramento forçado. Para presença de produção com detecção mais precisa, configure Firebase Realtime Database com `onDisconnect` e sincronização com Firestore.


## Notificações de mensagens e curtidas (FCM)
O projeto usa Firebase Cloud Messaging e notificações locais para mostrar alertas quando o app está aberto. As Cloud Functions `notifyOnMessage` e `notifyOnLike` enviam push para os dispositivos registrados, inclusive com o app em segundo plano/fechado.

1. No Firebase Console, abra **Configurações do projeto > Seus apps > Android** e confirme que o app Android está registrado.
2. Baixe/atualize o `google-services.json` para `android/app/` depois de criar as pastas Android com `flutter create . --platforms=android`.
3. Confira se `android/app/src/main/AndroidManifest.xml` contém esta permissão logo antes da tag `<application>`: `<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />`. O Android 13 ou superior exige essa permissão em tempo de execução; o app solicitará autorização na primeira sessão autenticada.
4. Instale as dependências Flutter: `flutter pub get`.
5. Publique as funções: `cd functions && npm install && npm run build && cd .. && firebase deploy --only functions,firestore:rules`.
6. Teste com duas contas: a conta A curte a conta B ou envia mensagem no chat; a conta B deve receber o alerta.

Os tokens FCM ficam em `users/{uid}/fcmTokens/{token}` e as regras permitem que cada pessoa gerencie somente os próprios tokens. As notificações dependem de Firebase corretamente configurado, Cloud Functions implantadas, conexão com a internet e permissão concedida no Android. No modo de primeiro plano, o alerta é exibido por notificação local.


## Salas de bate-papo e presentes virtuais

O app inclui uma aba **Salas** para criar e entrar em salas públicas. Dentro de cada sala, os participantes podem conversar em grupo e enviar presentes virtuais gratuitos (coração, rosa, presente, diamante, ursinho e estrela) a outros participantes. Os presentes não descontam moedas e não envolvem pagamento.

Para ativar no Firebase, publique as regras, índices e Cloud Functions: `firebase deploy --only firestore:rules,firestore:indexes,functions`. A primeira consulta às salas pode solicitar a criação do índice composto; o índice já está declarado em `firestore.indexes.json`. As notificações de mensagens e presentes em salas usam Firebase Cloud Messaging e dependem de tokens de dispositivo registrados.

## Gerar APK usando somente o celular (GitHub Actions)

O projeto inclui `.github/workflows/build-apk.yml`. Esse fluxo cria a pasta Android na nuvem, configura o plugin Google Services, executa `flutter analyze` e compila o APK. Para o Firebase funcionar, é obrigatório fornecer o arquivo de configuração do seu próprio projeto Firebase.

1. Crie um projeto no Firebase e registre um aplicativo Android com o identificador de pacote `com.example.lovemix` (ou ajuste o `applicationId` no Android para o identificador escolhido).
2. Baixe o arquivo `google-services.json` desse aplicativo Android.
3. Envie este ZIP para um repositório GitHub e extraia o conteúdo na raiz do repositório (a pasta `.github` precisa ficar visível na raiz).
4. No GitHub, abra Settings > Secrets and variables > Actions > New repository secret.
5. Crie uma chave de assinatura Android persistente (não use uma chave diferente a cada build). Em um computador com Java/keytool, execute `keytool -genkeypair -v -keystore lovemix-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias lovemix` e guarde com segurança o arquivo e as senhas.
6. Obtenha os fingerprints dessa chave com `keytool -list -v -keystore lovemix-release.jks -alias lovemix` e cadastre SHA-1 e SHA-256 em Configurações do projeto > Seus apps > Android no Firebase.
7. Ative Google em Authentication > Sign-in method, defina o e-mail de suporte e baixe novamente o `google-services.json`.
8. Converta `lovemix-release.jks` para Base64 (Linux: `base64 -w 0 lovemix-release.jks`; macOS: `base64 lovemix-release.jks | tr -d '\n'`). No GitHub, em Settings > Secrets and variables > Actions, crie `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` (por exemplo `lovemix`) e `ANDROID_KEY_PASSWORD`.
9. Crie também o secret `GOOGLE_SERVICES_JSON` e cole nele todo o conteúdo do arquivo `google-services.json` recém-baixado.
10. Abra Actions > Gerar APK LoveMix > Run workflow. Aguarde terminar e, em Artifacts, baixe `lovemix-apk` e extraia `app-release.apk`.
11. A etapa **Mostrar SHA-1 e SHA-256 da chave persistente** confirma os fingerprints cadastrados. Eles permanecem iguais nos builds seguintes, desde que você preserve o mesmo arquivo `.jks`.

Se o identificador do app Android no Firebase não for `com.example.lovemix`, altere o `applicationId` gerado no Android antes de compilar para ficar idêntico ao cadastrado no Firebase. Não compartilhe o `google-services.json` publicamente em mensagens.

## O que ainda exige configuração externa

- O projeto Firebase precisa existir e ter Authentication (Email/Senha), Firestore, Storage e Cloud Messaging ativados.
- As regras e índices devem ser publicados; as Cloud Functions precisam ser implantadas com Firebase CLI e plano compatível com Functions.
- Notificações push e salas dependem das Functions implantadas e das permissões Android.
- A compilação automática gera um APK, mas não configura contas, credenciais, política de privacidade, verificação de idade, testes de segurança nem publicação na Play Store.
- O fluxo de APK usa Android apenas. Não gera iOS.


## Login com Google e correção de configuração

O aplicativo inclui login com Google usando `google_sign_in` e Firebase Authentication. Para ativar no seu projeto real:

1. No Firebase Console, abra Authentication > Sign-in method e habilite Google e E-mail/senha.
2. Em Configurações do projeto > Seus apps > Android, confirme que o app Android está registrado. O workflow lê o `package_name` do `google-services.json` e aplica o mesmo `applicationId` ao APK.
3. Em Configurações do projeto > Seus apps > Android, adicione os certificados SHA-1 e SHA-256 da chave que assina o APK. Para o APK de teste gerado no GitHub Actions, gere/obtenha o certificado da chave de assinatura usada no build; para um APK assinado por você, cadastre o SHA da sua própria chave.
4. Baixe novamente o `google-services.json` depois de registrar o app e/ou atualizar as configurações e atualize o secret `GOOGLE_SERVICES_JSON` no GitHub.
5. Confirme que o e-mail de suporte do projeto está definido nas configurações do provedor Google.
6. Gere e instale um APK novo. O botão Google não funcionará em APK antigo.

O primeiro acesso com Google pede a data de nascimento e só cria o perfil se a pessoa tiver 18 anos ou mais. O login por Google não ignora essa etapa. O erro `CONFIGURATION_NOT_FOUND` não pode ser resolvido apenas pelo código se o provedor, o app Android, o pacote ou as credenciais OAuth estiverem ausentes no Console Firebase.

## Desempenho em aparelhos de entrada

O app mantém layouts simples, limites nas consultas Firestore e carregamento de listas paginado/limitado. Para aparelhos com pouca memória, prefira imagens de perfil comprimidas e conexão estável; recursos como notificações e Storage dependem da configuração do projeto Firebase.


## Descobrir pessoas do mundo todo
A aba Descobrir apresenta perfis ativos com visibilidade pública de diferentes países, com busca por nome, cidade ou país e filtro de país. Para aparecer corretamente nos filtros internacionais, cada pessoa deve preencher Cidade e País em Editar perfil. Perfis privados e de amigos não aparecem na descoberta pública; as regras do Firestore também impedem a leitura direta desses perfis por pessoas não autorizadas. A consulta de descoberta carrega até 500 perfis ativos por vez.


## Diagnóstico adicional do login Google
O workflow agora valida o `google-services.json` antes de compilar: ele exige o pacote `com.example.lovemix` e um cliente OAuth WEB (`client_type: 3`). Se essa validação falhar, o secret `GOOGLE_SERVICES_JSON` do GitHub está antigo/incompleto e precisa ser substituído pelo arquivo recém-baixado do Firebase. O código também mostra um diagnóstico mais específico quando o plugin Google retorna `DEVELOPER_ERROR`. Isso não cria credenciais OAuth: elas precisam ser emitidas pelo Firebase/Google para o certificado SHA da chave que assina o APK.


### Passos obrigatórios para corrigir o login Google no APK

Depois de configurar a chave persistente e executar o workflow **Gerar APK LoveMix** no GitHub:

1. Abra o log da etapa **Mostrar SHA-1 e SHA-256 da assinatura do APK** e copie os dois fingerprints.
2. No Firebase Console, abra **Configurações do projeto > Seus apps > Android** e confirme o pacote `com.example.lovemix`.
3. Cadastre ali o SHA-1 e o SHA-256 mostrados no log. Em **Authentication > Sign-in method**, confirme que Google está ativado e que há um e-mail de suporte.
4. Baixe o novo `google-services.json` e atualize o secret `GOOGLE_SERVICES_JSON` no GitHub (Settings > Secrets and variables > Actions).
5. Execute o workflow novamente e instale o APK recém-gerado. A chave persistente mantém os mesmos fingerprints entre builds; não perca nem substitua o arquivo `.jks`.

**Importante:** o fingerprint precisa corresponder exatamente à chave que assinou o APK instalado. Se você trocar a chave de assinatura, cadastre também os fingerprints dessa nova chave no Firebase. Não publique o `google-services.json` nem chaves privadas em repositórios públicos.


## Atualização visual LoveMix Neon (07/11/2026)

- Atualizada a identidade visual para preto arroxeado, neon rosa e roxo.
- Atualizados tema global, campos, botões e destaques das telas existentes.
- Reformulada a listagem de salas públicas com cartões em gradiente e chamada visual para criar sala.
- Mantidos os fluxos existentes de autenticação Google/e-mail e os serviços Firebase.

Observação: esta atualização é visual. As salas existentes continuam sendo salas de mensagens de texto; voz, vídeo, lives e recursos de palco exigem implementação e infraestrutura adicionais e não são anunciados como funcionais nesta versão.


## Ajuste adicional do login Google

O build injeta automaticamente o ID do cliente OAuth WEB lido do `google-services.json`, evitando manter um ID duplicado no código. Antes de compilar, o workflow compara o SHA-1 do keystore de release com o SHA-1 do cliente OAuth Android no arquivo Firebase. Se forem diferentes, a compilação para com uma mensagem clara: cadastre o SHA-1 da chave de assinatura no Firebase, baixe novamente o `google-services.json` e atualize o secret `GOOGLE_SERVICES_JSON`. O código também limpa a sessão Google anterior antes de abrir o seletor de contas.


## Telas sociais incluídas nesta atualização visual

- Descobrir pessoas e perfis.
- Mensagens privadas entre combinações (matches).
- Salas públicas de bate-papo por texto e criação de salas.
- Presentes virtuais nas salas.
- Perfil, edição de dados e publicação de fotos.
- Ranking de usuários por saldo de moedas, atualizado pelo Firestore.

Observação: as salas desta versão são de texto. Áudio ao vivo, vídeo ao vivo e presentes com cobrança/compra não estão implementados nesta entrega.


## Atualização visual: conversas, salas, recursos e ranking

- Conversas com balões diferenciados, avatar carregado do perfil, reações rápidas e atalhos de voz/vídeo.
- Criação de salas com nome, descrição, categoria, opção pública/privada e campo de senha (a senha é armazenada como hash SHA-256).
- Nova tela **Recursos Incríveis**, acessível pelo ícone de brilho no início, com cartões para voz, vídeo, lives, jogos, presentes, compatibilidade, comunidades e eventos.
- Ranking com abas Geral, Amizades e Namoro, pódio e lista de participantes com fotos.

**Atenção:** os cartões de voz, vídeo e lives são a interface de entrada; chamadas e transmissão em tempo real ainda precisam de integração com um provedor apropriado. O campo de senha de sala privada é armazenado como hash, mas o fluxo seguro de convite/validação e entrada de convidados ainda precisa ser implementado no backend antes de usar salas privadas em produção. O ranking de amizades/namoro usa os interesses cadastrados e usa moedas como critério alternativo quando não existe pontuação de curtidas.

## Atualização da sala de voz (interface e presentes)

Esta versão acrescenta ao fluxo de salas:
- animação de entrada dos avatares dos participantes;
- efeito visual temporário para presentes recebidos em tempo real;
- presentes Lamborghini (5.000 diamantes) e iPhone 18 (13.000 moedas), além dos presentes básicos;
- callable Cloud Function `sendRoomGift`, que valida a participação na sala e desconta o saldo no servidor antes de registrar o evento do presente.

Para ativar o envio real de presentes, publique as funções e os índices/regras do Firebase. O áudio bidirecional ao vivo ainda não está integrado nesta versão: o botão de microfone da interface não transmite áudio. É necessária a configuração de um provedor de áudio (por exemplo, LiveKit) e de um serviço seguro de emissão de tokens antes de anunciar chamadas ao vivo.


## Stories (fotos e vídeos)
- O LoveMix agora permite publicar stories de foto ou vídeo pela faixa de stories no Início e em Descobrir.
- Fotos são comprimidas na seleção; vídeos têm duração máxima de 30 segundos.
- Stories expiram após 24 horas e podem ser visualizados tocando no avatar.
- Para ativar a função no Firebase, publique também os arquivos `firestore.rules` e `storage.rules` no Console do Firebase (Firestore Database > Regras e Storage > Regras).
- A dependência `video_player` será baixada automaticamente ao executar `flutter pub get`.

## Mural de Alianças

A aba **💍 Mural** foi adicionada à área **Descobrir pessoas**. Usuários autenticados podem criar convites de aliança usando o ID público `LM-...`, escolhendo Namorados, BFF, Amigos ou Irmãos e uma data de início. A outra pessoa pode aceitar ou recusar; os dois participantes veem o cartão no mural com fotos, nomes e status.

Para habilitar a função no Firebase, publique as regras atualizadas do Firestore:

```bash
firebase deploy --only firestore:rules
```

As regras permitem que somente os participantes leiam uma aliança e que somente a pessoa convidada aceite ou recuse o convite.


## Integração ZEGOCLOUD (voz, vídeo e lives)

Esta versão integra os kits oficiais Flutter da ZEGOCLOUD:
- `zego_uikit_prebuilt_live_audio_room`: salas de voz com palco e controle de microfone.
- `zego_uikit_prebuilt_live_streaming`: lives de vídeo com host e espectadores.
- As salas públicas usam os documentos `rooms` do Firestore; o código da sala é o ID que os convidados podem compartilhar.
- Ao entrar em uma live, cada pessoa escolhe o nome que será exibido. O ID LoveMix permanece fixo; toque no cartão de identidade para ver a lista de participantes e seus IDs.
- O botão Presentes usa a Cloud Function `sendRoomGift`, que valida o saldo e debita moedas/diamantes no servidor.

O AppID e AppSign informados pelo proprietário estão em `lib/services/zego_config.dart`. O AppSign é uma credencial de cliente: para produção, a ZEGOCLOUD recomenda autenticação por Token gerado no servidor e não manter AppSign estático no aplicativo. Se o AppSign foi exposto fora de um canal privado, considere rotacioná-lo no Console.

O workflow Android configura `compileSdk 37` e as permissões INTERNET, CAMERA, RECORD_AUDIO e MODIFY_AUDIO_SETTINGS. Para compilar, execute `flutter pub get`, publique `firestore.rules` e `firestore.indexes.json`, e implante as Cloud Functions já existentes:
`firebase deploy --only firestore:rules,firestore:indexes,functions`

A integração ainda precisa ser compilada e testada em dois ou mais celulares Android reais, com o projeto ZEGOCLOUD ativo. A tela de lives usa o kit pronto da ZEGO; a lista de transmissões é descoberta via Firestore. O AppSign não substitui a implantação das regras e Functions do Firebase.

Para usar a lista de participantes e os nomes escolhidos na live, publique também as regras atualizadas do `firestore.rules` antes de entrar ou criar uma transmissão.

No Console ZEGOCLOUD, habilite o serviço **In-app Chat/Signaling** para habilitar solicitações de co-host nas lives de vídeo. A conta ZEGOCLOUD pode exigir configuração/limites próprios do projeto.


## Revisão dos controles da sala de voz
- Minimização dentro do aplicativo pelo botão superior do Zego.
- Microfone começa desligado; o botão inferior do próprio Zego alterna ligar/desligar.
- Chat de mensagens ao vivo habilitado na sala.
- Para liberar os assentos da sala, publique as regras do Firestore após atualizar o projeto: `firebase deploy --only firestore:rules`. Cada assento é vinculado à conta autenticada e só pode ser ocupado por uma pessoa.
- O anfitrião pode abrir a lista de membros; o menu nativo do Zego oferece remoção da sala, remoção do assento e atribuição/revogação de coanfitrião.
- O anfitrião pode bloquear/desbloquear a entrada na sala pelo botão de cadeado; o bloqueio é gravado em `rooms/{roomId}.isLocked` e também é verificado por `joinRoom` e pelas regras do Firestore.
- O botão de assento fechado controla separadamente quem pode ocupar o palco.

A integração ainda precisa ser compilada e testada no ambiente Flutter/Android do projeto. O bloqueio de entrada não é um banimento permanente individual; a remoção individual pelo menu do Zego expulsa da sessão atual.

## Molduras de perfil

O LoveMix inclui uma loja de molduras no perfil: Clássica (grátis), Neon Love (250 moedas), Corações (400 moedas), Dourada VIP (50 diamantes) e Galáxia (100 diamantes). A moldura equipada aparece no perfil público, na prévia do próprio perfil, no cabeçalho de conversas e nos participantes/assentos das salas.

As compras são validadas no servidor pela função `purchaseProfileFrame`; o aplicativo não pode adicionar molduras pagas ao inventário nem descontar saldo diretamente. Depois de atualizar o projeto, publique a função e as regras do Firestore com `firebase deploy --only functions,firestore:rules`.


## Build para iPhone (iOS)

Foi adicionado o workflow `.github/workflows/ios.yml`, executado em macOS pelo GitHub Actions. Antes de rodá-lo, registre um app iOS no projeto Firebase `lovemix-73849` e crie estes GitHub Actions Secrets:

- `FIREBASE_IOS_APP_ID`: identificador `1:...:ios:...` mostrado no Firebase para o app iOS.
- `IOS_BUNDLE_ID`: Bundle ID idêntico ao cadastrado no Firebase (ex.: `com.suaempresa.lovemix`).
- `GOOGLE_SERVICE_INFO_PLIST`: conteúdo completo do arquivo `GoogleService-Info.plist` baixado do Firebase.

O workflow compila e entrega um pacote **sem assinatura** para validação. Para instalar em um iPhone físico, publicar na App Store ou distribuir via TestFlight, ainda é obrigatório assinar com certificado e provisioning profile de uma conta Apple Developer. Esse pacote sem assinatura não é instalável diretamente no iPhone. O build Android continua no workflow `main.yml`.
