import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'services/data_service.dart';

class _AnimatedEntryGate extends StatefulWidget {
  const _AnimatedEntryGate();

  @override
  State<_AnimatedEntryGate> createState() => _AnimatedEntryGateState();
}

class _AnimatedEntryGateState extends State<_AnimatedEntryGate>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _scale;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 650),
    );
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _scale = Tween<double>(begin: 0.65, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
    _slide = Tween<Offset>(begin: const Offset(0, 0.18), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LoveMixApp.background,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: ScaleTransition(
              scale: _scale,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.favorite, color: LoveMixApp.gold, size: 82),
                  SizedBox(height: 12),
                  Text('LoveMix', style: TextStyle(
                    color: LoveMixApp.gold, fontSize: 43,
                    fontWeight: FontWeight.w900, letterSpacing: 1.2,
                  )),
                  SizedBox(height: 8),
                  Text('Conecte pessoas, viva novas histórias!',
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LoveMixApp extends StatelessWidget {
  const LoveMixApp({super.key});

  static const gold = Color(0xFFE7BD50);
  static const background = Color(0xFF090806);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LoveMix',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: gold,
          surface: Color(0xFF17140E),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: background,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF14120D),
          hintStyle: const TextStyle(color: Colors.white54),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: Color(0xFF66552C)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: Color(0xFF66552C)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(13),
            borderSide: const BorderSide(color: gold, width: 1.5),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: gold,
            foregroundColor: Colors.black,
            minimumSize: const Size.fromHeight(50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
            textStyle: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        useMaterial3: true,
      ),
      home: _LoveMixEntry(),
    );
  }
}

class _LoveMixEntry extends StatefulWidget {
  @override
  State<_LoveMixEntry> createState() => _LoveMixEntryState();
}

class _LoveMixEntryState extends State<_LoveMixEntry> {
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1100), () {
      if (mounted) setState(() => _showSplash = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_showSplash) return const _AnimatedEntryGate();
    return StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          final user = snapshot.data;
          if (user == null) return const AuthScreen();
          // Aguarda o perfil do Firestore. Isso evita abrir a tela principal
          // antes de terminar o primeiro cadastro (inclusive via Google).
          return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
            builder: (context, profileSnapshot) {
              if (profileSnapshot.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                  backgroundColor: LoveMixApp.background,
                  body: Center(child: CircularProgressIndicator(color: LoveMixApp.gold)),
                );
              }
              if (profileSnapshot.hasError) {
                return Scaffold(
                  backgroundColor: LoveMixApp.background,
                  body: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.cloud_off, color: LoveMixApp.gold, size: 48),
                          const SizedBox(height: 16),
                          const Text(
                            'Sua conta Google entrou, mas não foi possível carregar seu perfil.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Detalhes: ${profileSnapshot.error}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                          const SizedBox(height: 18),
                          ElevatedButton(
                            onPressed: () => setState(() {}),
                            child: const Text('Tentar novamente'),
                          ),
                          TextButton(
                            onPressed: () => FirebaseAuth.instance.signOut(),
                            child: const Text('Sair da conta'),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }
              return profileSnapshot.data?.exists == true
                  ? const HomeScreen()
                  : _CompleteProfileScreen(user: user);
            },
          );
        },
      );
  }
}


/// Recupera contas autenticadas que ficaram sem documento de perfil no Firestore.
/// Isso evita mandar o usuário de volta à tela de login após autenticar.
class _CompleteProfileScreen extends StatefulWidget {
  const _CompleteProfileScreen({required this.user});
  final User user;

  @override
  State<_CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<_CompleteProfileScreen> {
  late final TextEditingController _name;
  DateTime? _birthday;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    final displayName = (widget.user.displayName ?? '').trim();
    _name = TextEditingController(
      text: displayName.isNotEmpty
          ? displayName
          : (widget.user.email?.split('@').first ?? ''),
    );
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  bool _isAdult(DateTime date) {
    final now = DateTime.now();
    var age = now.year - date.year;
    if (now.month < date.month ||
        (now.month == date.month && now.day < date.day)) age--;
    return age >= 18;
  }

  Future<void> _chooseBirthday() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime(1900),
      lastDate: DateTime(now.year - 18, now.month, now.day),
      initialDate: DateTime(now.year - 25, now.month, now.day),
      helpText: 'Confirme que você tem 18 anos ou mais',
    );
    if (date != null && mounted) setState(() => _birthday = date);
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || _birthday == null) {
      setState(() => _error = 'Informe seu nome e sua data de nascimento.');
      return;
    }
    if (!_isAdult(_birthday!)) {
      setState(() => _error = 'O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }
    setState(() { _saving = true; _error = null; });
    try {
      await widget.user.updateDisplayName(_name.text.trim());
      await DataService.instance.createUser(
        name: _name.text.trim(),
        birthday: _birthday!,
      );
      // O StreamBuilder do perfil detecta o documento criado e abre a Home.
    } on FirebaseException catch (e) {
      if (mounted) setState(() => _error =
          'Não foi possível salvar seu perfil (${e.code}). Confira as regras do Firestore e tente novamente.');
    } catch (_) {
      if (mounted) setState(() => _error =
          'Não foi possível salvar seu perfil. Verifique a internet e tente novamente.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LoveMixApp.background,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.favorite, color: LoveMixApp.gold, size: 58),
                  const SizedBox(height: 12),
                  const Text('Só falta completar seu perfil',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(widget.user.email ?? '', textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 24),
                  TextField(controller: _name,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      hintText: 'Nome completo',
                      prefixIcon: Icon(Icons.person_outline))),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _saving ? null : _chooseBirthday,
                    icon: const Icon(Icons.calendar_month),
                    label: Text(_birthday == null ? 'Data de nascimento (18+)'
                      : '${_birthday!.day}/${_birthday!.month}/${_birthday!.year}'),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 18),
                  ElevatedButton(
                    onPressed: _saving ? null : _save,
                    child: _saving
                      ? const SizedBox(height: 20, width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                      : const Text('Salvar e continuar'),
                  ),
                  TextButton(
                    onPressed: _saving ? null : () async {
                      await FirebaseAuth.instance.signOut();
                    },
                    child: const Text('Sair desta conta'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
