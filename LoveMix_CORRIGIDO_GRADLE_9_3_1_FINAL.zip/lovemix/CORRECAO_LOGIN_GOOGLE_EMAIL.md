# Correção do login Google e e-mail — LoveMix

## O que foi ajustado no projeto
- O login por e-mail não espera mais a chamada administrativa opcional `claimFounderAdmin` para liberar a janela de entrada.
- Depois que o Firebase autentica a conta, a folha/modal de login é fechada; o `authStateChanges()` da aplicação direciona para a Home ou para completar o perfil.
- O login Google também não fica aguardando a chamada administrativa opcional antes de mudar de tela.
- O Gradle Android (arquivo Groovy `android/app/build.gradle`) agora usa a keystore persistente fornecida pelo GitHub Actions, em vez de ignorar a chave e assinar sempre com `debug`.
- O workflow foi ajustado para localizar e configurar os arquivos Gradle Groovy existentes no projeto.

## Etapa obrigatória para eliminar `DEVELOPER_ERROR` do Google
O erro `DEVELOPER_ERROR` (código 10) é uma rejeição da configuração OAuth. O pacote precisa ser `com.example.lovemix` e o SHA-1 da chave que assina o APK instalado precisa estar cadastrado no mesmo projeto Firebase/Google Cloud.

1. No GitHub, abra **Settings > Secrets and variables > Actions**.
2. Configure os quatro secrets de assinatura, se ainda não existirem: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` e `ANDROID_KEY_PASSWORD`. Use uma keystore de release persistente; não troque essa chave entre compilações.
3. Execute **Actions > Gerar APK LoveMix > Run workflow**.
4. Abra o resumo da execução e copie os valores **SHA-1** e **SHA-256** exibidos para a chave de assinatura/APK.
5. No Firebase Console, abra o projeto `lovemix-73849` > Configurações do projeto > Seus apps > Android (`com.example.lovemix`) e adicione esses dois fingerprints.
6. Em **Authentication > Sign-in method**, confirme que o provedor **Google** está ativado.
7. Baixe o novo `google-services.json` no Firebase e substitua os arquivos `google-services.json` da raiz e `android/app/google-services.json` do projeto. Se o GitHub Secret `GOOGLE_SERVICES_JSON` estiver configurado, atualize-o também com o conteúdo novo; ele tem prioridade no workflow.
8. Execute o workflow novamente e instale o APK recém-gerado.

Se o workflow informar que os secrets `ANDROID_*` não estão configurados, ele usará a chave debug temporária do runner. Nesse caso o SHA-1 pode mudar a cada execução e o Google Login continuará sujeito ao `DEVELOPER_ERROR`. Para um login Google estável, configure a keystore persistente antes de gerar o APK.

## Limite do que pode ser validado daqui
A transição de tela e a configuração de assinatura foram ajustadas no código, mas a autenticação Google real só pode ser confirmada depois de cadastrar o SHA-1/SHA-256 corretos no Firebase e instalar o APK assinado por essa mesma chave. Não inclua senhas nem arquivos privados da keystore no repositório público.
