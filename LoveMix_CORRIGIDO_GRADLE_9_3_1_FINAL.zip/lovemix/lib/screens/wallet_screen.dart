import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

const _gold = Color(0xFFFF2DAB);
const _panel = Color(0xFF241333);

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  @override
  Widget build(BuildContext context) => const _BalanceTab();
}

class _BalanceTab extends StatelessWidget {
  const _BalanceTab();
  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: DataService.instance.myProfile(),
    builder: (context, snap) {
      final p = snap.data?.data() ?? {};
      return ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [Expanded(child: _currencyCard('Moedas', '${p['coins'] ?? 0}', '🪙')), const SizedBox(width: 10), Expanded(child: _currencyCard('Diamantes', '${p['diamonds'] ?? 0}', '💎'))]),
        const SizedBox(height: 12),
        const Card(color: _panel, child: ListTile(leading: Icon(Icons.chat_bubble, color: _gold), title: Text('Chat sempre grátis'), subtitle: Text('Conversar com seus matches não consome moedas.'))),
        const SizedBox(height: 16),
        const Text('Resgatar moedas e diamantes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Adicione saldo usando somente códigos promocionais. Não há compras com dinheiro nesta aba.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 8),
        const _WalletCodeRedeemer(),
        const SizedBox(height: 20), const Text('Diamantes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const Text('Diamantes são uma moeda especial para presentes e alianças premium.'),
      ]);
    },
  );

  Widget _currencyCard(String title, String amount, String emoji) => Card(color: _panel, child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [Text(emoji, style: const TextStyle(fontSize: 30)), Text(amount, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: _gold)), Text(title)])));
}


class _WalletCodeRedeemer extends StatefulWidget {
  const _WalletCodeRedeemer();
  @override
  State<_WalletCodeRedeemer> createState() => _WalletCodeRedeemerState();
}

class _WalletCodeRedeemerState extends State<_WalletCodeRedeemer> {
  final _controller = TextEditingController();
  bool _loading = false;

  Future<void> _redeem() async {
    final code = _controller.text.trim().toUpperCase();
    if (code.isEmpty || _loading) return;
    setState(() => _loading = true);
    try {
      final reward = await DataService.instance.redeemPromoCode(code);
      final message = reward == 'vip'
          ? 'VIP liberado com sucesso!'
          : 'Código resgatado! +2.000 moedas e +2.000 diamantes.';
      _controller.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Card(
    color: _panel, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      TextField(controller: _controller, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Código de resgate', hintText: 'Digite seu código', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      ElevatedButton(onPressed: _loading ? null : _redeem, child: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Resgatar código')),
    ])),
  );
}

