# Correção do envio de presentes para si mesmo

A callable `sendRoomGift` foi ajustada para reconhecer o anfitrião (`ownerId`) como participante da própria sala, mesmo em salas antigas cujo array `members` não esteja sincronizado. O envio para si mesmo continua permitido somente ao anfitrião; para enviar a terceiros, ambos precisam continuar listados como participantes.

Também foram separados os erros de sala inexistente, perfil do remetente inexistente e perfil do destinatário inexistente, para que `NOT_FOUND` não esconda a origem do problema.

## Publicar a correção

Na raiz do projeto, execute:

```bash
cd functions
npm install
npm run build
cd ..
npx firebase-tools deploy --only functions:sendRoomGift
```

Depois de publicar a função, compile e instale novamente o APK. A função é executada no Firebase; apenas substituir o APK não publica essa correção no servidor.
