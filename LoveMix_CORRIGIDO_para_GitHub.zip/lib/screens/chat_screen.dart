import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  @override
  void dispose() { input.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return Scaffold(
      appBar: AppBar(title: Text(widget.otherName)),
      body: Column(children: [
        Expanded(
          child: StreamBuilder(
            stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              return ListView.builder(
                reverse: false,
                padding: const EdgeInsets.all(14),
                itemCount: docs.length,
                itemBuilder: (context, i) {
                  final m = docs[i].data();
                  final mine = m['senderId'] == FirebaseAuth.instance.currentUser!.uid;
                  return Align(
                    alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 5),
                      padding: const EdgeInsets.all(12),
                      constraints: const BoxConstraints(maxWidth: 280),
                      decoration: BoxDecoration(
                        color: mine ? const Color(0xFFB88D2D) : const Color(0xFF252118),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text((m['text'] ?? '').toString(), style: TextStyle(color: mine ? Colors.black : Colors.white)),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'Digite uma mensagem...'))),
              IconButton(
                icon: const Icon(Icons.send, color: Color(0xFFE7BD50)),
                onPressed: () async {
                  final text = input.text;
                  input.clear();
                  await service.sendMessage(widget.chatId, text);
                },
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
