# Sala de voz nova (estilo Litmatch) — LoveMix

## O que mudou
- **Sala antiga removida**: `RoomChatScreen` (8 assentos) e a sala de áudio pronta do Zego (`ZegoUIKitPrebuiltLiveAudioRoom`) saíram. Tudo que abria sala de voz agora abre `lib/screens/love_room_screen.dart`.
- **10 assentos** (2 fileiras de 5) com "Entrar" nos vazios. Ao sentar, o microfone liga (áudio via `ZegoUIKit`).
- **Painel preto "Usuários Off-mic(N)"**: mostra quem entrou na sala e não está em assento. Tem o X para fechar e um botão para reabrir.
- **Baú 🧰 + coroa 👑**: presente enviado ao anfitrião (dono da sala) ou a um admin do app enche o baú. Moedas valem o preço; diamantes valem 10x. Meta: 1000 pontos (`CHEST_TARGET` em `functions/src/index.ts`).
- **Chuva de alianças 💍**: ao encher, o baú solta alianças caindo na tela de todos. Sorteia entre *Aliança de Amigos* e *Aliança de Namorados*. A função `claimRoomDrop` usa transação: **só uma pessoa leva**. A chuva dura 25 s. O ganhador recebe o item em `users/{uid}/receivedItems`.
- Chat com mensagens do sistema (baú abriu / quem pegou).

## Para funcionar (obrigatório)
1. `cd functions && npm run deploy` (atualiza `sendRoomGift` e cria `claimRoomDrop`).
2. Publicar `firestore.rules` (assentos 9 e 10 + subcoleção `drops`).
3. Rodar o workflow de build do APK.

## Ajustes rápidos
- Meta do baú: `CHEST_TARGET` (functions). Duração da chuva: `DROP_LIFETIME_MS`.
- Tipos de aliança: `RING_TYPES` (functions).
- Pessoas que fecham o app sem sair podem continuar aparecendo no painel Off-mic.

## Não testado
Não havia Flutter SDK neste ambiente: o código não foi compilado. Teste com 2 celulares: assentos, áudio, presente ao anfitrião até 1000 pontos e toque simultâneo na aliança.
- O ID mostrado no topo da sala é o ID LoveMix (LM-...) de quem criou a sala; toque para copiar.

---
# Tela de LIVE nova (lib/screens/live_broadcast_screen.dart)
- **Topo:** pílula vermelha AO VIVO, contagem de quem assiste, botão convidar (só anfitrião) e fechar.
- **Vídeo:** anfitrião ocupa a tela toda. Se aceitar convite, vira live em dupla: convidado empilhado em cima, anfitrião embaixo.
- **Esquerda:** comentários em balões que sobem (somem com degradê no alto). Presentes e avisos aparecem ali também.
- **Embaixo:** barra "Adicionar comentário...", ❤️, 👍 e 🎁. Corações/curtidas flutuam na direita para todos.
- Anfitrião/convidado têm botões de microfone e trocar câmera na lateral direita.
- Aparece em Recursos > Salas de Vídeo e Lives LoveMix (substitui a live pronta do Zego).
- Convite: anfitrião toca em convidar, escolhe alguém que está assistindo; a pessoa recebe um aviso para aceitar (liga câmera e mic).
- **Publicar `firestore.rules` de novo** (novas coleções `guests` e `reactions`). Não precisa novo deploy das functions.
- Não compilado/testado (sem Flutter aqui). Teste com 2-3 celulares.

---
# Foto de perfil + comentários do story
- **Lápis na foto de perfil** (aba Perfil): toque no lápis rosa em cima da foto, escolha galeria ou câmera e a foto troca na hora, quantas vezes quiser. O endereço da foto ganha um número de versão para não aparecer a foto antiga em cache.
- **Comentários no story**: barra "Comentar este story..." embaixo, os 3 últimos comentários em balões e botão com a contagem que abre a lista completa. O story pausa enquanto você digita. Quem escreveu ou o dono do story pode apagar o comentário; ao apagar o story, os comentários vão junto. Comentários são públicos para quem vê o story e somem do app quando o story expira.
- **Publicar `firestore.rules` de novo** (subcoleção `stories/{id}/comments`).

---
# Foto completa no perfil
- A foto grande do perfil (sua tela de Perfil e o perfil de outras pessoas) agora aparece INTEIRA, sem cortar: ocupa a largura do cartão, com altura máxima de 520 e fundo desfocado da própria foto nas sobras.
- Tocar na foto grande ou na foto redonda abre em tela cheia, com zoom por pinça (`lib/widgets/full_photo.dart`).
- A galeria de fotos continua com miniaturas quadradas (3 por linha); ao tocar, a foto abre inteira.

---
# Chuva de alianças: no máximo 1 vez a cada 5 dias por sala
- A chuva continua caindo **somente quando alguém manda presente ao anfitrião** e o baú enche. Todo mundo pode seguir mandando presentes à vontade.
- Agora cada sala só pode ter uma chuva a cada 5 dias (`RAIN_COOLDOWN_MS` em `functions/src/index.ts`; o campo `lastRainAt` da sala guarda a última).
- Se o baú encher antes dos 5 dias, ele fica cheio (1000/1000) e a chuva cai no primeiro presente enviado depois do intervalo. Os presentes continuam sendo enviados e contando normalmente.
- **Para valer:** `cd functions && npm run deploy`. Não precisa republicar as regras.
- Não compilado/testado de ponta a ponta.

---
# Correção do carregamento infinito + salas de voz ao vivo na tela inicial
- **Bug do círculo girando** em "Salas em Destaque": as consultas ordenadas exigiam índices do Firestore. Sem o índice, davam erro e a tela ficava girando para sempre. Agora, se o índice faltar, o app usa uma consulta simples sem índice (`_withIndexFallback` em `data_service.dart`), e se mesmo assim falhar mostra uma mensagem em vez do círculo.
- **"Ao vivo agora"**: uma sala de voz aparece ali quando tem alguém dentro (campo `voiceLive`). Mostra "N na sala". Lives/salas de vídeo continuam aparecendo pelo `isLive`.
- Nova função `syncRoomPresence`: conta as pessoas ativas na sala (`participants` com `isActive`) e grava `onlineCount` e `voiceLive` na sala.
- **Para valer:** `cd functions && npm run deploy` e, se quiser os índices, `firebase deploy --only firestore:indexes`. Gere o APK de novo.
- Quem fecha o app à força sem sair continua "ativo" até a sala limpar; a sala pode demorar a sumir do "Ao vivo agora".
- Não compilado/testado (sem Flutter/Firebase aqui).

---
# Sala bloqueada: dono e admins sempre entram
- Bloquear a sala ("Bloquear novas entradas") barra só quem **não** é dono nem admin. O dono sempre volta para a própria sala sem precisar desbloquear, e admins também entram em sala bloqueada.
- Mudou em `joinRoom` (`data_service.dart`) e na regra de `rooms` em `firestore.rules`.
- **Para valer:** publicar `firestore.rules` de novo e gerar o APK. Não precisa deploy das functions.
- Admin = quem tem a claim `admin` (a mesma das regras). Se um admin acabou de ser promovido, ele precisa sair e entrar na conta uma vez.
- Não compilado/testado.

