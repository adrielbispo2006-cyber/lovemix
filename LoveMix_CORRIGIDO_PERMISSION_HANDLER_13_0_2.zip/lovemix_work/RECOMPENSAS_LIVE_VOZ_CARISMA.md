# Recompensas em lives de vídeo e salas de voz

O envio de presentes usa a callable `sendRoomGift` compartilhada pelos dois tipos de sala. Presentes recebidos por anfitriões de vídeo ou voz geram moedas (moedas 1:1; diamantes 10:1) e carisma no perfil. O carisma é incrementado para presentes recebidos de outra conta.

O anfitrião pode selecionar a si mesmo como destinatário. O presente é debitado normalmente, mas auto-presentes não geram moedas de recompensa nem carisma, evitando saldo infinito e manipulação de ranking. Apenas o anfitrião pode enviar presente para si mesmo.

Publique a função atualizada: `cd functions && npm install && npm run build && firebase deploy --only functions:sendRoomGift`. Depois compile e teste o APK.
