import 'package:flutter/material.dart';

class VipNickname extends StatelessWidget {
  const VipNickname({super.key, required this.name, this.isVip = false, this.styleId = 'royal_gold', this.textStyle});
  final String name;
  final bool isVip;
  final String styleId;
  final TextStyle? textStyle;

  static const styles = <String, Map<String, Object>>{
    'royal_gold': {'label':'Coroa Real','left':'♛','right':'†','colors':[Color(0xFFFFE08A),Color(0xFFFFB52E)]},
    'purple_king': {'label':'Rei Roxo','left':'♛','right':'✦','colors':[Color(0xFFD88BFF),Color(0xFF8D35FF)]},
    'pink_love': {'label':'Love Rosa','left':'♥','right':'♥','colors':[Color(0xFFFF8BCB),Color(0xFFFF19B8)]},
    'blue_legend': {'label':'Lenda Azul','left':'♛','right':'†','colors':[Color(0xFF83E7FF),Color(0xFF368CFF)]},
    'red_flame': {'label':'Chama','left':'♛','right':'†','colors':[Color(0xFFFFA06B),Color(0xFFFF3B55)]},
    'emerald': {'label':'Esmeralda','left':'♛','right':'✧','colors':[Color(0xFF8DFFD0),Color(0xFF19B887)]},
  };

  @override
  Widget build(BuildContext context) {
    final base = textStyle ?? const TextStyle(fontSize: 14, fontWeight: FontWeight.w800);
    if (!isVip) return Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: base);
    final style = styles[styleId] ?? styles['royal_gold']!;
    final colors = style['colors'] as List<Color>;
    return ShaderMask(shaderCallback: (bounds) => LinearGradient(colors: colors).createShader(bounds),
      child: Text('${style['left']}  $name  ${style['right']}', maxLines: 1, overflow: TextOverflow.ellipsis,
        style: base.copyWith(color: Colors.white, shadows: [Shadow(color: colors.first.withOpacity(.8), blurRadius: 8)])));
  }
}
