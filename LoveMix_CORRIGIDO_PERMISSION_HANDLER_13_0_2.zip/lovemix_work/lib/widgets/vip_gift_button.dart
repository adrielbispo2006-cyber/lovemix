import 'package:flutter/material.dart';

/// Botão de presentes das salas: caixa preta VIP (substitui o ícone de presente).
class VipGiftButton extends StatelessWidget {
  const VipGiftButton({super.key, required this.onTap, this.size = 46});
  final VoidCallback onTap;
  final double size;

  @override
  Widget build(BuildContext context) => InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFFFFD56A), width: 1.5),
          ),
          child: ClipOval(child: Image.asset('assets/vip_gift_box.jpg', fit: BoxFit.cover)),
        ),
      );
}
