import 'dart:ui' show ImageFilter;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// Abre a foto inteira em tela cheia, com zoom por pinça.
void showFullPhoto(BuildContext context, String url) {
  if (url.isEmpty) return;
  Navigator.of(context).push(MaterialPageRoute<void>(
    builder: (_) => Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, elevation: 0),
      body: Center(
        child: InteractiveViewer(
          minScale: 1,
          maxScale: 5,
          child: CachedNetworkImage(
            imageUrl: url,
            fit: BoxFit.contain,
            placeholder: (_, __) => const CircularProgressIndicator(color: Color(0xFFFF2DAB)),
            errorWidget: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white54, size: 48),
          ),
        ),
      ),
    ),
  ));
}

/// Foto de perfil COMPLETA: nada é cortado. A imagem aparece inteira na largura
/// do cartão (com altura máxima) e as sobras ficam preenchidas por um fundo
/// desfocado da própria foto. Toque para abrir em tela cheia.
class FullProfilePhoto extends StatelessWidget {
  const FullProfilePhoto({super.key, required this.url, this.maxHeight = 520, this.minHeight = 220});
  final String url;
  final double maxHeight;
  final double minHeight;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showFullPhoto(context, url),
      child: ConstrainedBox(
        constraints: BoxConstraints(minHeight: minHeight, maxHeight: maxHeight),
        child: Stack(alignment: Alignment.center, children: [
          Positioned.fill(
            child: ImageFiltered(
              imageFilter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
              child: CachedNetworkImage(
                imageUrl: url,
                fit: BoxFit.cover,
                color: const Color(0x66000000),
                colorBlendMode: BlendMode.darken,
                errorWidget: (_, __, ___) => const ColoredBox(color: Color(0xFF1A1028)),
              ),
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: CachedNetworkImage(
              imageUrl: url,
              fit: BoxFit.contain,
              placeholder: (_, __) => SizedBox(
                height: minHeight,
                child: const Center(child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFF2DAB))),
              ),
              errorWidget: (_, __, ___) => SizedBox(
                height: minHeight,
                child: const Icon(Icons.image_not_supported_outlined, size: 48, color: Colors.white54),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
