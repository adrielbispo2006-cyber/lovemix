import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'post_interactions_screen.dart';
import '../widgets/profile_frame.dart';
import '../widgets/full_photo.dart';
import '../widgets/vip_nickname.dart';

const _profilePink = Color(0xFFFF19B8);
const _profilePurple = Color(0xFF8D35FF);
const _profilePanel = Color(0xFF171022);

class ProfileViewScreen extends StatefulWidget {
  const ProfileViewScreen({super.key, required this.userId});
  final String userId;

  @override
  State<ProfileViewScreen> createState() => _ProfileViewScreenState();
}

class _ProfileViewScreenState extends State<ProfileViewScreen> {
  late Future<DocumentSnapshot<Map<String, dynamic>>> _profileFuture;
  late Future<bool> _matchFuture;

  @override
  void initState() {
    super.initState();
    _profileFuture = FirebaseFirestore.instance.collection('users').doc(widget.userId).get();
    _matchFuture = _checkMatch();
  }

  Future<bool> _checkMatch() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || uid == widget.userId) return false;
    final matches = await FirebaseFirestore.instance.collection('matches')
        .where('users', arrayContains: uid).get();
    return matches.docs.any((d) => List<String>.from(d.data()['users'] ?? []).contains(widget.userId));
  }

  int? _age(DateTime? birthday) {
    if (birthday == null) return null;
    final now = DateTime.now();
    var age = now.year - birthday.year;
    if (now.month < birthday.month || (now.month == birthday.month && now.day < birthday.day)) age--;
    return age;
  }

  String _place(Map<String, dynamic> p) {
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    if (city.isEmpty) return country;
    if (country.isEmpty) return city;
    if (country.toLowerCase() == 'brasil' && city.contains('-')) return city;
    return '$city • $country';
  }

  String _genderSymbol(String gender) => const {
    'woman': '♀', 'man': '♂', 'non_binary': '⚧', 'other': '✦',
  }[gender] ?? '';

  @override
  Widget build(BuildContext context) {
    final currentUid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final isOwner = currentUid == widget.userId;
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(
        title: const Text('Perfil'),
        backgroundColor: const Color(0xFF080510),
        actions: [
          if (!isOwner) PopupMenuButton<String>(
            onSelected: (value) => value == 'report' ? _report(context) : _block(context),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'report', child: Text('Denunciar perfil')),
              PopupMenuItem(value: 'block', child: Text('Bloquear usuário')),
            ],
          ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: _profileFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: _profilePink));
          }
          if (snap.hasError || !snap.hasData || !snap.data!.exists) {
            return const Center(child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Este perfil está indisponível ou é privado.', textAlign: TextAlign.center),
            ));
          }
          final p = snap.data!.data() ?? <String, dynamic>{};
          final cover = (p['profileCoverUrl'] ?? '').toString();
          final photo = cover.isNotEmpty ? cover : (p['photoUrl'] ?? '').toString();
          final birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
          final age = _age(birthday);
          final location = _place(p);
          final gender = (p['gender'] ?? '').toString();
          final genderSymbol = _genderSymbol(gender);
          final interests = List<String>.from(p['interests'] ?? const []);
          final bio = (p['bio'] ?? '').toString().trim();
          final online = p['isOnline'] == true;
          final name = (p['name'] ?? 'Pessoa').toString();

          return FutureBuilder<bool>(
            future: _matchFuture,
            builder: (context, matchSnap) {
              final isMatched = matchSnap.data == true;
              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF05030A),
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: _profilePurple.withOpacity(.85), width: 1.4),
                      boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.18), blurRadius: 20)],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(16, 22, 16, 18),
                        decoration: const BoxDecoration(gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFF210A38), Color(0xFF0B0612), Color(0xFF05030A)],
                        )),
                        child: Column(children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(15),
                            child: photo.isEmpty
                                ? const SizedBox(
                                    width: double.infinity, height: 230,
                                    child: ColoredBox(color: _profilePanel, child: Icon(Icons.person, size: 82, color: Colors.white54)))
                                : FullProfilePhoto(url: photo),
                          ),
                          const SizedBox(height: 14),
                          GestureDetector(
                            onTap: () => showFullPhoto(context, (p['photoUrl'] ?? '').toString()),
                            child: ProfileFrameAvatar(
                              photoUrl: (p['photoUrl'] ?? '').toString(),
                              frameId: (p['selectedProfileFrame'] ?? 'classic').toString(),
                              size: 82,
                            ),
                          ),
                          if (p['isVip'] == true)
                            const Align(alignment: Alignment.centerRight,
                              child: Icon(Icons.workspace_premium, color: Color(0xFFFFC247), size: 30)),
                          const SizedBox(height: 14),
                          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Flexible(child: VipNickname(name: name, isVip: p['isVip'] == true, styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
                            if (genderSymbol.isNotEmpty) ...[
                              const SizedBox(width: 7),
                              Text(genderSymbol, style: const TextStyle(color: _profilePink, fontSize: 23, fontWeight: FontWeight.bold)),
                            ],
                            if (p['isVerified'] == true) ...[
                              const SizedBox(width: 6),
                              const Icon(Icons.verified, color: Color(0xFF55A8FF), size: 21),
                            ],
                          ]),
                          const SizedBox(height: 4),
                          if (age != null || location.isNotEmpty)
                            Text([
                              if (age != null) '$age anos',
                              if (location.isNotEmpty) location,
                            ].join(' • '), textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w500)),
                          const SizedBox(height: 7),
                          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.circle, size: 9, color: online ? Colors.greenAccent : Colors.white30),
                            const SizedBox(width: 6),
                            Text(online ? 'Online' : 'Offline', style: TextStyle(color: online ? Colors.greenAccent : Colors.white54, fontSize: 12)),
                            if (p['isVip'] == true) ...[
                              const SizedBox(width: 8),
                              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: _profilePurple.withOpacity(.35), borderRadius: BorderRadius.circular(20)), child: const Text('VIP 👑', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold))),
                            ],
                          ]),
                        ]),
                      ),
                      if (interests.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(14, 2, 14, 10),
                          child: Wrap(spacing: 7, runSpacing: 7, alignment: WrapAlignment.center,
                            children: interests.map((interest) => Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                              decoration: BoxDecoration(color: const Color(0xFF28113B), borderRadius: BorderRadius.circular(20), border: Border.all(color: _profilePurple)),
                              child: Text(interest, style: const TextStyle(fontSize: 11, color: Colors.white)),
                            )).toList()),
                        ),
                      if (bio.isNotEmpty)
                        Padding(padding: const EdgeInsets.fromLTRB(16, 5, 16, 16),
                          child: Text(bio, style: const TextStyle(color: Colors.white, height: 1.4, fontSize: 14))),
                    ]),
                  ),
                  const SizedBox(height: 14),
                  if (!isOwner) Row(children: [
                    Expanded(child: SizedBox(height: 50, child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      stream: DataService.instance.followingStatus(widget.userId),
                      builder: (context, followSnap) {
                        final following = followSnap.data?.exists == true;
                        return ElevatedButton.icon(
                          onPressed: followSnap.connectionState == ConnectionState.waiting
                              ? null : () => _toggleFollow(context),
                          icon: Icon(following ? Icons.check : Icons.person_add_alt_1, color: Colors.white),
                          label: Text(following ? 'Seguindo' : 'Seguir'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: following ? const Color(0xFF49345B) : _profilePink,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                          ),
                        );
                      },
                    ))),
                    const SizedBox(width: 10),
                    Expanded(child: SizedBox(height: 50, child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      stream: DataService.instance.followingStatus(widget.userId),
                      builder: (context, followSnap) {
                        final following = followSnap.data?.exists == true;
                        return OutlinedButton.icon(
                          onPressed: following ? () => _openChat(context, name) : null,
                          icon: const Icon(Icons.chat_bubble, color: Colors.white),
                          label: Text(following ? 'Mensagem' : 'Siga para conversar',
                            style: const TextStyle(color: Colors.white),
                            overflow: TextOverflow.ellipsis),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: _profilePink, width: 1.5),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                          ),
                        );
                      },
                    ))),
                  ]),
                  const SizedBox(height: 22),
                  Row(children: [
                    const Text('Fotos publicadas', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                    const Spacer(),
                    Text('Galeria', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12)),
                  ]),
                  const SizedBox(height: 10),
                  _photosGallery(isOwner: isOwner, canSeeFriends: isMatched),
                  if (!isOwner) ...[
                    const SizedBox(height: 24),
                    OutlinedButton.icon(onPressed: () => _report(context), icon: const Icon(Icons.flag_outlined), label: const Text('Denunciar perfil')),
                    OutlinedButton.icon(onPressed: () => _block(context), icon: const Icon(Icons.block), label: const Text('Bloquear usuário')),
                  ],
                ],
              );
            },
          );
        },
      ),
    );
  }

  Widget _photosGallery({required bool isOwner, required bool canSeeFriends}) {
    final posts = FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('posts');
    if (isOwner) {
      return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: posts.snapshots(),
        builder: (context, snap) => _galleryContent(context, snap.data?.docs ?? [], loading: !snap.hasData, error: snap.hasError),
      );
    }
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: posts.where('visibility', isEqualTo: 'public').snapshots(),
      builder: (context, publicSnap) {
        if (publicSnap.hasError) return _galleryContent(context, [], loading: false, error: true);
        if (!canSeeFriends) {
          return _galleryContent(context, publicSnap.data?.docs ?? [], loading: !publicSnap.hasData);
        }
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: posts.where('visibility', isEqualTo: 'friends').snapshots(),
          builder: (context, friendsSnap) {
            if (friendsSnap.hasError) return _galleryContent(context, publicSnap.data?.docs ?? [], loading: !publicSnap.hasData);
            final combined = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
            combined.addAll(publicSnap.data?.docs ?? []);
            combined.addAll(friendsSnap.data?.docs ?? []);
            combined.sort((a, b) {
              final at = a.data()['createdAt'];
              final bt = b.data()['createdAt'];
              final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
              final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
              return bm.compareTo(am);
            });
            return _galleryContent(context, combined, loading: !publicSnap.hasData || !friendsSnap.hasData);
          },
        );
      },
    );
  }

  Widget _galleryContent(BuildContext context,
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
      {required bool loading, bool error = false}) {
    if (error) return const Text('As fotos não estão disponíveis para este perfil.', style: TextStyle(color: Colors.white60));
    if (loading) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(color: _profilePink)));
    if (docs.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 26),
        decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
        child: const Column(children: [
          Icon(Icons.photo_library_outlined, color: _profilePurple, size: 34),
          SizedBox(height: 8),
          Text('Nenhuma foto disponível ainda.', style: TextStyle(color: Colors.white70)),
        ]),
      );
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: docs.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 7, mainAxisSpacing: 7),
      itemBuilder: (_, i) {
        final url = (docs[i].data()['photoUrl'] ?? '').toString();
        return GestureDetector(
          onTap: url.isEmpty ? null : () => _showPhoto(context, docs[i].id, url),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: url.isEmpty
                ? const ColoredBox(color: _profilePanel, child: Icon(Icons.broken_image))
                : CachedNetworkImage(imageUrl: url, fit: BoxFit.cover,
                    placeholder: (_, __) => const ColoredBox(color: _profilePanel, child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: _profilePink))),
                    errorWidget: (_, __, ___) => const ColoredBox(color: _profilePanel, child: Icon(Icons.broken_image))),
          ),
        );
      },
    );
  }

  void _showPhoto(BuildContext context, String postId, String url) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: postId, photoUrl: url)));
  }

  Future<void> _toggleFollow(BuildContext context) async {
    try {
      final following = await DataService.instance.toggleFollow(widget.userId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(following ? 'Você começou a seguir 💗' : 'Você deixou de seguir.'),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _openChat(BuildContext context, String otherName) async {
    if (FirebaseAuth.instance.currentUser == null) return;
    try {
      final chatId = await DataService.instance.openDirectChat(widget.userId);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => ChatScreen(chatId: chatId, otherName: otherName),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _report(BuildContext context) async {
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Denunciar perfil'),
        children: ['Perfil falso', 'Assédio ou discurso de ódio', 'Conteúdo impróprio', 'Outro']
            .map((r) => SimpleDialogOption(onPressed: () => Navigator.pop(ctx, r), child: Text(r))).toList(),
      ),
    );
    if (reason == null) return;
    try {
      await DataService.instance.reportUser(widget.userId, reason);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Denúncia enviada para análise.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar a denúncia.')));
    }
  }

  Future<void> _block(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bloquear usuário?'),
        content: const Text('Este perfil não deverá mais aparecer para você.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bloquear')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await DataService.instance.blockUser(widget.userId);
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível bloquear este usuário.')));
    }
  }
}
