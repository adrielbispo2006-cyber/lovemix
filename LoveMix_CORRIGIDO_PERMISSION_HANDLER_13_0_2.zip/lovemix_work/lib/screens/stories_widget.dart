import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';

const _storyPink = Color(0xFFFF19B8);
const _storyPurple = Color(0xFF8D35FF);

class StoriesStrip extends StatefulWidget {
  const StoriesStrip({super.key});
  @override
  State<StoriesStrip> createState() => _StoriesStripState();
}

class _StoriesStripState extends State<StoriesStrip> {
  bool uploading = false;
  Future<void> _addStory() async {
    if (uploading) return;
    final choice = await showModalBottomSheet<String>(context: context, backgroundColor: const Color(0xFF171022), builder: (ctx) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.photo, color: _storyPink), title: const Text('Story com foto'), onTap: () => Navigator.pop(ctx, 'image')),
      ListTile(leading: const Icon(Icons.videocam, color: _storyPink), title: const Text('Story com vídeo'), onTap: () => Navigator.pop(ctx, 'video')),
      const Padding(padding: EdgeInsets.fromLTRB(16, 4, 16, 12), child: Text('Nudez e conteúdo sexual não são permitidos e são removidos automaticamente.', style: TextStyle(fontSize: 12, color: Colors.white54))),
    ])));
    if (choice == null) return;
    try {
      final picker = ImagePicker();
      final XFile? file = choice == 'image'
          ? await picker.pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1440)
          : await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 30));
      if (file == null) return;
      setState(() => uploading = true);
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final isImage = choice == 'image';
      // Lê os bytes direto do XFile (mais confiável que putFile no Android,
      // onde o caminho do picker pode não ser um arquivo acessível).
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) throw 'o arquivo selecionado está vazio';
      final maxBytes = 30 * 1024 * 1024;
      if (bytes.length >= maxBytes) throw 'o arquivo passa de 30 MB';
      final lowerName = file.name.toLowerCase();
      final String ext;
      final String contentType;
      if (isImage) {
        if (lowerName.endsWith('.png')) { ext = 'png'; contentType = 'image/png'; }
        else if (lowerName.endsWith('.webp')) { ext = 'webp'; contentType = 'image/webp'; }
        else { ext = 'jpg'; contentType = 'image/jpeg'; }
      } else {
        if (lowerName.endsWith('.mov')) { ext = 'mov'; contentType = 'video/quicktime'; }
        else { ext = 'mp4'; contentType = 'video/mp4'; }
      }
      final filePath = 'stories/$uid/${DateTime.now().millisecondsSinceEpoch}.$ext';
      final String url;
      // Fotos e vídeos de stories são armazenados exclusivamente no Supabase.
      // Não usar fallback para Firebase: em caso de falha, informar o erro.
      url = await SupabaseService.instance.uploadPhoto(
        path: filePath, bytes: bytes, contentType: contentType,
      );
      final profile = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      await FirebaseFirestore.instance.collection('stories').add({
        'ownerId': uid, 'name': profile.data()?['name'] ?? 'Pessoa',
        'photoUrl': profile.data()?['photoUrl'] ?? '', 'mediaUrl': url,
        'mediaType': choice, 'createdAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Story publicado por 24 horas!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível publicar: $e')));
    } finally { if (mounted) setState(() => uploading = false); }
  }

  @override
  Widget build(BuildContext context) => SizedBox(height: 104, child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('stories').where('expiresAt', isGreaterThan: Timestamp.now()).orderBy('expiresAt').snapshots(),
    builder: (context, snap) {
      final docs = snap.data?.docs ?? [];
      final grouped = <String, List<QueryDocumentSnapshot<Map<String, dynamic>>>>{};
      for (final d in docs) { final id = (d.data()['ownerId'] ?? '').toString(); if (id.isNotEmpty) (grouped[id] ??= []).add(d); }
      final myUid = FirebaseAuth.instance.currentUser?.uid;
      List<QueryDocumentSnapshot<Map<String, dynamic>>> sorted(List<QueryDocumentSnapshot<Map<String, dynamic>>> l) {
        final c = [...l];
        c.sort((a, b) {
          final ta = a.data()['createdAt'], tb = b.data()['createdAt'];
          if (ta is Timestamp && tb is Timestamp) return ta.compareTo(tb);
          return 0;
        });
        return c;
      }
      void open(List<QueryDocumentSnapshot<Map<String, dynamic>>> l) =>
          Navigator.push(context, MaterialPageRoute(builder: (_) => StoryViewer(stories: sorted(l))));
      final mine = myUid == null ? null : grouped[myUid];
      final hasMine = mine != null && mine.isNotEmpty;
      return ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
        _bubble('Seu story', hasMine ? (mine!.first.data()['photoUrl'] ?? '').toString() : '',
            own: true, hasStory: hasMine, onTap: hasMine ? () => open(mine!) : _addStory, onAdd: _addStory),
        ...grouped.entries.where((e) => e.key != myUid).map((entry) {
          final first = entry.value.first.data();
          return _bubble((first['name'] ?? 'Pessoa').toString(), (first['photoUrl'] ?? '').toString(), hasStory: true, onTap: () => open(entry.value));
        }),
      ]);
    },
  ));

  Widget _bubble(String name, String photo, {bool own = false, bool hasStory = false, required VoidCallback onTap, VoidCallback? onAdd}) => GestureDetector(onTap: onTap, child: SizedBox(width: 76, child: Column(children: [
    Stack(clipBehavior: Clip.none, children: [
      Container(width: 66, height: 66, padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(shape: BoxShape.circle,
          border: own && !hasStory ? Border.all(color: _storyPink, width: 2) : null,
          gradient: own && !hasStory ? null : const LinearGradient(colors: [_storyPink, _storyPurple])),
        child: ClipOval(child: photo.isEmpty ? Container(color: const Color(0xFF241333), child: Icon(own && !hasStory ? Icons.add : Icons.person, color: Colors.white, size: 28)) : Image.network(photo, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.person)))),
      if (own && hasStory) Positioned(right: -2, bottom: -2, child: GestureDetector(onTap: onAdd, child: Container(width: 24, height: 24, decoration: BoxDecoration(color: _storyPink, shape: BoxShape.circle, border: Border.all(color: const Color(0xFF0B0713), width: 2)), child: const Icon(Icons.add, color: Colors.white, size: 16)))),
    ]),
    const SizedBox(height: 4), Text(uploading && own ? 'Enviando...' : name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
  ])));
}

class StoryViewer extends StatefulWidget {
  const StoryViewer({super.key, required this.stories});
  final List<QueryDocumentSnapshot<Map<String, dynamic>>> stories;
  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

String _timeAgo(dynamic ts) {
  if (ts is! Timestamp) return 'agora';
  final d = DateTime.now().difference(ts.toDate());
  if (d.inMinutes < 1) return 'agora';
  if (d.inMinutes < 60) return 'há ${d.inMinutes} min';
  if (d.inHours < 24) return 'há ${d.inHours} h';
  return 'há ${d.inDays} d';
}

class _StoryViewerState extends State<StoryViewer> {
  late final List<QueryDocumentSnapshot<Map<String, dynamic>>> stories = [...widget.stories];
  int index = 0;
  VideoPlayerController? video;
  Timer? timer;
  Timer? ticker;
  bool advancing = false;
  final _commentCtrl = TextEditingController();
  final _commentFocus = FocusNode();
  Map<String, dynamic> _me = {};
  bool _sheetOpen = false;

  @override
  void initState() {
    super.initState();
    _loadMe();
    _commentFocus.addListener(() {
      if (_commentFocus.hasFocus) { _pause(); } else if (!_sheetOpen) { _resume(); }
    });
    // atualiza o "há X min" enquanto o story está aberto
    ticker = Timer.periodic(const Duration(seconds: 20), (_) { if (mounted) setState(() {}); });
    _loadStory();
  }

  Future<void> _loadStory() async {
    timer?.cancel();
    advancing = false;
    final old = video; video = null;
    await old?.dispose();
    if (!mounted) return;
    final data = stories[index].data();
    if (data['mediaType'] == 'video') {
      try {
        final c = VideoPlayerController.networkUrl(Uri.parse((data['mediaUrl'] ?? '').toString()));
        video = c;
        await c.initialize();
        if (!mounted || video != c) return;
        c.addListener(() {
          final v = c.value;
          if (mounted && video == c && !advancing && v.isInitialized && v.duration > Duration.zero && v.position >= v.duration) { advancing = true; _next(); }
        });
        await c.play();
        if (mounted) setState(() {});
      } catch (_) {
        // vídeo não carregou: passa para o próximo depois de alguns segundos
        timer = Timer(const Duration(seconds: 3), _next);
      }
    } else {
      timer = Timer(const Duration(seconds: 5), _next);
    }
  }

  void _next() {
    if (!mounted) return;
    if (index + 1 >= stories.length) { Navigator.pop(context); return; }
    setState(() => index++);
    _loadStory();
  }

  void _prev() {
    if (index == 0) { _loadStory(); return; }
    setState(() => index--);
    _loadStory();
  }

  void _resume() {
    final c = video;
    if (c != null && c.value.isInitialized) { c.play(); } else { _loadStory(); }
  }

  Future<void> _deleteCurrent() async {
    timer?.cancel();
    await video?.pause();
    if (!mounted) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF171022),
      title: const Text('Apagar story?'),
      content: const Text('Ele será removido para todos e não poderá ser recuperado.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar', style: TextStyle(color: Colors.redAccent))),
      ],
    ));
    if (ok != true) { if (mounted) _resume(); return; }
    final doc = stories[index];
    final url = (doc.data()['mediaUrl'] ?? '').toString();
    try {
      try {
        final cs = await doc.reference.collection('comments').get();
        for (final c in cs.docs) { await c.reference.delete(); }
      } catch (_) {}
      await doc.reference.delete();
    } catch (e) {
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar: $e'))); _resume(); }
      return;
    }
    // remove também o arquivo (se falhar, o story já saiu do ar)
    try { if (url.isNotEmpty) { final removed = await SupabaseService.instance.deletePublicUrl(url); if (!removed) await FirebaseStorage.instance.refFromURL(url).delete(); } } catch (_) {}
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Story apagado.')));
    stories.removeAt(index);
    if (stories.isEmpty) { Navigator.pop(context); return; }
    if (index >= stories.length) index = stories.length - 1;
    setState(() {});
    _loadStory();
  }

  // ------------------------------------------------------ comentários
  CollectionReference<Map<String, dynamic>> get _commentsRef =>
      stories[index].reference.collection('comments');

  Future<void> _loadMe() async {
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final snap = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      _me = snap.data() ?? {};
    } catch (_) {}
  }

  void _pause() { timer?.cancel(); video?.pause(); }

  void _tapNav(bool next) {
    if (_commentFocus.hasFocus) { _commentFocus.unfocus(); return; }
    next ? _next() : _prev();
  }

  Future<void> _sendComment() async {
    final text = _commentCtrl.text.trim();
    if (text.isEmpty) return;
    if (text.length > 300) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('O comentário pode ter até 300 caracteres.')));
      return;
    }
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    _commentCtrl.clear();
    try {
      await _commentsRef.add({
        'uid': uid,
        'name': (_me['name'] ?? 'Pessoa').toString(),
        'photoUrl': (_me['photoUrl'] ?? '').toString(),
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível comentar: $e')));
    }
  }

  Future<void> _openComments() async {
    _commentFocus.unfocus();
    _pause();
    _sheetOpen = true;
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    final storyOwner = (stories[index].data()['ownerId'] ?? '').toString();
    final ref = _commentsRef;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF171022),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(ctx).size.height * .62,
          child: Column(children: [
            const SizedBox(height: 12),
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(8))),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Comentários', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ),
            Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: ref.orderBy('createdAt', descending: true).limit(100).snapshots(),
              builder: (context, snap) {
                final docs = snap.data?.docs ?? [];
                if (snap.hasError) return const Center(child: Text('Não foi possível carregar os comentários.'));
                if (docs.isEmpty) {
                  return Center(child: Text(
                    storyOwner == myUid ? 'Ainda não há comentários no seu story 💬' : 'Seja a primeira pessoa a comentar 💬',
                    style: const TextStyle(color: Colors.white54)));
                }
                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final c = docs[i].data();
                    final photo = (c['photoUrl'] ?? '').toString();
                    final canDelete = c['uid'] == myUid || storyOwner == myUid;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        CircleAvatar(
                          radius: 17,
                          backgroundColor: const Color(0xFF3A1D52),
                          backgroundImage: photo.isEmpty ? null : NetworkImage(photo),
                          child: photo.isEmpty ? const Icon(Icons.person, size: 18, color: Colors.white70) : null,
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Row(children: [
                            Flexible(child: Text((c['name'] ?? 'Pessoa').toString(), maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: Color(0xFFFFB3E6)))),
                            const SizedBox(width: 8),
                            Text(_timeAgo(c['createdAt']), style: const TextStyle(color: Colors.white38, fontSize: 11)),
                          ]),
                          const SizedBox(height: 2),
                          Text((c['text'] ?? '').toString(), style: const TextStyle(color: Colors.white, height: 1.3)),
                        ])),
                        if (canDelete) IconButton(
                          visualDensity: VisualDensity.compact,
                          tooltip: 'Apagar comentário',
                          icon: const Icon(Icons.delete_outline, size: 19, color: Colors.white38),
                          onPressed: () async { try { await docs[i].reference.delete(); } catch (_) {} },
                        ),
                      ]),
                    );
                  },
                );
              },
            )),
            // O dono do story só lê os comentários; quem assiste pode comentar.
            if (storyOwner != myUid) Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(children: [
                Expanded(child: TextField(
                  controller: _commentCtrl,
                  maxLength: 300,
                  buildCounter: (_, {required currentLength, required isFocused, maxLength}) => null,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _sendComment(),
                  decoration: InputDecoration(
                    hintText: 'Escreva um comentário...',
                    filled: true, fillColor: const Color(0xFF241333),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: BorderSide.none),
                  ),
                )),
                const SizedBox(width: 8),
                Container(
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [_storyPink, _storyPurple])),
                  child: IconButton(onPressed: _sendComment, icon: const Icon(Icons.send_rounded, color: Colors.white)),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
    _sheetOpen = false;
    if (mounted) _resume();
  }

  Widget _commentsBar() {
    final storyId = stories[index].id;
    return Positioned(
      left: 0, right: 0, bottom: 0,
      child: Padding(
        padding: EdgeInsets.fromLTRB(12, 6, 12, 10 + MediaQuery.of(context).viewInsets.bottom),
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          key: ValueKey('comments-$storyId'),
          stream: _commentsRef.orderBy('createdAt', descending: true).limit(100).snapshots(),
          builder: (context, snap) {
            final docs = snap.data?.docs ?? [];
            final isOwner = (stories[index].data()['ownerId'] ?? '') == FirebaseAuth.instance.currentUser?.uid;
            // Dono vê mais comentários direto sobre o story e abre a lista completa ao tocar.
            final preview = docs.take(isOwner ? 5 : 3).toList().reversed.toList();
            return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (isOwner && docs.length > preview.length)
                GestureDetector(
                  onTap: _openComments,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white24)),
                    child: Text('Ver todos os ${docs.length >= 100 ? '99+' : docs.length} comentários',
                      style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ),
              for (final d in preview)
                GestureDetector(
                  onTap: _openComments,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 5),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .72),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
                    child: RichText(
                      maxLines: 2, overflow: TextOverflow.ellipsis,
                      text: TextSpan(children: [
                        TextSpan(text: '${(d.data()['name'] ?? 'Pessoa').toString().split(' ').first}  ',
                          style: const TextStyle(color: Color(0xFFFFB3E6), fontWeight: FontWeight.w800, fontSize: 13)),
                        TextSpan(text: (d.data()['text'] ?? '').toString(), style: const TextStyle(color: Colors.white, fontSize: 13)),
                      ]),
                    ),
                  ),
                ),
              if (!isOwner) const SizedBox(height: 4),
              if (!isOwner) Row(children: [
                Expanded(child: TextField(
                  controller: _commentCtrl,
                  focusNode: _commentFocus,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _sendComment(),
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Comentar este story...',
                    hintStyle: const TextStyle(color: Colors.white70),
                    filled: true, fillColor: Colors.black54,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: const BorderSide(color: Colors.white24)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: const BorderSide(color: Colors.white24)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(26), borderSide: const BorderSide(color: _storyPink)),
                    suffixIcon: IconButton(icon: const Icon(Icons.send_rounded, color: Color(0xFFFF65D5)), onPressed: _sendComment),
                  ),
                )),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _openComments,
                  child: Container(
                    height: 44,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white24)),
                    child: Row(children: [
                      const Icon(Icons.chat_bubble_outline, color: Colors.white, size: 19),
                      const SizedBox(width: 5),
                      Text(docs.length >= 100 ? '99+' : '${docs.length}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                    ]),
                  ),
                ),
              ]),
            ]);
          },
        ),
      ),
    );
  }

  @override
  void dispose() { timer?.cancel(); ticker?.cancel(); video?.dispose(); _commentCtrl.dispose(); _commentFocus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final data = stories[index].data(); final isVideo = data['mediaType'] == 'video';
    final isOwner = (data['ownerId'] ?? '') == FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(backgroundColor: Colors.black, resizeToAvoidBottomInset: false, body: SafeArea(child: Stack(fit: StackFit.expand, children: [
      Center(child: isVideo ? (video?.value.isInitialized == true ? AspectRatio(aspectRatio: video!.value.aspectRatio, child: VideoPlayer(video!)) : const CircularProgressIndicator(color: _storyPink)) : Image.network((data['mediaUrl'] ?? '').toString(), key: ValueKey(stories[index].id), fit: BoxFit.contain, loadingBuilder: (c, child, p) => p == null ? child : const Center(child: CircularProgressIndicator(color: _storyPink)), errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white))),
      Positioned.fill(top: 90, bottom: 170, child: Row(children: [
        Expanded(flex: 1, child: GestureDetector(behavior: HitTestBehavior.translucent, onTap: () => _tapNav(false))),
        Expanded(flex: 2, child: GestureDetector(behavior: HitTestBehavior.translucent, onTap: () => _tapNav(true))),
      ])),
      Positioned(top: 12, left: 12, right: 4, child: Row(children: [
        Expanded(child: Row(children: [for (var i = 0; i < stories.length; i++) Expanded(child: Container(height: 3, margin: const EdgeInsets.symmetric(horizontal: 2), decoration: BoxDecoration(color: i <= index ? _storyPink : Colors.white24, borderRadius: BorderRadius.circular(2))))])),
        const SizedBox(width: 4),
        if (isOwner) IconButton(tooltip: 'Apagar story', onPressed: _deleteCurrent, icon: const Icon(Icons.delete_outline, color: Colors.white)),
        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, color: Colors.white)),
      ])),
      Positioned(top: 58, left: 16, child: Row(children: [
        Text((data['name'] ?? 'Story').toString(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, shadows: [Shadow(blurRadius: 4, color: Colors.black54)])),
        const SizedBox(width: 8),
        Text(_timeAgo(data['createdAt']), style: const TextStyle(color: Colors.white70, fontSize: 12, shadows: [Shadow(blurRadius: 4, color: Colors.black54)])),
      ])),
      _commentsBar(),
    ])));
  }
}
