import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';

class RankingScreen extends StatefulWidget {
  const RankingScreen({super.key});
  @override State<RankingScreen> createState() => _RankingScreenState();
}

class _RankingScreenState extends State<RankingScreen> {
  static const pink = Color(0xFFFF2DAB);
  static const purple = Color(0xFF8B35FF);
  static const panel = Color(0xFF171022);
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final myUid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Ranking')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users')
          .where('isActive', isEqualTo: true).limit(100).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text('Não foi possível carregar o ranking. Confira a conexão e as regras do Firestore.'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: pink));
          final users = snapshot.data!.docs.where((d) {
            if (tab == 0) return true;
            final interests = List<String>.from(d.data()['interests'] ?? const []);
            if (tab == 1) return interests.any((v) => v.toLowerCase().contains('amiz'));
            return interests.any((v) => v.toLowerCase().contains('namor'));
          }).toList();
          users.sort((a,b) {
            final av = tab == 0 ? (a.data()['coins'] ?? 0) : (a.data()['likesReceived'] ?? a.data()['coins'] ?? 0);
            final bv = tab == 0 ? (b.data()['coins'] ?? 0) : (b.data()['likesReceived'] ?? b.data()['coins'] ?? 0);
            return (bv as num).compareTo(av as num);
          });
          final top = users.take(3).toList();
          final rest = users.length > 3 ? users.sublist(3) : <QueryDocumentSnapshot<Map<String,dynamic>>>[];
          return ListView(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 28),
            children: [
              Container(
                padding: const EdgeInsets.all(17),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF36104F), Color(0xFF171022)]),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: purple.withOpacity(.8)),
                ),
                child: const Row(children: [
                  Icon(Icons.emoji_events_rounded, color: Color(0xFFFFD76A), size: 38),
                  SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Ranking LoveMix 👑', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                    Text('Conecte-se, interaja e suba no ranking!', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ])),
                ]),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(30), border: Border.all(color: purple.withOpacity(.7))),
                child: Row(children: List.generate(3, (i) {
                  final labels = ['Geral','Amizades','Namoro'];
                  final selected = tab == i;
                  return Expanded(child: GestureDetector(
                    onTap: () => setState(() => tab = i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.symmetric(vertical: 11),
                      decoration: BoxDecoration(
                        gradient: selected ? const LinearGradient(colors: [pink, Color(0xFFB51BFF)]) : null,
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Text(labels[i], textAlign: TextAlign.center,
                        style: TextStyle(fontWeight: FontWeight.w800, color: selected ? Colors.white : Colors.white70)),
                    ),
                  ));
                })),
              ),
              const SizedBox(height: 20),
              if (top.isNotEmpty) SizedBox(
                height: 190,
                child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  if (top.length > 1) Expanded(child: _podium(top[1], 2, 112, myUid)),
                  if (top.isNotEmpty) Expanded(child: _podium(top[0], 1, 154, myUid)),
                  if (top.length > 2) Expanded(child: _podium(top[2], 3, 100, myUid)),
                ]),
              ),
              const SizedBox(height: 18),
              if (users.isEmpty)
                const Padding(padding: EdgeInsets.all(25), child: Text('Ainda não há participantes nesta categoria.', textAlign: TextAlign.center))
              else
                ...List.generate(rest.length, (i) {
                  final doc = rest[i]; final d = doc.data();
                  final score = tab == 0 ? (d['coins'] ?? 0) : (d['likesReceived'] ?? d['coins'] ?? 0);
                  final photo = (d['photoUrl'] ?? '').toString();
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: doc.id == myUid ? pink : const Color(0xFF49305C))),
                    child: ListTile(
                      leading: SizedBox(width: 52, child: Row(mainAxisSize: MainAxisSize.min, children: [Text('${i+4}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)), const SizedBox(width: 7), ProfileFrameAvatar(photoUrl: photo, frameId: (d['selectedProfileFrame'] ?? 'classic').toString(), size: 30)])),
                      title: VipNickname(name: (d['name'] ?? 'Participante').toString(), isVip: d['isVip'] == true, styleId: (d['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(doc.id == myUid ? 'Você' : 'LoveMix', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(tab == 0 ? Icons.monetization_on : Icons.favorite, color: tab == 0 ? const Color(0xFFFFD76A) : pink, size: 17),
                        const SizedBox(width: 5), Text((score as num).toStringAsFixed(0), style: const TextStyle(fontWeight: FontWeight.w900)),
                      ]),
                      leadingAndTrailingTextStyle: const TextStyle(color: Colors.white),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 3),
                      // A foto é carregada no avatar decorativo abaixo pelo fallback de iniciais.
                      isThreeLine: false,
                    ),
                  );
                }),
              const SizedBox(height: 10),
              const Text('Geral usa o saldo de moedas. Amizades e Namoro consideram os interesses cadastrados; quando não há pontuação de curtidas, o saldo é usado como critério alternativo.',
                style: TextStyle(color: Colors.white54, fontSize: 11)),
            ],
          );
        },
      ),
    );
  }

  Widget _podium(QueryDocumentSnapshot<Map<String,dynamic>> doc, int position, double height, String? myUid) {
    final d = doc.data();
    final name = (d['name'] ?? 'Pessoa').toString();
    final photo = (d['photoUrl'] ?? '').toString();
    final score = (tab == 0 ? (d['coins'] ?? 0) : (d['likesReceived'] ?? d['coins'] ?? 0)) as num;
    final color = position == 1 ? const Color(0xFFFFD76A) : position == 2 ? const Color(0xFFB9C7E8) : const Color(0xFFCE8B62);
    return Column(mainAxisAlignment: MainAxisAlignment.end, children: [
      Icon(Icons.workspace_premium, color: color, size: position == 1 ? 28 : 23),
      Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 2.5), boxShadow: [BoxShadow(color: color.withOpacity(.3), blurRadius: 12)]),
        child: ProfileFrameAvatar(photoUrl: photo, frameId: (d['selectedProfileFrame'] ?? 'classic').toString(), size: position == 1 ? 70 : 58),
      ),
      const SizedBox(height: 5),
      VipNickname(name: name, isVip: d['isVip'] == true, styleId: (d['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
      Text('${score.toStringAsFixed(0)} ${tab == 0 ? '🟡' : '💗'}', style: const TextStyle(color: Colors.white70, fontSize: 10)),
      Container(height: height * .35, margin: const EdgeInsets.only(top: 5), alignment: Alignment.center,
        decoration: BoxDecoration(gradient: LinearGradient(colors: [color.withOpacity(.75), color.withOpacity(.25)]), borderRadius: const BorderRadius.vertical(top: Radius.circular(12))),
        child: Text('$position', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: position == 1 ? 24 : 19))),
    ]);
  }
}
