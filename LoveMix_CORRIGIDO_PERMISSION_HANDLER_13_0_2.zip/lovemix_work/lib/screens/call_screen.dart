import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import '../services/zego_config.dart';

Future<bool> _granted(bool video) async {
  final wanted = <Permission>[Permission.microphone, if (video) Permission.camera];
  for (final p in wanted) {
    if (!(await p.status).isGranted) return false;
  }
  return true;
}

/// Espera o usuário voltar das configurações do aparelho ao app.
class _ResumeWaiter with WidgetsBindingObserver {
  _ResumeWaiter() { WidgetsBinding.instance.addObserver(this); }
  final _c = Completer<void>();
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_c.isCompleted) _c.complete();
  }
  Future<void> wait() async {
    await _c.future.timeout(const Duration(minutes: 5), onTimeout: () {});
    WidgetsBinding.instance.removeObserver(this);
  }
}

/// Pede as permissões necessárias (microfone; câmera também no vídeo).
/// Se estiverem bloqueadas, leva o usuário às configurações e, ao voltar,
/// confere de novo. Retorna true somente se tudo foi liberado.
Future<bool> requestCallPermissions(BuildContext context, {required bool video}) async {
  final wanted = <Permission>[Permission.microphone, if (video) Permission.camera];
  final result = await wanted.request();
  if (result.values.every((s) => s.isGranted)) return true;
  if (!context.mounted) return false;

  final blocked = result.values.any((s) => s.isPermanentlyDenied || s.isRestricted);
  final what = video ? 'à câmera e ao microfone' : 'ao microfone';
  final openSettings = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF21132E),
      title: const Text('Permissão necessária'),
      content: Text(blocked
          ? 'Para fazer chamadas de ${video ? 'vídeo' : 'voz'}, permita o acesso $what nas configurações do aparelho (Permissões). Depois é só voltar ao app que a chamada continua.'
          : 'Sem acesso $what não é possível fazer a chamada. Toque em "Permitir" para continuar.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Agora não')),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(blocked ? 'Abrir configurações' : 'Permitir'),
        ),
      ],
    ),
  );
  if (openSettings != true) return false;

  if (!blocked) return requestCallPermissions(context, video: video);

  final waiter = _ResumeWaiter();
  await openAppSettings();
  await waiter.wait();
  return _granted(video);
}

/// Chamada 1:1 de voz ou vídeo. Quem abre a mesma [callId] entra na mesma sala.
class CallScreen extends StatelessWidget {
  const CallScreen({super.key, required this.callId, required this.video});
  final String callId;
  final bool video;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final name = (user?.displayName ?? '').trim();
    return Scaffold(
      body: SafeArea(
        child: ZegoUIKitPrebuiltCall(
          appID: ZegoConfig.appId,
          appSign: ZegoConfig.appSign,
          userID: user?.uid ?? 'anon',
          userName: name.isEmpty ? 'Você' : name,
          callID: callId,
          config: video
              ? ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()
              : ZegoUIKitPrebuiltCallConfig.oneOnOneVoiceCall(),
        ),
      ),
    );
  }
}
