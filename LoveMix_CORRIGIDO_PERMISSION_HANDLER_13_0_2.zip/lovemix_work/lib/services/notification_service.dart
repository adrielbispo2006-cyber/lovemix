import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Recebe notificações push e também mostra notificações enquanto o app está aberto.
class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  String? _registeredUid;
  StreamSubscription<String>? _tokenRefreshSubscription;

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'lovemix_updates',
    'LoveMix',
    description: 'Notificações de mensagens e curtidas do LoveMix',
    importance: Importance.high,
  );

  Future<void> initializeForUser(User user) async {
    if (!_initialized) {
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      const settings = InitializationSettings(android: android);
      await _local.initialize(settings: settings);
      await _local
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(_channel);

      FirebaseMessaging.onMessage.listen(_showForegroundNotification);
      FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationTap);
      _initialized = true;
    }

    final permission = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    if (permission.authorizationStatus == AuthorizationStatus.denied) return;

    if (_registeredUid == user.uid) return;
    _registeredUid = user.uid;
    await _saveToken(user.uid);
    await _tokenRefreshSubscription?.cancel();
    _tokenRefreshSubscription = _messaging.onTokenRefresh.listen((token) async {
      final current = FirebaseAuth.instance.currentUser;
      if (current != null && current.uid == user.uid) {
        await _saveToken(user.uid, token: token);
      }
    });
  }

  Future<void> _saveToken(String uid, {String? token}) async {
    final value = token ?? await _messaging.getToken();
    if (value == null || value.isEmpty) return;
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('fcmTokens')
        .doc(value)
        .set({
      'token': value,
      'updatedAt': FieldValue.serverTimestamp(),
      'platform': 'android',
    });
  }

  Future<void> _showForegroundNotification(RemoteMessage message) async {
    final notification = message.notification;
    final title = notification?.title ?? message.data['title']?.toString() ?? 'LoveMix';
    final body = notification?.body ?? message.data['body']?.toString() ?? 'Você tem uma novidade.';
    await _local.show(
      id: message.hashCode,
      title: title,
      body: body,
      notificationDetails: NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
      payload: jsonEncode(message.data),
    );
  }

  void _handleNotificationTap(RemoteMessage message) {
    // A tela de destino pode ser aberta aqui quando a navegação global do app
    // estiver configurada. Por enquanto, tocar na notificação abre o LoveMix.
  }
}
