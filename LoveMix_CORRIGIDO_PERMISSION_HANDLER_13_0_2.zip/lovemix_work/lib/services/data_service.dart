import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';

class DataService {
  DataService._();
  static final instance = DataService._();

  /// Converte qualquer valor vindo do Firestore em lista de textos, sem nunca
  /// lançar exceção (salas antigas podem ter `members` nulo, mapa ou misto).
  static List<String> stringList(dynamic value) {
    if (value is Iterable) {
      return value.where((e) => e != null).map((e) => e.toString()).toList();
    }
    return <String>[];
  }
  final db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> createUser({
    required String name,
    required DateTime birthday,
    String bio = '',
  }) async {
    final user = FirebaseAuth.instance.currentUser!;
    final publicId = 'LM-${sha256.convert(utf8.encode(user.uid)).toString().substring(0, 12).toUpperCase()}';
    await db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'publicId': publicId,
      'name': name.trim(),
      'birthday': Timestamp.fromDate(birthday),
      'bio': bio,
      'photoUrl': '',
      'city': '',
      'country': '',
      'interests': <String>[],
      'coins': 200,
      'diamonds': 0,
      'ownedProfileFrames': <String>['classic'],
      'selectedProfileFrame': 'classic',
      'profileVisibility': 'public',
      'postVisibility': 'public',
      'isVip': false,
      'isAdmin': false,
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': true,
      'isOnline': false,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }


  Future<void> setOnlineStatus(bool online) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(user.uid).set({
      'isOnline': online,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> ensurePublicId() async {
    final userId = uid;
    final ref = db.collection('users').doc(userId);
    final snap = await ref.get();
    if (!snap.exists) return;
    final current = (snap.data()?['publicId'] ?? '').toString().trim();
    if (current.isNotEmpty) return;
    final publicId = 'LM-${sha256.convert(utf8.encode(userId)).toString().substring(0, 12).toUpperCase()}';
    await ref.set({'publicId': publicId}, SetOptions(merge: true));
  }

  Future<QuerySnapshot<Map<String, dynamic>>> findUserByPublicId(String value) {
    // A consulta inclui a visibilidade para que as regras do Firestore
    // consigam garantir que nenhum perfil privado seja retornado.
    final clean = value.trim().toUpperCase().replaceAll(RegExp(r'\s+'), '');
    final publicId = clean.startsWith('LM-') ? clean : 'LM-$clean';
    return db.collection('users')
        .where('publicId', isEqualTo: publicId)
        .where('profileVisibility', isEqualTo: 'public')
        .limit(1)
        .get();
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() =>
      db.collection('users').doc(uid).snapshots();

  Future<void> updateProfile(Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set(data, SetOptions(merge: true));

  Stream<QuerySnapshot<Map<String, dynamic>>> discoverUsers() =>
      db.collection('users')
          // Não exigir isActive == true: contas antigas podem não ter esse
          // campo. A tela remove explicitamente apenas quem está inativo.
          .where('profileVisibility', isEqualTo: 'public')
          .limit(1000)
          .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> myAlliances() => db
      .collection('alliances').where('members', arrayContains: uid).snapshots();

  Future<void> createAllianceByPublicId(String publicId, String relationshipType,
      DateTime startDate, String message) async {
    final cleanId = publicId.trim().toUpperCase();
    if (!cleanId.startsWith('LM-')) throw Exception('Informe um ID público válido (LM-...).');
    const allowed = ['Namorados', 'BFF', 'Amigos', 'Irmãos'];
    if (!allowed.contains(relationshipType)) throw Exception('Tipo de aliança inválido.');
    final found = await findUserByPublicId(cleanId);
    if (found.docs.isEmpty) throw Exception('Não encontramos uma pessoa com esse ID.');
    final partner = found.docs.first;
    if (partner.id == uid) throw Exception('Você não pode criar uma aliança consigo mesmo.');
    if (partner.data()['isActive'] == false) throw Exception('Essa conta não está disponível.');
    final existing = await db.collection('alliances')
        .where('members', arrayContains: uid).get();
    final duplicate = existing.docs.any((d) =>
      (d.data()['members'] as List? ?? []).contains(partner.id) &&
      d.data()['invitationStatus'] != 'rejected');
    if (duplicate) throw Exception('Já existe uma aliança ou convite com essa pessoa.');
    final me = await db.collection('users').doc(uid).get();
    final mine = me.data() ?? {};
    final planned = startDate.isAfter(DateTime.now());
    await db.collection('alliances').add({
      'createdBy': uid, 'invitedUid': partner.id, 'members': [uid, partner.id],
      'creatorName': (mine['name'] ?? 'LoveMix').toString(),
      'creatorPhotoUrl': (mine['photoUrl'] ?? '').toString(),
      'relationshipType': relationshipType, 'message': message.trim(),
      'startDate': Timestamp.fromDate(DateTime(startDate.year, startDate.month, startDate.day)),
      'status': planned ? 'planned' : 'active',
      'invitationStatus': 'pending', 'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> respondAlliance(String allianceId, bool accept) async {
    final ref = db.collection('alliances').doc(allianceId);
    final snap = await ref.get();
    if (!snap.exists || snap.data()?['invitedUid'] != uid ||
        snap.data()?['invitationStatus'] != 'pending') {
      throw Exception('Este convite não está mais disponível.');
    }
    await ref.update({
      'invitationStatus': accept ? 'accepted' : 'rejected',
      'respondedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> pass(String targetUid) async {
    if (targetUid == uid) return;
    await db.collection('users').doc(uid).collection('passed').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<bool> like(String targetUid) async {
    final callable = FirebaseFunctions.instance.httpsCallable('likeUser');
    final result = await callable.call({'targetUid': targetUid});
    return result.data is Map && result.data['matched'] == true;
  }

  DocumentReference<Map<String, dynamic>> followingRef(String targetUid) =>
      db.collection('users').doc(uid).collection('following').doc(targetUid);

  Stream<DocumentSnapshot<Map<String, dynamic>>> followingStatus(String targetUid) =>
      followingRef(targetUid).snapshots();

  Future<bool> toggleFollow(String targetUid) async {
    if (targetUid.isEmpty || targetUid == uid) {
      throw Exception('Perfil inválido.');
    }
    final targetRef = db.collection('users').doc(targetUid);
    final mineRef = followingRef(targetUid);
    final theirsRef = targetRef.collection('followers').doc(uid);
    final blockedByMe = db.collection('users').doc(uid).collection('blocked').doc(targetUid);
    final blockedMe = targetRef.collection('blocked').doc(uid);

    return db.runTransaction<bool>((transaction) async {
      final target = await transaction.get(targetRef);
      final current = await transaction.get(mineRef);
      final blocked1 = await transaction.get(blockedByMe);
      final blocked2 = await transaction.get(blockedMe);
      if (!target.exists || target.data()?['isActive'] == false) {
        throw Exception('Este perfil não está disponível.');
      }
      if (blocked1.exists || blocked2.exists) {
        throw Exception('Não é possível seguir este perfil.');
      }
      if (current.exists) {
        transaction.delete(mineRef);
        transaction.delete(theirsRef);
        return false;
      }
      transaction.set(mineRef, {
        'uid': targetUid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      transaction.set(theirsRef, {
        'uid': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      return true;
    });
  }

  Future<String> openDirectChat(String otherUid) async {
    if (otherUid.isEmpty || otherUid == uid) {
      throw Exception('Perfil inválido.');
    }
    final followsTarget = await followingRef(otherUid).get();
    if (!followsTarget.exists) {
      throw Exception('Siga essa pessoa antes de enviar uma mensagem.');
    }
    final blocked1 = await db.collection('users').doc(uid)
        .collection('blocked').doc(otherUid).get();
    final blocked2 = await db.collection('users').doc(otherUid)
        .collection('blocked').doc(uid).get();
    if (blocked1.exists || blocked2.exists) {
      throw Exception('Não é possível iniciar conversa com este perfil.');
    }
    final users = [uid, otherUid]..sort();
    final chatId = users.join('_');
    final chatRef = db.collection('chats').doc(chatId);
    await chatRef.set({
      'users': users,
      'lastMessage': '',
      'lastMessageAt': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
      'chatType': 'direct',
    }, SetOptions(merge: true));
    return chatId;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myChats() => db
      .collection('chats')
      .where('users', arrayContains: uid)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> myMatches() => db
      .collection('matches')
      .where('users', arrayContains: uid)
      .orderBy('lastMessageAt', descending: true)
      .snapshots();

  CollectionReference<Map<String, dynamic>> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages');



  CollectionReference<Map<String, dynamic>> roomMessages(String roomId) =>
      db.collection('rooms').doc(roomId).collection('messages');

  /// Tenta a consulta ordenada; se o índice do Firestore não existir (erro),
  /// cai para a consulta simples, que não precisa de índice. Assim a tela nunca
  /// fica com o carregamento girando para sempre.
  Stream<QuerySnapshot<Map<String, dynamic>>> _withIndexFallback(
    Query<Map<String, dynamic>> ordered,
    Query<Map<String, dynamic>> simple,
  ) async* {
    try {
      await for (final snap in ordered.snapshots()) {
        yield snap;
      }
    } catch (_) {
      yield* simple.snapshots();
    }
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> publicRooms() {
    final base = db.collection('rooms').where('isPublic', isEqualTo: true);
    return _withIndexFallback(
      base.orderBy('createdAt', descending: true).limit(50),
      base.limit(50),
    );
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> publicLiveRooms({String? mediaMode}) {
    // Busca somente salas públicas. Os campos isLive/mediaMode são filtrados
    // no cliente para evitar consultas compostas que podem falhar quando o
    // índice ainda não foi publicado no projeto Firebase.
    final base = db.collection('rooms').where('isPublic', isEqualTo: true);
    return _withIndexFallback(
      base.orderBy('createdAt', descending: true).limit(100),
      base.limit(100),
    );
  }

  /// Salas de voz com gente dentro agora (campo `voiceLive`, mantido pela
  /// Cloud Function `syncRoomPresence`). Só usa igualdade: não precisa de índice.
  Stream<QuerySnapshot<Map<String, dynamic>>> publicVoiceLiveRooms() => db
      .collection('rooms')
      .where('isPublic', isEqualTo: true)
      .where('voiceLive', isEqualTo: true)
      .limit(50)
      .snapshots();

  Future<Map<String, String>> liveIdentityDefaults() async {
    await ensurePublicId();
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para participar da live.');

    final profile = await db.collection('users').doc(user.uid).get();
    final data = profile.data() ?? <String, dynamic>{};
    final publicId = (data['publicId'] ?? '').toString().trim();
    if (!RegExp(r'^LM-[A-F0-9]{12}$').hasMatch(publicId)) {
      throw Exception('Não foi possível carregar seu ID LoveMix. Complete seu perfil e tente novamente.');
    }

    final profileName = (data['name'] ?? '').toString().trim();
    final accountName = (user.displayName ?? '').trim();
    final emailName = (user.email?.split('@').first ?? '').trim();
    final displayName = profileName.isNotEmpty
        ? profileName
        : accountName.isNotEmpty
            ? accountName
            : emailName.isNotEmpty
                ? emailName
                : 'LoveMix';

    return {'publicId': publicId, 'displayName': displayName};
  }

  CollectionReference<Map<String, dynamic>> liveParticipants(String roomId) =>
      db.collection('rooms').doc(roomId).collection('participants');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchLiveParticipants(String roomId) =>
      liveParticipants(roomId).where('isActive', isEqualTo: true).limit(50).snapshots();

  Future<void> registerLiveParticipant({
    required String roomId,
    required String publicId,
    required String displayName,
  }) async {
    final cleanName = displayName.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (cleanName.isEmpty || cleanName.length > 32) {
      throw Exception('Escolha um nome de 1 a 32 caracteres para a live.');
    }
    final identity = await liveIdentityDefaults();
    if (identity['publicId'] != publicId) {
      throw Exception('Seu ID LoveMix mudou. Feche e entre na live novamente.');
    }
    await liveParticipants(roomId).doc(uid).set({
      'uid': uid,
      'publicId': publicId,
      'displayName': cleanName,
      'isActive': true,
      'joinedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> leaveLiveParticipant(String roomId) async {
    await liveParticipants(roomId).doc(uid).set({
      'isActive': false,
      'leftAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  /// Filtra as salas que realmente estão ao vivo agora e devolve NO MÁXIMO
  /// 1 sala por pessoa (dono) para o tipo pedido: `audio` (voz) ou `video`.
  /// Regras:
  ///  - isLive == true e o tipo da sala bate com o pedido;
  ///  - se a sala já tem `onlineCount` (mantido pela Cloud Function
  ///    `syncRoomPresence`) e ele for 0, ninguém está dentro => não aparece;
  ///  - se a mesma pessoa tiver mais de uma sala, fica só a mais recente.
  static List<QueryDocumentSnapshot<Map<String, dynamic>>> activeLivesOnePerOwner(
    Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
    String mediaMode,
  ) {
    final wantAudio = mediaMode == 'audio';
    final list = docs.where((d) {
      final data = d.data();
      if (data['isLive'] != true) return false;
      final mode = (data['mediaMode'] ?? '').toString();
      if (wantAudio ? mode != 'audio' : (mode != 'video' && mode != 'live')) return false;
      final online = data['onlineCount'];
      if (online is num && online <= 0) return false;
      return true;
    }).toList();

    int millis(QueryDocumentSnapshot<Map<String, dynamic>> d) {
      final t = d.data()['createdAt'];
      return t is Timestamp ? t.millisecondsSinceEpoch : 0;
    }

    list.sort((a, b) => millis(b).compareTo(millis(a)));
    final seenOwners = <String>{};
    final result = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
    for (final d in list) {
      final owner = (d.data()['ownerId'] ?? d.id).toString();
      if (seenOwners.add(owner)) result.add(d);
    }
    return result;
  }

  /// Encerra as outras lives da própria pessoa do mesmo tipo (voz ou vídeo),
  /// para que ela nunca tenha mais de 1 live de voz e 1 live de vídeo ao vivo.
  Future<void> endMyOtherLives(String mediaMode) async {
    try {
      final snap = await db
          .collection('rooms')
          .where('ownerId', isEqualTo: uid)
          .where('isLive', isEqualTo: true)
          .get();
      for (final d in snap.docs) {
        final mode = (d.data()['mediaMode'] ?? '').toString();
        final sameKind = mediaMode == 'audio'
            ? mode == 'audio'
            : (mode == 'video' || mode == 'live');
        if (sameKind) {
          try {
            await d.reference.update({'isLive': false});
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  Future<void> endLiveRoom(String roomId) async {
    await db.collection('rooms').doc(roomId).update({'isLive': false});
  }

  Future<String> createRoom(String name, {bool isPublic = true, String category = 'Amizades', String description = '', String password = '', bool isLive = false, String mediaMode = 'text'}) async {
    final clean = name.trim();
    if (clean.length < 3 || clean.length > 40) {
      throw Exception('O nome da sala deve ter entre 3 e 40 caracteres.');
    }
    if (isLive && (mediaMode == 'audio' || mediaMode == 'video')) {
      await endMyOtherLives(mediaMode);
    }
    if (!isPublic && password.trim().length < 4) {
      throw Exception('A senha da sala privada deve ter pelo menos 4 caracteres.');
    }
    final payload = <String, dynamic>{
      'name': clean,
      'ownerId': uid,
      'members': [uid],
      'isPublic': isPublic,
      'category': category,
      'description': description.trim(),
      'isLive': isLive,
      'liveCoinEarnings': 0,
      'isLocked': false,
      'mediaMode': mediaMode,
      'passwordHash': isPublic ? null : sha256.convert(utf8.encode(password.trim())).toString(),
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': 'Sala criada. Dê boas-vindas!',
      'lastMessageAt': FieldValue.serverTimestamp(),
    };

    // Falhas "unavailable" são normalmente temporárias (rede/Firestore).
    // Repetimos apenas erros transitórios; nunca repetimos permission-denied.
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final ref = await db.collection('rooms').add(payload);
        return ref.id;
      } on FirebaseException catch (e) {
        final transient = e.code == 'unavailable' ||
            e.code == 'deadline-exceeded' || e.code == 'network-request-failed';
        if (!transient || attempt == 2) rethrow;
        await Future<void>.delayed(Duration(seconds: attempt + 1));
      }
    }
    throw Exception('Não foi possível criar a sala. Verifique sua conexão e tente novamente.');
  }

  /// Admin do app (mesma claim usada nas regras do Firestore).
  Future<bool> _isAdminClaim() async {
    try {
      final token = await FirebaseAuth.instance.currentUser?.getIdTokenResult(true);
      return token?.claims?['admin'] == true;
    } catch (_) {
      return false;
    }
  }

  /// O dono da sala pode promover ou remover administradores.
  Future<void> setRoomAdmin(String roomId, String targetUid, bool makeAdmin) async {
    if (targetUid == uid) throw Exception('O dono da sala já tem controle total.');
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      final data = snap.data() ?? <String, dynamic>{};
      if (data['ownerId'] != uid) throw Exception('Somente o dono pode gerenciar administradores.');
      final members = List<String>.from(data['members'] ?? const []);
      if (!members.contains(targetUid)) throw Exception('A pessoa não está mais na sala.');
      final admins = List<String>.from(data['roomAdmins'] ?? const []);
      if (makeAdmin) {
        if (!admins.contains(targetUid)) admins.add(targetUid);
      } else {
        admins.remove(targetUid);
      }
      tx.update(ref, {'roomAdmins': admins});
    });
  }

  /// Remove um participante, seus privilégios e seu assento. O dono não pode ser expulso.
  Future<void> kickRoomMember(String roomId, String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode expulsar o dono da sala.');
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      final data = snap.data() ?? <String, dynamic>{};
      if (data['ownerId'] != uid) throw Exception('Somente o dono pode expulsar participantes.');
      final members = List<String>.from(data['members'] ?? const []);
      if (!members.contains(targetUid)) throw Exception('A pessoa não está mais na sala.');
      members.remove(targetUid);
      final admins = List<String>.from(data['roomAdmins'] ?? const [])..remove(targetUid);
      tx.update(ref, {'members': members, 'roomAdmins': admins});
    });
    // Limpeza complementar: libera assento e marca a presença como encerrada.
    final seats = roomSeats(roomId);
    final occupied = await seats.where('uid', isEqualTo: targetUid).get();
    for (final seat in occupied.docs) { await seat.reference.delete(); }
    final participantRef = liveParticipants(roomId).doc(targetUid);
    final participantSnap = await participantRef.get();
    if (participantSnap.exists) {
      await participantRef.update({'isActive': false, 'leftAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> joinRoom(String roomId) async {
    final roomRef = db.collection('rooms').doc(roomId);
    await db.runTransaction((transaction) async {
      final snapshot = await transaction.get(roomRef);
      if (!snapshot.exists) throw Exception('Sala não encontrada.');
      final data = snapshot.data() ?? <String, dynamic>{};
      final members = List<String>.from(data['members'] ?? const []);
      if (members.contains(uid)) return;
      // Sala bloqueada: só o dono e os admins entram. Os demais não.
      final isRoomOwner = (data['ownerId'] ?? '').toString() == uid;
      if (data['isLocked'] == true && !isRoomOwner && !await _isAdminClaim()) {
        throw Exception('Esta sala está bloqueada pelo anfitrião.');
      }
      transaction.update(roomRef, {
        'members': FieldValue.arrayUnion([uid]),
      });
    });
  }

  CollectionReference<Map<String, dynamic>> roomSeats(String roomId) =>
      db.collection('rooms').doc(roomId).collection('seats');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchRoomSeats(String roomId) =>
      roomSeats(roomId).snapshots();

  Future<void> takeRoomSeat(String roomId, int seatNumber) async {
    if (seatNumber < 1 || seatNumber > 10) {
      throw Exception('Assento inválido.');
    }
    await joinRoom(roomId);
    final seats = roomSeats(roomId);
    await db.runTransaction((transaction) async {
      final refs = List.generate(10, (i) => seats.doc('${i + 1}'));
      final snapshots = <DocumentSnapshot<Map<String, dynamic>>>[];
      for (final ref in refs) {
        snapshots.add(await transaction.get(ref));
      }

      final targetIndex = seatNumber - 1;
      final targetData = snapshots[targetIndex].data();
      if (targetData != null && targetData['uid'] != uid) {
        throw Exception('Esse assento já está ocupado. Escolha outro.');
      }

      if (targetData?['uid'] == uid) {
        for (var i = 0; i < snapshots.length; i++) {
          if (i != targetIndex && snapshots[i].data()?['uid'] == uid) {
            transaction.delete(refs[i]);
          }
        }
        return;
      }

      for (var i = 0; i < snapshots.length; i++) {
        final data = snapshots[i].data();
        if (data != null && data['uid'] == uid) {
          transaction.delete(refs[i]);
        }
      }
      transaction.set(refs[targetIndex], {
        'uid': uid,
        'seatNumber': seatNumber,
        'micOn': false,
        'joinedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> leaveRoomSeat(String roomId) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    for (final seat in ownSeat.docs) {
      await seat.reference.delete();
    }
  }

  Future<void> setRoomSeatMic(String roomId, bool enabled) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    if (ownSeat.docs.isEmpty) return;
    await ownSeat.docs.first.reference.update({'micOn': enabled});
  }

  Future<void> sendRoomMessage(String roomId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 1000) return;
    final room = db.collection('rooms').doc(roomId);
    await roomMessages(roomId).add({
      'senderId': uid, 'text': clean, 'type': 'text',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await room.update({'lastMessage': clean, 'lastMessageAt': FieldValue.serverTimestamp()});
  }

  Future<void> sendRoomGift(String roomId, String recipientUid, String giftId,
      String emoji, String giftName) async {
    final callable = FirebaseFunctions.instance.httpsCallable('sendRoomGift');
    await callable.call(<String, dynamic>{
      'roomId': roomId,
      'recipientUid': recipientUid,
      'giftId': giftId,
    });
  }

  /// Última chuva de alianças do baú da sala (aberta, resgatada ou expirada).
  Stream<QuerySnapshot<Map<String, dynamic>>> watchLatestDrop(String roomId) =>
      db.collection('rooms').doc(roomId).collection('drops')
          .orderBy('createdAt', descending: true).limit(1).snapshots();

  /// Tenta pegar a aliança da chuva. O servidor garante que só 1 pessoa leva.
  Future<void> claimRoomDrop(String roomId, String dropId) async {
    final callable = FirebaseFunctions.instance.httpsCallable('claimRoomDrop');
    await callable.call(<String, dynamic>{'roomId': roomId, 'dropId': dropId});
  }

  Future<void> blockUser(String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode bloquear sua própria conta.');
    await db.collection('users').doc(uid).collection('blocked').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> reportUser(String targetUid, String reason, {String details = ''}) async {
    final cleanReason = reason.trim();
    if (targetUid == uid || cleanReason.isEmpty) {
      throw Exception('Selecione um motivo válido para a denúncia.');
    }
    await db.collection('reports').add({
      'reporterId': uid,
      'reportedUserId': targetUid,
      'reason': cleanReason,
      'details': details.trim(),
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteMyAccount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(uid).delete();
    await user.delete();
  }

  /// Resgata um código promocional (VIP ou saldo). As regras do Firestore
  /// validam o código e impedem que a mesma conta o use duas vezes.
  /// Retorna 'vip' ou 'wallet'.
  Future<String> redeemPromoCode(String raw) async {
    final code = raw.trim().toUpperCase().replaceAll(RegExp(r'\s+'), '');
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para resgatar.');
    if (code.isEmpty) throw Exception('Digite o código.');
    final isVip = code.startsWith('LMVIP');
    final db = FirebaseFirestore.instance;
    final batch = db.batch();
    batch.set(db.collection('promoCodeClaims').doc('${code}_${user.uid}'), {
      'uid': user.uid,
      'code': code,
      'reward': isVip ? 'vip' : 'wallet',
      'claimedAt': FieldValue.serverTimestamp(),
    });
    batch.update(db.collection('users').doc(user.uid), isVip
        ? {'pendingPromoCode': code, 'isVip': true, 'vipGrantedAt': FieldValue.serverTimestamp()}
        : {'pendingPromoCode': code, 'coins': FieldValue.increment(2000), 'diamonds': FieldValue.increment(2000)});
    try {
      await batch.commit();
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw Exception('Código inválido ou já resgatado nesta conta.');
      }
      throw Exception('Não foi possível resgatar (${e.code}). Tente novamente.');
    }
    return isVip ? 'vip' : 'wallet';
  }

  Future<void> sendMessage(String chatId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    final chat = db.collection('chats').doc(chatId);
    // O chat é criado pela Cloud Function no momento do match.
    // Aqui atualizamos somente o chat existente; não criamos conversas arbitrárias.
    await chat.update({
      'lastMessage': clean,
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    await messages(chatId).add({
      'senderId': uid,
      'text': clean,
      'createdAt': FieldValue.serverTimestamp(),
      'type': 'text',
    });
  }
}
