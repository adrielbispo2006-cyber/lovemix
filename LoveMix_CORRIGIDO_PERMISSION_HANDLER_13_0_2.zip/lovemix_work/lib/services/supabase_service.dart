import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Integração do LoveMix com Supabase Storage.
/// A chave publishable pode ficar no app; nunca coloque service_role aqui.
class SupabaseService {
  SupabaseService._();
  static final instance = SupabaseService._();

  static const projectId = 'pcruxbtuimndtjtuclhf';
  static const projectUrl = 'https://pcruxbtuimndtjtuclhf.supabase.co';
  static const publishableKey =
      'sb_publishable_eFocZg9VHa6PWHmg3_ae9w_X2ChWfZO';
  static const bucket = 'lovemix-photos';

  bool _initialized = false;
  bool get isInitialized => _initialized;
  SupabaseClient get client => Supabase.instance.client;

  Future<void> initialize() async {
    if (_initialized) return;
    await Supabase.initialize(
      url: projectUrl,
      publishableKey: publishableKey,
    );
    _initialized = true;
  }

  /// Envia arquivo para o bucket público e devolve a URL pública.
  Future<String> uploadPhoto({
    required String path,
    required Uint8List bytes,
    required String contentType,
  }) async {
    if (!_initialized) throw Exception('Supabase ainda não foi inicializado.');
    if (bytes.isEmpty) throw Exception('O arquivo está vazio.');
    await client.storage.from(bucket).uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(
        contentType: contentType,
        upsert: true,
        cacheControl: '3600',
      ),
    );
    return client.storage.from(bucket).getPublicUrl(path);
  }

  Future<void> deleteFile(String path) async {
    if (!_initialized) return;
    await client.storage.from(bucket).remove([path]);
  }

  Future<bool> deletePublicUrl(String url) async {
    if (!_initialized) return false;
    final marker = '/storage/v1/object/public/$bucket/';
    final index = url.indexOf(marker);
    if (index < 0) return false;
    final path = Uri.decodeComponent(url.substring(index + marker.length));
    if (path.isEmpty) return false;
    await deleteFile(path);
    return true;
  }
}
