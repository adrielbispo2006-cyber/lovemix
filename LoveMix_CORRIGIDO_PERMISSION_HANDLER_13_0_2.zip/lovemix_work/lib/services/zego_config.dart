/// Configuração ZEGOCLOUD do LoveMix.
/// ATENÇÃO: AppSign no aplicativo pode ser extraído do APK.
/// Para produção, prefira autenticação por tokens gerados no servidor.
class ZegoConfig {
  static const int appId = 2116602891;
  static const String appSign =
      '24d114310e641995571461803b9d25b717dc7b9e2e3bbc7c42aed01c959c298d';
}
