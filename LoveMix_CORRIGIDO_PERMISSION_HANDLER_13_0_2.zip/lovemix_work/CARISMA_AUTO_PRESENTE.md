# Carisma ao se presentear na própria live

O anfitrião da sala pode enviar um presente para si mesmo e receber carisma no perfil.
O carisma segue a regra do catálogo: presentes pagos com moedas dão `cost` pontos;
presentes pagos com diamantes dão `cost * 10` pontos.

O auto-presente continua descontando o saldo do anfitrião normalmente. Ele não gera
moedas de recompensa de anfitrião nem pontos extras do baú; apenas carisma.
A alteração é aplicada pela callable `sendRoomGift` no Firebase Functions, portanto
é necessário publicar as Functions para que entre em vigor no aplicativo.
