# Administração das salas LoveMix

O dono da sala pode abrir o menu (⋯) e escolher **Gerenciar participantes e administradores**. Ali pode promover/remover administradores e expulsar participantes. A promoção é gravada em `roomAdmins`; a expulsão remove o UID de `members`, remove o privilégio de admin, libera assento e marca a presença como inativa.

**Obrigatório:** publicar o arquivo `firestore.rules` atualizado no Firebase Console (Firestore Database → Rules) antes de testar. O dono continua protegido contra expulsão. A remoção do Firestore não substitui revogação de credenciais/token do provedor de mídia; teste também a desconexão do ZEGOCLOUD.
