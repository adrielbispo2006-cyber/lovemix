# LoveMix — Seguir e mensagens diretas

## O que mudou
- O botão de coração no perfil foi substituído por **Seguir / Seguindo**.
- Seguir cria registros em `users/{uid}/following/{targetUid}` e `users/{targetUid}/followers/{uid}`.
- Tocar novamente em **Seguindo** deixa de seguir e remove os dois registros.
- Depois de seguir, o botão **Mensagem** fica habilitado e cria ou reutiliza uma conversa direta em `chats/{uidOrdenados}`; não exige match nem que a outra pessoa siga de volta.
- A tela Mensagens agora lista conversas diretas e conversas que já vieram de match.
- O coração na tela Descobrir também segue/deixa de seguir. A estrela continua enviando curtida especial.
- As regras permitem consultar somente o registro de bloqueio que diz respeito ao próprio usuário, para impedir seguir/conversar com quem bloqueou ou foi bloqueado.

## Publicar as regras atualizadas
Na pasta do projeto, execute:

```bash
firebase deploy --only firestore:rules
```

Depois gere e instale um novo APK. As alterações no app não passam a valer nos celulares até instalar a nova versão.

## Observação
As conversas são criadas quando o usuário toca em **Mensagem** no perfil. O destinatário não precisa seguir de volta. O bloqueio continua impedindo a abertura de novas conversas.
