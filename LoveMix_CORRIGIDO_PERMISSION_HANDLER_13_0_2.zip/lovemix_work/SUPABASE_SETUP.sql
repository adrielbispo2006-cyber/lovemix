-- Execute no SQL Editor do projeto pcruxbtuimndtjtuclhf.
-- Cria armazenamento público para fotos e vídeos de stories do LoveMix.
-- ATENÇÃO: o app usa Firebase Auth, não Supabase Auth. Por isso as políticas
-- abaixo permitem upload anônimo limitado a 30 MB e tipos de mídia comuns.
-- Para produção com proteção por usuário, migre a autenticação para Supabase
-- ou faça os uploads por uma Edge Function que valide o token Firebase.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'lovemix-photos',
  'lovemix-photos',
  true,
  31457280,
  array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "LoveMix public media uploads"
on storage.objects for insert
to anon, authenticated
with check (bucket_id = 'lovemix-photos');

create policy "LoveMix public media updates"
on storage.objects for update
to anon, authenticated
using (bucket_id = 'lovemix-photos')
with check (bucket_id = 'lovemix-photos');

create policy "LoveMix public media reads"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'lovemix-photos');
