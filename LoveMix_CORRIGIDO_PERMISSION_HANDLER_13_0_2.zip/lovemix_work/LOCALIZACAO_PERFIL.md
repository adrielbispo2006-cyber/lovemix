# Localização no perfil LoveMix

- O botão de localizador ao lado de Cidade/Estado solicita permissão de localização durante o uso.
- O app usa o GPS para identificar cidade/estado e país e preencher os campos do perfil.
- O salvamento automático existente grava os nomes da cidade/estado e do país.
- Latitude e longitude exatas NÃO são gravadas no perfil público.
- O workflow do GitHub Actions adiciona ACCESS_COARSE_LOCATION e ACCESS_FINE_LOCATION ao AndroidManifest.
- Dependências adicionadas: geolocator e geocoding.

Após enviar o projeto ao GitHub, execute o workflow para gerar um novo APK. No primeiro uso, permita a localização enquanto estiver usando o aplicativo.
