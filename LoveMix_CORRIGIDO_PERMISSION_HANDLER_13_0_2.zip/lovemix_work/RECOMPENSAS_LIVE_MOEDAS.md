# Recompensas de moedas nas lives

- O anfitrião recebe moedas somente quando um espectador envia um presente diretamente para o dono da sala.
- Presentes pagos com moedas: recompensa de 1 moeda por moeda gasta.
- Presentes pagos com diamantes: recompensa de 10 moedas por diamante gasto.
- O total recebido durante a live fica no campo `rooms/{roomId}.liveCoinEarnings` e começa em zero quando uma sala é criada.
- O pequeno contador com ícone de moeda aparece somente na tela do anfitrião. Os espectadores não veem esse contador.
- O saldo de moedas do anfitrião é atualizado no servidor, dentro da mesma transação que desconta o presente do espectador.

## Publicar a alteração do servidor

A recompensa é processada pela Firebase Callable Function `sendRoomGift`. Para ativá-la no projeto Firebase, publique a função atualizada:

```bash
cd functions
npm install
npm run build
cd ..
firebase deploy --only functions:sendRoomGift
```

Depois, gere e instale o APK atualizado para exibir o contador na tela da live. Apenas compilar o APK não publica a função no Firebase.
