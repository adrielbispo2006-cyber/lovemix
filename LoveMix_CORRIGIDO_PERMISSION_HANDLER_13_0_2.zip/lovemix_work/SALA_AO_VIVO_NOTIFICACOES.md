LOVE MIX — AVISO DE NOVA LIVE

Alterações incluídas:
- A página inicial mostra a seção “Ao vivo agora” em tempo real para transmissões públicas.
- O cartão identifica live de voz ou vídeo e abre a sala correspondente ao tocar.
- A Cloud Function notifyOnLiveStarted envia notificação push aos demais usuários com token FCM registrado quando uma sala pública é criada já com isLive=true.
- O aviso também aparece com o app aberto, usando o serviço de notificações já existente.

IMPORTANTE — PUBLICAR AS CLOUD FUNCTIONS

Para que os avisos push cheguem aos celulares, publique as funções atualizadas no mesmo projeto Firebase usado pelo app:
  cd functions
  npm install
  npm run build
  cd ..
  firebase deploy --only functions

Confirme que Cloud Messaging está habilitado e que cada usuário aceitou as permissões de notificação no aplicativo.

Observação: somente lives públicas são anunciadas. Lives privadas não são exibidas nem notificadas. A função dispara quando a sala é criada com isLive=true, que é como o projeto inicia as lives atualmente.
