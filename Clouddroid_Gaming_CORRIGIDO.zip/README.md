# Clouddroid Gaming

Projeto inicial Flutter para Android, com identidade preta e roxa, catálogo pesquisável (incluindo GTA V e GTA VI), filtros por categoria, tela Tradutor Gamer e área de conta.

## Estado real desta versão

Esta é a **primeira base do aplicativo**, não um serviço de cloud gaming operacional. Os jogos aparecem como catálogo planejado. Nenhum jogo é incluído, hospedado ou desbloqueado pelo app.

Para habilitar streaming real será necessário:
1. Escolher um provedor/infraestrutura de GPU compatível com streaming interativo.
2. Criar o backend de contas, sessões, filas, limites e segurança.
3. Integrar um cliente de streaming (por exemplo, WebRTC ou SDK do provedor).
4. Confirmar licenças, propriedade/cópias e termos de cada jogo.
5. Testar latência, bitrate, controles, áudio e compatibilidade Android.

A gratuidade para jogadores dependerá de patrocínio, créditos, servidores gratuitos disponíveis ou outro financiamento. GPU na nuvem não é ilimitada nem garantidamente gratuita.

## Gerar APK

Com Flutter instalado:
```bash
flutter pub get
flutter analyze
flutter build apk --release
```

O APK será gerado em:
`build/app/outputs/flutter-apk/app-release.apk`

## Requisitos

- Flutter stable
- Android SDK
- Java 17 (para builds Android atuais)

## Próxima etapa técnica

Definir o provedor de cloud gaming e criar o backend/API antes de apresentar qualquer botão como “Jogar agora”.


## Controles Bluetooth

A tela **Controle Bluetooth** lista os gamepads reconhecidos pelo Android e mostra eventos de botões e analógicos. Para usar, pareie primeiro o controle em Configurações do Android → Bluetooth e depois atualize a lista no aplicativo. A integração usa o pacote `gamepads` e encaminhamento nativo de `KeyEvent`/`MotionEvent` no Android. A compatibilidade de comandos dentro de cada jogo depende do jogo e do serviço de streaming.

### Detecção automática de controles

O app inicia o monitoramento de eventos de conexão de gamepads assim que é aberto. Depois de parear o controle nas configurações Bluetooth do Android, ele deve aparecer automaticamente na tela inicial e no indicador do ícone de controle, sem precisar tocar em “Procurar controles conectados”. A detecção ocorre enquanto o app está em execução; o Android não permite que um app comum se abra sozinho quando um controle é pareado com o app totalmente fechado. O encaminhamento de botões para cada jogo ainda depende do jogo e do serviço de streaming.
