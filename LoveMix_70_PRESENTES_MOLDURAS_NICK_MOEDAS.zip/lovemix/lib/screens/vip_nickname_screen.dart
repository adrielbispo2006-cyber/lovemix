import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/vip_nickname.dart';
import 'profile_frames_screen.dart';

class VipNicknameScreen extends StatefulWidget {
  const VipNicknameScreen({super.key});
  @override
  State<VipNicknameScreen> createState() => _VipNicknameScreenState();
}

class _VipNicknameScreenState extends State<VipNicknameScreen> {
  bool loading = true;
  bool busy = false;
  int coins = 0;
  List<String> owned = <String>[];
  String selected = '';
  String? uid;

  static const decorations = <Map<String, Object>>[
    {'id':'royal_gold','label':'Coroa Real','price':300},
    {'id':'purple_king','label':'Rei Roxo','price':350},
    {'id':'pink_love','label':'Love Rosa','price':300},
    {'id':'blue_legend','label':'Lenda Azul','price':350},
    {'id':'red_flame','label':'Chama','price':400},
    {'id':'emerald','label':'Esmeralda','price':400},
  ];
  String key(String suffix) => 'lovemix_frames_${uid}_$suffix';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) { setState(() => loading = false); return; }
    final prefs = await SharedPreferences.getInstance();
    final profile = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (!prefs.containsKey(key('coins'))) {
      await prefs.setInt(key('coins'), (profile.data()?['coins'] as num?)?.toInt() ?? 0);
    }
    if (!mounted) return;
    setState(() {
      coins = prefs.getInt(key('coins')) ?? 0;
      owned = prefs.getStringList(key('nick_owned')) ?? <String>[];
      selected = prefs.getString(key('nick_selected')) ?? '';
      loading = false;
    });
  }

  Future<void> _buy(Map<String, Object> item) async {
    if (busy || uid == null) return;
    final id = item['id'] as String;
    final price = item['price'] as int;
    if (!owned.contains(id) && coins < price) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Você não tem moedas suficientes.')));
      return;
    }
    setState(() => busy = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final nextOwned = List<String>.from(owned);
      var nextCoins = coins;
      if (!nextOwned.contains(id)) {
        nextCoins -= price;
        nextOwned.add(id);
        await prefs.setInt(key('coins'), nextCoins);
        await prefs.setStringList(key('nick_owned'), nextOwned);
      }
      await prefs.setString(key('nick_selected'), id);
      // O estilo selecionado fica no perfil para aparecer também aos outros usuários.
      await FirebaseFirestore.instance.collection('users').doc(uid).set(
        {'vipNicknameStyle': id, 'nicknameDecorationActive': true}, SetOptions(merge: true));
      if (!mounted) return;
      setState(() { coins = nextCoins; owned = nextOwned; selected = id; });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${item['label']} ativada!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível ativar: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    if (loading) return const Scaffold(backgroundColor: Color(0xFF080510), body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Loja de personalização'), backgroundColor: const Color(0xFF080510)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF21132F), borderRadius: BorderRadius.circular(16)),
          child: Row(children: [const Text('🪙', style: TextStyle(fontSize: 26)), const SizedBox(width: 10), Text('$coins moedas', style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 19, fontWeight: FontWeight.bold))])),
        const SizedBox(height: 18),
        const Text('Decorações de nick', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        ...decorations.map((item) {
          final id = item['id'] as String;
          final has = owned.contains(id);
          final active = selected == id;
          return Card(color: const Color(0xFF171022), child: ListTile(
            title: VipNickname(name: 'Seu Nick', isVip: true, styleId: id),
            subtitle: Text(has ? 'Comprada' : '🪙 ${item['price']} moedas', style: const TextStyle(color: Colors.white60)),
            trailing: busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator()) : active ? const Icon(Icons.check_circle, color: Color(0xFFFF19B8)) : ElevatedButton(onPressed: () => _buy(item), child: Text(has ? 'Usar' : 'Comprar')),
          ));
        }),
        const SizedBox(height: 20),
        const Text('Molduras de perfil', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Card(color: const Color(0xFF171022), child: ListTile(
          leading: const Icon(Icons.auto_awesome, color: Color(0xFFFF19B8)),
          title: const Text('Loja de molduras', style: TextStyle(color: Colors.white)),
          subtitle: const Text('Compre e equipe molduras usando moedas', style: TextStyle(color: Colors.white60)),
          trailing: const Icon(Icons.chevron_right, color: Color(0xFFFF19B8)),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen())),
        )),
      ]),
    );
  }
}
