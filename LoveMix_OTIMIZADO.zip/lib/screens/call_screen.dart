import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';
import '../services/zego_config.dart';

Future<bool> _granted(bool video) async {
  final wanted = <Permission>[Permission.microphone, if (video) Permission.camera];
  for (final p in wanted) {
    if (!(await p.status).isGranted) return false;
  }
  return true;
}

/// Espera o usuário voltar das configurações do aparelho ao app.
class _ResumeWaiter with WidgetsBindingObserver {
  _ResumeWaiter() { WidgetsBinding.instance.addObserver(this); }
  final _c = Completer<void>();
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_c.isCompleted) _c.complete();
  }
  Future<void> wait() async {
    await _c.future.timeout(const Duration(minutes: 5), onTimeout: () {});
    WidgetsBinding.instance.removeObserver(this);
  }
}

/// Pede as permissões necessárias (microfone; câmera também no vídeo).
/// Se estiverem bloqueadas, leva o usuário às configurações e, ao voltar,
/// confere de novo. Retorna true somente se tudo foi liberado.
Future<bool> requestCallPermissions(BuildContext context, {required bool video}) async {
  final wanted = <Permission>[Permission.microphone, if (video) Permission.camera];
  final result = await wanted.request();
  if (result.values.every((s) => s.isGranted)) return true;
  if (!context.mounted) return false;

  final blocked = result.values.any((s) => s.isPermanentlyDenied || s.isRestricted);
  final what = video ? 'à câmera e ao microfone' : 'ao microfone';
  final openSettings = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF21132E),
      title: const Text('Permissão necessária'),
      content: Text(blocked
          ? 'Para fazer chamadas de ${video ? 'vídeo' : 'voz'}, permita o acesso $what nas configurações do aparelho (Permissões). Depois é só voltar ao app que a chamada continua.'
          : 'Sem acesso $what não é possível fazer a chamada. Toque em "Permitir" para continuar.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Agora não')),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(blocked ? 'Abrir configurações' : 'Permitir'),
        ),
      ],
    ),
  );
  if (openSettings != true) return false;

  if (!blocked) return requestCallPermissions(context, video: video);

  final waiter = _ResumeWaiter();
  await openAppSettings();
  await waiter.wait();
  return _granted(video);
}

/// Chamada 1:1 com convite, tempo limite e cronômetro iniciado após atender.
class CallScreen extends StatefulWidget {
  const CallScreen({
    super.key,
    required this.callRef,
    required this.video,
    this.isCaller = false,
  });

  final DocumentReference<Map<String, dynamic>> callRef;
  final bool video;
  final bool isCaller;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  Timer? _ringTimeout;
  Timer? _clock;
  int _elapsedSeconds = 0;
  bool _enteredCall = false;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    if (widget.isCaller) {
      _ringTimeout = Timer(const Duration(seconds: 30), _expireIfUnanswered);
    }
  }

  Future<void> _expireIfUnanswered() async {
    if (!mounted || _enteredCall) return;
    try {
      final snap = await widget.callRef.get();
      if (snap.data()?['status'] == 'ringing') {
        await widget.callRef.update({
          'status': 'missed',
          'endedAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (_) {}
  }

  void _startClock(Timestamp? acceptedAt) {
    if (_enteredCall) return;
    _enteredCall = true;
    _ringTimeout?.cancel();
    final start = acceptedAt?.toDate() ?? DateTime.now();
    _elapsedSeconds = DateTime.now().difference(start).inSeconds.clamp(0, 86400).toInt();
    _clock = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        _elapsedSeconds = DateTime.now().difference(start).inSeconds.clamp(0, 86400).toInt();
      });
    });
  }

  String get _formattedTime {
    final minutes = (_elapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final seconds = (_elapsedSeconds % 60).toString().padLeft(2, '0');
    final hours = (_elapsedSeconds ~/ 3600);
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:$minutes:$seconds';
    }
    return '$minutes:$seconds';
  }

  Future<void> _finishCall() async {
    if (_closing) return;
    _closing = true;
    _ringTimeout?.cancel();
    _clock?.cancel();
    try {
      await widget.callRef.update({
        'status': 'ended',
        'endedAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _ringTimeout?.cancel();
    _clock?.cancel();
    // Se a tela sair enquanto a chamada estiver conectada, encerra para ambos.
    if (_enteredCall && !_closing) {
      widget.callRef.update({
        'status': 'ended',
        'endedAt': FieldValue.serverTimestamp(),
      }).catchError((_) {});
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final name = (user?.displayName ?? '').trim();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: widget.callRef.snapshots(),
      builder: (context, snapshot) {
        final data = snapshot.data?.data() ?? <String, dynamic>{};
        final status = (data['status'] ?? 'ringing').toString();

        if (status == 'accepted') {
          final acceptedAt = data['acceptedAt'];
          _startClock(acceptedAt is Timestamp ? acceptedAt : null);
        }

        if (status == 'rejected' || status == 'missed' || status == 'ended') {
          if (!_closing) {
            _closing = true;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (!mounted) return;
              final message = status == 'missed'
                  ? 'Ninguém atendeu. Chamada encerrada.'
                  : status == 'rejected'
                      ? 'A chamada foi recusada.'
                      : 'A chamada foi encerrada.';
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
              Navigator.of(context).pop();
            });
          }
          return const Scaffold(
            backgroundColor: Color(0xFF100A19),
            body: Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB))),
          );
        }

        if (status != 'accepted') {
          return Scaffold(
            backgroundColor: const Color(0xFF100A19),
            body: SafeArea(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(widget.video ? Icons.videocam : Icons.call,
                        color: const Color(0xFFFF2DAB), size: 76),
                    const SizedBox(height: 18),
                    Text(widget.isCaller ? 'Chamando...' : 'Conectando...',
                        style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    const Text('Aguardando a outra pessoa atender',
                        style: TextStyle(color: Colors.white70)),
                    const SizedBox(height: 28),
                    IconButton.filled(
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        minimumSize: const Size(66, 66),
                      ),
                      onPressed: _finishCall,
                      icon: const Icon(Icons.call_end, color: Colors.white, size: 30),
                    ),
                    const SizedBox(height: 10),
                    const Text('Cancelar', style: TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
            ),
          );
        }

        final callerUid = (data['callerUid'] ?? '').toString();
        final calleeUid = (data['calleeUid'] ?? '').toString();
        final callerPhotoUrl = (data['callerPhotoUrl'] ?? '').toString();
        final calleePhotoUrl = (data['calleePhotoUrl'] ?? '').toString();
        final callConfig = widget.video
            ? ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()
            : ZegoUIKitPrebuiltCallConfig.oneOnOneVoiceCall();
        // O layout padrão de vídeo da ZEGOCLOUD já inclui o botão de câmera:
        // cada participante pode desligar/ligar sua própria câmera durante a chamada.
        if (widget.video) {
          callConfig.turnOnCameraWhenJoining = true;
        } else {
          callConfig.turnOnCameraWhenJoining = false;
          callConfig.avatarBuilder = (context, size, zegoUser, extraInfo) {
            final participantId = zegoUser?.id ?? '';
            final photoUrl = participantId == callerUid
                ? callerPhotoUrl
                : participantId == calleeUid
                    ? calleePhotoUrl
                    : '';
            return Container(
              width: size.width,
              height: size.height,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF321846),
                image: photoUrl.isNotEmpty
                    ? DecorationImage(
                        image: NetworkImage(photoUrl),
                        fit: BoxFit.cover,
                        onError: (_, __) {},
                      )
                    : null,
              ),
              child: photoUrl.isEmpty
                  ? Icon(Icons.person, color: Colors.white70, size: size.width * 0.55)
                  : null,
            );
          };
        }

        return Scaffold(
          backgroundColor: const Color(0xFF100A19),
          body: Stack(
            children: [
              SafeArea(
                child: ZegoUIKitPrebuiltCall(
                  appID: ZegoConfig.appId,
                  appSign: ZegoConfig.appSign,
                  userID: user?.uid ?? 'anon',
                  userName: name.isEmpty ? 'LoveMix' : name,
                  callID: 'lovemix_${widget.callRef.id}',
                  config: callConfig,
                ),
              ),
              Positioned(
                top: MediaQuery.of(context).padding.top + 8,
                left: 0,
                right: 0,
                child: IgnorePointer(
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                      decoration: BoxDecoration(
                        color: const Color(0xDD160B20),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFFFF2DAB)),
                      ),
                      child: Text(
                        '⏱ $_formattedTime',
                        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
