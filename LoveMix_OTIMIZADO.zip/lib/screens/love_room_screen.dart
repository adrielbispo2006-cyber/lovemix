import 'dart:async';
import 'dart:math' as math;
import '../data/gift_catalog.dart';
import '../widgets/vip_gift_button.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:zego_uikit/zego_uikit.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:image_picker/image_picker.dart';
import 'package:zego_uikit_prebuilt_live_audio_room/zego_uikit_prebuilt_live_audio_room.dart';

import '../services/data_service.dart';
import '../services/zego_config.dart';
import '../services/supabase_service.dart';
import '../widgets/profile_frame.dart';

/// Sala de voz do LoveMix: 10 assentos (2 fileiras de 5), painel de pessoas
/// fora do microfone, chat, presentes e o baú que solta a chuva de alianças.
class LoveRoomScreen extends StatefulWidget {
  const LoveRoomScreen({super.key, required this.roomId, required this.roomName});
  final String roomId;
  final String roomName;

  @override
  State<LoveRoomScreen> createState() => _LoveRoomScreenState();
}

class _LoveRoomScreenState extends State<LoveRoomScreen> {
  static const int seatCount = 10;
  static const int defaultChestTarget = 1000;
  static const pink = Color(0xFFFF2DAB);

  static const gifts = kRoomGifts;

  final _input = TextEditingController();
  Timer? _stayPointsTimer;
  final Map<String, Future<Map<String, dynamic>>> _users = {};
  final Map<String, DateTime> _rainSeen = {};
  final Map<String, DateTime> _resultSeen = {};

  List<Map<String, dynamic>> _people = [];
  bool _showOffMic = true;
  bool _myMic = false;
  bool _left = false;
  bool _claiming = false;
  bool _voiceReady = false;
  bool _roomMembershipReady = false;
  // Alterna apenas a aparência dos assentos neste aparelho; não altera quem ocupa cada lugar.
  bool _neonSeatStyle = false;
  String _myName = 'LoveMix';
  String? _enterError;

  String get _myUid => DataService.instance.uid;

  String get _safeUserId {
    final raw = FirebaseAuth.instance.currentUser?.uid ?? 'guest';
    return raw.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '_');
  }

  @override
  void initState() {
    super.initState();
    _enter();
  }

  @override
  void dispose() {
    _stayPointsTimer?.cancel();
    _input.dispose();
    if (!_left) _cleanup(endIfHost: false);
    super.dispose();
  }

  // ---------------------------------------------------------------- entrada

  Future<void> _enter() async {
    try {
      final identity = await DataService.instance.liveIdentityDefaults();
      _myName = identity['displayName']!;
      await DataService.instance.joinRoom(widget.roomId);
      _roomMembershipReady = true;
      await DataService.instance.registerLiveParticipant(
        roomId: widget.roomId,
        publicId: identity['publicId']!,
        displayName: _myName,
      );
      _startStayPoints();
    } catch (e) {
      if (mounted) {
        setState(() => _enterError = e.toString().replaceFirst('Exception: ', ''));
      }
      return;
    }
    await _initVoice();
  }

  // Cada minuto ativo na sala soma 1 ponto à coroa da sala.
  // O incremento é atômico no Firestore para somar corretamente vários participantes.
  void _startStayPoints() {
    _stayPointsTimer?.cancel();
    _stayPointsTimer = Timer.periodic(const Duration(minutes: 1), (_) async {
      if (!mounted || _left) return;
      try {
        await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).update({
          'stayPoints': FieldValue.increment(1),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      } catch (e) {
        debugPrint('Não foi possível registrar ponto de permanência: $e');
      }
    });
  }

  Future<void> _initVoice() async {
    try {
      await ZegoUIKit.instance.init(
        appID: ZegoConfig.appId,
        appSign: ZegoConfig.appSign,
      );
      ZegoUIKit.instance.login(_safeUserId, _myName);
      await ZegoUIKit.instance.joinRoom(widget.roomId);
      if (mounted) setState(() => _voiceReady = true);
    } catch (e) {
      debugPrint('Falha ao iniciar o áudio da sala: $e');
    }
  }

  Future<void> _cleanup({required bool endIfHost}) async {
    try {
      await DataService.instance.leaveRoomSeat(widget.roomId);
    } catch (_) {}
    try {
      await DataService.instance.leaveLiveParticipant(widget.roomId);
    } catch (_) {}
    try {
      ZegoUIKit.instance.turnMicrophoneOn(false);
      await ZegoUIKit.instance.leaveRoom();
    } catch (_) {}
    if (endIfHost) {
      try {
        await DataService.instance.endLiveRoom(widget.roomId);
      } catch (_) {}
    }
  }

  Future<void> _leave({required bool isHost}) async {
    if (_left) return;
    _left = true;
    _stayPointsTimer?.cancel();
    await _cleanup(endIfHost: isHost);
  }

  // ----------------------------------------------------------------- helpers

  Future<Map<String, dynamic>> _user(String id) => _users.putIfAbsent(id, () async {
        try {
          final snap = await FirebaseFirestore.instance.collection('users').doc(id).get();
          return snap.data() ?? <String, dynamic>{};
        } catch (_) {
          return <String, dynamic>{};
        }
      });

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  String _clean(Object e) {
    if (e is FirebaseFunctionsException) return e.message ?? 'Algo deu errado.';
    return e.toString().replaceFirst('Exception: ', '');
  }

  // --------------------------------------------------------------- microfone

  Future<void> _setMic(bool on) async {
    if (on) {
      final status = await Permission.microphone.request();
      if (!status.isGranted) {
        _snack('Permita o microfone nas configurações do celular para falar.');
        return;
      }
    }
    try {
      await DataService.instance.setRoomSeatMic(widget.roomId, on);
    } catch (_) {}
    try {
      ZegoUIKit.instance.turnMicrophoneOn(on);
    } catch (e) {
      debugPrint('Falha ao alternar microfone: $e');
    }
    if (mounted) setState(() => _myMic = on);
  }

  Future<void> _onSeatTap(int number, Map<String, dynamic>? seat) async {
    final seatedUid = (seat?['uid'] ?? '').toString();
    if (seatedUid.isNotEmpty && seatedUid != _myUid) {
      _snack('Esse assento já está ocupado.');
      return;
    }
    try {
      if (seatedUid == _myUid) {
        await showModalBottomSheet<void>(
          context: context,
          backgroundColor: const Color(0xFF1B1028),
          builder: (ctx) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                leading: Icon(_myMic ? Icons.mic_off : Icons.mic, color: const Color(0xFFD85BFF)),
                title: Text(_myMic ? 'Desligar microfone' : 'Ligar microfone'),
                onTap: () {
                  Navigator.pop(ctx);
                  _setMic(!_myMic);
                },
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: Color(0xFFFF5C8A)),
                title: const Text('Sair do microfone'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _setMic(false);
                  await DataService.instance.leaveRoomSeat(widget.roomId);
                },
              ),
            ]),
          ),
        );
        return;
      }
      await DataService.instance.takeRoomSeat(widget.roomId, number);
      await _setMic(true);
    } on FirebaseException catch (e) {
      _snack(e.code == 'permission-denied'
          ? 'O Firebase bloqueou o assento. Publique as regras atualizadas do Firestore.'
          : 'Não foi possível usar o assento (${e.code}).');
    } catch (e) {
      _snack(_clean(e));
    }
  }

  // ------------------------------------------------------------------- chat

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    _input.clear();
    try {
      await DataService.instance.sendRoomMessage(widget.roomId, text);
    } catch (e) {
      _snack('Não foi possível enviar: ${_clean(e)}');
    }
  }

  // --------------------------------------------------------------- presentes

  Future<void> _openGifts(String ownerId) async {
    final targets = _people.where((p) => p['uid'] != _myUid || (_myUid == ownerId)).toList()
      ..sort((a, b) =>
          (a['uid'] == ownerId ? 0 : 1).compareTo(b['uid'] == ownerId ? 0 : 1));
    if (targets.isEmpty) {
      _snack('Ainda não há mais ninguém na sala para receber presentes.');
      return;
    }
    String recipient = targets.first['uid'].toString();
    Map<String, dynamic> chosen = gifts[1];

    final picked = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: DataService.instance.myProfile(),
          builder: (ctx, profileSnap) {
            final profile = profileSnap.data?.data() ?? <String, dynamic>{};
            final coins = (profile['coins'] as num?)?.toInt() ?? 0;
            final diamonds = (profile['diamonds'] as num?)?.toInt() ?? 0;
            final balance = chosen['currency'] == 'coins' ? coins : diamonds;
            final canAfford = balance >= (chosen['cost'] as int);
            final toHost = recipient == ownerId;
            return SafeArea(
              child: Container(
                height: MediaQuery.of(ctx).size.height * .78,
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                decoration: const BoxDecoration(
                  color: Color(0xFF160D22),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                  border: Border(top: BorderSide(color: Color(0xFFFF4FCB), width: 1.5)),
                ),
                child: Column(children: [
                  Container(
                    width: 42, height: 4,
                    decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(8)),
                  ),
                  const SizedBox(height: 12),
                  const Text('LOVEMIX PRESENTES',
                      style: TextStyle(color: Color(0xFFFF65D5), fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text(
                    toHost
                        ? '🧰 Presentes para o anfitrião enchem o baú da sala!'
                        : 'Escolha quem vai receber',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 38,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: targets.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, i) {
                        final p = targets[i];
                        final id = p['uid'].toString();
                        final active = id == recipient;
                        final name = (p['displayName'] ?? 'Pessoa').toString();
                        return ChoiceChip(
                          selected: active,
                          selectedColor: const Color(0xFF63258D),
                          backgroundColor: const Color(0xFF281638),
                          label: Text(id == ownerId ? '👑 $name' : name,
                              style: const TextStyle(color: Colors.white, fontSize: 12)),
                          onSelected: (_) => setSheet(() => recipient = id),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: _pill('🪙', '$coins moedas')),
                    const SizedBox(width: 8),
                    Expanded(child: _pill('💎', '$diamonds diamantes')),
                  ]),
                  const SizedBox(height: 10),
                  Expanded(
                    child: GridView.builder(
                      itemCount: gifts.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: .94),
                      itemBuilder: (_, i) {
                        final g = gifts[i];
                        final active = g['id'] == chosen['id'];
                        return InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => setSheet(() => chosen = g),
                          child: Container(
                            decoration: BoxDecoration(
                              color: active ? const Color(0xFF4A1B60) : const Color(0xFF261633),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: active ? const Color(0xFFFF55C9) : const Color(0xFF58356A),
                                width: active ? 2 : 1),
                            ),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Text(g['emoji'] as String, style: const TextStyle(fontSize: 32)),
                              const SizedBox(height: 4),
                              Text(g['name'] as String,
                                  maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 3),
                              Text('${g['cost']} ${g['currency'] == 'coins' ? '🪙' : '💎'}',
                                  style: const TextStyle(color: Color(0xFFFFD66B), fontSize: 10, fontWeight: FontWeight.w800)),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    width: double.infinity, height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: canAfford ? pink : Colors.white24,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: canAfford
                          ? () => Navigator.pop(ctx, {'gift': chosen, 'recipient': recipient})
                          : null,
                      child: Text(
                        canAfford ? 'Enviar ${chosen['emoji']} ${chosen['name']}' : 'Saldo insuficiente',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    );
    if (picked == null) return;
    final gift = picked['gift'] as Map<String, dynamic>;
    try {
      await DataService.instance.sendRoomGift(
        widget.roomId,
        picked['recipient'].toString(),
        gift['id'] as String,
        gift['emoji'] as String,
        gift['name'] as String,
      );
    } catch (e) {
      _snack(_clean(e));
    }
  }

  Widget _pill(String emoji, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        decoration: BoxDecoration(
          color: const Color(0xFF2B1A39),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF67417A)),
        ),
        child: Text('$emoji  $value',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
      );

  // -------------------------------------------------------------------- baú

  void _chestInfo(int points, int target) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Image.asset('assets/chest_purple.webp', width: 88, height: 76, fit: BoxFit.contain, cacheWidth: 256, cacheHeight: 220),
            const SizedBox(height: 8),
            const Text('Baú da sala',
                style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('$points / $target pontos',
                style: const TextStyle(color: Color(0xFFFFD66B), fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            const Text(
              'Quando a galera manda muitos presentes para o anfitrião, o baú enche e solta '
              'uma chuva de alianças de amigos ou de namorados. A chuva cai uma vez a cada '
              '5 dias em cada sala. Toque numa aliança antes de todo mundo: só UMA pessoa '
              'consegue pegar! 💍',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, height: 1.35),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _chestRow(int score, int points, int target) {
    final value = (points / target).clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.fromLTRB(8, 5, 14, 5),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF6A5410), Color(0xFF2E2508)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Text('👑', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 6),
            Text('$score',
                style: const TextStyle(color: Color(0xFFFFE27A), fontWeight: FontWeight.w900, fontSize: 17)),
          ]),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => _chestInfo(points, target),
          child: Row(children: [
            const Text('🧰', style: TextStyle(fontSize: 34)),
            const SizedBox(width: 6),
            SizedBox(
              width: 96,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: value),
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: v,
                      minHeight: 9,
                      backgroundColor: const Color(0xFF1A0F2B),
                      valueColor: const AlwaysStoppedAnimation(Color(0xFFFFC83D)),
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text('$points/$target',
                    style: const TextStyle(color: Colors.white60, fontSize: 9)),
              ]),
            ),
          ]),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0x33FFFFFF),
            borderRadius: BorderRadius.circular(18),
          ),
          child: const Text('💍 Chuva de alianças',
              style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
        ),
      ]),
    );
  }

  // --------------------------------------------------------------- assentos

  Widget _seatsGrid(Map<int, Map<String, dynamic>> seats, String ownerId) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 0),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: seatCount,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 5, mainAxisSpacing: 8, crossAxisSpacing: 2, childAspectRatio: .86),
      itemBuilder: (_, i) => _seat(i + 1, seats[i + 1], ownerId),
    );
  }

  Widget _seat(int number, Map<String, dynamic>? seat, String ownerId) {
    final seatedUid = (seat?['uid'] ?? '').toString();
    final occupied = seatedUid.isNotEmpty;
    final mine = seatedUid == _myUid;
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => _onSeatTap(number, seat),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        SizedBox(
          width: 62, height: 62,
          child: occupied
              ? FutureBuilder<Map<String, dynamic>>(
                  future: _user(seatedUid),
                  builder: (_, snap) {
                    final data = snap.data ?? <String, dynamic>{};
                    final micOn = seat?['micOn'] == true;
                    return Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: micOn
                              ? const [BoxShadow(color: Color(0x88FF35C8), blurRadius: 14, spreadRadius: 1)]
                              : null,
                        ),
                        child: ProfileFrameAvatar(
                          photoUrl: (data['photoUrl'] ?? '').toString(),
                          frameId: (data['selectedProfileFrame'] ?? 'classic').toString(),
                          size: 56,
                        ),
                      ),
                      if (seatedUid == ownerId)
                        const Positioned(top: -8, child: Text('👑', style: TextStyle(fontSize: 16))),
                      Positioned(
                        right: 0, bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            color: micOn ? const Color(0xFF1FBF72) : const Color(0xFF3A2A4A),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(micOn ? Icons.mic : Icons.mic_off, size: 11, color: Colors.white),
                        ),
                      ),
                    ]);
                  },
                )
              : (_neonSeatStyle ? _neonEmptySeat() : Container(
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0x33FFFFFF)),
                  child: const Icon(Icons.weekend_rounded, color: Color(0xFFE8DDF5), size: 30),
                )),
        ),
        const SizedBox(height: 4),
        occupied
            ? FutureBuilder<Map<String, dynamic>>(
                future: _user(seatedUid),
                builder: (_, snap) => Text(
                  (snap.data?['name'] ?? '...').toString().split(' ').first,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: mine ? const Color(0xFFFF8AD8) : Colors.white,
                    fontSize: 11, fontWeight: FontWeight.w700),
                ),
              )
            : const Text('Entrar', style: TextStyle(color: Colors.white70, fontSize: 11)),
      ]),
    );
  }

  Widget _neonEmptySeat() {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF542078), Color(0xFF210A3D)],
        ),
        border: Border.all(color: const Color(0xFFD52BFF), width: 2.2),
        boxShadow: const [
          BoxShadow(color: Color(0x99D52BFF), blurRadius: 13, spreadRadius: 1),
          BoxShadow(color: Color(0x554A0D80), blurRadius: 5),
        ],
      ),
      child: const Icon(Icons.add_rounded, color: Color(0xFFF3D9FF), size: 34),
    );
  }

  // ------------------------------------------------------- painel off-mic

  Widget _offMicPanel(Set<String> seatedUids) {
    final offMic = _people.where((p) => !seatedUids.contains(p['uid'])).toList();
    if (!_showOffMic) {
      return Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: ActionChip(
            backgroundColor: Colors.black,
            avatar: const Icon(Icons.people_alt_rounded, color: Colors.white70, size: 16),
            label: Text('Off-mic (${offMic.length})',
                style: const TextStyle(color: Colors.white, fontSize: 12)),
            onPressed: () => setState(() => _showOffMic = true),
          ),
        ),
      );
    }
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
      padding: const EdgeInsets.fromLTRB(12, 10, 8, 12),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF2A2236)),
      ),
      child: Column(children: [
        Row(children: [
          const SizedBox(width: 28),
          Expanded(
            child: Text('Usuários Off-mic(${offMic.length})',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
          ),
          SizedBox(
            width: 28, height: 28,
            child: IconButton(
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.close, color: Colors.white, size: 22),
              onPressed: () => setState(() => _showOffMic = false),
            ),
          ),
        ]),
        const SizedBox(height: 8),
        SizedBox(
          height: 82,
          child: offMic.isEmpty
              ? const Center(
                  child: Text('Ninguém aguardando fora do microfone.',
                      style: TextStyle(color: Colors.white54, fontSize: 12)))
              : ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: offMic.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (_, i) {
                    final p = offMic[i];
                    final id = p['uid'].toString();
                    return SizedBox(
                      width: 66,
                      child: FutureBuilder<Map<String, dynamic>>(
                        future: _user(id),
                        builder: (_, snap) {
                          final data = snap.data ?? <String, dynamic>{};
                          return Column(mainAxisSize: MainAxisSize.min, children: [
                            ProfileFrameAvatar(
                              photoUrl: (data['photoUrl'] ?? '').toString(),
                              frameId: (data['selectedProfileFrame'] ?? 'classic').toString(),
                              size: 50,
                            ),
                            const SizedBox(height: 5),
                            Text(
                              id == _myUid ? 'Você' : (p['displayName'] ?? 'Pessoa').toString(),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: id == _myUid ? const Color(0xFFFF8AD8) : Colors.white,
                                fontSize: 11, fontWeight: FontWeight.w600),
                            ),
                          ]);
                        },
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------------- chat

  Widget _tipCard() => Container(
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xCC0C0716),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFF2B2140)),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Party Dicas:', style: TextStyle(color: Color(0xFF4FD6FF), fontSize: 15)),
          SizedBox(height: 4),
          Text(
            'Fique na sala para ganhar pontos na coroa a cada minuto e mande presentes ao anfitrião para encher o baú e fazer chover alianças (1 vez a cada 5 dias)! '
            'Use fones de ouvido para evitar ecos.',
            style: TextStyle(color: Color(0xFF4FD6FF), fontSize: 13, height: 1.35),
          ),
        ]),
      );

  Widget _chatLine(Map<String, dynamic> m) {
    final type = (m['type'] ?? 'text').toString();
    final text = (m['text'] ?? '').toString();
    if (type == 'system') {
      return Container(
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: const Color(0xCC3A2A05),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFFFC83D).withValues(alpha: .6)),
        ),
        child: Text(text,
            style: const TextStyle(color: Color(0xFFFFE27A), fontSize: 13, fontWeight: FontWeight.w700)),
      );
    }
    final sender = (m['senderId'] ?? '').toString();
    final isGift = type == 'gift';
    return FutureBuilder<Map<String, dynamic>>(
      future: _user(sender),
      builder: (_, snap) {
        final name = (snap.data?['name'] ?? 'Participante').toString();
        return Container(
          margin: const EdgeInsets.only(top: 6),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xCC0C0716),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0xFF2B2140)),
          ),
          child: RichText(
            text: TextSpan(children: [
              TextSpan(
                text: isGift ? '$name enviou ' : '$name: ',
                style: const TextStyle(color: Color(0xFF4FD6FF), fontWeight: FontWeight.w900, fontSize: 14)),
              TextSpan(
                text: text,
                style: TextStyle(color: Colors.white, fontSize: isGift ? 16 : 14)),
            ]),
          ),
        );
      },
    );
  }

  Widget _chat() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.roomMessages(widget.roomId)
          .orderBy('createdAt', descending: true).limit(60).snapshots(),
      builder: (context, snap) {
        if (snap.hasError) {
          return const Center(child: Text('Não foi possível carregar o chat.',
              style: TextStyle(color: Colors.white70)));
        }
        final docs = snap.data?.docs ?? [];
        return Stack(children: [
          ListView.builder(
            reverse: true,
            padding: const EdgeInsets.fromLTRB(12, 4, 70, 8),
            itemCount: docs.length + 1,
            itemBuilder: (_, i) =>
                i == docs.length ? _tipCard() : _chatLine(docs[i].data()),
          ),
          if (docs.isNotEmpty && docs.first.data()['type'] == 'gift')
            Positioned(left: 16, right: 70, top: 4, child: IgnorePointer(child: _giftToast(docs.first))),
        ]);
      },
    );
  }

  Widget _giftToast(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final g = doc.data();
    final created = (g['createdAt'] as Timestamp?)?.toDate();
    if (created != null && DateTime.now().difference(created).inSeconds > 20) {
      return const SizedBox.shrink();
    }
    return TweenAnimationBuilder<double>(
      key: ValueKey(doc.id),
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 2400),
      builder: (_, v, child) => Opacity(
        opacity: (1 - v).clamp(0.0, 1.0),
        child: Transform.translate(offset: Offset(0, -26 * v), child: child),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF4A176D), Color(0xFFB52DAB)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFFFD36A), width: 1.4),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Text((g['emoji'] ?? '🎁').toString(), style: const TextStyle(fontSize: 32)),
          const SizedBox(width: 10),
          Flexible(
            child: Text('${g['giftName'] ?? 'Presente'} enviado!',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          ),
        ]),
      ),
    );
  }

  Widget _bottomBar(bool seated, String ownerId) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
      child: Row(children: [
        _roundBtn(
          icon: seated ? (_myMic ? Icons.mic : Icons.mic_off) : Icons.mic_none,
          active: seated && _myMic,
          onTap: () {
            if (!seated) {
              _snack('Toque em um assento "Entrar" para subir no microfone.');
            } else {
              _setMic(!_myMic);
            }
          },
        ),
        const SizedBox(width: 8),
        Expanded(
          child: TextField(
            controller: _input,
            minLines: 1, maxLines: 2,
            style: const TextStyle(color: Colors.white),
            onSubmitted: (_) => _send(),
            decoration: InputDecoration(
              hintText: 'Enviar uma mensagem..',
              hintStyle: const TextStyle(color: Colors.white54),
              filled: true,
              fillColor: const Color(0x33FFFFFF),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
              suffixIcon: IconButton(
                icon: const Icon(Icons.send_rounded, color: Color(0xFFFF65D5)),
                onPressed: _send,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        VipGiftButton(size: 46, onTap: () => _openGifts(ownerId)),
      ]),
    );
  }

  Widget _roundBtn({required IconData icon, required VoidCallback onTap, bool active = false}) =>
      Material(
        color: active ? const Color(0x66FF2DAB) : const Color(0x33FFFFFF),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(width: 46, height: 46, child: Icon(icon, color: Colors.white)),
        ),
      );

  // ------------------------------------------------------------- chuva de anel

  Widget _dropLayer() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.watchLatestDrop(widget.roomId),
      builder: (context, snap) {
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) return const SizedBox.shrink();
        final doc = docs.first;
        final d = doc.data();
        final created = (d['createdAt'] as Timestamp?)?.toDate();
        if (created == null) return const SizedBox.shrink();
        if (DateTime.now().difference(created).inSeconds > 120) return const SizedBox.shrink();
        final status = (d['status'] ?? '').toString();
        final ringName = (d['ringName'] ?? 'Aliança').toString();

        if (status == 'open') {
          if (!_rainSeen.containsKey(doc.id)) {
            _rainSeen[doc.id] = DateTime.now();
            Future<void>.delayed(const Duration(seconds: 23), () {
              if (mounted) setState(() {});
            });
          }
          if (DateTime.now().difference(_rainSeen[doc.id]!).inSeconds > 22) {
            return const SizedBox.shrink();
          }
          return _RingRain(
            label: 'Chuva de $ringName!',
            busy: _claiming,
            onTapRing: () => _claim(doc.id),
          );
        }

        if (status == 'claimed') {
          if (!_resultSeen.containsKey(doc.id)) {
            _resultSeen[doc.id] = DateTime.now();
            Future<void>.delayed(const Duration(seconds: 6), () {
              if (mounted) setState(() {});
            });
          }
          if (DateTime.now().difference(_resultSeen[doc.id]!).inSeconds > 5) {
            return const SizedBox.shrink();
          }
          final winner = (d['claimedBy'] ?? '').toString() == _myUid
              ? 'Você pegou'
              : '${d['claimedByName'] ?? 'Alguém'} pegou';
          return Align(
            alignment: const Alignment(0, -.35),
            child: IgnorePointer(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                decoration: BoxDecoration(
                  color: const Color(0xEE2A1140),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: const Color(0xFFFFD36A), width: 1.5),
                ),
                child: Text('💍 $winner a $ringName!',
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
              ),
            ),
          );
        }
        return const SizedBox.shrink();
      },
    );
  }

  Future<void> _claim(String dropId) async {
    if (_claiming) return;
    setState(() => _claiming = true);
    try {
      await DataService.instance.claimRoomDrop(widget.roomId, dropId);
      _snack('💍 Você foi o mais rápido e pegou a aliança! Veja em seus itens recebidos.');
    } catch (e) {
      _snack(_clean(e));
    } finally {
      if (mounted) setState(() => _claiming = false);
    }
  }

  // ------------------------------------------------------------------ menu

  Future<void> _manageParticipants() async {
    final roomSnap = await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).get();
    final room = roomSnap.data() ?? <String, dynamic>{};
    if (room['ownerId'] != _myUid) { _snack('Somente o dono pode gerenciar esta sala.'); return; }
    final admins = List<String>.from(room['roomAdmins'] ?? const []);
    final people = _people.where((p) => (p['uid'] ?? '').toString() != _myUid).toList();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context, backgroundColor: const Color(0xFF1B1028), isScrollControlled: true,
      builder: (ctx) => SafeArea(child: SizedBox(
        height: MediaQuery.of(ctx).size.height * .65,
        child: Column(children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('Gerenciar participantes',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
          Expanded(child: people.isEmpty
            ? const Center(child: Text('Nenhum participante para gerenciar.', style: TextStyle(color: Colors.white70)))
            : ListView.builder(itemCount: people.length, itemBuilder: (_, i) {
              final person = people[i];
              final id = (person['uid'] ?? '').toString();
              final name = (person['displayName'] ?? 'Participante').toString();
              final isAdmin = admins.contains(id);
              return ListTile(
                leading: CircleAvatar(backgroundColor: const Color(0xFF7027A5), child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?')),
                title: Text(name, style: const TextStyle(color: Colors.white)),
                subtitle: Text(isAdmin ? 'Administrador da sala' : 'Participante', style: const TextStyle(color: Colors.white60)),
                trailing: PopupMenuButton<String>(
                  color: const Color(0xFF30203F),
                  onSelected: (action) async {
                    Navigator.pop(ctx);
                    try {
                      if (action == 'admin') {
                        await DataService.instance.setRoomAdmin(widget.roomId, id, !isAdmin);
                        _snack(isAdmin ? '$name não é mais administrador.' : '$name agora é administrador.');
                      } else if (action == 'kick') {
                        final confirmed = await showDialog<bool>(context: context, builder: (dctx) => AlertDialog(
                          backgroundColor: const Color(0xFF241331),
                          title: const Text('Expulsar participante?', style: TextStyle(color: Colors.white)),
                          content: Text('Deseja remover $name desta sala?', style: const TextStyle(color: Colors.white70)),
                          actions: [TextButton(onPressed: () => Navigator.pop(dctx, false), child: const Text('Cancelar')),
                            TextButton(onPressed: () => Navigator.pop(dctx, true), child: const Text('Expulsar'))],
                        ));
                        if (confirmed == true) {
                          await DataService.instance.kickRoomMember(widget.roomId, id);
                          _snack('$name foi removido da sala.');
                        }
                      }
                    } catch (e) { _snack('Não foi possível concluir: ${_clean(e)}'); }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'admin', child: Text(isAdmin ? 'Remover administrador' : 'Tornar administrador')),
                    const PopupMenuItem(value: 'kick', child: Text('Expulsar da sala')),
                  ],
                ),
              );
            })),
        ]),
      )),
    );
  }

  Future<void> _wallpaperOptions(Map<String, dynamic> room) async {
    final currentType = (room['wallpaperType'] ?? 'original').toString();
    final currentUrl = (room['wallpaperUrl'] ?? '').toString();
    if (room['ownerId']?.toString() != _myUid) {
      _snack('Somente o dono da sala pode trocar o papel de parede.');
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Papel de parede da sala', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            _wallpaperChoice(ctx, 'original', 'Original LoveMix', Icons.gradient, currentType == 'original'),
            _wallpaperChoice(ctx, 'royal', '👑 Realeza — roxo e dourado', Icons.workspace_premium, currentType == 'royal'),
            _wallpaperChoice(ctx, 'galaxy', '🌌 Galáxia — estrelas neon', Icons.nights_stay, currentType == 'galaxy'),
            _wallpaperChoice(ctx, 'luxury', '💛 Luxo — preto e dourado', Icons.diamond, currentType == 'luxury'),
            _wallpaperChoice(ctx, 'romantic', '💗 Romântica — corações neon', Icons.favorite, currentType == 'romantic'),
            _wallpaperChoice(ctx, 'love_luxury', '💜 Sala Luxo LoveMix — sofás, palco e baú central', Icons.weekend_rounded, currentType == 'love_luxury'),
            _wallpaperChoice(ctx, 'chest', 'Baú mágico roxo', Icons.auto_awesome, currentType == 'chest'),
            _wallpaperChoice(ctx, 'neon', 'Neon roxo e rosa', Icons.brightness_7, currentType == 'neon'),
            if (currentUrl.isNotEmpty)
              _wallpaperChoice(ctx, 'custom', 'Imagem personalizada atual', Icons.image, currentType == 'custom'),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(
              icon: const Icon(Icons.photo_library_outlined), label: const Text('Escolher imagem da galeria'),
              onPressed: () async {
                Navigator.pop(ctx);
                await _pickRoomWallpaper();
              },
            )),
            SizedBox(width: double.infinity, child: ElevatedButton.icon(
              icon: const Icon(Icons.check), label: const Text('Restaurar fundo original'),
              onPressed: () async {
                Navigator.pop(ctx);
                await _saveRoomWallpaper('original', '');
              },
            )),
          ]),
        ),
      ),
    );
  }

  Widget _wallpaperChoice(BuildContext ctx, String type, String label, IconData icon, bool selected) {
    return ListTile(
      leading: Icon(icon, color: const Color(0xFFE879FF)),
      title: Text(label, style: const TextStyle(color: Colors.white)),
      trailing: selected ? const Icon(Icons.check_circle, color: Color(0xFFFF2DAB)) : null,
      onTap: () async {
        Navigator.pop(ctx);
        await _saveRoomWallpaper(type, type == 'custom' ? null : '');
      },
    );
  }

  Future<void> _saveRoomWallpaper(String type, String? url) async {
    try {
      final update = <String, dynamic>{
        'wallpaperType': type,
        'wallpaperUpdatedAt': FieldValue.serverTimestamp(),
        'wallpaperUpdatedBy': _myUid,
      };
      if (url != null) update['wallpaperUrl'] = url;
      await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).update(update);
      _snack('Papel de parede aplicado para todos na sala.');
    } catch (e) {
      _snack('Não foi possível trocar o papel de parede: ${_clean(e)}');
    }
  }

  Future<void> _pickRoomWallpaper() async {
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 76, maxWidth: 1280);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.length > 4 * 1024 * 1024) {
        _snack('Escolha uma imagem de até 4 MB.');
        return;
      }
      final ext = picked.name.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'room_wallpapers/${widget.roomId}/${DateTime.now().millisecondsSinceEpoch}.$ext',
        bytes: bytes,
        contentType: ext == 'png' ? 'image/png' : 'image/jpeg',
      );
      await _saveRoomWallpaper('custom', url);
    } catch (e) {
      _snack('Não foi possível enviar a imagem: ${_clean(e)}');
    }
  }

  BoxDecoration _roomBackground(Map<String, dynamic> room) {
    final type = (room['wallpaperType'] ?? 'original').toString();
    final url = (room['wallpaperUrl'] ?? '').toString();
    if (type == 'chest') {
      return const BoxDecoration(
        image: DecorationImage(image: AssetImage('assets/chest_purple.webp'), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Color(0xAA1A0838), BlendMode.darken)),
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFF3A1070), Color(0xFF1A0838), Color(0xFF0E0420)]),
      );
    }
    if (type == 'custom' && url.isNotEmpty) {
      return BoxDecoration(
        image: DecorationImage(image: NetworkImage(url), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Color(0xAA1A0838), BlendMode.darken)),
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFF3A1070), Color(0xFF1A0838), Color(0xFF0E0420)]),
      );
    }
    if (type == 'love_luxury') {
      return const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: [Color(0xFF25003F), Color(0xFF10051F), Color(0xFF05020D), Color(0xFF21002F)]),
      );
    }
    if (type == 'royal') {
      return const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF6D3A08), Color(0xFF32105F), Color(0xFF10051F), Color(0xFF4A1769)]));
    }
    if (type == 'galaxy') {
      return const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF071B52), Color(0xFF32106B), Color(0xFF090018), Color(0xFF4B176D)]));
    }
    if (type == 'luxury') {
      return const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomRight,
        colors: [Color(0xFF49320B), Color(0xFF17130B), Color(0xFF050505), Color(0xFF30200A)]));
    }
    if (type == 'romantic') {
      return const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF8B145E), Color(0xFF45106D), Color(0xFF170626), Color(0xFF6A164D)]));
    }
    if (type == 'neon') {
      return const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF5B0A91), Color(0xFF250044), Color(0xFF090018), Color(0xFF7A075E)]));
    }
    return const BoxDecoration(gradient: LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: [Color(0xFF3A1070), Color(0xFF1A0838), Color(0xFF0E0420)],
    ));
  }

  Widget _roomThemeOverlay(String type) {
    if (type == 'love_luxury') return _loveLuxuryRoomOverlay();
    final symbols = switch (type) {
      'royal' => const ['👑', '✦', '♛', '✧', '👑'],
      'galaxy' => const ['✦', '🌙', '✧', '星', '✦'],
      'luxury' => const ['✧', '◆', '♛', '✦', '◆'],
      'romantic' => const ['♥', '♡', '💗', '✧', '♥'],
      _ => const <String>[],
    };
    if (symbols.isEmpty) return const SizedBox.shrink();
    final color = type == 'luxury' || type == 'royal'
        ? const Color(0x66FFD36A)
        : type == 'romantic'
            ? const Color(0x66FF83D0)
            : const Color(0x66B7A2FF);
    return IgnorePointer(child: Stack(children: [
      Positioned(top: 76, right: 18, child: Text(symbols[0], style: TextStyle(fontSize: 35, color: color))),
      Positioned(top: 210, left: 12, child: Text(symbols[1], style: TextStyle(fontSize: 24, color: color))),
      Positioned(bottom: 150, right: 22, child: Text(symbols[2], style: TextStyle(fontSize: 30, color: color))),
      Positioned(bottom: 75, left: 24, child: Text(symbols[3], style: TextStyle(fontSize: 22, color: color))),
      Positioned(top: 390, right: 62, child: Text(symbols[4], style: TextStyle(fontSize: 18, color: color))),
    ]));
  }

  // Decoração completa da sala: cenário visual atrás dos assentos e controles.
  // Os elementos são ignoráveis ao toque para não bloquear os assentos reais.
  Widget _loveLuxuryRoomOverlay() {
    return IgnorePointer(
      child: LayoutBuilder(builder: (context, constraints) {
        final w = constraints.maxWidth;
        final h = constraints.maxHeight;
        final neon = const Color(0xFFD83BFF);
        Widget sofa({required double width}) => Container(
          width: width,
          height: 54,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF54206E), Color(0xFF1C0B2B)]),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFB83CFF), width: 1.4),
            boxShadow: const [BoxShadow(color: Color(0x887D18C7), blurRadius: 15)],
          ),
          child: const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            Icon(Icons.weekend_rounded, color: Color(0xFFE9B8FF), size: 27),
            Icon(Icons.favorite, color: Color(0xFFCE69FF), size: 17),
            Icon(Icons.weekend_rounded, color: Color(0xFFE9B8FF), size: 27),
          ]),
        );
        return Stack(children: [
          // Moldura luminosa da parede.
          Positioned(left: 10, right: 10, top: h * .145, height: h * .30,
            child: Container(decoration: BoxDecoration(
              border: Border.all(color: neon.withOpacity(.55), width: 2),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [BoxShadow(color: neon.withOpacity(.20), blurRadius: 18)],
              gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Color(0x442D0648), Color(0x11000000)]),
            ))),
          Positioned(top: h * .205, left: 0, right: 0,
            child: Column(children: [
              const Text('👑', style: TextStyle(fontSize: 27)),
              Text('LoveMix', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900,
                color: Colors.white, letterSpacing: 1.2,
                shadows: [Shadow(color: neon, blurRadius: 18), Shadow(color: neon, blurRadius: 30)])),
              const Text('♡     ✦     ♡', style: TextStyle(color: Color(0xFFFF75E5), fontSize: 18)),
            ])),
          // Sofás laterais e almofadas.
          Positioned(left: 8, top: h * .39, child: sofa(width: w * .36)),
          Positioned(right: 8, top: h * .39, child: sofa(width: w * .36)),
          Positioned(left: 5, top: h * .48, child: const Text('🌿', style: TextStyle(fontSize: 29))),
          Positioned(right: 5, top: h * .48, child: const Text('🌿', style: TextStyle(fontSize: 29))),
          // Palco circular central e baú decorativo.
          Positioned(left: w * .19, right: w * .19, top: h * .51, height: h * .15,
            child: Container(decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              gradient: const RadialGradient(colors: [Color(0x665F1A83), Color(0x22100020), Color(0x00100020)]),
              border: Border.all(color: neon.withOpacity(.72), width: 2),
              boxShadow: [BoxShadow(color: neon.withOpacity(.35), blurRadius: 22)],
            ))),
          Positioned(top: h * .505, left: 0, right: 0,
            child: Center(child: Image.asset('assets/chest_purple.webp', width: w * .29,
              height: h * .13, fit: BoxFit.contain, cacheWidth: 320, cacheHeight: 280,
              errorBuilder: (_, __, ___) => const Text('🧰', style: TextStyle(fontSize: 54))))),
          Positioned(top: h * .665, left: 0, right: 0,
            child: Center(child: Container(width: w * .68, height: 7,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                color: neon.withOpacity(.45), boxShadow: [BoxShadow(color: neon, blurRadius: 15)])))),
          // Pontos de luz e detalhes de teto.
          Positioned(top: h * .16, left: w * .13, child: Text('✦', style: TextStyle(color: neon, fontSize: 25, shadows: [Shadow(color: neon, blurRadius: 12)]))),
          Positioned(top: h * .17, right: w * .13, child: Text('✦', style: TextStyle(color: neon, fontSize: 25, shadows: [Shadow(color: neon, blurRadius: 12)]))),
          Positioned(top: h * .35, left: w * .45, child: const Text('💜', style: TextStyle(fontSize: 18))),
          Positioned(bottom: h * .12, left: 14, child: Text('✧', style: TextStyle(color: neon.withOpacity(.6), fontSize: 22))),
          Positioned(bottom: h * .12, right: 14, child: Text('✧', style: TextStyle(color: neon.withOpacity(.6), fontSize: 22))),
        ]);
      }),
    );
  }

  void _menu(bool isHost, bool locked) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: Icon(_neonSeatStyle ? Icons.weekend_rounded : Icons.add_circle_outline,
                color: const Color(0xFFD85BFF)),
            title: Text(_neonSeatStyle ? 'Voltar aos assentos tradicionais' : 'Trocar para assentos neon'),
            subtitle: Text(_neonSeatStyle
                ? 'Mostrar os assentos no formato atual'
                : 'Mostrar círculos roxos com botão de entrar'),
            onTap: () {
              Navigator.pop(ctx);
              if (mounted) {
                setState(() => _neonSeatStyle = !_neonSeatStyle);
                _snack(_neonSeatStyle ? 'Assentos neon ativados.' : 'Assentos tradicionais ativados.');
              }
            },
          ),
          const Divider(color: Colors.white12, height: 1),
          if (isHost)
            ListTile(
              leading: const Icon(Icons.wallpaper, color: Color(0xFFD85BFF)),
              title: const Text('Papel de parede da sala', style: TextStyle(color: Colors.white)),
              subtitle: const Text('Escolher fundo para todos os participantes', style: TextStyle(color: Colors.white60, fontSize: 11)),
              onTap: () {
                Navigator.pop(ctx);
                final currentRoom = FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).get();
                currentRoom.then((snap) { if (mounted && snap.exists) _wallpaperOptions(snap.data() ?? {}); });
              },
            ),
          if (isHost)
            const Divider(color: Colors.white12, height: 1),
          if (isHost)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings, color: Color(0xFFD85BFF)),
              title: const Text('Gerenciar participantes e administradores'),
              onTap: () { Navigator.pop(ctx); _manageParticipants(); },
            ),
          if (isHost)
            ListTile(
              leading: Icon(locked ? Icons.lock_open : Icons.lock, color: const Color(0xFFD85BFF)),
              title: Text(locked ? 'Liberar entrada na sala' : 'Bloquear novas entradas'),
              onTap: () async {
                Navigator.pop(ctx);
                try {
                  await FirebaseFirestore.instance
                      .collection('rooms').doc(widget.roomId).update({'isLocked': !locked});
                } catch (e) {
                  _snack('Não foi possível alterar o bloqueio: ${_clean(e)}');
                }
              },
            ),
          ListTile(
            leading: const Icon(Icons.logout, color: Color(0xFFFF5C8A)),
            title: Text(isHost ? 'Encerrar sala' : 'Sair da sala'),
            onTap: () async {
              Navigator.pop(ctx);
              await _leave(isHost: isHost);
              if (mounted) Navigator.pop(context);
            },
          ),
        ]),
      ),
    );
  }

  // ----------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    if (_enterError != null) {
      return Scaffold(
        backgroundColor: const Color(0xFF12062A),
        appBar: AppBar(backgroundColor: Colors.transparent),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Text(_enterError!, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 16)),
          ),
        ),
      );
    }

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).snapshots(),
      builder: (context, roomSnap) {
        final room = roomSnap.data?.data() ?? <String, dynamic>{};
        if (_roomMembershipReady && roomSnap.hasData && roomSnap.data!.exists &&
            !List<String>.from(room['members'] ?? const []).contains(_myUid) && !_left) {
          WidgetsBinding.instance.addPostFrameCallback((_) async {
            if (!mounted || _left) return;
            _left = true;
            _stayPointsTimer?.cancel();
            await _cleanup(endIfHost: false);
            if (mounted) { _snack('Você foi removido desta sala pelo anfitrião.'); Navigator.pop(context); }
          });
        }
        final ownerId = (room['ownerId'] ?? '').toString();
        final isHost = ownerId == _myUid;
        final locked = room['isLocked'] == true;
        final points = (room['chestPoints'] as num?)?.toInt() ?? 0;
        final target = (room['chestTarget'] as num?)?.toInt() ?? defaultChestTarget;
        final giftScore = (room['giftScore'] as num?)?.toInt() ?? 0;
        final stayScore = (room['stayPoints'] as num?)?.toInt() ?? 0;
        final score = giftScore + stayScore;
        final roomName = (room['name'] ?? widget.roomName).toString();

        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, _) async {
            if (didPop) return;
            await _leave(isHost: isHost);
            if (context.mounted) Navigator.pop(context);
          },
          child: Scaffold(
            resizeToAvoidBottomInset: true,
            body: Container(
              decoration: _roomBackground(room),
              child: SafeArea(
                child: Stack(children: [
                  Positioned.fill(child: _roomThemeOverlay((room['wallpaperType'] ?? 'original').toString())),
                  Column(children: [
                    // Cabeçalho
                    Padding(
                      padding: const EdgeInsets.fromLTRB(4, 4, 8, 0),
                      child: Row(children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () async {
                            await _leave(isHost: isHost);
                            if (context.mounted) Navigator.pop(context);
                          },
                        ),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(roomName,
                                maxLines: 1, overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                            FutureBuilder<Map<String, dynamic>>(
                              future: ownerId.isEmpty
                                  ? Future.value(<String, dynamic>{})
                                  : _user(ownerId),
                              builder: (context, ownerSnap) {
                                final ownerPublicId =
                                    (ownerSnap.data?['publicId'] ?? '').toString();
                                return GestureDetector(
                                  onTap: ownerPublicId.isEmpty
                                      ? null
                                      : () {
                                          Clipboard.setData(ClipboardData(text: ownerPublicId));
                                          _snack('ID copiado.');
                                        },
                                  child: Row(children: [
                                    Text('ID: ${ownerPublicId.isEmpty ? '...' : ownerPublicId}',
                                        style: const TextStyle(color: Colors.white60, fontSize: 11)),
                                    const SizedBox(width: 4),
                                    const Icon(Icons.copy_rounded, size: 11, color: Colors.white60),
                                    if (!_voiceReady) ...[
                                      const SizedBox(width: 8),
                                      const Text('conectando áudio…',
                                          style: TextStyle(color: Color(0xFFFFC83D), fontSize: 10)),
                                    ],
                                  ]),
                                );
                              },
                            ),
                          ]),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: const Color(0x33FFFFFF), borderRadius: BorderRadius.circular(18)),
                          child: Text('${_people.length}',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        ),
                        IconButton(
                          icon: const Icon(Icons.more_horiz, color: Colors.white),
                          onPressed: () => _menu(isHost, locked),
                        ),
                      ]),
                    ),
                    _chestRow(score, points, target),
                    // Assentos + painel off-mic
                    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: DataService.instance.watchRoomSeats(widget.roomId),
                      builder: (context, seatSnap) {
                        final seats = <int, Map<String, dynamic>>{};
                        for (final doc in seatSnap.data?.docs ?? []) {
                          final n = (doc.data()['seatNumber'] as num?)?.toInt() ?? int.tryParse(doc.id) ?? 0;
                          if (n >= 1 && n <= seatCount) seats[n] = doc.data();
                        }
                        final seatedUids = seats.values.map((s) => (s['uid'] ?? '').toString()).toSet();
                        final seated = seatedUids.contains(_myUid);
                        // Se o assento foi liberado por fora, garante microfone desligado.
                        if (!seated && _myMic) {
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            if (mounted && _myMic) {
                              _myMic = false;
                              ZegoUIKit.instance.turnMicrophoneOn(false);
                              setState(() {});
                            }
                          });
                        }
                        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                          stream: DataService.instance.watchLiveParticipants(widget.roomId),
                          builder: (context, pSnap) {
                            _people = (pSnap.data?.docs ?? []).map((d) => d.data()).toList();
                            return Expanded(
                              child: Column(children: [
                                _seatsGrid(seats, ownerId),
                                _offMicPanel(seatedUids),
                                Expanded(child: _chat()),
                                _bottomBar(seated, ownerId),
                              ]),
                            );
                          },
                        );
                      },
                    ),
                  ]),
                  Positioned.fill(child: _dropLayer()),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Chuva de alianças: várias alianças caindo; tocar em qualquer uma tenta pegar.
class _RingRain extends StatefulWidget {
  const _RingRain({required this.label, required this.onTapRing, required this.busy});
  final String label;
  final VoidCallback onTapRing;
  final bool busy;

  @override
  State<_RingRain> createState() => _RingRainState();
}

class _RingSpec {
  _RingSpec(math.Random r)
      : x = .02 + r.nextDouble() * .86,
        phase = r.nextDouble(),
        speed = r.nextInt(3) == 0 ? 2 : 1,
        sway = 1 + r.nextInt(2),
        size = 34 + r.nextDouble() * 22;
  final double x;
  final double phase;
  final int speed;
  final int sway;
  final double size;
}

class _RingRainState extends State<_RingRain> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final List<_RingSpec> _rings;

  @override
  void initState() {
    super.initState();
    final r = math.Random();
    _rings = List.generate(16, (_) => _RingSpec(r));
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final w = box.maxWidth;
      final h = box.maxHeight;
      return AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Stack(children: [
            for (final ring in _rings)
              Positioned(
                left: ring.x * (w - 60) +
                    math.sin((_c.value * ring.sway + ring.phase) * 2 * math.pi) * 14,
                top: ((_c.value * ring.speed + ring.phase) % 1.0) * (h + 90) - 70,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: widget.busy ? null : widget.onTapRing,
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text('💍',
                        style: TextStyle(fontSize: ring.size, shadows: const [
                          Shadow(color: Color(0xCCFFD36A), blurRadius: 16),
                        ])),
                  ),
                ),
              ),
            Positioned(
              top: 64, left: 24, right: 24,
              child: IgnorePointer(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: const Color(0xDD2A1140),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFFFD36A)),
                  ),
                  child: Text('🧰 ${widget.label}  Toque numa aliança!',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                ),
              ),
            ),
          ]);
        },
      );
    });
  }
}
