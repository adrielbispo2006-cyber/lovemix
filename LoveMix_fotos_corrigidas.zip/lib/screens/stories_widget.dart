import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../services/data_service.dart';

const _storyPink = Color(0xFFFF19B8);
const _storyPurple = Color(0xFF8D35FF);

class StoriesStrip extends StatefulWidget {
  const StoriesStrip({super.key});
  @override
  State<StoriesStrip> createState() => _StoriesStripState();
}

class _StoriesStripState extends State<StoriesStrip> {
  bool uploading = false;
  Future<void> _addStory() async {
    if (uploading) return;
    final choice = await showModalBottomSheet<String>(context: context, backgroundColor: const Color(0xFF171022), builder: (ctx) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.photo, color: _storyPink), title: const Text('Story com foto'), onTap: () => Navigator.pop(ctx, 'image')),
      ListTile(leading: const Icon(Icons.videocam, color: _storyPink), title: const Text('Story com vídeo'), onTap: () => Navigator.pop(ctx, 'video')),
      const Padding(padding: EdgeInsets.fromLTRB(16, 4, 16, 12), child: Text('Nudez e conteúdo sexual não são permitidos e são removidos automaticamente.', style: TextStyle(fontSize: 12, color: Colors.white54))),
    ])));
    if (choice == null) return;
    try {
      final picker = ImagePicker();
      final XFile? file = choice == 'image'
          ? await picker.pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1440)
          : await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 30));
      if (file == null) return;
      setState(() => uploading = true);
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final isImage = choice == 'image';
      // Lê os bytes direto do XFile (mais confiável que putFile no Android,
      // onde o caminho do picker pode não ser um arquivo acessível).
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty) throw 'o arquivo selecionado está vazio';
      final maxBytes = 30 * 1024 * 1024;
      if (bytes.length >= maxBytes) throw 'o arquivo passa de 30 MB';
      final lowerName = file.name.toLowerCase();
      final String ext;
      final String contentType;
      if (isImage) {
        if (lowerName.endsWith('.png')) { ext = 'png'; contentType = 'image/png'; }
        else if (lowerName.endsWith('.webp')) { ext = 'webp'; contentType = 'image/webp'; }
        else { ext = 'jpg'; contentType = 'image/jpeg'; }
      } else {
        if (lowerName.endsWith('.mov')) { ext = 'mov'; contentType = 'video/quicktime'; }
        else { ext = 'mp4'; contentType = 'video/mp4'; }
      }
      final ref = FirebaseStorage.instance.ref('stories/$uid/${DateTime.now().millisecondsSinceEpoch}.$ext');
      final snapshot = await ref.putData(bytes, SettableMetadata(contentType: contentType));
      if (snapshot.state != TaskState.success) throw 'falha no envio da mídia';
      final url = await snapshot.ref.getDownloadURL();
      final profile = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      await FirebaseFirestore.instance.collection('stories').add({
        'ownerId': uid, 'name': profile.data()?['name'] ?? 'Pessoa',
        'photoUrl': profile.data()?['photoUrl'] ?? '', 'mediaUrl': url,
        'mediaType': choice, 'createdAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Story publicado por 24 horas!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível publicar: $e')));
    } finally { if (mounted) setState(() => uploading = false); }
  }

  @override
  Widget build(BuildContext context) => SizedBox(height: 104, child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance.collection('stories').where('expiresAt', isGreaterThan: Timestamp.now()).orderBy('expiresAt').snapshots(),
    builder: (context, snap) {
      final docs = snap.data?.docs ?? [];
      final grouped = <String, List<QueryDocumentSnapshot<Map<String, dynamic>>>>{};
      for (final d in docs) { final id = (d.data()['ownerId'] ?? '').toString(); if (id.isNotEmpty) (grouped[id] ??= []).add(d); }
      final myUid = FirebaseAuth.instance.currentUser?.uid;
      List<QueryDocumentSnapshot<Map<String, dynamic>>> sorted(List<QueryDocumentSnapshot<Map<String, dynamic>>> l) {
        final c = [...l];
        c.sort((a, b) {
          final ta = a.data()['createdAt'], tb = b.data()['createdAt'];
          if (ta is Timestamp && tb is Timestamp) return ta.compareTo(tb);
          return 0;
        });
        return c;
      }
      void open(List<QueryDocumentSnapshot<Map<String, dynamic>>> l) =>
          Navigator.push(context, MaterialPageRoute(builder: (_) => StoryViewer(stories: sorted(l))));
      final mine = myUid == null ? null : grouped[myUid];
      final hasMine = mine != null && mine.isNotEmpty;
      return ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
        _bubble('Seu story', hasMine ? (mine!.first.data()['photoUrl'] ?? '').toString() : '',
            own: true, hasStory: hasMine, onTap: hasMine ? () => open(mine!) : _addStory, onAdd: _addStory),
        ...grouped.entries.where((e) => e.key != myUid).map((entry) {
          final first = entry.value.first.data();
          return _bubble((first['name'] ?? 'Pessoa').toString(), (first['photoUrl'] ?? '').toString(), hasStory: true, onTap: () => open(entry.value));
        }),
      ]);
    },
  ));

  Widget _bubble(String name, String photo, {bool own = false, bool hasStory = false, required VoidCallback onTap, VoidCallback? onAdd}) => GestureDetector(onTap: onTap, child: SizedBox(width: 76, child: Column(children: [
    Stack(clipBehavior: Clip.none, children: [
      Container(width: 66, height: 66, padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(shape: BoxShape.circle,
          border: own && !hasStory ? Border.all(color: _storyPink, width: 2) : null,
          gradient: own && !hasStory ? null : const LinearGradient(colors: [_storyPink, _storyPurple])),
        child: ClipOval(child: photo.isEmpty ? Container(color: const Color(0xFF241333), child: Icon(own && !hasStory ? Icons.add : Icons.person, color: Colors.white, size: 28)) : Image.network(photo, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.person)))),
      if (own && hasStory) Positioned(right: -2, bottom: -2, child: GestureDetector(onTap: onAdd, child: Container(width: 24, height: 24, decoration: BoxDecoration(color: _storyPink, shape: BoxShape.circle, border: Border.all(color: const Color(0xFF0B0713), width: 2)), child: const Icon(Icons.add, color: Colors.white, size: 16)))),
    ]),
    const SizedBox(height: 4), Text(uploading && own ? 'Enviando...' : name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
  ])));
}

class StoryViewer extends StatefulWidget {
  const StoryViewer({super.key, required this.stories});
  final List<QueryDocumentSnapshot<Map<String, dynamic>>> stories;
  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

String _timeAgo(dynamic ts) {
  if (ts is! Timestamp) return 'agora';
  final d = DateTime.now().difference(ts.toDate());
  if (d.inMinutes < 1) return 'agora';
  if (d.inMinutes < 60) return 'há ${d.inMinutes} min';
  if (d.inHours < 24) return 'há ${d.inHours} h';
  return 'há ${d.inDays} d';
}

class _StoryViewerState extends State<StoryViewer> {
  late final List<QueryDocumentSnapshot<Map<String, dynamic>>> stories = [...widget.stories];
  int index = 0;
  VideoPlayerController? video;
  Timer? timer;
  Timer? ticker;
  bool advancing = false;

  @override
  void initState() {
    super.initState();
    // atualiza o "há X min" enquanto o story está aberto
    ticker = Timer.periodic(const Duration(seconds: 20), (_) { if (mounted) setState(() {}); });
    _loadStory();
  }

  Future<void> _loadStory() async {
    timer?.cancel();
    advancing = false;
    final old = video; video = null;
    await old?.dispose();
    if (!mounted) return;
    final data = stories[index].data();
    if (data['mediaType'] == 'video') {
      try {
        final c = VideoPlayerController.networkUrl(Uri.parse((data['mediaUrl'] ?? '').toString()));
        video = c;
        await c.initialize();
        if (!mounted || video != c) return;
        c.addListener(() {
          final v = c.value;
          if (mounted && video == c && !advancing && v.isInitialized && v.duration > Duration.zero && v.position >= v.duration) { advancing = true; _next(); }
        });
        await c.play();
        if (mounted) setState(() {});
      } catch (_) {
        // vídeo não carregou: passa para o próximo depois de alguns segundos
        timer = Timer(const Duration(seconds: 3), _next);
      }
    } else {
      timer = Timer(const Duration(seconds: 5), _next);
    }
  }

  void _next() {
    if (!mounted) return;
    if (index + 1 >= stories.length) { Navigator.pop(context); return; }
    setState(() => index++);
    _loadStory();
  }

  void _prev() {
    if (index == 0) { _loadStory(); return; }
    setState(() => index--);
    _loadStory();
  }

  void _resume() {
    final c = video;
    if (c != null && c.value.isInitialized) { c.play(); } else { _loadStory(); }
  }

  Future<void> _deleteCurrent() async {
    timer?.cancel();
    await video?.pause();
    if (!mounted) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF171022),
      title: const Text('Apagar story?'),
      content: const Text('Ele será removido para todos e não poderá ser recuperado.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar', style: TextStyle(color: Colors.redAccent))),
      ],
    ));
    if (ok != true) { if (mounted) _resume(); return; }
    final doc = stories[index];
    final url = (doc.data()['mediaUrl'] ?? '').toString();
    try {
      await doc.reference.delete();
    } catch (e) {
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar: $e'))); _resume(); }
      return;
    }
    // remove também o arquivo (se falhar, o story já saiu do ar)
    try { if (url.isNotEmpty) await FirebaseStorage.instance.refFromURL(url).delete(); } catch (_) {}
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Story apagado.')));
    stories.removeAt(index);
    if (stories.isEmpty) { Navigator.pop(context); return; }
    if (index >= stories.length) index = stories.length - 1;
    setState(() {});
    _loadStory();
  }

  @override
  void dispose() { timer?.cancel(); ticker?.cancel(); video?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final data = stories[index].data(); final isVideo = data['mediaType'] == 'video';
    final isOwner = (data['ownerId'] ?? '') == FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(backgroundColor: Colors.black, body: SafeArea(child: Stack(fit: StackFit.expand, children: [
      Center(child: isVideo ? (video?.value.isInitialized == true ? AspectRatio(aspectRatio: video!.value.aspectRatio, child: VideoPlayer(video!)) : const CircularProgressIndicator(color: _storyPink)) : Image.network((data['mediaUrl'] ?? '').toString(), key: ValueKey(stories[index].id), fit: BoxFit.contain, loadingBuilder: (c, child, p) => p == null ? child : const Center(child: CircularProgressIndicator(color: _storyPink)), errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white))),
      Positioned.fill(top: 90, child: Row(children: [
        Expanded(flex: 1, child: GestureDetector(behavior: HitTestBehavior.translucent, onTap: _prev)),
        Expanded(flex: 2, child: GestureDetector(behavior: HitTestBehavior.translucent, onTap: _next)),
      ])),
      Positioned(top: 12, left: 12, right: 4, child: Row(children: [
        Expanded(child: Row(children: [for (var i = 0; i < stories.length; i++) Expanded(child: Container(height: 3, margin: const EdgeInsets.symmetric(horizontal: 2), decoration: BoxDecoration(color: i <= index ? _storyPink : Colors.white24, borderRadius: BorderRadius.circular(2))))])),
        const SizedBox(width: 4),
        if (isOwner) IconButton(tooltip: 'Apagar story', onPressed: _deleteCurrent, icon: const Icon(Icons.delete_outline, color: Colors.white)),
        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, color: Colors.white)),
      ])),
      Positioned(top: 58, left: 16, child: Row(children: [
        Text((data['name'] ?? 'Story').toString(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, shadows: [Shadow(blurRadius: 4, color: Colors.black54)])),
        const SizedBox(width: 8),
        Text(_timeAgo(data['createdAt']), style: const TextStyle(color: Colors.white70, fontSize: 12, shadows: [Shadow(blurRadius: 4, color: Colors.black54)])),
      ])),
    ])));
  }
}
