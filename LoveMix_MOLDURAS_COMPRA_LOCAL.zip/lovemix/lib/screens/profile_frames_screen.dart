import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../widgets/profile_frame.dart';

class ProfileFramesScreen extends StatefulWidget {
  const ProfileFramesScreen({super.key});
  @override
  State<ProfileFramesScreen> createState() => _ProfileFramesScreenState();
}

class _ProfileFramesScreenState extends State<ProfileFramesScreen> {
  static const _pink = Color(0xFFFF19B8);
  static const _purple = Color(0xFF8D35FF);
  bool busy = false;
  bool localReady = false;
  bool localLoading = false;
  List<String> localOwned = ['classic'];
  String localSelected = 'classic';
  int localCoins = 200;
  int localDiamonds = 0;
  bool localVip = false;
  String? localUid;

  String _key(String name) => 'lovemix_frames_${localUid ?? 'guest'}_$name';

  Future<void> _loadLocal(Map<String, dynamic> profile, String uid) async {
    if (localUid == uid && (localReady || localLoading)) return;
    localUid = uid;
    localLoading = true;
    final prefs = await SharedPreferences.getInstance();
    // Importa o saldo/perfil atual apenas na primeira abertura. Depois disso,
    // compras e molduras são mantidas exclusivamente no armazenamento local.
    if (!prefs.containsKey(_key('initialized'))) {
      await prefs.setStringList(_key('owned'), ['classic']);
      await prefs.setString(_key('selected'), 'classic');
      await prefs.setInt(_key('coins'), (profile['coins'] as num?)?.toInt() ?? 200);
      await prefs.setInt(_key('diamonds'), (profile['diamonds'] as num?)?.toInt() ?? 0);
      await prefs.setBool(_key('vip'), profile['isVip'] == true);
      await prefs.setBool(_key('initialized'), true);
    }
    if (!mounted) return;
    setState(() {
      localLoading = false;
      localOwned = prefs.getStringList(_key('owned')) ?? ['classic'];
      localSelected = prefs.getString(_key('selected')) ?? 'classic';
      localCoins = prefs.getInt(_key('coins')) ?? 200;
      localDiamonds = prefs.getInt(_key('diamonds')) ?? 0;
      localVip = prefs.getBool(_key('vip')) ?? false;
      localReady = true;
    });
  }
  final items = const [
    {'id':'classic','name':'Clássica','description':'Moldura padrão do LoveMix','emoji':'💜','currency':'free','cost':0},
    {'id':'neon','name':'Neon Love','description':'Brilho neon roxo, rosa e azul','emoji':'✨','currency':'coins','cost':250},
    {'id':'hearts','name':'Corações','description':'Moldura romântica com corações','emoji':'💗','currency':'coins','cost':400},
    {'id':'gold','name':'Dourada VIP','description':'Visual dourado de destaque','emoji':'👑','currency':'diamonds','cost':50},
    {'id':'cosmic','name':'Galáxia','description':'Efeito cósmico colorido','emoji':'🌌','currency':'diamonds','cost':100},
    {'id':'royal_crown','name':'Rainha Real','description':'Coroa dourada com joias','emoji':'👑','currency':'diamonds','cost':80},
    {'id':'kitty','name':'Gatinho','description':'Orelhinhas e bigodes fofos','emoji':'🐱','currency':'coins','cost':500},
    {'id':'butterfly','name':'Borboletas','description':'Borboletas brilhantes','emoji':'🦋','currency':'coins','cost':550},
    {'id':'rose','name':'Rosa Negra','description':'Rosas elegantes em neon','emoji':'🌹','currency':'coins','cost':600},
    {'id':'headphones','name':'Music Love','description':'Fones e ondas musicais','emoji':'🎧','currency':'coins','cost':450},
    {'id':'pink_bow','name':'Laço Rosa','description':'Laço delicado com corações','emoji':'🎀','currency':'coins','cost':450},
    {'id':'flame','name':'Chamas','description':'Aura de fogo roxo','emoji':'🔥','currency':'diamonds','cost':70},
    {'id':'angel','name':'Asas de Anjo','description':'Asas luminosas e halo','emoji':'🪽','currency':'diamonds','cost':90},
    {'id':'love_wings','name':'Asas LoveMix','description':'Asas e placa LoveMix','emoji':'💞','currency':'diamonds','cost':120},
    {'id':'flower','name':'Jardim','description':'Flores e pétalas coloridas','emoji':'🌸','currency':'coins','cost':500},
    {'id':'sparkle','name':'Estrelas','description':'Estrelas e brilho mágico','emoji':'⭐','currency':'coins','cost':350},
    {'id':'diamond_heart','name':'Coração de Diamante','description':'Coração rosa com cristais','emoji':'💎','currency':'diamonds','cost':110},
    {'id':'broken_heart','name':'Coração Rebelde','description':'Coração neon estilizado','emoji':'💔','currency':'coins','cost':400},
    {'id':'royal_purple','name':'Realeza Roxa','description':'Coroa e aro violeta','emoji':'💜','currency':'diamonds','cost':75},
    {'id':'couple','name':'Casal Apaixonado','description':'Silhueta romântica e corações','emoji':'💑','currency':'coins','cost':650},
    {'id':'butterfly_royal','name':'Borboleta Real','description':'Borboletas, cristais e coroa brilhante','emoji':'🦋','currency':'diamonds','cost':130},
    {'id':'rose_gold','name':'Rosa de Ouro','description':'Rosas douradas com aro luminoso','emoji':'🌹','currency':'diamonds','cost':140},
    {'id':'celestial','name':'Celestial VIP','description':'Halo celestial, estrelas e brilho lilás','emoji':'😇','currency':'diamonds','cost':150},
    {'id':'royal_wings','name':'Asas da Realeza','description':'Asas majestosas com detalhes em ouro','emoji':'🪽','currency':'diamonds','cost':160},
    {'id':'diamond_crown','name':'Coroa de Diamantes','description':'Coroa cravejada de pedras preciosas','emoji':'💎','currency':'diamonds','cost':180},
    {'id':'lovemix_deluxe','name':'LoveMix Deluxe','description':'Corações, laço e emblema LoveMix','emoji':'💖','currency':'diamonds','cost':200},
  ];

  Future<void> _buyOrEquip(Map<String, Object> item) async {
    if (busy || !localReady) return;
    final id = item['id'] as String;
    final currency = item['currency'] as String;
    final cost = (item['cost'] as num).toInt();
    final owned = List<String>.from(localOwned);
    if (currency == 'diamonds' && !localVip) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Esta moldura é exclusiva para assinantes VIP.')));
      return;
    }
    setState(() => busy = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!owned.contains(id)) {
        if (currency == 'coins' && localCoins < cost) {
          throw Exception('Você não tem moedas suficientes.');
        }
        if (currency == 'diamonds' && localDiamonds < cost) {
          throw Exception('Você não tem diamantes suficientes.');
        }
        if (currency == 'coins') localCoins -= cost;
        if (currency == 'diamonds') localDiamonds -= cost;
        owned.add(id);
        await prefs.setStringList(_key('owned'), owned);
        await prefs.setInt(_key('coins'), localCoins);
        await prefs.setInt(_key('diamonds'), localDiamonds);
      }
      await prefs.setString(_key('selected'), id);
      if (!mounted) return;
      setState(() {
        localOwned = owned;
        localSelected = id;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${item['name']} equipada no seu aparelho!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Molduras de perfil'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData || !snap.data!.exists) {
            return const Center(child: CircularProgressIndicator(color: _pink));
          }
          final data = snap.data!.data() ?? <String, dynamic>{};
          _loadLocal(data, uid);
          final owned = localOwned;
          final selected = localSelected;
          final photo = (data['photoUrl'] ?? '').toString();
          final coins = localCoins;
          final diamonds = localDiamonds;
          if (!localReady) return const Center(child: CircularProgressIndicator(color: _pink));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF32104D), Color(0xFF12091E)]),
              border: Border.all(color: _purple.withOpacity(.7))),
              child: Column(children: [
                const Text('Sua moldura atual', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                ProfileFrameAvatar(photoUrl: photo, frameId: selected, size: 94),
                const SizedBox(height: 10),
                Text(items.firstWhere((e) => e['id'] == selected, orElse: () => items.first)['name'] as String,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('🪙 $coins', style: const TextStyle(color: Color(0xFFFFD56A), fontWeight: FontWeight.bold)),
                  const SizedBox(width: 18),
                  Text('💎 $diamonds', style: const TextStyle(color: Color(0xFF70DFFF), fontWeight: FontWeight.bold)),
                ]),
              ]),
            ),
            const SizedBox(height: 20),
            const SizedBox(height: 20),
            const Text('Loja de molduras' , style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Compre e equipe molduras salvas neste aparelho.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 12),
            ...items.map((item) {
              final id = item['id'] as String;
              final has = owned.contains(id);
              final active = selected == id;
              final currency = item['currency'] as String;
              final cost = item['cost'];
              return Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: active ? _pink : _purple.withOpacity(.35))),
                child: Row(children: [
                  ProfileFrameAvatar(photoUrl: photo, frameId: id, size: 55),
                  const SizedBox(width: 13),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${item['emoji']} ${item['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(item['description'] as String, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    const SizedBox(height: 4),
                    Text(currency == 'free' ? 'Grátis' : currency == 'coins' ? '🪙 $cost moedas' : (localVip ? '💎 $cost diamantes • VIP' : '🔒 Exclusiva VIP'),
                      style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 12, fontWeight: FontWeight.bold)),
                  ])),
                  const SizedBox(width: 8),
                  SizedBox(width: 100, child: ElevatedButton(
                    onPressed: busy || active ? null : () => _buyOrEquip(item),
                    style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10)),
                    child: Text(active ? 'Ativa' : has ? 'Equipar' : (currency == 'diamonds' && data['isVip'] != true ? 'VIP' : 'Comprar'), style: const TextStyle(fontSize: 12)),
                  )),
                ]),
              );
            }),
            if (busy) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: _pink))),
          ]);
        },
      ),
    );
  }
}
