import 'dart:async';
import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../services/data_service.dart';
import 'admin_screen.dart';
import 'post_interactions_screen.dart';
import 'profile_view_screen.dart';
import 'profile_frames_screen.dart';
import 'vip_nickname_screen.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';

const _pink = Color(0xFFFF19B8);
const _purple = Color(0xFF8D35FF);
const _panel = Color(0xFF171022);
const _muted = Color(0xFFB9AFC7);

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    DataService.instance.ensurePublicId().catchError((_) {});
  }

  final name = TextEditingController();
  final bio = TextEditingController();
  final city = TextEditingController();
  final country = TextEditingController();
  final customInterest = TextEditingController();

  bool loaded = false;
  bool saving = false;
  bool profileSaved = false;
  String gender = '';
  String profileVisibility = 'public';
  String postVisibility = 'public';
  DateTime? birthday;
  List<String> interests = [];

  static const interestOptions = [
    'Amizades', 'Namoro', 'Música', 'Games', 'Viagens', 'Séries',
    'Filmes', 'Esportes', 'Leitura', 'Tecnologia', 'Pets', 'Culinária',
    'Fotografia', 'Dança', 'Academia', 'Natureza',
  ];

  @override
  void dispose() {
    name.dispose();
    bio.dispose();
    city.dispose();
    country.dispose();
    customInterest.dispose();
    super.dispose();
  }

  int? _age(DateTime? date) {
    if (date == null) return null;
    final now = DateTime.now();
    var result = now.year - date.year;
    if (now.month < date.month || (now.month == date.month && now.day < date.day)) {
      result--;
    }
    return result;
  }

  String get _place {
    final c = city.text.trim();
    final countryName = country.text.trim();
    if (c.isEmpty) return countryName;
    if (countryName.isEmpty) return c;
    // When the state abbreviation is already part of the city (São Paulo-SP),
    // avoid repeating the Brazilian state/country in the compact profile line.
    if (countryName.toLowerCase() == 'brasil' && c.contains('-')) return c;
    return '$c • $countryName';
  }

  String get _genderSymbol => const {
    'woman': '♀', 'man': '♂', 'non_binary': '⚧', 'other': '✦',
  }[gender] ?? '';

  Future<void> pickBirthday() async {
    final now = DateTime.now();
    final lastAllowed = DateTime(now.year - 18, now.month, now.day);
    final selected = birthday != null && !birthday!.isAfter(lastAllowed)
        ? birthday!
        : DateTime(now.year - 25, now.month, now.day);
    final picked = await showDatePicker(
      context: context,
      initialDate: selected,
      firstDate: DateTime(1900),
      lastDate: lastAllowed,
      helpText: 'Data de nascimento (somente maiores de 18 anos)',
    );
    if (picked != null && mounted) {
      setState(() {
        birthday = picked;
        profileSaved = false;
      });
    }
  }

  Future<void> publishPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Entre novamente para publicar.');
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 65,
        maxWidth: 1000,
        maxHeight: 1000,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length >= 5 * 1024 * 1024) {
        throw Exception('Escolha uma foto válida de até 5 MB.');
      }
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final isPng = picked.name.toLowerCase().endsWith('.png');
      final type = isPng ? 'image/png' : 'image/jpeg';
      final ext = isPng ? 'png' : 'jpg';
      final ref = FirebaseStorage.instance.ref('user_posts/${user.uid}/$id.$ext');
      final upload = ref.putData(
        bytes,
        SettableMetadata(contentType: type, cacheControl: 'public,max-age=3600'),
      );
      final url = await _downloadUploadedImageUrl(upload);
      await FirebaseFirestore.instance
          .collection('users').doc(user.uid).collection('posts').doc(id).set({
        'photoUrl': url,
        'visibility': postVisibility,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Foto publicada no seu perfil!')),
        );
      }
    } on FirebaseException catch (e) {
      final message = switch (e.code) {
        'object-not-found' => 'O Firebase não localizou o arquivo após o envio. Confira se o bucket Storage do projeto lovemix-73849 está ativo e se as regras foram publicadas.',
        'unauthorized' || 'permission-denied' => 'O Firebase bloqueou a publicação. Verifique as regras do ${e.plugin == 'firebase_storage' ? 'Storage' : 'Firestore'}.',
        _ => 'Não foi possível publicar a foto (${e.code}).',
      };
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível publicar: ${e.toString().replaceFirst('Exception: ', '')}')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<String> _downloadUploadedImageUrl(UploadTask task) async {
    // Aguarda o término real do upload antes de consultar a URL do objeto.
    final snapshot = await task;
    for (var attempt = 0; attempt < 5; attempt++) {
      try {
        await snapshot.ref.getMetadata();
        return await snapshot.ref.getDownloadURL();
      } on FirebaseException catch (error) {
        final transient = error.code == 'object-not-found' ||
            error.code == 'unknown' || error.code == 'unavailable';
        if (!transient || attempt == 4) rethrow;
        await Future<void>.delayed(Duration(milliseconds: 500 * (attempt + 1)));
      }
    }
    throw Exception('O upload terminou, mas o Firebase ainda não disponibilizou a foto. Tente novamente.');
  }

  Future<void> pickCoverPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login novamente para alterar a capa.');
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery, imageQuality: 75, maxWidth: 1600, maxHeight: 1200,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length >= 8 * 1024 * 1024) {
        throw Exception('Escolha uma imagem válida de até 8 MB.');
      }
      final isPng = picked.name.toLowerCase().endsWith('.png');
      final ext = isPng ? 'png' : 'jpg';
      final type = isPng ? 'image/png' : 'image/jpeg';
      final ref = FirebaseStorage.instance.ref('profile_covers/${user.uid}/cover.$ext');
      final upload = ref.putData(
        bytes,
        SettableMetadata(contentType: type, cacheControl: 'public,max-age=3600'),
      );
      final url = await _downloadUploadedImageUrl(upload);
      await DataService.instance.updateProfile({'profileCoverUrl': url});
      if (mounted) _message('Foto de capa atualizada! 💜');
    } on FirebaseException catch (e) {
      final message = switch (e.code) {
        'object-not-found' => 'O Firebase não localizou o arquivo após o envio. Confira se o bucket Storage do projeto lovemix-73849 está ativo e se as regras foram publicadas.',
        'unauthorized' || 'permission-denied' => 'O Firebase bloqueou a gravação. Publique as regras do Storage e do Firestore.',
        _ => 'Não foi possível atualizar a capa (${e.code}).',
      };
      if (mounted) _message(message);
    } catch (e) {
      if (mounted) _message('Não foi possível atualizar a capa: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> pickPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Faça login novamente para alterar sua foto.');
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 65,
        maxWidth: 720,
        maxHeight: 720,
      );
      if (picked == null) return;
      final Uint8List bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A imagem selecionada está vazia.');
      if (bytes.length > 5 * 1024 * 1024) {
        throw Exception('A foto ficou muito grande. Escolha outra imagem.');
      }
      final lowerPath = picked.name.toLowerCase();
      final contentType = lowerPath.endsWith('.png')
          ? 'image/png'
          : lowerPath.endsWith('.webp') ? 'image/webp' : 'image/jpeg';
      final extension = contentType == 'image/png'
          ? 'png' : contentType == 'image/webp' ? 'webp' : 'jpg';
      final ref = FirebaseStorage.instance.ref()
          .child('profile_photos').child(user.uid).child('profile.$extension');
      await ref.putData(bytes, SettableMetadata(
        contentType: contentType,
        cacheControl: 'public,max-age=3600',
      ));
      final url = await ref.getDownloadURL();
      await DataService.instance.updateProfile({'photoUrl': url});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Foto de perfil atualizada!')),
        );
      }
    } on FirebaseException catch (e) {
      final message = e.code == 'unauthorized'
          ? 'O Firebase Storage bloqueou o envio. Verifique as regras do Storage.'
          : e.code == 'canceled' ? 'Envio cancelado.' : 'Falha no envio da foto (${e.code}). Tente novamente.';
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _saveProfile() async {
    if (saving) return;
    if (name.text.trim().isEmpty) {
      _message('Digite seu nome.');
      return;
    }
    final age = _age(birthday);
    if (birthday == null || age == null) {
      _message('Adicione sua data de nascimento para mostrar sua idade no perfil.');
      return;
    }
    if (age < 18) {
      _message('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }
    setState(() {
      saving = true;
      profileSaved = false;
    });
    try {
      await DataService.instance.updateProfile({
        'name': name.text.trim(),
        'bio': bio.text.trim(),
        'city': city.text.trim(),
        'country': country.text.trim(),
        'gender': gender,
        'birthday': Timestamp.fromDate(birthday!),
        'interests': interests,
        'profileVisibility': profileVisibility,
        'postVisibility': postVisibility,
      }).timeout(const Duration(seconds: 20));
      if (mounted) {
        setState(() => profileSaved = true);
        _message('Perfil salvo com sucesso!');
      }
    } on TimeoutException {
      if (mounted) {
        _message('Ainda não consegui confirmar o salvamento. Verifique sua conexão.');
      }
    } catch (e) {
      if (mounted) _message('Não foi possível salvar o perfil: $e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  void _addCustomInterest() {
    final value = customInterest.text.trim();
    if (value.isEmpty) return;
    if (!interests.any((e) => e.toLowerCase() == value.toLowerCase())) {
      setState(() {
        interests.add(value);
        profileSaved = false;
      });
    }
    customInterest.clear();
    FocusScope.of(context).unfocus();
  }

  void _openPhoto(String postId, String url) {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => PostInteractionsScreen(ownerId: userId, postId: postId, photoUrl: url)));
  }

  Future<void> _deletePost(String postId, String url) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remover foto?'),
        content: const Text('Essa foto será removida da sua galeria.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Remover')),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      await FirebaseFirestore.instance.collection('users').doc(uid).collection('posts').doc(postId).delete();
      if (url.isNotEmpty) {
        try { await FirebaseStorage.instance.refFromURL(url).delete(); } catch (_) {}
      }
      if (mounted) _message('Foto removida da galeria.');
    } catch (e) {
      if (mounted) _message('Não foi possível remover a foto: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.myProfile(),
      builder: (context, snap) {
        final p = snap.data?.data() ?? <String, dynamic>{};
        if (!loaded && p.isNotEmpty) {
          name.text = (p['name'] ?? '').toString();
          bio.text = (p['bio'] ?? '').toString();
          city.text = (p['city'] ?? '').toString();
          country.text = (p['country'] ?? '').toString();
          gender = (p['gender'] ?? '').toString();
          profileVisibility = (p['profileVisibility'] ?? 'public').toString();
          postVisibility = (p['postVisibility'] ?? 'public').toString();
          birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
          interests = List<String>.from(p['interests'] ?? const []);
          loaded = true;
        }
        final photo = (p['photoUrl'] ?? '').toString();
        final cover = (p['profileCoverUrl'] ?? '').toString();
        final user = FirebaseAuth.instance.currentUser;
        if (user == null) return const Center(child: Text('Entre na sua conta para editar o perfil.'));

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: [
            const Text('Conecta', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            const Text('Veja como as pessoas enxergam você no LoveMix.', style: TextStyle(color: _muted)),
            const SizedBox(height: 16),
            _profilePreview(cover.isNotEmpty ? cover : photo, p),
            const SizedBox(height: 12),
            Card(color: _panel, child: ListTile(
              leading: const Icon(Icons.auto_awesome, color: _pink, size: 28),
              title: const Text('Molduras de perfil', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Escolha uma moldura neon, romântica ou dourada.'),
              trailing: const Icon(Icons.chevron_right, color: _pink),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen())),
            )),
            Card(color: _panel, child: ListTile(
              leading: const Icon(Icons.workspace_premium, color: Color(0xFFFFD56A), size: 28),
              title: const Text('Nick VIP decorado', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Coroas, cruzes e efeitos coloridos exclusivos para VIP.'),
              trailing: const Icon(Icons.chevron_right, color: _pink),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VipNicknameScreen())),
            )),
            if ((p['publicId'] ?? '').toString().isNotEmpty)
              Card(
                color: _panel,
                child: ListTile(
                  leading: const Icon(Icons.badge_outlined, color: _pink),
                  title: const Text('Meu ID LoveMix', style: TextStyle(fontSize: 12, color: _muted)),
                  subtitle: SelectableText((p['publicId'] ?? '').toString(), style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  trailing: IconButton(
                    tooltip: 'Copiar ID',
                    icon: const Icon(Icons.copy, color: _pink),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: (p['publicId'] ?? '').toString()));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ID copiado!')));
                    },
                  ),
                ),
              ),
            const SizedBox(height: 20),
            _sectionHeader(Icons.edit_rounded, 'Nome e idade', 'Essas informações aparecem no seu perfil público.'),
            const SizedBox(height: 12),
            _formCard([
              TextField(
                controller: name,
                textCapitalization: TextCapitalization.words,
                onChanged: (_) => setState(() => profileSaved = false),
                decoration: const InputDecoration(labelText: 'Nome que será exibido', prefixIcon: Icon(Icons.person_outline)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bio,
                maxLines: 3,
                maxLength: 300,
                onChanged: (_) => setState(() => profileSaved = false),
                decoration: const InputDecoration(labelText: 'Sobre mim', hintText: 'Conte um pouco sobre você... ', prefixIcon: Icon(Icons.favorite_border)),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: pickBirthday,
                icon: const Icon(Icons.cake_outlined),
                label: Text(birthday == null ? 'Adicionar data de nascimento (18+)' : 'Nascimento: ${birthday!.day.toString().padLeft(2, '0')}/${birthday!.month.toString().padLeft(2, '0')}/${birthday!.year}  •  ${_age(birthday)} anos'),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: TextField(
                  controller: city,
                  textCapitalization: TextCapitalization.words,
                  onChanged: (_) => setState(() => profileSaved = false),
                  decoration: const InputDecoration(labelText: 'Cidade / Estado', hintText: 'Ex.: São Paulo-SP', prefixIcon: Icon(Icons.location_city)),
                )),
              ]),
              const SizedBox(height: 12),
              TextField(
                controller: country,
                textCapitalization: TextCapitalization.words,
                onChanged: (_) => setState(() => profileSaved = false),
                decoration: const InputDecoration(labelText: 'País', hintText: 'Ex.: Brasil', prefixIcon: Icon(Icons.public)),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: gender.isEmpty ? null : gender,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Gênero', prefixIcon: Icon(Icons.wc_outlined)),
                items: const [
                  DropdownMenuItem(value: 'woman', child: Text('♀ Mulher')),
                  DropdownMenuItem(value: 'man', child: Text('♂ Homem')),
                  DropdownMenuItem(value: 'non_binary', child: Text('⚧ Não binário')),
                  DropdownMenuItem(value: 'other', child: Text('✦ Outro')),
                  DropdownMenuItem(value: 'prefer_not', child: Text('Prefiro não informar')),
                ],
                onChanged: (v) => setState(() {
                  gender = v ?? '';
                  profileSaved = false;
                }),
              ),
            ]),
            const SizedBox(height: 18),
            _sectionHeader(Icons.auto_awesome, 'Interesses', 'Adicione e remova os assuntos que combinam com você.'),
            const SizedBox(height: 10),
            _formCard([
              Wrap(
                spacing: 8,
                runSpacing: 2,
                children: interestOptions.map((item) {
                  final selected = interests.contains(item);
                  return FilterChip(
                    label: Text(item),
                    selected: selected,
                    showCheckmark: false,
                    selectedColor: _purple.withOpacity(.35),
                    backgroundColor: const Color(0xFF100A19),
                    side: BorderSide(color: selected ? _pink : Colors.white24),
                    labelStyle: TextStyle(color: selected ? Colors.white : Colors.white70, fontWeight: selected ? FontWeight.bold : FontWeight.normal),
                    onSelected: (value) => setState(() {
                      if (value) { interests.add(item); } else { interests.remove(item); }
                      profileSaved = false;
                    }),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(
                  controller: customInterest,
                  textCapitalization: TextCapitalization.sentences,
                  onSubmitted: (_) => _addCustomInterest(),
                  decoration: const InputDecoration(hintText: 'Adicionar outro interesse', prefixIcon: Icon(Icons.add)),
                )),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _addCustomInterest, icon: const Icon(Icons.add), style: IconButton.styleFrom(backgroundColor: _pink)),
              ]),
              if (interests.any((e) => !interestOptions.contains(e))) ...[
                const SizedBox(height: 10),
                Wrap(spacing: 8, children: interests.where((e) => !interestOptions.contains(e)).map((e) => InputChip(
                  label: Text(e), onDeleted: () => setState(() {
                    interests.remove(e);
                    profileSaved = false;
                  }),
                  backgroundColor: _purple.withOpacity(.25), side: const BorderSide(color: _purple),
                )).toList()),
              ],
            ]),
            const SizedBox(height: 18),
            _sectionHeader(Icons.visibility_outlined, 'Privacidade', 'Controle quem encontra seu perfil e quem vê cada publicação.'),
            const SizedBox(height: 10),
            _formCard([
              DropdownButtonFormField<String>(
                value: profileVisibility,
                decoration: const InputDecoration(labelText: 'Quem pode encontrar seu perfil?', prefixIcon: Icon(Icons.person_search_outlined)),
                items: const [
                  DropdownMenuItem(value: 'public', child: Text('🌎 Público — todos podem encontrar')),
                  DropdownMenuItem(value: 'friends', child: Text('👥 Amigos — somente conexões')),
                  DropdownMenuItem(value: 'private', child: Text('🔒 Privado — somente você')),
                ],
                onChanged: (v) => setState(() {
                  profileVisibility = v ?? 'public';
                  profileSaved = false;
                }),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: postVisibility,
                decoration: const InputDecoration(labelText: 'Privacidade padrão das próximas fotos', prefixIcon: Icon(Icons.photo_library_outlined)),
                items: const [
                  DropdownMenuItem(value: 'public', child: Text('🌎 Público')),
                  DropdownMenuItem(value: 'friends', child: Text('👥 Apenas amigos / matches')),
                  DropdownMenuItem(value: 'private', child: Text('🔒 Somente eu')),
                ],
                onChanged: (v) => setState(() {
                  postVisibility = v ?? 'public';
                  profileSaved = false;
                }),
              ),
              const SizedBox(height: 8),
              const Text('A privacidade padrão é aplicada às novas fotos publicadas. Cada publicação mantém a opção escolhida no momento do envio.', style: TextStyle(color: _muted, fontSize: 12)),
            ]),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                onPressed: saving ? null : _saveProfile,
                icon: saving
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Icon(profileSaved ? Icons.check_circle_outline : Icons.save_outlined),
                label: Text(saving ? 'Salvando...' : profileSaved ? 'Perfil salvo' : 'Salvar alterações'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: profileSaved && !saving ? const Color(0xFF188A62) : _pink,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 48,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => ProfileViewScreen(userId: user.uid),
                )),
                icon: const Icon(Icons.visibility_outlined),
                label: const Text('Visualizar perfil público'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: _purple, width: 1.4),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
            const SizedBox(height: 24),
            _sectionHeader(Icons.photo_library_outlined, 'Galeria de fotos', 'Gerencie as fotos que aparecem no seu perfil público.'),
            const SizedBox(height: 8),
            StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance.collection('users').doc(user.uid)
                  .collection('posts').snapshots(),
              builder: (context, postsSnap) {
                if (postsSnap.hasError) return const Text('Não foi possível carregar suas fotos.', style: TextStyle(color: Colors.white70));
                if (!postsSnap.hasData) return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator(color: _pink)));
                final posts = [...postsSnap.data!.docs];
                posts.sort((a, b) {
                  final at = a.data()['createdAt'];
                  final bt = b.data()['createdAt'];
                  final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
                  final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
                  return bm.compareTo(am);
                });
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text('Fotos (${posts.length})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const Spacer(),
                    TextButton.icon(onPressed: saving ? null : publishPhoto, icon: const Icon(Icons.add_a_photo_outlined), label: const Text('Adicionar fotos')),
                  ]),
                  if (posts.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 18),
                      decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
                      child: const Column(children: [
                        Icon(Icons.add_photo_alternate_outlined, size: 38, color: _purple),
                        SizedBox(height: 8),
                        Text('Você ainda não publicou fotos.', style: TextStyle(color: Colors.white70)),
                        Text('Toque em Publicar para adicionar a primeira.', style: TextStyle(color: _muted, fontSize: 12)),
                      ]),
                    )
                  else
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: posts.length,
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 7, mainAxisSpacing: 7),
                      itemBuilder: (_, i) {
                        final post = posts[i].data();
                        final url = (post['photoUrl'] ?? '').toString();
                        final privacy = (post['visibility'] ?? 'public').toString();
                        return GestureDetector(
                          onTap: url.isEmpty ? null : () => _openPhoto(posts[i].id, url),
                          child: Stack(fit: StackFit.expand, children: [
                            ClipRRect(borderRadius: BorderRadius.circular(12), child: url.isEmpty
                                ? const ColoredBox(color: _panel, child: Icon(Icons.broken_image))
                                : Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: _panel, child: Icon(Icons.broken_image)))),
                            Positioned(right: 5, top: 5, child: Container(
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(color: Color(0xB3000000), shape: BoxShape.circle),
                              child: Icon(privacy == 'private' ? Icons.lock : privacy == 'friends' ? Icons.group : Icons.public, size: 13, color: Colors.white),
                            )),
                            Positioned(left: 3, top: 3, child: Material(
                              color: const Color(0xB3000000), shape: const CircleBorder(),
                              child: InkWell(onTap: () => _deletePost(posts[i].id, url),
                                customBorder: const CircleBorder(),
                                child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.delete_outline, size: 15, color: Colors.white))),
                            )),
                          ]),
                        );
                      },
                    ),
                ]);
              },
            ),
            const SizedBox(height: 18),
            if (p['isAdmin'] == true)
              OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())), icon: const Icon(Icons.admin_panel_settings), label: const Text('Painel administrativo')),
            OutlinedButton.icon(
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Excluir conta?'),
                    content: const Text('A exclusão é permanente. Talvez seja necessário entrar novamente antes de confirmar.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir')),
                    ],
                  ),
                );
                if (confirm != true) return;
                try {
                  await DataService.instance.deleteMyAccount();
                } on FirebaseAuthException catch (e) {
                  if (mounted) _message(e.code == 'requires-recent-login'
                      ? 'Por segurança, saia e entre novamente antes de excluir a conta.'
                      : 'Não foi possível excluir a conta.');
                }
              },
              icon: const Icon(Icons.delete_forever), label: const Text('Excluir minha conta'),
            ),
            OutlinedButton.icon(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout), label: const Text('Sair da conta')),
          ],
        );
      },
    );
  }

  Widget _profilePreview(String cover, Map<String, dynamic> profile) {
    final age = _age(birthday);
    final displayName = name.text.trim().isEmpty ? 'Seu nome' : name.text.trim();
    final isOnline = profile['isOnline'] == true;
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF090909),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _purple.withOpacity(.75), width: 1.3),
        boxShadow: [BoxShadow(color: _purple.withOpacity(.16), blurRadius: 18)],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Stack(children: [
          SizedBox(
            width: double.infinity, height: 270,
            child: cover.isEmpty
                ? Container(
                    decoration: const BoxDecoration(gradient: LinearGradient(
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                      colors: [Color(0xFF29113D), Color(0xFF100A19), Color(0xFF050505)],
                    )),
                    child: const Icon(Icons.add_a_photo_outlined, size: 62, color: Colors.white38),
                  )
                : Image.network(cover, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const ColoredBox(color: _panel, child: Icon(Icons.image_not_supported_outlined, size: 48))),
          ),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Colors.black.withOpacity(.04), Colors.transparent, Colors.black.withOpacity(.78)]),
          ))),
          Positioned(left: 12, bottom: 12, child: Text(
            cover.isEmpty ? 'Adicione sua foto de capa' : 'Foto de capa',
            style: const TextStyle(color: Colors.white70, fontSize: 12, shadows: [Shadow(color: Colors.black, blurRadius: 5)]),
          )),
          Positioned(right: 12, bottom: 10, child: Material(
            color: Colors.black54, shape: const CircleBorder(),
            child: IconButton(onPressed: saving ? null : pickCoverPhoto,
              tooltip: 'Editar foto de capa', icon: const Icon(Icons.edit, color: Colors.white)),
          )),
          Positioned(left: 14, top: 12, child: Row(children: [
            const Icon(Icons.circle, size: 9, color: Colors.greenAccent),
            const SizedBox(width: 5),
            Text(isOnline ? 'Online' : 'LoveMix', style: const TextStyle(color: Colors.white, fontSize: 12, shadows: [Shadow(color: Colors.black, blurRadius: 5)])),
          ])),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: ProfileFrameAvatar(photoUrl: (profile['photoUrl'] ?? '').toString(), frameId: (profile['selectedProfileFrame'] ?? 'classic').toString(), size: 78)),
            const SizedBox(height: 12),
            VipNickname(name: '$displayName${age == null ? '' : ', $age'}', isVip: profile['isVip'] == true,
              styleId: (profile['vipNicknameStyle'] ?? 'royal_gold').toString(),
              textStyle: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Colors.white)),
            if (_place.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3),
              child: Text(_place, style: const TextStyle(color: Colors.white60, fontSize: 13))),
            if (interests.isNotEmpty) ...[
              const SizedBox(height: 12),
              Wrap(spacing: 7, runSpacing: 7, children: interests.map((item) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                decoration: BoxDecoration(color: const Color(0xFF25202B), borderRadius: BorderRadius.circular(18), border: Border.all(color: _purple.withOpacity(.7))),
                child: Text(item, style: const TextStyle(color: Colors.white, fontSize: 12)),
              )).toList()),
            ],
            if (bio.text.trim().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12),
              child: Text(bio.text.trim(), maxLines: 4, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, height: 1.35))),
          ]),
        ),
      ]),
    );
  }

  Widget _previewButton(String label, Color color, {bool outlined = false}) => Container(
    height: 43,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: outlined ? Colors.transparent : color,
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: color, width: 1.5),
    ),
    child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
  );

  Widget _sectionHeader(IconData icon, String title, String subtitle) => Row(children: [
    Container(width: 39, height: 39, decoration: BoxDecoration(color: _purple.withOpacity(.2), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: _pink)),
    const SizedBox(width: 10),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      Text(subtitle, style: const TextStyle(color: _muted, fontSize: 11)),
    ])),
  ]);

  Widget _formCard(List<Widget> children) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF4B2867))),
    child: Column(children: children),
  );
}
