import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../widgets/vip_nickname.dart';
import 'profile_frames_screen.dart';

class VipNicknameScreen extends StatefulWidget {
  const VipNicknameScreen({super.key});
  @override
  State<VipNicknameScreen> createState() => _VipNicknameScreenState();
}

class _VipNicknameScreenState extends State<VipNicknameScreen> {
  bool loading = true;
  bool busy = false;
  int coins = 0;
  List<String> owned = <String>[];
  String selected = '';
  String? uid;

  static const decorations = <Map<String, Object>>[
    {'id':'royal_gold','label':'Coroa Real','price':300},
    {'id':'purple_king','label':'Rei Roxo','price':350},
    {'id':'pink_love','label':'Coração Rosa','price':300},
    {'id':'blue_legend','label':'Lenda Azul','price':350},
    {'id':'red_flame','label':'Chama','price':400},
    {'id':'emerald','label':'Esmeralda','price':400},
    {'id':'silver_moon','label':'Lua Prateada','price':450},
    {'id':'cosmic_fire','label':'Fogo Cósmico','price':500},
    {'id':'blue_diamond','label':'Diamante Azul','price':500},
    {'id':'sakura_bloom','label':'Flor de Cerejeira','price':450},
    {'id':'rainbow','label':'Arco-Íris','price':450},
    {'id':'golden_comet','label':'Cometa Dourado','price':500},
    {'id':'crystal_ice','label':'Gelo Cristal','price':500},
    {'id':'ruby_dragon','label':'Dragão Rubi','price':550},
    {'id':'star_cloud','label':'Nuvem de Estrelas','price':450},
    {'id':'sky_butterfly','label':'Borboleta Celeste','price':500},
    {'id':'emerald_aura','label':'Aura Esmeralda','price':500},
    {'id':'galaxy','label':'Galáxia','price':600},
    {'id':'vip_wings','label':'Asas VIP','price':500},
    {'id':'golden_star','label':'Estrela Dourada','price':450},
    {'id':'enchanted_rose','label':'Rosa Encantada','price':500},
    {'id':'purple_butterfly','label':'Borboleta Roxa','price':500},
  ];
  @override
  void initState() { super.initState(); _load(); }

  DocumentReference<Map<String, dynamic>> get _userRef =>
      FirebaseFirestore.instance.collection('users').doc(uid);

  String get _ownedKey => 'lovemix_nickname_owned_$uid';

  Future<void> _load() async {
    uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      if (mounted) setState(() => loading = false);
      return;
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      final snap = await _userRef.get();
      final data = snap.data() ?? <String, dynamic>{};

      // Compras e histórico de itens ficam somente no armazenamento local.
      final localOwned = prefs.getStringList(_ownedKey) ?? <String>[];
      final publicSelected = (data['vipNicknameStyle'] ?? '').toString();

      if (!mounted) return;
      setState(() {
        coins = (data['coins'] as num?)?.toInt() ?? 0;
        owned = localOwned;
        selected = publicSelected;
        loading = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() => loading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível carregar a loja: $e')),
        );
      }
    }
  }

  Future<void> _buy(Map<String, Object> item) async {
    if (busy || uid == null) return;
    final id = item['id'] as String;
    final price = item['price'] as int;
    setState(() => busy = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final alreadyOwned = owned.contains(id);

      if (!alreadyOwned) {
        // O saldo de moedas da conta continua sendo validado e descontado
        // atomicamente. Nenhuma lista de compras é enviada ao Firestore.
        final newBalance = await FirebaseFirestore.instance
            .runTransaction<int>((tx) async {
          final snap = await tx.get(_userRef);
          if (!snap.exists) throw Exception('Sua conta não foi encontrada.');
          final data = snap.data() ?? <String, dynamic>{};
          final currentCoins = (data['coins'] as num?)?.toInt() ?? 0;
          if (currentCoins < price) {
            throw Exception('Você não tem moedas suficientes.');
          }
          final balance = currentCoins - price;
          tx.update(_userRef, {'coins': balance});
          return balance;
        });

        final nextOwned = <String>{...owned, id}.toList();
        await prefs.setStringList(_ownedKey, nextOwned);
        owned = nextOwned;
        coins = newBalance;
      }

      // Publica somente o estilo atualmente equipado, para que os outros
      // usuários vejam a decoração no perfil e nos balões do chat.
      await _userRef.update({
        'vipNicknameStyle': id,
        'nicknameDecorationActive': true,
      });

      if (!mounted) return;
      setState(() => selected = id);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(alreadyOwned
            ? '${item['label']} ativada sem nova cobrança!'
            : '${item['label']} comprada e ativada!')),
      );
    } catch (e) {
      if (mounted) {
        final message = e.toString().replaceFirst('Exception: ', '');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message.contains('permission-denied')
              ? 'O Firebase bloqueou a atualização do saldo ou do Nick. Confira as regras atualizadas.'
              : message)),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    if (loading) return const Scaffold(backgroundColor: Color(0xFF080510), body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Loja de personalização'), backgroundColor: const Color(0xFF080510)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF21132F), borderRadius: BorderRadius.circular(16)),
          child: Row(children: [const Text('🪙', style: TextStyle(fontSize: 26)), const SizedBox(width: 10), Text('$coins moedas', style: const TextStyle(color: Color(0xFFFFD56A), fontSize: 19, fontWeight: FontWeight.bold))])),
        const SizedBox(height: 18),
        const Text('Decorações de nick', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        ...decorations.map((item) {
          final id = item['id'] as String;
          final label = item['label'] as String;
          final price = item['price'] as int;
          final has = owned.contains(id);
          final active = selected == id;
          final colors = VipNickname.styles[id]?['colors'] as List<Color>? ??
              const [Color(0xFFE0B8FF), Color(0xFF923BFF)];

          return Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF171022),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: active ? colors.last : const Color(0xFF342342),
                width: active ? 1.8 : 1,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [colors.first.withOpacity(.28), colors.last.withOpacity(.12)],
                    ),
                    border: Border.all(color: colors.last.withOpacity(.75)),
                  ),
                  child: Icon(Icons.auto_awesome, color: colors.first, size: 23),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: VipNickname(
                          name: 'Seu Nick',
                          isVip: true,
                          styleId: id,
                          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        has ? (active ? 'Comprada • Em uso' : 'Comprada') : '🪙 $price moedas',
                        style: TextStyle(
                          color: active ? colors.first : Colors.white60,
                          fontSize: 12,
                          fontWeight: active ? FontWeight.w700 : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                if (busy)
                  const SizedBox(
                    width: 28, height: 28,
                    child: CircularProgressIndicator(strokeWidth: 2.5),
                  )
                else if (active)
                  Icon(Icons.check_circle, color: colors.last, size: 28)
                else
                  SizedBox(
                    width: 104,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF19B8),
                        foregroundColor: Colors.white,
                        minimumSize: const Size(104, 42),
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () => _buy(item),
                      child: Text(has ? 'Usar' : 'Comprar', maxLines: 1),
                    ),
                  ),
              ],
            ),
          );
        }),
        const SizedBox(height: 20),
        const Text('Molduras de perfil', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Card(color: const Color(0xFF171022), child: ListTile(
          leading: const Icon(Icons.auto_awesome, color: Color(0xFFFF19B8)),
          title: const Text('Loja de molduras', style: TextStyle(color: Colors.white)),
          subtitle: const Text('Compre e equipe molduras usando moedas', style: TextStyle(color: Colors.white60)),
          trailing: const Icon(Icons.chevron_right, color: Color(0xFFFF19B8)),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileFramesScreen())),
        )),
      ]),
    );
  }
}
