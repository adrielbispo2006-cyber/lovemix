# Correção do erro NOT_FOUND ao enviar presentes

O aplicativo chama a Cloud Function `sendRoomGift`. O código da função já existe em `functions/src/index.ts`, mas gerar o APK não publica Cloud Functions. Se a função não estiver publicada no projeto Firebase, o aplicativo pode receber `NOT_FOUND`.

## Publicar a função

1. Envie este projeto ao mesmo repositório GitHub usado para gerar o APK.
2. Abra **GitHub → Actions**.
3. Escolha **Publicar envio de presentes LoveMix**.
4. Toque em **Run workflow** e aguarde a execução terminar com sucesso.
5. Confirme que o repositório tem o secret `FIREBASE_SERVICE_ACCOUNT_LOVEMIX_73849` com permissão de implantação no projeto `lovemix-73849`.
6. Abra o LoveMix novamente e teste um presente barato com moedas e outro com diamantes, verificando os saldos antes e depois.

## O que foi ajustado no app

- A chamada `sendRoomGift` agora aponta explicitamente para a região `us-central1`.
- A mensagem de erro explica quando a função ainda não está publicada.
- A função valida o saldo no servidor e desconta a moeda/diamante em transação; o cliente não consegue definir o preço.

A publicação da Cloud Function é necessária. Apenas instalar um APK novo não publica a função no Firebase.
