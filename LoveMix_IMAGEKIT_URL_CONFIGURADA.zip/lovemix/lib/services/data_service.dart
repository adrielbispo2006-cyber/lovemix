import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import '../data/gift_catalog.dart';

class DataService {
  DataService._();
  static final instance = DataService._();

  /// Converte qualquer valor vindo do Firestore em lista de textos, sem nunca
  /// lançar exceção (salas antigas podem ter `members` nulo, mapa ou misto).
  static List<String> stringList(dynamic value) {
    if (value is Iterable) {
      return value.where((e) => e != null).map((e) => e.toString()).toList();
    }
    return <String>[];
  }
  final db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> createUser({
    required String name,
    required DateTime birthday,
    String bio = '',
  }) async {
    final user = FirebaseAuth.instance.currentUser!;
    final publicId = await _allocateShortPublicId();
    await db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'publicId': publicId,
      'name': name.trim(),
      'birthday': Timestamp.fromDate(birthday),
      'bio': bio,
      'photoUrl': '',
      'city': '',
      'country': '',
      'interests': <String>[],
      'coins': 200,
      'diamonds': 0,
      'ownedProfileFrames': <String>['classic'],
      'selectedProfileFrame': 'classic',
      'profileVisibility': 'public',
      'postVisibility': 'public',
      'isVip': false,
      'isAdmin': false,
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': true,
      'isOnline': false,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }


  Future<void> setOnlineStatus(bool online) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(user.uid).set({
      'isOnline': online,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // ID público curto. O UID original continua sendo usado internamente.
  static const String _publicIdAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  String _randomShortPublicId() {
    final random = Random.secure();
    return List.generate(8, (_) =>
      _publicIdAlphabet[random.nextInt(_publicIdAlphabet.length)]).join();
  }

  Future<String> _allocateShortPublicId() async {
    for (var attempt = 0; attempt < 20; attempt++) {
      final candidate = _randomShortPublicId();
      final exists = await db.collection('users')
          .where('publicId', isEqualTo: candidate).limit(1).get();
      if (exists.docs.isEmpty) return candidate;
    }
    throw Exception('Não foi possível gerar um ID. Tente novamente.');
  }

  Future<void> ensurePublicId() async {
    final userId = uid;
    final ref = db.collection('users').doc(userId);
    final snap = await ref.get();
    if (!snap.exists) return;
    final current = (snap.data()?['publicId'] ?? '').toString().trim().toUpperCase();
    if (RegExp(r'^[A-Z0-9]{8}$').hasMatch(current)) return;
    final publicId = await _allocateShortPublicId();
    await ref.set({'publicId': publicId}, SetOptions(merge: true));
  }

  Future<QuerySnapshot<Map<String, dynamic>>> findUserByPublicId(String value) {
    // A consulta inclui a visibilidade para que as regras do Firestore
    // consigam garantir que nenhum perfil privado seja retornado.
    final publicId = value.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9-]'), '');
    return db.collection('users')
        .where('publicId', isEqualTo: publicId)
        .where('profileVisibility', isEqualTo: 'public')
        .limit(1)
        .get();
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() =>
      db.collection('users').doc(uid).snapshots();

  Future<void> updateProfile(Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set(data, SetOptions(merge: true));

  Stream<QuerySnapshot<Map<String, dynamic>>> discoverUsers() =>
      db.collection('users')
          // Não exigir isActive == true: contas antigas podem não ter esse
          // campo. A tela remove explicitamente apenas quem está inativo.
          .where('profileVisibility', isEqualTo: 'public')
          .limit(1000)
          .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> myAlliances() => db
      .collection('alliances').where('members', arrayContains: uid).snapshots();

  Future<void> createAllianceByPublicId(String publicId, String relationshipType,
      DateTime startDate, String message) async {
    final cleanId = publicId.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9-]'), '');
    if (!RegExp(r'^(?:[A-Z0-9]{8}|LM-[A-F0-9]{12})$').hasMatch(cleanId)) {
      throw Exception('Informe o ID curto de 8 letras e números.');
    }
    const allowed = ['Namorados', 'BFF', 'Amigos', 'Irmãos'];
    if (!allowed.contains(relationshipType)) throw Exception('Tipo de aliança inválido.');
    final found = await findUserByPublicId(cleanId);
    if (found.docs.isEmpty) throw Exception('Não encontramos uma pessoa com esse ID.');
    final partner = found.docs.first;
    if (partner.id == uid) throw Exception('Você não pode criar uma aliança consigo mesmo.');
    if (partner.data()['isActive'] == false) throw Exception('Essa conta não está disponível.');
    final existing = await db.collection('alliances')
        .where('members', arrayContains: uid).get();
    final duplicate = existing.docs.any((d) =>
      (d.data()['members'] as List? ?? []).contains(partner.id) &&
      d.data()['invitationStatus'] != 'rejected');
    if (duplicate) throw Exception('Já existe uma aliança ou convite com essa pessoa.');
    final me = await db.collection('users').doc(uid).get();
    final mine = me.data() ?? {};
    final planned = startDate.isAfter(DateTime.now());
    await db.collection('alliances').add({
      'createdBy': uid, 'invitedUid': partner.id, 'members': [uid, partner.id],
      'creatorName': (mine['name'] ?? 'LoveMix').toString(),
      'creatorPhotoUrl': (mine['photoUrl'] ?? '').toString(),
      'relationshipType': relationshipType, 'message': message.trim(),
      'startDate': Timestamp.fromDate(DateTime(startDate.year, startDate.month, startDate.day)),
      'status': planned ? 'planned' : 'active',
      'invitationStatus': 'pending', 'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> respondAlliance(String allianceId, bool accept) async {
    final ref = db.collection('alliances').doc(allianceId);
    final snap = await ref.get();
    if (!snap.exists || snap.data()?['invitedUid'] != uid ||
        snap.data()?['invitationStatus'] != 'pending') {
      throw Exception('Este convite não está mais disponível.');
    }
    await ref.update({
      'invitationStatus': accept ? 'accepted' : 'rejected',
      'respondedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> pass(String targetUid) async {
    if (targetUid == uid) return;
    await db.collection('users').doc(uid).collection('passed').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<Set<String>> getPassedUserIds() async {
    final snapshot = await db.collection('users').doc(uid)
        .collection('passed').get();
    return snapshot.docs.map((doc) => doc.id).toSet();
  }

  Future<bool> like(String targetUid) async {
    final callable = FirebaseFunctions.instance.httpsCallable('likeUser');
    final result = await callable.call({'targetUid': targetUid});
    return result.data is Map && result.data['matched'] == true;
  }

  DocumentReference<Map<String, dynamic>> followingRef(String targetUid) =>
      db.collection('users').doc(uid).collection('following').doc(targetUid);

  Stream<DocumentSnapshot<Map<String, dynamic>>> followingStatus(String targetUid) =>
      followingRef(targetUid).snapshots();

  Future<bool> toggleFollow(String targetUid) async {
    if (targetUid.isEmpty || targetUid == uid) {
      throw Exception('Perfil inválido.');
    }
    final targetRef = db.collection('users').doc(targetUid);
    final mineRef = followingRef(targetUid);
    final theirsRef = targetRef.collection('followers').doc(uid);
    final blockedByMe = db.collection('users').doc(uid).collection('blocked').doc(targetUid);
    final blockedMe = targetRef.collection('blocked').doc(uid);

    return db.runTransaction<bool>((transaction) async {
      final target = await transaction.get(targetRef);
      final current = await transaction.get(mineRef);
      final blocked1 = await transaction.get(blockedByMe);
      final blocked2 = await transaction.get(blockedMe);
      if (!target.exists || target.data()?['isActive'] == false) {
        throw Exception('Este perfil não está disponível.');
      }
      if (blocked1.exists || blocked2.exists) {
        throw Exception('Não é possível seguir este perfil.');
      }
      if (current.exists) {
        transaction.delete(mineRef);
        transaction.delete(theirsRef);
        return false;
      }
      transaction.set(mineRef, {
        'uid': targetUid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      transaction.set(theirsRef, {
        'uid': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      return true;
    });
  }

  Future<String> openDirectChat(String otherUid) async {
    if (otherUid.isEmpty || otherUid == uid) {
      throw Exception('Perfil inválido.');
    }
    final followsTarget = await followingRef(otherUid).get();
    if (!followsTarget.exists) {
      throw Exception('Siga essa pessoa antes de enviar uma mensagem.');
    }
    final blocked1 = await db.collection('users').doc(uid)
        .collection('blocked').doc(otherUid).get();
    final blocked2 = await db.collection('users').doc(otherUid)
        .collection('blocked').doc(uid).get();
    if (blocked1.exists || blocked2.exists) {
      throw Exception('Não é possível iniciar conversa com este perfil.');
    }
    final users = [uid, otherUid]..sort();
    final chatId = users.join('_');
    final chatRef = db.collection('chats').doc(chatId);
    await chatRef.set({
      'users': users,
      'lastMessage': '',
      'lastMessageAt': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
      'chatType': 'direct',
    }, SetOptions(merge: true));
    return chatId;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myChats() => db
      .collection('chats')
      .where('users', arrayContains: uid)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> myMatches() => db
      .collection('matches')
      .where('users', arrayContains: uid)
      .orderBy('lastMessageAt', descending: true)
      .snapshots();

  CollectionReference<Map<String, dynamic>> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages');



  CollectionReference<Map<String, dynamic>> roomMessages(String roomId) =>
      db.collection('rooms').doc(roomId).collection('messages');

  /// Tenta a consulta ordenada; se o índice do Firestore não existir (erro),
  /// cai para a consulta simples, que não precisa de índice. Assim a tela nunca
  /// fica com o carregamento girando para sempre.
  Stream<QuerySnapshot<Map<String, dynamic>>> _withIndexFallback(
    Query<Map<String, dynamic>> ordered,
    Query<Map<String, dynamic>> simple,
  ) async* {
    try {
      await for (final snap in ordered.snapshots()) {
        yield snap;
      }
    } catch (_) {
      yield* simple.snapshots();
    }
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> publicRooms() {
    final base = db.collection('rooms').where('isPublic', isEqualTo: true);
    return _withIndexFallback(
      base.orderBy('createdAt', descending: true).limit(50),
      base.limit(50),
    );
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> publicLiveRooms({String? mediaMode}) {
    // Busca somente salas públicas. Os campos isLive/mediaMode são filtrados
    // no cliente para evitar consultas compostas que podem falhar quando o
    // índice ainda não foi publicado no projeto Firebase.
    final base = db.collection('rooms').where('isPublic', isEqualTo: true);
    return _withIndexFallback(
      base.orderBy('createdAt', descending: true).limit(100),
      base.limit(100),
    );
  }

  /// Salas de voz com gente dentro agora (campo `voiceLive`, mantido pela
  /// Cloud Function `syncRoomPresence`). Só usa igualdade: não precisa de índice.
  Stream<QuerySnapshot<Map<String, dynamic>>> publicVoiceLiveRooms() => db
      .collection('rooms')
      .where('isPublic', isEqualTo: true)
      .where('voiceLive', isEqualTo: true)
      .limit(50)
      .snapshots();

  Future<Map<String, String>> liveIdentityDefaults() async {
    await ensurePublicId();
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para participar da live.');

    final profile = await db.collection('users').doc(user.uid).get();
    final data = profile.data() ?? <String, dynamic>{};
    final publicId = (data['publicId'] ?? '').toString().trim();
    if (!RegExp(r'^LM-[A-F0-9]{12}$').hasMatch(publicId)) {
      throw Exception('Não foi possível carregar seu ID LoveMix. Complete seu perfil e tente novamente.');
    }

    final profileName = (data['name'] ?? '').toString().trim();
    final accountName = (user.displayName ?? '').trim();
    final emailName = (user.email?.split('@').first ?? '').trim();
    final displayName = profileName.isNotEmpty
        ? profileName
        : accountName.isNotEmpty
            ? accountName
            : emailName.isNotEmpty
                ? emailName
                : 'LoveMix';

    return {'publicId': publicId, 'displayName': displayName};
  }

  CollectionReference<Map<String, dynamic>> liveParticipants(String roomId) =>
      db.collection('rooms').doc(roomId).collection('participants');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchLiveParticipants(String roomId) =>
      liveParticipants(roomId).where('isActive', isEqualTo: true).limit(50).snapshots();

  Future<void> registerLiveParticipant({
    required String roomId,
    required String publicId,
    required String displayName,
  }) async {
    final cleanName = displayName.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (cleanName.isEmpty || cleanName.length > 32) {
      throw Exception('Escolha um nome de 1 a 32 caracteres para a live.');
    }
    final identity = await liveIdentityDefaults();
    if (identity['publicId'] != publicId) {
      throw Exception('Seu ID LoveMix mudou. Feche e entre na live novamente.');
    }
    await liveParticipants(roomId).doc(uid).set({
      'uid': uid,
      'publicId': publicId,
      'displayName': cleanName,
      'isActive': true,
      'joinedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> leaveLiveParticipant(String roomId) async {
    await liveParticipants(roomId).doc(uid).set({
      'isActive': false,
      'leftAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  /// Filtra as salas que realmente estão ao vivo agora e devolve NO MÁXIMO
  /// 1 sala por pessoa (dono) para o tipo pedido: `audio` (voz) ou `video`.
  /// Regras:
  ///  - isLive == true e o tipo da sala bate com o pedido;
  ///  - se a sala já tem `onlineCount` (mantido pela Cloud Function
  ///    `syncRoomPresence`) e ele for 0, ninguém está dentro => não aparece;
  ///  - se a mesma pessoa tiver mais de uma sala, fica só a mais recente.
  static List<QueryDocumentSnapshot<Map<String, dynamic>>> activeLivesOnePerOwner(
    Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
    String mediaMode,
  ) {
    final wantAudio = mediaMode == 'audio';
    final list = docs.where((d) {
      final data = d.data();
      if (data['isLive'] != true) return false;
      final mode = (data['mediaMode'] ?? '').toString();
      if (wantAudio ? mode != 'audio' : (mode != 'video' && mode != 'live')) return false;
      final online = data['onlineCount'];
      if (online is num && online <= 0) return false;
      return true;
    }).toList();

    int millis(QueryDocumentSnapshot<Map<String, dynamic>> d) {
      final t = d.data()['createdAt'];
      return t is Timestamp ? t.millisecondsSinceEpoch : 0;
    }

    list.sort((a, b) => millis(b).compareTo(millis(a)));
    final seenOwners = <String>{};
    final result = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
    for (final d in list) {
      final owner = (d.data()['ownerId'] ?? d.id).toString();
      if (seenOwners.add(owner)) result.add(d);
    }
    return result;
  }

  /// Encerra as outras lives da própria pessoa do mesmo tipo (voz ou vídeo),
  /// para que ela nunca tenha mais de 1 live de voz e 1 live de vídeo ao vivo.
  Future<void> endMyOtherLives(String mediaMode) async {
    try {
      final snap = await db
          .collection('rooms')
          .where('ownerId', isEqualTo: uid)
          .where('isLive', isEqualTo: true)
          .get();
      for (final d in snap.docs) {
        final mode = (d.data()['mediaMode'] ?? '').toString();
        final sameKind = mediaMode == 'audio'
            ? mode == 'audio'
            : (mode == 'video' || mode == 'live');
        if (sameKind) {
          try {
            await d.reference.update({'isLive': false});
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  Future<void> endLiveRoom(String roomId) async {
    await db.collection('rooms').doc(roomId).update({'isLive': false});
  }

  Future<String> createRoom(String name, {bool isPublic = true, String category = 'Amizades', String description = '', String password = '', bool isLive = false, String mediaMode = 'text', bool isVipRoom = false}) async {
    final clean = name.trim();
    if (clean.length < 3 || clean.length > 40) {
      throw Exception('O nome da sala deve ter entre 3 e 40 caracteres.');
    }
    if (isLive && (mediaMode == 'audio' || mediaMode == 'video')) {
      await endMyOtherLives(mediaMode);
    }
    if (!isPublic && password.trim().length < 4) {
      throw Exception('A senha da sala privada deve ter pelo menos 4 caracteres.');
    }
    final payload = <String, dynamic>{
      'name': clean,
      'ownerId': uid,
      'members': [uid],
      'isPublic': isPublic,
      'category': category,
      'description': description.trim(),
      'isLive': isLive,
      'isVipRoom': isVipRoom,
      'liveCoinEarnings': 0,
      'isLocked': false,
      'mediaMode': mediaMode,
      'passwordHash': isPublic ? null : sha256.convert(utf8.encode(password.trim())).toString(),
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': 'Sala criada. Dê boas-vindas!',
      'lastMessageAt': FieldValue.serverTimestamp(),
    };

    // Falhas "unavailable" são normalmente temporárias (rede/Firestore).
    // Repetimos apenas erros transitórios; nunca repetimos permission-denied.
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final ref = await db.collection('rooms').add(payload);
        return ref.id;
      } on FirebaseException catch (e) {
        final transient = e.code == 'unavailable' ||
            e.code == 'deadline-exceeded' || e.code == 'network-request-failed';
        if (!transient || attempt == 2) rethrow;
        await Future<void>.delayed(Duration(seconds: attempt + 1));
      }
    }
    throw Exception('Não foi possível criar a sala. Verifique sua conexão e tente novamente.');
  }

  /// Admin do app (mesma claim usada nas regras do Firestore).
  Future<bool> _isAdminClaim() async {
    try {
      final token = await FirebaseAuth.instance.currentUser?.getIdTokenResult(true);
      return token?.claims?['admin'] == true;
    } catch (_) {
      return false;
    }
  }

  /// O dono da sala pode promover ou remover administradores.
  Future<void> setRoomAdmin(String roomId, String targetUid, bool makeAdmin) async {
    if (targetUid == uid) throw Exception('O dono da sala já tem controle total.');
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      final data = snap.data() ?? <String, dynamic>{};
      if (data['ownerId'] != uid) throw Exception('Somente o dono pode gerenciar administradores.');
      final members = List<String>.from(data['members'] ?? const []);
      if (!members.contains(targetUid)) throw Exception('A pessoa não está mais na sala.');
      final admins = List<String>.from(data['roomAdmins'] ?? const []);
      if (makeAdmin) {
        if (!admins.contains(targetUid)) admins.add(targetUid);
      } else {
        admins.remove(targetUid);
      }
      tx.update(ref, {'roomAdmins': admins});
    });
  }

  /// Remove um participante, seus privilégios e seu assento. O dono não pode ser expulso.
  Future<void> kickRoomMember(String roomId, String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode expulsar o dono da sala.');
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      final data = snap.data() ?? <String, dynamic>{};
      if (data['ownerId'] != uid) throw Exception('Somente o dono pode expulsar participantes.');
      final members = List<String>.from(data['members'] ?? const []);
      if (!members.contains(targetUid)) throw Exception('A pessoa não está mais na sala.');
      members.remove(targetUid);
      final admins = List<String>.from(data['roomAdmins'] ?? const [])..remove(targetUid);
      tx.update(ref, {'members': members, 'roomAdmins': admins});
    });
    // Limpeza complementar: libera assento e marca a presença como encerrada.
    final seats = roomSeats(roomId);
    final occupied = await seats.where('uid', isEqualTo: targetUid).get();
    for (final seat in occupied.docs) { await seat.reference.delete(); }
    final participantRef = liveParticipants(roomId).doc(targetUid);
    final participantSnap = await participantRef.get();
    if (participantSnap.exists) {
      await participantRef.update({'isActive': false, 'leftAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> joinRoom(String roomId) async {
    final roomRef = db.collection('rooms').doc(roomId);
    await db.runTransaction((transaction) async {
      final snapshot = await transaction.get(roomRef);
      if (!snapshot.exists) throw Exception('Sala não encontrada.');
      final data = snapshot.data() ?? <String, dynamic>{};
      final members = List<String>.from(data['members'] ?? const []);
      if (members.contains(uid)) return;
      // Sala bloqueada: só o dono e os admins entram. Os demais não.
      final isRoomOwner = (data['ownerId'] ?? '').toString() == uid;
      if (data['isLocked'] == true && !isRoomOwner && !await _isAdminClaim()) {
        throw Exception('Esta sala está bloqueada pelo anfitrião.');
      }
      transaction.update(roomRef, {
        'members': FieldValue.arrayUnion([uid]),
      });
    });
  }

  CollectionReference<Map<String, dynamic>> roomSeats(String roomId) =>
      db.collection('rooms').doc(roomId).collection('seats');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchRoomSeats(String roomId) =>
      roomSeats(roomId).snapshots();

  Future<void> takeRoomSeat(String roomId, int seatNumber) async {
    if (seatNumber < 1 || seatNumber > 10) {
      throw Exception('Assento inválido.');
    }
    await joinRoom(roomId);
    final seats = roomSeats(roomId);
    await db.runTransaction((transaction) async {
      final refs = List.generate(10, (i) => seats.doc('${i + 1}'));
      final snapshots = <DocumentSnapshot<Map<String, dynamic>>>[];
      for (final ref in refs) {
        snapshots.add(await transaction.get(ref));
      }

      final targetIndex = seatNumber - 1;
      final targetData = snapshots[targetIndex].data();
      if (targetData != null && targetData['uid'] != uid) {
        throw Exception('Esse assento já está ocupado. Escolha outro.');
      }

      if (targetData?['uid'] == uid) {
        for (var i = 0; i < snapshots.length; i++) {
          if (i != targetIndex && snapshots[i].data()?['uid'] == uid) {
            transaction.delete(refs[i]);
          }
        }
        return;
      }

      for (var i = 0; i < snapshots.length; i++) {
        final data = snapshots[i].data();
        if (data != null && data['uid'] == uid) {
          transaction.delete(refs[i]);
        }
      }
      transaction.set(refs[targetIndex], {
        'uid': uid,
        'seatNumber': seatNumber,
        'micOn': false,
        'joinedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> leaveRoomSeat(String roomId) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    for (final seat in ownSeat.docs) {
      await seat.reference.delete();
    }
  }

  Future<void> setRoomSeatMic(String roomId, bool enabled) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    if (ownSeat.docs.isEmpty) return;
    await ownSeat.docs.first.reference.update({'micOn': enabled});
  }

  Future<void> sendRoomMessage(String roomId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 1000) return;
    final room = db.collection('rooms').doc(roomId);
    await roomMessages(roomId).add({
      'senderId': uid, 'text': clean, 'type': 'text',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await room.update({'lastMessage': clean, 'lastMessageAt': FieldValue.serverTimestamp()});
  }

  Future<void> sendRoomGift(String roomId, String recipientUid, String giftId,
      String emoji, String giftName) async {
    if (recipientUid.isEmpty) throw Exception('Escolha uma pessoa para receber o presente.');
    // A função segura no servidor valida o catálogo, cobra uma única vez,
    // credita o anfitrião e atualiza o baú sem depender das regras do cliente.
    final callable = FirebaseFunctions.instance.httpsCallable('sendRoomGift');
    await callable.call(<String, dynamic>{
      'roomId': roomId,
      'recipientUid': recipientUid,
      'giftId': giftId,
    });
  }

  /// Última chuva de alianças do baú da sala (aberta, resgatada ou expirada).
  Stream<QuerySnapshot<Map<String, dynamic>>> watchLatestDrop(String roomId) =>
      db.collection('rooms').doc(roomId).collection('drops')
          .orderBy('createdAt', descending: true).limit(1).snapshots();

  /// Tenta pegar a aliança da chuva. O servidor garante que só 1 pessoa leva.
  Future<void> claimRoomDrop(String roomId, String dropId) async {
    final callable = FirebaseFunctions.instance.httpsCallable('claimRoomDrop');
    await callable.call(<String, dynamic>{'roomId': roomId, 'dropId': dropId});
  }

  Future<void> blockUser(String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode bloquear sua própria conta.');
    await db.collection('users').doc(uid).collection('blocked').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> reportUser(String targetUid, String reason, {String details = ''}) async {
    final cleanReason = reason.trim();
    if (targetUid == uid || cleanReason.isEmpty) {
      throw Exception('Selecione um motivo válido para a denúncia.');
    }
    await db.collection('reports').add({
      'reporterId': uid,
      'reportedUserId': targetUid,
      'reason': cleanReason,
      'details': details.trim(),
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteMyAccount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(uid).delete();
    await user.delete();
  }

  /// Resgata um código promocional diretamente no Firestore, sem Cloud Functions.
  /// O claim e o crédito de moedas são gravados na mesma transação; as regras
  /// do Firestore validam a lista oficial e impedem reutilização por conta.
  Future<String> redeemPromoCode(String raw) async {
    final code = raw.trim().toUpperCase().replaceAll(RegExp(r'\s+'), '');
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para resgatar.');
    if (code.isEmpty) throw Exception('Digite o código.');

    const officialCodes = <String>{
      'LMX-7KQ2-M9XA',
      'LMX-4PZ8-R3WB',
      'LMX-9T6N-2KCY',
      'LMX-5XQ7-D4JA',
      'LMX-2H8W-6RTP',
      'LMX-8C3M-5YQF',
      'LMX-6J4V-9K2P',
      'LMX-3R7X-2N8D',
      'LMX-W5K9-T3Q2',
      'LMX-Q8D4-M7X1',
      'LMX-N2P6-R9W3',
      'LMX-Y7C5-K2J8',
      'LMX-D4T9-X6M1',
      'LMX-R8W3-Q5N2',
      'LMX-K6J2-P9V4',
      'LMX-X3M7-D5R8',
      'LMX-T9Q4-N6C2',
      'LMX-H5V8-K3P7',
      'LMX-M2R6-X9D4',
      'LMX-C7W3-J8Q5',
      'LMX-83GJ-WC8T-ACFJ',
      'LMX-ACN7-ZRCT-4XL7',
      'LMX-B85G-GBNG-5QCT',
      'LMX-V34D-ZLFT-L94C',
      'LMX-WZC5-APJT-LBDK',
      'LMX-FTVR-WM49-4L89',
      'LMX-82R6-KGWG-LY7D',
      'LMX-M9PB-XNPB-5TTH',
      'LMX-7DMT-KPRE-QB74',
      'LMX-69XS-HJK3-GGFB',
      'LMX-FDFD-RNWH-QZMC',
      'LMX-8SVT-2CLF-V2ZJ',
      'LMX-NWLZ-WFH7-7NZW',
      'LMX-FKTT-BUQX-4LYK',
      'LMX-VCLP-7L2A-SZR9',
      'LMX-T6YE-8H6U-ZKXU',
      'LMX-X5ND-KRXN-NBXT',
      'LMX-ZTCS-25RV-MEZN',
      'LMX-FT52-AVGA-WM9W',
      'LMX-GHGC-GL8Q-NZ9V',
      'LMX-SZ3M-MYR4-4NC2',
      'LMX-HQUL-9QDC-DHBY',
      'LMX-2QYD-XHKQ-3AZL',
      'LMX-NDE8-625J-K5PF',
      'LMX-PNW5-U649-7VQ2',
      'LMX-LTWZ-9PAQ-9SKY',
      'LMX-GNQC-ZDZA-7SNJ',
      'LMX-5WXM-7B5L-RBFX',
      'LMX-6ZQG-TMFE-9YSQ',
      'LMX-VSCL-CWLD-NJGF',
      'LMX-37SY-LVHF-Y9X7',
      'LMX-RNG3-C9VX-JCY9',
      'LMX-87VY-3SBA-4PJ2',
      'LMX-FMHA-6KBJ-DB8M',
      'LMX-GQM4-FDY3-CULR',
      'LMX-C5JR-QNKV-LAQP',
      'LMX-SCKZ-6AU8-FWMY',
      'LMX-HVA3-WGJ9-R8PZ',
      'LMX-DBWJ-KSAN-BELT',
      'LMX-2JBG-PP9F-WK5A',
      'LMX-2ZAX-FQ4L-VVDA',
      'LMX-M56P-YNEQ-EEYB',
      'LMX-F8V9-T7QY-RG3U',
      'LMX-H896-BXK4-SDHW',
      'LMX-94UQ-ZV4L-8Z24',
      'LMX-KVQ9-DJW6-CGZ3',
      'LMX-VD4P-GJX4-AJTT',
      'LMX-G8Q6-WKML-LD9P',
      'LMX-ERQS-KVNA-DRXB',
      'LMX-57ZC-4GWD-3W69',
      'LMX-5NHX-XHYG-KKH4',
      'LMX-GDGB-VUMR-NH54',
      'LMX-AE8N-QK7Y-2ZRD',
      'LMX-NWUT-ZD3G-9JLF',
      'LMX-5CHF-STVU-VTM5',
      'LMX-6A75-73QP-4SXG',
      'LMX-P7AR-2M8E-F78Y',
      'LMX-7MWB-7LS8-NRKP',
      'LMX-G7A8-59WM-H7Z5',
      'LMX-4VNS-RJAK-9FX9',
      'LMX-A9L8-URY5-LVD5',
      'LMX-2CS3-N3LV-LQAA',
      'LMX-DF54-92AF-7BRR',
      'LMX-ZBVS-UR26-H97D',
      'LMX-95TJ-8VGD-L7HC',
      'LMX-EMT2-9N2G-C8C6',
      'LMX-T52R-5NLE-VTKP',
      'LMX-R5BT-28BR-P2QY',
      'LMX-TM6G-SQ94-NA3C',
      'LMX-M5WU-WJXW-NPCT',
      'LMX-28JL-QBW8-XFVK',
      'LMX-YNCS-6ZKG-4QMF',
      'LMX-BHSX-4L3R-944S',
      'LMX-KXXP-JE4J-7V96',
      'LMX-X2HZ-G5AW-C8KY',
      'LMX-9KN7-B6TP-MYSU',
      'LMX-BDU8-C2CG-42V8',
      'LMX-T3QU-UYBE-ZBCJ',
      'LMX-BR9E-LALT-4GHX',
      'LMX-R2F5-3U6C-7J46',
      'LMX-9AAH-PX6R-CQBK',
      'LMX-S3LG-S4EU-S96W',
      'LMX-R65F-GS4S-BXCP',
      'LMX-6SJG-BKFB-EU82',
      'LMX-XEM9-LQP5-AJ6D',
      'LMX-XSXG-3BW8-JY7G',
      'LMX-3J3D-JAZC-9CPL',
      'LMX-R3DK-SPE8-A3W5',
      'LMX-9UWD-3BZS-UXP8',
      'LMX-3Q3X-3WTC-6DZU',
      'LMX-5T2V-325G-KV8Z',
      'LMX-NVYJ-Q94C-WZJR',
      'LMX-7TJG-KBZ2-EAJ7',
      'LMX-CLNQ-RWGD-WEE5',
      'LMX-XZK6-X6WL-KBBF',
      'LMX-PFBY-9H9K-HXHE',
      'LMX-P6M8-5FDW-XNZD',
      'LMX-9WS7-F7FX-YPBM',
      'LMX-G937-Q6ES-ZQA8',
      'LMX-TL4U-YC6P-Y3Y3',
    };
    if (!officialCodes.contains(code)) throw Exception('Código inválido. Confira e tente novamente.');

    final userRef = db.collection('users').doc(user.uid);
    final claimRef = db.collection('promoCodeClaims').doc('${user.uid}_$code');
    try {
      await db.runTransaction((tx) async {
        final claim = await tx.get(claimRef);
        if (claim.exists) {
          throw Exception('Você já resgatou este código nesta conta.');
        }
        final profile = await tx.get(userRef);
        if (!profile.exists) throw Exception('Perfil não encontrado.');
        final data = profile.data() ?? <String, dynamic>{};
        final currentCoins = (data['coins'] as num?)?.toInt() ?? 0;
        tx.set(claimRef, {
          'uid': user.uid,
          'code': code,
          'rewardCoins': 2000,
          'redeemedAt': FieldValue.serverTimestamp(),
        });
        tx.update(userRef, {'coins': currentCoins + 2000, 'lastRedeemCode': code});
      });
      return 'coins';
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw Exception('O Firebase bloqueou o resgate. Publique as novas regras do Firestore e tente novamente.');
      }
      rethrow;
    }
  }

  /// Envia um presente diretamente para o UID do perfil e registra o presente
  /// como mensagem especial na conversa privada. O débito e a mensagem são
  /// gravados na mesma transação para evitar cobrança sem entrega.
  Future<void> sendDirectGift({
    required String chatId,
    required String recipientUid,
    required String giftId,
  }) async {
    if (recipientUid.isEmpty || recipientUid == uid) {
      throw Exception('Escolha outra pessoa para receber o presente.');
    }
    final allGifts = <Map<String, dynamic>>[...kRoomGifts, ...kAllianceRings];
    final gift = allGifts.firstWhere(
      (item) => item['id'] == giftId,
      orElse: () => throw Exception('Presente não encontrado.'),
    );
    final cost = (gift['cost'] as num).toInt();
    final currency = (gift['currency'] ?? 'coins').toString();
    final senderRef = db.collection('users').doc(uid);
    final recipientRef = db.collection('users').doc(recipientUid);
    final chatRef = db.collection('chats').doc(chatId);
    final messageRef = chatRef.collection('messages').doc();

    await db.runTransaction((tx) async {
      final senderSnap = await tx.get(senderRef);
      final recipientSnap = await tx.get(recipientRef);
      final chatSnap = await tx.get(chatRef);
      if (!senderSnap.exists || !recipientSnap.exists || !chatSnap.exists) {
        throw Exception('Perfil ou conversa não encontrado.');
      }
      final chatUsers = List<String>.from(chatSnap.data()?['users'] ?? const []);
      if (!chatUsers.contains(uid) || !chatUsers.contains(recipientUid)) {
        throw Exception('Esta conversa não pertence a essas pessoas.');
      }
      final balanceField = currency == 'diamonds' ? 'diamonds' : 'coins';
      final balance = (senderSnap.data()?[balanceField] as num?)?.toInt() ?? 0;
      if (balance < cost) {
        throw Exception(currency == 'diamonds'
            ? 'Diamantes insuficientes.' : 'Moedas insuficientes.');
      }
      final emoji = (gift['emoji'] ?? '🎁').toString();
      final name = (gift['name'] ?? 'Presente').toString();
      final label = '$emoji $name';
      tx.update(senderRef, {balanceField: balance - cost});
      tx.update(chatRef, {
        'lastMessage': '🎁 Você enviou $label',
        'lastMessageAt': FieldValue.serverTimestamp(),
      });
      tx.set(messageRef, {
        'senderId': uid,
        'recipientUid': recipientUid,
        'type': 'gift',
        'text': '🎁 Você recebeu $label',
        'giftId': giftId,
        'giftEmoji': emoji,
        'giftName': name,
        'giftCost': cost,
        'giftCurrency': currency,
        'createdAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> sendMessage(String chatId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    final chat = db.collection('chats').doc(chatId);
    // O chat é criado pela Cloud Function no momento do match.
    // Aqui atualizamos somente o chat existente; não criamos conversas arbitrárias.
    await chat.update({
      'lastMessage': clean,
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    await messages(chatId).add({
      'senderId': uid,
      'text': clean,
      'createdAt': FieldValue.serverTimestamp(),
      'type': 'text',
    });
  }
}
