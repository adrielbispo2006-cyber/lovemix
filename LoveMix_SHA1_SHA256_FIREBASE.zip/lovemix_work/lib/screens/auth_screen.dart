import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../services/data_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool showEmailForm = false;
  bool busy = false;
  bool obscurePassword = true;
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  DateTime? birthday;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  bool _isAdult(DateTime date) {
    final today = DateTime.now();
    final age = today.year - date.year -
        ((today.month < date.month ||
                (today.month == date.month && today.day < date.day))
            ? 1
            : 0);
    return age >= 18;
  }

  Future<DateTime?> _askBirthday() async {
    final now = DateTime.now();
    return showDatePicker(
      context: context,
      firstDate: DateTime(1900),
      lastDate: DateTime(now.year - 18, now.month, now.day),
      initialDate: DateTime(now.year - 25, now.month, now.day),
      helpText: 'Confirme que você tem 18 anos ou mais',
    );
  }

  Future<void> _claimFounderIfEligible() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email?.toLowerCase() != 'adrielbispo3009@gmail.com' || !user.emailVerified && user.providerData.every((p) => p.providerId != 'google.com')) return;
    try {
      await FirebaseFunctions.instance.httpsCallable('claimFounderAdmin').call();
    } catch (_) {
      // A função só fica disponível depois de publicar as Cloud Functions.
      // O login normal continua funcionando enquanto isso.
    }
  }

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      show('Informe seu e-mail e sua senha.');
      return;
    }
    if (register && name.text.trim().isEmpty) {
      show('Informe seu nome.');
      return;
    }
    if (register && birthday == null) {
      show('Informe sua data de nascimento.');
      return;
    }
    if (register && !_isAdult(birthday!)) {
      show('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }

    setState(() => busy = true);
    try {
      if (register) {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await cred.user!.updateDisplayName(name.text.trim());
        await DataService.instance.createUser(
          name: name.text.trim(),
          birthday: birthday!,
        );
        await _claimFounderIfEligible();
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await _claimFounderIfEligible();
      }
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } catch (e) {
      show('Não foi possível concluir. Verifique sua internet e tente novamente.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  // O ID OAuth WEB é injetado pelo workflow a partir do google-services.json.
  // O valor padrão mantém compatibilidade com builds locais deste projeto.
  static const String _googleServerClientId = String.fromEnvironment(
    'GOOGLE_SERVER_CLIENT_ID',
    defaultValue: '985069046748-eb17v8ri34e4c9l5kevua27kt0ibgj50.apps.googleusercontent.com',
  );

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    serverClientId: _googleServerClientId,
    scopes: const ['email'],
  );

  Future<void> signInGoogle() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      // O seletor nativo do Google funciona com a configuração OAuth Android.
      // Usa o cliente WEB correspondente ao google-services.json do build.
      // O cliente Android é selecionado pelo pacote + SHA-1 da assinatura.
      await _googleSignIn.signOut();
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return; // O usuário cancelou.

      final googleAuth = await googleUser.authentication;
      if (googleAuth.idToken == null || googleAuth.idToken!.isEmpty) {
        throw Exception(
          'O Google não retornou um ID token. Confira o cliente OAuth WEB e o SHA-1/SHA-256 da assinatura deste APK no Firebase.',
        );
      }
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final result = await FirebaseAuth.instance.signInWithCredential(credential);
      final user = result.user;
      if (user == null) throw Exception('Não foi possível obter a conta Google.');

      // Cria o perfil no Firestore somente na primeira entrada e solicita
      // data de nascimento para respeitar a regra de uso para maiores de 18.
      final profile = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (!profile.exists) {
        if (!mounted) return;
        final date = await _askBirthday();
        if (date == null) {
          await FirebaseAuth.instance.signOut();
          await _googleSignIn.signOut();
          show('Para criar sua conta, confirme sua data de nascimento.');
          return;
        }
        if (!_isAdult(date)) {
          await FirebaseAuth.instance.signOut();
          await _googleSignIn.signOut();
          show('O LoveMix é destinado somente a maiores de 18 anos.');
          return;
        }
        final displayName = (user.displayName ?? '').trim();
        final fallbackName = user.email?.split('@').first ?? 'Pessoa LoveMix';
        await DataService.instance.createUser(
          name: displayName.isEmpty ? fallbackName : displayName,
          birthday: date,
        );
      }
      await _claimFounderIfEligible();
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } on PlatformException catch (e) {
      final details = '${e.code}: ${e.message ?? e.details ?? 'sem detalhes'}';
      if (details.contains('10') ||
          details.contains('DEVELOPER_ERROR') ||
          details.contains('sign_in_failed')) {
        show('O Google recusou este APK (DEVELOPER_ERROR). O pacote deve ser com.example.lovemix e o SHA-1 da chave que assinou este APK precisa estar cadastrado no Firebase. Depois baixe um novo google-services.json e gere outro APK. Detalhe: $details');
      } else {
        show('Falha no seletor do Google ($details). Atualize o Google Play Services e tente novamente.');
      }
    } catch (e) {
      show('Não foi possível concluir o login Google: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _authError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'O e-mail informado é inválido.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'E-mail ou senha incorretos.';
      case 'email-already-in-use':
        return 'Este e-mail já possui uma conta. Tente entrar.';
      case 'weak-password':
        return 'Escolha uma senha com pelo menos 6 caracteres.';
      case 'network-request-failed':
        return 'Sem conexão. Verifique sua internet e tente novamente.';
      case 'operation-not-allowed':
        return 'Este método de login ainda não foi ativado no Firebase.';
      case 'configuration-not-found':
        return 'Configuração de autenticação ausente no Firebase. Confira o provedor e as configurações do aplicativo.';
      default:
        return e.message ?? 'Não foi possível autenticar. Tente novamente.';
    }
  }

  void show(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _openEmailForm({bool createAccount = false}) {
    setState(() {
      showEmailForm = true;
      register = createAccount;
    });
  }

  Widget _buildLanding(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: const Color(0xFF07020D),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment(0, -0.25),
                    radius: 1.0,
                    colors: [Color(0xFF26002F), Color(0xFF0B0312), Color(0xFF050208)],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 12, left: 10, right: 10, bottom: 12,
              child: IgnorePointer(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: const Color(0xFFB000FF).withValues(alpha: .72), width: 2),
                    boxShadow: [
                      BoxShadow(color: const Color(0xFFB000FF).withValues(alpha: .34), blurRadius: 20, spreadRadius: 2),
                      BoxShadow(color: const Color(0xFFFF16B8).withValues(alpha: .18), blurRadius: 34, spreadRadius: 1),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(top: 95, left: 18, child: _neonHeart(38)),
            Positioned(top: 105, right: 24, child: _neonHeart(34)),
            Positioned(top: size.height * .31, left: 16, child: _neonHeart(30)),
            Positioned(top: size.height * .40, right: 16, child: _neonHeart(32)),
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(28, 30, 28, 28),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(
                  children: [
                    SizedBox(
                      height: size.height < 760 ? 148 : 170,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Positioned(
                            top: 0,
                            child: Icon(Icons.workspace_premium, size: 55, color: const Color(0xFFFFC84A),
                              shadows: [Shadow(color: const Color(0xFFFFB52E).withValues(alpha: .75), blurRadius: 20)]),
                          ),
                          Positioned(
                            top: 42,
                            child: ShaderMask(
                              shaderCallback: (bounds) => const LinearGradient(
                                colors: [Color(0xFFFF22B8), Color(0xFF8C28FF), Color(0xFFFF22B8)],
                              ).createShader(bounds),
                              child: const Icon(Icons.all_inclusive, size: 142, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Colors.white, Color(0xFFFF38C3), Color(0xFFB44AFF)],
                      ).createShader(bounds),
                      child: const Text(
                        'LoveMix',
                        style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, color: Colors.white, height: 1),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Conecte-se. Faça amizades.\nEncontre seu amor! 💗',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 17, height: 1.35, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 26),
                    Container(
                      height: size.height < 760 ? 255 : 330,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: const Color(0xFFFF28C0).withValues(alpha: .55), width: 1.5),
                        boxShadow: [BoxShadow(color: const Color(0xFFFF16C8).withValues(alpha: .28), blurRadius: 25, spreadRadius: 2)],
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.asset('assets/lovemix_couple.jpg', fit: BoxFit.cover),
                          const DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Colors.transparent, Color(0x1107000D), Color(0xAA07000D)],
                                stops: [0, .62, 1],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFFFF20B6), Color(0xFFDB00A8)]),
                          borderRadius: BorderRadius.circular(32),
                          boxShadow: [BoxShadow(color: const Color(0xFFFF18B8).withValues(alpha: .42), blurRadius: 18, spreadRadius: 1)],
                        ),
                        child: ElevatedButton.icon(
                          onPressed: busy ? null : signInGoogle,
                          icon: const Icon(Icons.g_mobiledata, size: 34, color: Colors.white),
                          label: Text(busy ? 'Conectando...' : 'Entrar com Google', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                            foregroundColor: Colors.white, shape: const StadiumBorder(),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 13),
                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: OutlinedButton.icon(
                        onPressed: busy ? null : () => _openEmailForm(),
                        icon: const Icon(Icons.email_rounded, color: Color(0xFFD9B8FF), size: 27),
                        label: const Text('Entrar com E-mail', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Color(0xFFE7D5FF), width: 1.6),
                          shape: const StadiumBorder(),
                          backgroundColor: Colors.black.withValues(alpha: .22),
                        ),
                      ),
                    ),
                    const SizedBox(height: 13),
                    SizedBox(
                      width: double.infinity,
                      height: 58,
                      child: OutlinedButton(
                        onPressed: busy ? null : () => _openEmailForm(createAccount: true),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Color(0xFF9A35FF), width: 1.8),
                          backgroundColor: const Color(0xFF4B087A).withValues(alpha: .48),
                          shape: const StadiumBorder(),
                          shadowColor: const Color(0xFF9B2CFF),
                        ),
                        child: const Text('Criar Conta', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextButton(
                      onPressed: busy ? null : () => _openEmailForm(),
                      child: const Text('Entrar Agora', style: TextStyle(color: Color(0xFFE9D7FF), fontSize: 17, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 2),
                    const Text('Acesso exclusivo para maiores de 18 anos', style: TextStyle(color: Colors.white38, fontSize: 11)),
                  ],
                ),
              ),
            ),
            if (busy)
              Positioned.fill(
                child: Container(
                  color: Colors.black.withValues(alpha: .28),
                  child: const Center(child: CircularProgressIndicator(color: Color(0xFFFF28B8))),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _neonHeart(double size) {
    return Icon(
      Icons.favorite_border_rounded,
      size: size,
      color: const Color(0xFFFF20C0),
      shadows: [
        Shadow(color: const Color(0xFFFF20C0).withValues(alpha: .9), blurRadius: 14),
        Shadow(color: const Color(0xFF9B28FF).withValues(alpha: .7), blurRadius: 22),
      ],
    );
  }

  Widget _buildEmailForm(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF08030E),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFFF35BC)),
          onPressed: () => setState(() { showEmailForm = false; register = false; }),
        ),
        title: const Text('LoveMix', style: TextStyle(color: Color(0xFFFF35BC), fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                children: [
                  Container(
                    width: 88, height: 88,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(colors: [Color(0xFFFF19B8), Color(0xFF762BFF)]),
                      boxShadow: [BoxShadow(color: const Color(0xFFFF19B8).withValues(alpha: .35), blurRadius: 30, spreadRadius: 4)],
                    ),
                    child: const Icon(Icons.all_inclusive, color: Colors.white, size: 58),
                  ),
                  const SizedBox(height: 12),
                  const Text('LoveMix', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: Color(0xFFFF2DAB), fontStyle: FontStyle.italic)),
                  const Text('Conecte-se. Faça amizades.\nEncontre seu amor! 💗', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.35)),
                  const SizedBox(height: 28),
                  Text(register ? 'Criar uma conta' : 'Boas-vindas de volta', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 18),
                  if (register) ...[
                    TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Nome completo', prefixIcon: Icon(Icons.person_outline))),
                    const SizedBox(height: 12),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(hintText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: obscurePassword,
                    autofillHints: register ? const [AutofillHints.newPassword] : const [AutofillHints.password],
                    decoration: InputDecoration(
                      hintText: 'Senha',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => obscurePassword = !obscurePassword),
                        icon: Icon(obscurePassword ? Icons.visibility : Icons.visibility_off),
                      ),
                    ),
                  ),
                  if (register) ...[
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: busy ? null : () async {
                        final d = await _askBirthday();
                        if (d != null && mounted) setState(() => birthday = d);
                      },
                      icon: const Icon(Icons.calendar_month),
                      label: Text(birthday == null ? 'Data de nascimento (18+)' : '${birthday!.day}/${birthday!.month}/${birthday!.year}'),
                    ),
                  ],
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: busy ? null : submit,
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF22B7), foregroundColor: Colors.white, shape: const StadiumBorder()),
                      child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(register ? 'Criar minha conta' : 'Entrar'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(children: [
                    const Expanded(child: Divider(color: Colors.white24)),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('OU', style: TextStyle(color: Colors.white.withValues(alpha: .55), fontSize: 12))),
                    const Expanded(child: Divider(color: Colors.white24)),
                  ]),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: busy ? null : signInGoogle,
                    icon: const Icon(Icons.g_mobiledata, size: 30, color: Color(0xFFFF2DAB)),
                    label: const Text('Continuar com Google'),
                    style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50), foregroundColor: const Color(0xFFFF2DAB), side: const BorderSide(color: Color(0xFFFF2DAB)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28))),
                  ),
                  TextButton(
                    onPressed: busy ? null : () => setState(() => register = !register),
                    child: Text(register ? 'Já tem uma conta? Entrar' : 'Não tem uma conta? Criar conta'),
                  ),
                  if (!register)
                    TextButton(
                      onPressed: busy ? null : () async {
                        if (email.text.trim().isEmpty) return show('Digite seu e-mail primeiro.');
                        try {
                          await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
                          show('Enviamos um link de recuperação para seu e-mail.');
                        } on FirebaseAuthException catch (e) {
                          show(_authError(e));
                        }
                      },
                      child: const Text('Esqueci minha senha'),
                    ),
                  const SizedBox(height: 8),
                  const Text('Acesso exclusivo para maiores de 18 anos', style: TextStyle(color: Colors.white38, fontSize: 11)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return showEmailForm ? _buildEmailForm(context) : _buildLanding(context);
  }
}
