import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'gifts_screen.dart';
import 'post_interactions_screen.dart';
import '../widgets/full_photo.dart';
import '../widgets/vip_nickname.dart';

const _profilePink = Color(0xFFB54CFF);
const _profilePurple = Color(0xFF8B35FF);
const _profileSilver = Color(0xFFD9DCE8);
const _profilePanel = Color(0xFF100D18);

class ProfileViewScreen extends StatefulWidget {
  const ProfileViewScreen({super.key, required this.userId});
  final String userId;

  @override
  State<ProfileViewScreen> createState() => _ProfileViewScreenState();
}

class _ProfileViewScreenState extends State<ProfileViewScreen> {
  late Future<DocumentSnapshot<Map<String, dynamic>>> _profileFuture;
  late Future<bool> _matchFuture;

  @override
  void initState() {
    super.initState();
    _profileFuture = FirebaseFirestore.instance.collection('users').doc(widget.userId).get();
    _matchFuture = _checkMatch();
  }

  Future<bool> _checkMatch() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null || uid == widget.userId) return false;
    final matches = await FirebaseFirestore.instance.collection('matches')
        .where('users', arrayContains: uid).get();
    return matches.docs.any((d) => List<String>.from(d.data()['users'] ?? []).contains(widget.userId));
  }

  int? _age(DateTime? birthday) {
    if (birthday == null) return null;
    final now = DateTime.now();
    var age = now.year - birthday.year;
    if (now.month < birthday.month || (now.month == birthday.month && now.day < birthday.day)) age--;
    return age;
  }

  String _place(Map<String, dynamic> p) {
    final city = (p['city'] ?? '').toString().trim();
    final country = (p['country'] ?? '').toString().trim();
    if (city.isEmpty) return country;
    if (country.isEmpty) return city;
    if (country.toLowerCase() == 'brasil' && city.contains('-')) return city;
    return '$city • $country';
  }

  String _genderSymbol(String gender) => const {
    'woman': '♀', 'man': '♂', 'non_binary': '⚧', 'other': '✦',
  }[gender] ?? '';

  @override
  Widget build(BuildContext context) {
    final currentUid = FirebaseAuth.instance.currentUser?.uid ?? '';
    final isOwner = currentUid == widget.userId;
    return Scaffold(
      backgroundColor: const Color(0xFF05040A),
      appBar: AppBar(
        title: const Text('LoveMix', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .5)),
        backgroundColor: const Color(0xFF080510),
        actions: [
          if (!isOwner) PopupMenuButton<String>(
            onSelected: (value) => value == 'report' ? _report(context) : _block(context),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'report', child: Text('Denunciar perfil')),
              PopupMenuItem(value: 'block', child: Text('Bloquear usuário')),
            ],
          ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: _profileFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: _profilePink));
          }
          if (snap.hasError || !snap.hasData || !snap.data!.exists) {
            return const Center(child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Este perfil está indisponível ou é privado.', textAlign: TextAlign.center),
            ));
          }
          final p = snap.data!.data() ?? <String, dynamic>{};
          final cover = (p['profileCoverUrl'] ?? '').toString();
          final photo = cover.isNotEmpty ? cover : (p['photoUrl'] ?? '').toString();
          final birthday = p['birthday'] is Timestamp ? (p['birthday'] as Timestamp).toDate() : null;
          final age = _age(birthday);
          final location = _place(p);
          final gender = (p['gender'] ?? '').toString();
          final genderSymbol = _genderSymbol(gender);
          final interests = List<String>.from(p['interests'] ?? const []);
          final bio = (p['bio'] ?? '').toString().trim();
          final online = p['isOnline'] == true;
          final name = (p['name'] ?? 'Pessoa').toString();

          return FutureBuilder<bool>(
            future: _matchFuture,
            builder: (context, matchSnap) {
              final isMatched = matchSnap.data == true;
              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF05030A),
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: _profileSilver.withOpacity(.72), width: 1.2),
                      boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.28), blurRadius: 22), BoxShadow(color: _profileSilver.withOpacity(.08), blurRadius: 8)],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(16, 22, 16, 18),
                        decoration: const BoxDecoration(gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFF25103B), Color(0xFF100A19), Color(0xFF05030A)],
                        )),
                        child: Column(children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(15),
                            child: photo.isEmpty
                                ? const SizedBox(
                                    width: double.infinity, height: 230,
                                    child: ColoredBox(color: _profilePanel, child: Icon(Icons.person, size: 82, color: Colors.white54)))
                                : FullProfilePhoto(url: photo),
                          ),
                          const SizedBox(height: 14),
                          // Perfil de visitante sem moldura decorativa: a foto principal
                          // permanece em destaque e pode ser aberta em tela cheia.
                          if (p['isVip'] == true)
                            const Align(alignment: Alignment.centerRight,
                              child: Icon(Icons.workspace_premium, color: Color(0xFFFFC247), size: 30)),
                          const SizedBox(height: 14),
                          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Flexible(child: VipNickname(name: name, isVip: (p['isVip'] == true || p['nicknameDecorationActive'] == true), styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
                            if (genderSymbol.isNotEmpty) ...[
                              const SizedBox(width: 7),
                              Text(genderSymbol, style: const TextStyle(color: _profilePink, fontSize: 23, fontWeight: FontWeight.bold)),
                            ],
                            if (p['isVerified'] == true) ...[
                              const SizedBox(width: 6),
                              const Icon(Icons.verified, color: Color(0xFF55A8FF), size: 21),
                            ],
                          ]),
                          const SizedBox(height: 4),
                          if (age != null || location.isNotEmpty)
                            Text([
                              if (age != null) '$age anos',
                              if (location.isNotEmpty) location,
                            ].join(' • '), textAlign: TextAlign.center,
                              style: const TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w500)),
                          const SizedBox(height: 7),
                          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.circle, size: 9, color: online ? Colors.greenAccent : Colors.white30),
                            const SizedBox(width: 6),
                            Text(online ? 'Online' : 'Offline', style: TextStyle(color: online ? Colors.greenAccent : Colors.white54, fontSize: 12)),
                            if (p['isVip'] == true) ...[
                              const SizedBox(width: 8),
                              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: _profilePurple.withOpacity(.35), borderRadius: BorderRadius.circular(20)), child: const Text('VIP 👑', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold))),
                            ],
                          ]),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(.06),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _profileSilver.withOpacity(.42)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.fingerprint, color: _profilePink, size: 18),
                                const SizedBox(width: 7),
                                const Text('ID:', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: SelectableText(
                                    (p['publicId'] ?? '--------').toString(),
                                    maxLines: 1,
                                    style: const TextStyle(color: Colors.white, fontSize: 11),
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'Copiar ID de aliança',
                                  visualDensity: VisualDensity.compact,
                                  padding: EdgeInsets.zero,
                                  constraints: const BoxConstraints(minWidth: 34, minHeight: 34),
                                  icon: const Icon(Icons.copy, color: _profilePink, size: 18),
                                  onPressed: () async {
                                    await Clipboard.setData(ClipboardData(text: (p['publicId'] ?? '').toString()));
                                    if (!context.mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('ID de aliança copiado!')),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ]),
                      ),
                      if (interests.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(14, 2, 14, 10),
                          child: Wrap(spacing: 7, runSpacing: 7, alignment: WrapAlignment.center,
                            children: interests.map((interest) => Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                              decoration: BoxDecoration(color: const Color(0xFF21142E), borderRadius: BorderRadius.circular(20), border: Border.all(color: _profileSilver.withOpacity(.55))),
                              child: Text(interest, style: const TextStyle(fontSize: 11, color: Colors.white)),
                            )).toList()),
                        ),
                      if (bio.isNotEmpty)
                        Padding(padding: const EdgeInsets.fromLTRB(16, 5, 16, 16),
                          child: Text(bio, style: const TextStyle(color: Colors.white, height: 1.4, fontSize: 14))),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  _profileStats(),
                  const SizedBox(height: 14),
                  if (!isOwner) ...[
                    _profileLikeButton(context),
                    const SizedBox(height: 10),
                    Row(children: [
                    Expanded(child: SizedBox(height: 50, child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      stream: DataService.instance.followingStatus(widget.userId),
                      builder: (context, followSnap) {
                        final following = followSnap.data?.exists == true;
                        return ElevatedButton.icon(
                          onPressed: followSnap.connectionState == ConnectionState.waiting
                              ? null : () => _toggleFollow(context),
                          icon: Icon(following ? Icons.check : Icons.person_add_alt_1, color: Colors.white),
                          label: Text(following ? 'Seguindo' : 'Seguir'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: following ? const Color(0xFF49345B) : _profilePink,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                          ),
                        );
                      },
                    ))),
                    const SizedBox(width: 10),
                    Expanded(child: SizedBox(height: 50, child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      stream: DataService.instance.followingStatus(widget.userId),
                      builder: (context, followSnap) {
                        final following = followSnap.data?.exists == true;
                        return OutlinedButton.icon(
                          onPressed: following ? () => _openChat(context, name) : null,
                          icon: const Icon(Icons.chat_bubble, color: Colors.white),
                          label: Text(following ? 'Mensagem' : 'Siga para conversar',
                            style: const TextStyle(color: Colors.white),
                            overflow: TextOverflow.ellipsis),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: _profilePink, width: 1.5),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                          ),
                        );
                      },
                    ))),
                  ]),
                  ],
                  if (!isOwner) ...[
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton.icon(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: widget.userId))),
                        icon: const Icon(Icons.card_giftcard, color: Colors.white),
                        label: const Text('Enviar presente', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        style: ElevatedButton.styleFrom(backgroundColor: _profilePurple, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26))),
                      ),
                    ),
                  ],
                  const SizedBox(height: 22),
                  _receivedGiftsSection(),
                  const SizedBox(height: 22),
                  Row(children: [
                    const Text('Fotos publicadas', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                    const Spacer(),
                    Text('Galeria', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12)),
                  ]),
                  const SizedBox(height: 10),
                  _photosGallery(isOwner: isOwner, canSeeFriends: isMatched),
                  if (!isOwner) ...[
                    const SizedBox(height: 24),
                    OutlinedButton.icon(onPressed: () => _report(context), icon: const Icon(Icons.flag_outlined), label: const Text('Denunciar perfil')),
                    OutlinedButton.icon(onPressed: () => _block(context), icon: const Icon(Icons.block), label: const Text('Bloquear usuário')),
                  ],
                ],
              );
            },
          );
        },
      ),
    );
  }

  Widget _profileStats() {
    final user = FirebaseFirestore.instance.collection('users').doc(widget.userId);
    return Row(children: [
      Expanded(child: _liveStat(user.collection('followers'), Icons.people_alt_rounded, 'Seguidores')),
      const SizedBox(width: 8),
      Expanded(child: _liveStat(user.collection('following'), Icons.person_add_alt_1_rounded, 'Seguindo')),
      const SizedBox(width: 8),
      Expanded(child: _liveStat(user.collection('profileLikes'), Icons.favorite_rounded, 'Curtidas')),
    ]);
  }

  Widget _liveStat(Query<Map<String, dynamic>> query, IconData icon, String label) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: query.snapshots(),
      builder: (context, snap) {
        final count = snap.data?.docs.length ?? 0;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 5),
          decoration: BoxDecoration(
            color: const Color(0xFF100B18),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _profileSilver.withOpacity(.38)),
            boxShadow: [BoxShadow(color: _profilePurple.withOpacity(.16), blurRadius: 12)],
          ),
          child: Column(children: [
            Icon(icon, color: _profilePurple, size: 23),
            const SizedBox(height: 4),
            Text('$count', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _profileSilver, fontSize: 10)),
          ]),
        );
      },
    );
  }

  Widget _receivedGiftsSection() {
    final gifts = FirebaseFirestore.instance.collection('users').doc(widget.userId)
        .collection('receivedGifts').orderBy('createdAt', descending: true).limit(60);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Icon(Icons.card_giftcard, color: _profilePink, size: 21),
        const SizedBox(width: 8),
        const Text('Presentes recebidos', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      ]),
      const SizedBox(height: 10),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: gifts.snapshots(),
        builder: (context, snap) {
          if (snap.hasError) {
            return const Text('Não foi possível carregar os presentes.', style: TextStyle(color: Colors.white60));
          }
          if (!snap.hasData) {
            return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator(color: _profilePink)));
          }
          final docs = snap.data!.docs;
          if (docs.isEmpty) {
            return Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 12),
              decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
              child: const Column(children: [
                Icon(Icons.redeem, color: _profilePurple, size: 32),
                SizedBox(height: 7),
                Text('Ainda não recebeu presentes', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
              ]),
            );
          }
          return GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: docs.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .9,
            ),
            itemBuilder: (context, index) {
              final gift = docs[index].data();
              final emoji = (gift['emoji'] ?? '🎁').toString();
              final name = (gift['giftName'] ?? 'Presente').toString();
              final sender = (gift['senderName'] ?? 'Alguém').toString();
              return Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFF21132E),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _profileSilver.withOpacity(.42)),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(emoji, style: const TextStyle(fontSize: 34)),
                  const SizedBox(height: 5),
                  Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text('De: $sender', maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white60, fontSize: 9)),
                  if (gift['source'] == 'live')
                    const Text('LIVE', style: TextStyle(color: _profilePink, fontSize: 8, fontWeight: FontWeight.w900)),
                ]),
              );
            },
          );
        },
      ),
    ]);
  }

  Widget _photosGallery({required bool isOwner, required bool canSeeFriends}) {
    final posts = FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('posts');
    if (isOwner) {
      return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: posts.snapshots(),
        builder: (context, snap) => _galleryContent(context, snap.data?.docs ?? [], loading: !snap.hasData, error: snap.hasError),
      );
    }
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: posts.where('visibility', isEqualTo: 'public').snapshots(),
      builder: (context, publicSnap) {
        if (publicSnap.hasError) return _galleryContent(context, [], loading: false, error: true);
        if (!canSeeFriends) {
          return _galleryContent(context, publicSnap.data?.docs ?? [], loading: !publicSnap.hasData);
        }
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: posts.where('visibility', isEqualTo: 'friends').snapshots(),
          builder: (context, friendsSnap) {
            if (friendsSnap.hasError) return _galleryContent(context, publicSnap.data?.docs ?? [], loading: !publicSnap.hasData);
            final combined = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
            combined.addAll(publicSnap.data?.docs ?? []);
            combined.addAll(friendsSnap.data?.docs ?? []);
            combined.sort((a, b) {
              final at = a.data()['createdAt'];
              final bt = b.data()['createdAt'];
              final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
              final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
              return bm.compareTo(am);
            });
            return _galleryContent(context, combined, loading: !publicSnap.hasData || !friendsSnap.hasData);
          },
        );
      },
    );
  }

  Widget _galleryContent(BuildContext context,
      List<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
      {required bool loading, bool error = false}) {
    if (error) return const Text('As fotos não estão disponíveis para este perfil.', style: TextStyle(color: Colors.white60));
    if (loading) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(color: _profilePink)));
    if (docs.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 26),
        decoration: BoxDecoration(color: _profilePanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4B2867))),
        child: const Column(children: [
          Icon(Icons.photo_library_outlined, color: _profilePurple, size: 34),
          SizedBox(height: 8),
          Text('Nenhuma foto disponível ainda.', style: TextStyle(color: Colors.white70)),
        ]),
      );
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: docs.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 7, mainAxisSpacing: 7),
      itemBuilder: (_, i) {
        final url = (docs[i].data()['photoUrl'] ?? '').toString();
        return GestureDetector(
          onTap: url.isEmpty ? null : () => _showPhoto(context, docs[i].id, url),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: url.isEmpty
                ? const ColoredBox(color: _profilePanel, child: Icon(Icons.broken_image))
                : CachedNetworkImage(imageUrl: url, fit: BoxFit.cover,
                    placeholder: (_, __) => const ColoredBox(color: _profilePanel, child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: _profilePink))),
                    errorWidget: (_, __, ___) => const ColoredBox(color: _profilePanel, child: Icon(Icons.broken_image))),
          ),
        );
      },
    );
  }

  void _showPhoto(BuildContext context, String postId, String url) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PostInteractionsScreen(ownerId: widget.userId, postId: postId, photoUrl: url)));
  }

  Widget _profileLikeButton(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final likes = FirebaseFirestore.instance.collection('users')
        .doc(widget.userId).collection('profileLikes');
    if (uid == null || uid == widget.userId) return const SizedBox.shrink();
    final myLike = likes.doc(uid);
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: myLike.snapshots(),
      builder: (context, likeSnap) {
        final liked = likeSnap.data?.exists == true;
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: likes.snapshots(),
          builder: (context, countSnap) {
            final count = countSnap.data?.docs.length ?? 0;
            return SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: likeSnap.connectionState == ConnectionState.waiting
                    ? null : () => _toggleProfileLike(context, liked),
                icon: Icon(liked ? Icons.favorite : Icons.favorite_border,
                    color: Colors.white, size: 25),
                label: Text(liked ? 'Perfil curtido  •  $count' : 'Curtir Perfil  •  $count',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: liked ? const Color(0xFF542078) : _profilePurple,
                  foregroundColor: Colors.white,
                  elevation: 8,
                  shadowColor: _profilePurple.withOpacity(.45),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                    side: const BorderSide(color: _profileSilver, width: 1.2),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _toggleProfileLike(BuildContext context, bool alreadyLiked) async {
    final me = FirebaseAuth.instance.currentUser;
    if (me == null || me.uid == widget.userId) return;
    final db = FirebaseFirestore.instance;
    final likeRef = db.collection('users').doc(widget.userId)
        .collection('profileLikes').doc(me.uid);
    try {
      if (alreadyLiked) {
        await likeRef.delete();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Curtida removida.')),
        );
        return;
      }
      final myProfile = await db.collection('users').doc(me.uid).get();
      final myName = (myProfile.data()?['name'] ?? me.displayName ?? 'Alguém').toString();
      await likeRef.set({
        'uid': me.uid,
        'name': myName,
        'createdAt': FieldValue.serverTimestamp(),
      });
      await db.collection('users').doc(widget.userId).collection('notifications').add({
        'type': 'profile_like',
        'fromUid': me.uid,
        'fromName': myName,
        'body': '$myName curtiu seu perfil. 💜',
        'read': false,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Você curtiu este perfil! 💜')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível curtir o perfil: ${e.toString().replaceFirst('Exception: ', '')}')),
      );
    }
  }

  Future<void> _toggleFollow(BuildContext context) async {
    try {
      final following = await DataService.instance.toggleFollow(widget.userId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(following ? 'Você começou a seguir 💗' : 'Você deixou de seguir.'),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _openChat(BuildContext context, String otherName) async {
    if (FirebaseAuth.instance.currentUser == null) return;
    try {
      final chatId = await DataService.instance.openDirectChat(widget.userId);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => ChatScreen(chatId: chatId, otherName: otherName),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }


  Future<void> _report(BuildContext context) async {
    final reason = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Denunciar perfil'),
        children: ['Perfil falso', 'Assédio ou discurso de ódio', 'Conteúdo impróprio', 'Outro']
            .map((r) => SimpleDialogOption(onPressed: () => Navigator.pop(ctx, r), child: Text(r))).toList(),
      ),
    );
    if (reason == null) return;
    try {
      await DataService.instance.reportUser(widget.userId, reason);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Denúncia enviada para análise.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível enviar a denúncia.')));
    }
  }

  Future<void> _block(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bloquear usuário?'),
        content: const Text('Este perfil não deverá mais aparecer para você.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bloquear')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await DataService.instance.blockUser(widget.userId);
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Não foi possível bloquear este usuário.')));
    }
  }
}
