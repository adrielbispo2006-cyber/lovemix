import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:convert';

/// Bloqueio local opcional: a sessão Firebase continua ativa; o PIN nunca é
/// enviado ao servidor e somente seu hash fica no armazenamento seguro.
class QuickAccessGate extends StatefulWidget {
  const QuickAccessGate({super.key, required this.child, required this.uid});
  final Widget child;
  final String uid;

  @override
  State<QuickAccessGate> createState() => _QuickAccessGateState();
}

class _QuickAccessGateState extends State<QuickAccessGate> {
  static const _storage = FlutterSecureStorage();
  final _auth = LocalAuthentication();
  bool _loading = true;
  bool _unlocked = false;
  bool _hasPin = false;
  bool _biometricEnabled = false;
  bool _busy = false;
  String? _error;

  String get _pinKey => 'lovemix_quick_pin_${widget.uid}';
  String get _bioKey => 'lovemix_quick_bio_${widget.uid}';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final pin = await _storage.read(key: _pinKey);
    final bio = await _storage.read(key: _bioKey);
    if (!mounted) return;
    setState(() {
      _hasPin = pin != null;
      _biometricEnabled = bio == 'true';
      // Primeiro acesso: pede para cadastrar um PIN. O usuário pode pular.
      _loading = false;
    });
  }

  String _hash(String pin) => sha256.convert(utf8.encode('${widget.uid}:$pin')).toString();

  Future<void> _setupPin() async {
    final first = TextEditingController();
    final second = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF100719),
        title: const Text('Criar PIN de acesso', style: TextStyle(color: Colors.white)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Crie um PIN de 4 a 6 números para entrar rapidamente no LoveMix.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 14),
          TextField(controller: first, keyboardType: TextInputType.number, obscureText: true, maxLength: 6, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(labelText: 'Novo PIN')),
          TextField(controller: second, keyboardType: TextInputType.number, obscureText: true, maxLength: 6, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(labelText: 'Confirme o PIN')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Agora não')),
          ElevatedButton(onPressed: () {
            if (first.text.length < 4 || first.text.length > 6) return;
            if (first.text != second.text) return;
            Navigator.pop(dialogContext, first.text);
          }, child: const Text('Salvar PIN')),
        ],
      ),
    );
    first.dispose();
    second.dispose();
    if (result == null) return;
    await _storage.write(key: _pinKey, value: _hash(result));
    var bio = false;
    try {
      bio = await _auth.isDeviceSupported() && (await _auth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {}
    await _storage.write(key: _bioKey, value: bio ? 'true' : 'false');
    if (!mounted) return;
    setState(() { _hasPin = true; _biometricEnabled = bio; _unlocked = true; _error = null; });
  }

  Future<void> _enterPin() async {
    final pin = TextEditingController();
    final entered = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF100719),
        title: const Text('Entrar com PIN', style: TextStyle(color: Colors.white)),
        content: TextField(controller: pin, autofocus: true, keyboardType: TextInputType.number, obscureText: true, maxLength: 6, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(hintText: 'Digite seu PIN')),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')), ElevatedButton(onPressed: () => Navigator.pop(dialogContext, pin.text), child: const Text('Entrar'))],
      ),
    );
    pin.dispose();
    if (entered == null) return;
    final saved = await _storage.read(key: _pinKey);
    if (saved != null && _hash(entered) == saved) {
      if (mounted) setState(() { _unlocked = true; _error = null; });
    } else if (mounted) {
      setState(() => _error = 'PIN incorreto. Tente novamente.');
    }
  }

  Future<void> _biometric() async {
    if (_busy || !_biometricEnabled) {
      if (mounted) setState(() => _error = 'Biometria não está configurada neste aparelho. Use seu PIN.');
      return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'Confirme sua identidade para entrar no LoveMix',
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      if (ok && mounted) setState(() => _unlocked = true);
    } on PlatformException catch (e) {
      if (mounted) setState(() => _error = 'Biometria indisponível. Use seu PIN. (${e.message ?? e.code})');
    } catch (_) {
      if (mounted) setState(() => _error = 'Não foi possível usar a biometria. Entre com seu PIN.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _skipSetup() async {
    // Não ativa acesso rápido: usuário continua com a sessão normal do Firebase.
    if (mounted) setState(() => _unlocked = true);
  }

  @override
  Widget build(BuildContext context) {
    if (_unlocked) return widget.child;
    if (_loading) return const Scaffold(backgroundColor: Colors.black, body: Center(child: CircularProgressIndicator(color: Color(0xFFE52BFF))));
    if (!_hasPin) {
      return _QuickAccessScaffold(
        title: '⚡ Acesso rápido', subtitle: 'Configure seu acesso em um toque!',
        error: _error,
        children: [
          const Icon(Icons.fingerprint, size: 96, color: Color(0xFFE52BFF)),
          const SizedBox(height: 12),
          const Text('Ative o acesso rápido', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('Crie um PIN para proteger sua entrada. A biometria poderá ser usada se seu aparelho oferecer suporte.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 24),
          _NeonButton(text: 'Criar PIN', icon: Icons.lock, onTap: _setupPin),
          TextButton(onPressed: _skipSetup, child: const Text('Agora não', style: TextStyle(color: Colors.white70))),
        ],
      );
    }
    return _QuickAccessScaffold(
      title: '⚡ Acesso rápido', subtitle: 'Entre em um toque!', error: _error,
      children: [
        GestureDetector(onTap: _biometric, child: Icon(Icons.fingerprint, size: 112, color: _biometricEnabled ? const Color(0xFFE52BFF) : Colors.white24)),
        const SizedBox(height: 12),
        Text(_biometricEnabled ? 'Entrar com Biometria' : 'Biometria indisponível neste aparelho', style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 30),
        const Row(children: [Expanded(child: Divider(color: Colors.white54)), Padding(padding: EdgeInsets.symmetric(horizontal: 14), child: Text('ou', style: TextStyle(color: Colors.white))), Expanded(child: Divider(color: Colors.white54))]),
        const SizedBox(height: 22),
        _NeonButton(text: 'Entrar com PIN', icon: Icons.lock, onTap: _enterPin),
        const SizedBox(height: 12),
        TextButton(onPressed: () async { await FirebaseAuth.instance.signOut(); }, child: const Text('Trocar de conta', style: TextStyle(color: Colors.white70))),
      ],
    );
  }
}

class _QuickAccessScaffold extends StatelessWidget {
  const _QuickAccessScaffold({required this.title, required this.subtitle, required this.children, this.error});
  final String title, subtitle;
  final String? error;
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: SafeArea(child: Center(child: Container(
      margin: const EdgeInsets.all(12), padding: const EdgeInsets.fromLTRB(24, 28, 24, 22),
      decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(30), border: Border.all(color: const Color(0xFFE52BFF), width: 2), boxShadow: const [BoxShadow(color: Color(0xAAE000FF), blurRadius: 18)]),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.arrow_back, color: Colors.white)), const SizedBox(width: 6), Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold))]),
        Text(subtitle, style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 26),
        ...children,
        if (error != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent))),
      ]),
    ))),
  );
}

class _NeonButton extends StatelessWidget {
  const _NeonButton({required this.text, required this.icon, required this.onTap});
  final String text; final IconData icon; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SizedBox(width: double.infinity, height: 52, child: OutlinedButton.icon(onPressed: onTap, icon: Icon(icon, color: const Color(0xFFE52BFF)), label: Text(text, style: const TextStyle(color: Color(0xFFFFA8F1), fontWeight: FontWeight.bold, fontSize: 16)), style: OutlinedButton.styleFrom(side: const BorderSide(color: Color(0xFFE52BFF), width: 1.6), shape: const StadiumBorder())));
}
