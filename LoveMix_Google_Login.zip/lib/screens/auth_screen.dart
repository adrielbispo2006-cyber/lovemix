import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../services/data_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool busy = false;
  bool obscurePassword = true;
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  DateTime? birthday;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  bool _isAdult(DateTime date) {
    final today = DateTime.now();
    final age = today.year - date.year -
        ((today.month < date.month ||
                (today.month == date.month && today.day < date.day))
            ? 1
            : 0);
    return age >= 18;
  }

  Future<DateTime?> _askBirthday() async {
    final now = DateTime.now();
    return showDatePicker(
      context: context,
      firstDate: DateTime(1900),
      lastDate: DateTime(now.year - 18, now.month, now.day),
      initialDate: DateTime(now.year - 25, now.month, now.day),
      helpText: 'Confirme que você tem 18 anos ou mais',
    );
  }

  Future<void> _claimFounderIfEligible() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email?.toLowerCase() != 'adrielbispo3009@gmail.com' || !user.emailVerified && user.providerData.every((p) => p.providerId != 'google.com')) return;
    try {
      await FirebaseFunctions.instance.httpsCallable('claimFounderAdmin').call();
    } catch (_) {
      // A função só fica disponível depois de publicar as Cloud Functions.
      // O login normal continua funcionando enquanto isso.
    }
  }

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      show('Informe seu e-mail e sua senha.');
      return;
    }
    if (register && name.text.trim().isEmpty) {
      show('Informe seu nome.');
      return;
    }
    if (register && birthday == null) {
      show('Informe sua data de nascimento.');
      return;
    }
    if (register && !_isAdult(birthday!)) {
      show('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }

    setState(() => busy = true);
    try {
      if (register) {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await cred.user!.updateDisplayName(name.text.trim());
        await DataService.instance.createUser(
          name: name.text.trim(),
          birthday: birthday!,
        );
        await _claimFounderIfEligible();
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await _claimFounderIfEligible();
      }
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } catch (e) {
      show('Não foi possível concluir. Verifique sua internet e tente novamente.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> signInGoogle() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      // O seletor nativo do Google funciona com a configuração OAuth Android.
      final googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return; // O usuário cancelou.

      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final result = await FirebaseAuth.instance.signInWithCredential(credential);
      final user = result.user;
      if (user == null) throw Exception('Não foi possível obter a conta Google.');

      // Cria o perfil no Firestore somente na primeira entrada e solicita
      // data de nascimento para respeitar a regra de uso para maiores de 18.
      final profile = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (!profile.exists) {
        if (!mounted) return;
        final date = await _askBirthday();
        if (date == null) {
          await FirebaseAuth.instance.signOut();
          await GoogleSignIn().signOut();
          show('Para criar sua conta, confirme sua data de nascimento.');
          return;
        }
        if (!_isAdult(date)) {
          await FirebaseAuth.instance.signOut();
          await GoogleSignIn().signOut();
          show('O LoveMix é destinado somente a maiores de 18 anos.');
          return;
        }
        final displayName = (user.displayName ?? '').trim();
        final fallbackName = user.email?.split('@').first ?? 'Pessoa LoveMix';
        await DataService.instance.createUser(
          name: displayName.isEmpty ? fallbackName : displayName,
          birthday: date,
        );
      }
      await _claimFounderIfEligible();
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } catch (e) {
      final message = e.toString();
      if (message.contains('ApiException: 10') ||
          message.contains('DEVELOPER_ERROR') ||
          message.contains('configuration-not-found')) {
        show('O Google ainda não está configurado para este APK. Confira o SHA-1, SHA-256, o pacote Android e o provedor Google no Firebase.');
      } else {
        show('Não foi possível entrar com Google. Confira a internet e a configuração Firebase.');
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _authError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'O e-mail informado é inválido.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'E-mail ou senha incorretos.';
      case 'email-already-in-use':
        return 'Este e-mail já possui uma conta. Tente entrar.';
      case 'weak-password':
        return 'Escolha uma senha com pelo menos 6 caracteres.';
      case 'network-request-failed':
        return 'Sem conexão. Verifique sua internet e tente novamente.';
      case 'operation-not-allowed':
        return 'Este método de login ainda não foi ativado no Firebase.';
      case 'configuration-not-found':
        return 'Configuração de autenticação ausente no Firebase. Confira o provedor e as configurações do aplicativo.';
      default:
        return e.message ?? 'Não foi possível autenticar. Tente novamente.';
    }
  }

  void show(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                children: [
                  const Icon(Icons.favorite, color: Color(0xFFE7BD50), size: 62),
                  const SizedBox(height: 8),
                  const Text('LoveMix', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: Color(0xFFE7BD50))),
                  const Text('Amizades e conexões que aproximam.', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 32),
                  Text(register ? 'Criar uma conta' : 'Boas-vindas de volta', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 18),
                  if (register) ...[
                    TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Nome completo', prefixIcon: Icon(Icons.person_outline))),
                    const SizedBox(height: 12),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(hintText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
                  const SizedBox(height: 12),
                  TextField(
                    controller: password,
                    obscureText: obscurePassword,
                    autofillHints: register ? const [AutofillHints.newPassword] : const [AutofillHints.password],
                    decoration: InputDecoration(
                      hintText: 'Senha',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => obscurePassword = !obscurePassword),
                        icon: Icon(obscurePassword ? Icons.visibility : Icons.visibility_off),
                      ),
                    ),
                  ),
                  if (register) ...[
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: busy ? null : () async {
                        final d = await _askBirthday();
                        if (d != null && mounted) setState(() => birthday = d);
                      },
                      icon: const Icon(Icons.calendar_month),
                      label: Text(birthday == null ? 'Data de nascimento (18+)' : '${birthday!.day}/${birthday!.month}/${birthday!.year}'),
                    ),
                  ],
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: busy ? null : submit,
                    child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black)) : Text(register ? 'Criar minha conta' : 'Entrar'),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Expanded(child: Divider(color: Colors.white24)),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          'OU',
                          style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 12),
                        ),
                      ),
                      const Expanded(child: Divider(color: Colors.white24)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: busy ? null : signInGoogle,
                    icon: const Icon(Icons.g_mobiledata, size: 30, color: Color(0xFFE7BD50)),
                    label: const Text('Continuar com Google'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                      foregroundColor: const Color(0xFFE7BD50),
                      side: const BorderSide(color: Color(0xFFE7BD50)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  TextButton(
                    onPressed: busy ? null : () => setState(() => register = !register),
                    child: Text(register ? 'Já tem uma conta? Entrar' : 'Não tem uma conta? Criar conta'),
                  ),
                  if (!register)
                    TextButton(
                      onPressed: busy ? null : () async {
                        if (email.text.trim().isEmpty) return show('Digite seu e-mail primeiro.');
                        try {
                          await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
                          show('Enviamos um link de recuperação para seu e-mail.');
                        } on FirebaseAuthException catch (e) {
                          show(_authError(e));
                        }
                      },
                      child: const Text('Esqueci minha senha'),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
