# Atualização de perfil LoveMix

Esta atualização adiciona:
- Data de nascimento editável e idade calculada no perfil público.
- Campo de gênero com ícones/símbolos.
- Publicação de fotos na galeria do perfil.
- Visibilidade por publicação: público, amigos (match) ou privado.
- Upload comprimido para reduzir consumo de dados em celulares simples.

## Publicação das regras Firebase
Antes de testar, publique as regras atualizadas:
- Firestore: `firestore.rules`
- Storage: `storage.rules`

As fotos de amigos usam os documentos `matches/{uid1_uid2}` criados pelo fluxo de match existente. O perfil e a data/gênero continuam visíveis a usuários autenticados; a seleção de visibilidade controla as publicações da galeria. URLs de download do Firebase Storage são links portadores: quem obtiver e compartilhar uma URL poderá acessá-la. Para privacidade forte de mídia, migre a entrega das imagens para URLs autenticadas/temporárias via backend.

A compilação e os testes no Firebase real ainda precisam ser executados no GitHub Actions com as credenciais do projeto.
