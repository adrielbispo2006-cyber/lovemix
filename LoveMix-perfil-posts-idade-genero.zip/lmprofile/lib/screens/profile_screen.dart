import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/data_service.dart';
import 'admin_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final name = TextEditingController();
  final bio = TextEditingController();
  final city = TextEditingController();
  bool loaded = false;
  bool saving = false;
  String gender = '';
  String visibility = 'public';
  DateTime? birthday;

  Future<void> pickBirthday() async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: birthday ?? DateTime(now.year - 18, now.month, now.day), firstDate: DateTime(1900), lastDate: now, helpText: 'Sua data de nascimento');
    if (picked != null && mounted) setState(() => birthday = picked);
  }

  Future<void> publishPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) throw Exception('Entre novamente para publicar.');
      final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 65, maxWidth: 1000, maxHeight: 1000);
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty || bytes.length > 5 * 1024 * 1024) throw Exception('Escolha uma foto válida de até 5 MB.');
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final type = picked.name.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
      final ext = type == 'image/png' ? 'png' : 'jpg';
      final ref = FirebaseStorage.instance.ref('user_posts/${user.uid}/$id.$ext');
      await ref.putData(bytes, SettableMetadata(contentType: type));
      final url = await ref.getDownloadURL();
      await FirebaseFirestore.instance.collection('users').doc(user.uid).collection('posts').doc(id).set({
        'photoUrl': url, 'visibility': visibility, 'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Foto publicada no seu perfil!')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível publicar: $e')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  Future<void> pickPhoto() async {
    if (saving) return;
    setState(() => saving = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception('Faça login novamente para alterar sua foto.');
      }

      // Pick a reasonably small image so uploads also work on slower phones.
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 65,
        maxWidth: 720,
        maxHeight: 720,
      );
      if (picked == null) return;

      final Uint8List bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A imagem selecionada está vazia.');
      if (bytes.length > 5 * 1024 * 1024) {
        throw Exception('A foto ficou muito grande. Escolha outra imagem.');
      }

      final lowerPath = picked.name.toLowerCase();
      final contentType = lowerPath.endsWith('.png')
          ? 'image/png'
          : lowerPath.endsWith('.webp')
              ? 'image/webp'
              : 'image/jpeg';
      final extension = contentType == 'image/png'
          ? 'png'
          : contentType == 'image/webp'
              ? 'webp'
              : 'jpg';

      final ref = FirebaseStorage.instance
          .ref()
          .child('profile_photos')
          .child(user.uid)
          .child('profile.$extension');
      await ref.putData(
        bytes,
        SettableMetadata(
          contentType: contentType,
          cacheControl: 'public,max-age=3600',
        ),
      );
      final url = await ref.getDownloadURL();
      await DataService.instance.updateProfile({'photoUrl': url});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Foto de perfil atualizada!')),
        );
      }
    } on FirebaseException catch (e) {
      final message = e.code == 'unauthorized'
          ? 'O Firebase Storage bloqueou o envio. Verifique as regras do Storage.'
          : e.code == 'canceled'
              ? 'Envio cancelado.'
              : 'Falha no envio da foto (${e.code}). Tente novamente.';
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  void dispose() { name.dispose(); bio.dispose(); city.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: DataService.instance.myProfile(),
      builder: (context, snap) {
        final p = snap.data?.data() ?? {};
        if (!loaded && p.isNotEmpty) {
          name.text = (p['name'] ?? '').toString();
          bio.text = (p['bio'] ?? '').toString();
          city.text = (p['city'] ?? '').toString();
          gender = (p['gender'] ?? '').toString();
          visibility = (p['profileVisibility'] ?? 'public').toString();
          birthday = (p['birthday'] as Timestamp?)?.toDate();
          loaded = true;
        }
        final photo = (p['photoUrl'] ?? '') as String;
        return ListView(padding: const EdgeInsets.all(18), children: [
          Center(
            child: Stack(children: [
              CircleAvatar(radius: 58, backgroundColor: const Color(0xFF443719),
                backgroundImage: photo.isEmpty ? null : NetworkImage(photo),
                child: photo.isEmpty ? const Icon(Icons.person, size: 55) : null),
              Positioned(right: 0, bottom: 0, child: IconButton.filled(
                onPressed: saving ? null : pickPhoto, icon: const Icon(Icons.camera_alt))),
            ]),
          ),
          const SizedBox(height: 20),
          const Text('Editar perfil', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome')),
          const SizedBox(height: 12),
          TextField(controller: bio, maxLines: 3, decoration: const InputDecoration(labelText: 'Bio')),
          const SizedBox(height: 12),
          TextField(controller: city, decoration: const InputDecoration(labelText: 'Cidade')),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: pickBirthday, icon: const Icon(Icons.cake_outlined), label: Text(birthday == null ? 'Adicionar data de nascimento' : 'Nascimento: ${birthday!.day.toString().padLeft(2, '0')}/${birthday!.month.toString().padLeft(2, '0')}/${birthday!.year}')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: gender.isEmpty ? null : gender, decoration: const InputDecoration(labelText: 'Gênero', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'woman', child: Text('♀ Mulher')), DropdownMenuItem(value: 'man', child: Text('♂ Homem')), DropdownMenuItem(value: 'non_binary', child: Text('⚧ Não binário')), DropdownMenuItem(value: 'other', child: Text('Outro')), DropdownMenuItem(value: 'prefer_not', child: Text('Prefiro não informar'))], onChanged: (v) => setState(() => gender = v ?? '')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: visibility, decoration: const InputDecoration(labelText: 'Quem pode ver suas fotos?', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'public', child: Text('🌍 Público')), DropdownMenuItem(value: 'friends', child: Text('👥 Apenas amigos')), DropdownMenuItem(value: 'private', child: Text('🔒 Privado'))], onChanged: (v) => setState(() => visibility = v ?? 'public')),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: () async {
            await DataService.instance.updateProfile({'name': name.text.trim(), 'bio': bio.text.trim(), 'city': city.text.trim(), 'gender': gender, 'birthday': birthday == null ? null : Timestamp.fromDate(birthday!), 'profileVisibility': visibility});
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Perfil salvo.')));
          }, child: const Text('Salvar perfil')),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Minhas fotos', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), TextButton.icon(onPressed: saving ? null : publishPhoto, icon: const Icon(Icons.add_a_photo), label: const Text('Publicar'))]),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).collection('posts').orderBy('createdAt', descending: true).snapshots(), builder: (context, postsSnap) {
            if (postsSnap.hasError) return const Text('Não foi possível carregar suas fotos.');
            final posts = postsSnap.data?.docs ?? [];
            if (posts.isEmpty) return const Padding(padding: EdgeInsets.symmetric(vertical: 20), child: Text('Você ainda não publicou fotos.'));
            return GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: posts.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6), itemBuilder: (_, i) => ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(posts[i].data()['photoUrl'] ?? '', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image))));
          }),
          const SizedBox(height: 10),
          if (p['isAdmin'] == true)
            OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())),
              icon: const Icon(Icons.admin_panel_settings), label: const Text('Painel administrativo')),
          OutlinedButton.icon(
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Excluir conta?'),
                  content: const Text('A exclusão é permanente. Talvez seja necessário entrar novamente antes de confirmar.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Excluir')),
                  ],
                ),
              );
              if (confirm != true) return;
              try {
                await DataService.instance.deleteMyAccount();
              } on FirebaseAuthException catch (e) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(e.code == 'requires-recent-login'
                    ? 'Por segurança, saia e entre novamente antes de excluir a conta.'
                    : 'Não foi possível excluir a conta.')),
                );
              }
            },
            icon: const Icon(Icons.delete_forever),
            label: const Text('Excluir minha conta'),
          ),
          OutlinedButton.icon(onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout), label: const Text('Sair da conta')),
        ]);
      },
    );
  }
}
