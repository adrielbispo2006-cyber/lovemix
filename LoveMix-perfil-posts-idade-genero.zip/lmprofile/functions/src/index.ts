import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { getMessaging } from "firebase-admin/messaging";

initializeApp();
const db = getFirestore();



/** Concede a função de fundador somente à conta verificada definida no código.
 * O cliente não pode escolher o e-mail nem definir isAdmin diretamente.
 */
export const claimFounderAdmin = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta primeiro.");
  const email = String(request.auth.token.email ?? "").trim().toLowerCase();
  const emailVerified = request.auth.token.email_verified === true;
  if (email !== "adrielbispo3009@gmail.com" || !emailVerified) {
    throw new HttpsError("permission-denied", "Esta conta não está autorizada como administradora.");
  }
  const uid = request.auth.uid;
  await getAuth().setCustomUserClaims(uid, { admin: true, founder: true });
  await db.collection("users").doc(uid).set({
    uid, email, isAdmin: true, adminRole: "founder", adminGrantedAt: FieldValue.serverTimestamp()
  }, { merge: true });
  return { success: true, role: "founder" };
});

/** Envia push para todos os dispositivos registrados do usuário destinatário. */
async function notifyUser(
  uid: string,
  title: string,
  body: string,
  data: Record<string, string>
): Promise<void> {
  const tokensSnapshot = await db.collection("users").doc(uid)
    .collection("fcmTokens").get();
  const tokens = tokensSnapshot.docs
    .map((doc) => ({ id: doc.id, token: String(doc.data().token ?? doc.id) }))
    .filter((item) => item.token.length > 0);
  if (tokens.length === 0) return;

  const response = await getMessaging().sendEachForMulticast({
    tokens: tokens.map((item) => item.token),
    notification: { title, body },
    data,
    android: {
      priority: "high",
      notification: { channelId: "lovemix_updates", sound: "default" }
    }
  });

  const removals: Promise<unknown>[] = [];
  response.responses.forEach((result, index) => {
    const code = result.error?.code ?? "";
    if (!result.success && (
      code.includes("registration-token-not-registered") ||
      code.includes("invalid-registration-token")
    )) {
      removals.push(tokensSnapshot.docs[index].ref.delete());
    }
  });
  await Promise.all(removals);
}

/** Notifica o destinatário quando alguém curte seu perfil. */
export const notifyOnLike = onDocumentCreated(
  "users/{fromUid}/likes/{targetUid}",
  async (event) => {
    const { fromUid, targetUid } = event.params;
    if (fromUid === targetUid) return;
    const sender = await db.collection("users").doc(fromUid).get();
    const name = String(sender.data()?.name ?? "Alguém");
    await notifyUser(targetUid, "Nova curtida ❤️", `${name} curtiu seu perfil.`, {
      type: "like", fromUid
    });
  }
);

/** Notifica o outro participante quando uma nova mensagem chega. */
export const notifyOnMessage = onDocumentCreated(
  "chats/{chatId}/messages/{messageId}",
  async (event) => {
    const message = event.data?.data();
    if (!message) return;
    const senderUid = String(message.senderId ?? "");
    const chat = await db.collection("chats").doc(event.params.chatId).get();
    const participants = (chat.data()?.users ?? []) as string[];
    const recipientUid = participants.find((participant) => participant !== senderUid);
    if (!recipientUid || !senderUid) return;
    const sender = await db.collection("users").doc(senderUid).get();
    const name = String(sender.data()?.name ?? "Nova mensagem");
    const rawText = String(message.text ?? "");
    const preview = rawText.length > 100 ? `${rawText.substring(0, 97)}...` : rawText;
    await notifyUser(recipientUid, `Mensagem de ${name}`, preview, {
      type: "message", chatId: event.params.chatId, fromUid: senderUid
    });
  }
);


/** Notifica os participantes de uma sala sobre mensagens e presentes recebidos. */
export const notifyOnRoomActivity = onDocumentCreated(
  "rooms/{roomId}/messages/{messageId}",
  async (event) => {
    const message = event.data?.data();
    if (!message) return;
    const senderUid = String(message.senderId ?? "");
    const room = await db.collection("rooms").doc(event.params.roomId).get();
    const members = (room.data()?.members ?? []) as string[];
    const recipients = members.filter((member) => member !== senderUid);
    if (!senderUid || recipients.length === 0) return;
    const sender = await db.collection("users").doc(senderUid).get();
    const senderName = String(sender.data()?.name ?? "Alguém");
    const isGift = message.type === "gift";
    const body = isGift
      ? `${senderName} enviou ${String(message.emoji ?? "🎁")} ${String(message.giftName ?? "um presente")}.`
      : `${senderName}: ${String(message.text ?? "Nova mensagem").substring(0, 100)}`;
    await Promise.all(recipients.map((uid) => notifyUser(
      uid,
      isGift ? "Você recebeu um presente 🎁" : `Nova mensagem em ${String(room.data()?.name ?? "uma sala")}`,
      body,
      { type: isGift ? "room_gift" : "room_message", roomId: event.params.roomId, fromUid: senderUid }
    )));
  }
);

/**
 * Server-side like operation. Creates a match only after reciprocal like.
 * Clients must call this callable instead of writing match documents directly.
 */
export const likeUser = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  const uid = request.auth.uid;
  const targetUid = String(request.data?.targetUid ?? "");
  if (!targetUid || targetUid === uid) {
    throw new HttpsError("invalid-argument", "Perfil de destino inválido.");
  }

  const targetRef = db.collection("users").doc(targetUid);
  const myLikeRef = db.collection("users").doc(uid).collection("likes").doc(targetUid);
  const theirLikeRef = db.collection("users").doc(targetUid).collection("likes").doc(uid);
  const matchUsers = [uid, targetUid].sort();
  const matchId = matchUsers.join("_");
  const matchRef = db.collection("matches").doc(matchId);
  let matched = false;

  await db.runTransaction(async (tx) => {
    const target = await tx.get(targetRef);
    if (!target.exists || target.data()?.isActive !== true) {
      throw new HttpsError("not-found", "Este perfil não está disponível.");
    }
    const blocked = await db.collection("users").doc(uid)
      .collection("blocked").doc(targetUid).get();
    const blockedByTarget = await db.collection("users").doc(targetUid)
      .collection("blocked").doc(uid).get();
    if (blocked.exists || blockedByTarget.exists) {
      throw new HttpsError("permission-denied", "Não é possível curtir este perfil.");
    }
    const reciprocal = await tx.get(theirLikeRef);
    tx.set(myLikeRef, { createdAt: FieldValue.serverTimestamp() });
    if (reciprocal.exists) {
      matched = true;
      tx.set(matchRef, {
        users: matchUsers,
        createdAt: FieldValue.serverTimestamp(),
        lastMessage: "",
        lastMessageAt: FieldValue.serverTimestamp()
      }, { merge: true });
      tx.set(db.collection("chats").doc(matchId), {
        users: matchUsers,
        lastMessage: "",
        lastMessageAt: FieldValue.serverTimestamp()
      }, { merge: true });
    }
  });
  return { success: true, matched, matchId: matched ? matchId : null };
});

/** Report review is intentionally admin-only and should be expanded with moderation workflow. */
export const closeReport = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  const admin = await db.collection("users").doc(request.auth.uid).get();
  if (admin.data()?.isAdmin !== true) {
    throw new HttpsError("permission-denied", "Acesso restrito.");
  }
  const reportId = String(request.data?.reportId ?? "");
  if (!reportId) throw new HttpsError("invalid-argument", "Denúncia inválida.");
  await db.collection("reports").doc(reportId).update({
    status: "reviewed",
    reviewedAt: FieldValue.serverTimestamp(),
    reviewedBy: request.auth.uid
  });
  return { success: true };
});
