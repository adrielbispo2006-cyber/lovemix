import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import 'discover_screen.dart';
import 'messages_screen.dart';
import 'profile_view_screen.dart';
import 'wallet_screen.dart';
import 'gifts_screen.dart';
import 'chat_rooms_screen.dart';
import 'love_room_screen.dart';
import 'live_broadcast_screen.dart';
import 'ranking_screen.dart';
import 'resources_screen.dart';
import 'stories_widget.dart';
import 'notifications_screen.dart';
import 'extras_screen.dart';
import 'vip_nickname_screen.dart';
import '../widgets/vip_nickname.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  static const panel = Color(0xFF171022);
  int index = 0;
  // Abas são montadas só na primeira visita (e depois mantidas vivas). Antes as
  // 5 abas, com dezenas de streams do Firestore, eram criadas de uma vez na entrada.
  final Set<int> _visitedTabs = {0};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Deixa a primeira tela desenhar antes de gravar no Firestore.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      DataService.instance.setOnlineStatus(true);
      DataService.instance.startCharismaTicker();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DataService.instance.setOnlineStatus(true);
      DataService.instance.startCharismaTicker();
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      DataService.instance.stopCharismaTicker();
      DataService.instance.setOnlineStatus(false);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    DataService.instance.stopCharismaTicker();
    DataService.instance.setOnlineStatus(false);
    super.dispose();
  }

  final _feedKey = GlobalKey<_LoveMixFeedState>();

  void open(int page) => setState(() {
    index = page;
    _visitedTabs.add(page);
  });

  void _push(Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  Future<void> _showCreateMenu() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF12041F),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: SingleChildScrollView(child: Wrap(children: [
        ListTile(leading: const Icon(Icons.workspace_premium, color: Color(0xFFFFD36A)), title: const Text('Loja VIP (personalização)'), onTap: () => Navigator.pop(ctx, 'vip')),
        ListTile(leading: const Icon(Icons.edit, color: Color(0xFFE34CFF)), title: const Text('Nova publicação'), onTap: () => Navigator.pop(ctx, 'post')),
        ListTile(leading: const Icon(Icons.mic, color: Color(0xFFE34CFF)), title: const Text('Criar sala de voz'), onTap: () => Navigator.pop(ctx, 'room')),
        ListTile(leading: const Icon(Icons.groups_outlined, color: Color(0xFFE34CFF)), title: const Text('Salas LoveMix'), onTap: () => Navigator.pop(ctx, 'rooms')),
        ListTile(leading: const Icon(Icons.notifications_none, color: Color(0xFFE34CFF)), title: const Text('Notificações'), onTap: () => Navigator.pop(ctx, 'notifications')),
        ListTile(leading: const Icon(Icons.card_giftcard, color: Color(0xFFFFD700)), title: const Text('Presentes'), onTap: () => Navigator.pop(ctx, 'gifts')),
        ListTile(leading: const Icon(Icons.account_balance_wallet_outlined, color: Color(0xFFE34CFF)), title: const Text('Carteira (moedas e diamantes)'), onTap: () => Navigator.pop(ctx, 'wallet')),
      ]))),
    );
    if (!mounted || choice == null) return;
    switch (choice) {
      case 'vip':
        _push(const VipNicknameScreen());
      case 'post':
        _openFeed(compose: true);
      case 'room':
        _createRoom(context);
      case 'rooms':
        _push(const _RoomsRoute());
      case 'notifications':
        _push(const NotificationsScreen());
      case 'gifts':
        _push(const GiftsScreen());
      case 'wallet':
        _push(const WalletScreen());
    }
  }

  /// Vai para o Início e abre a janela de nova publicação.
  void _openFeed({bool compose = false}) {
    open(0);
    if (compose) {
      Future.delayed(const Duration(milliseconds: 250), () {
        if (mounted) _feedKey.currentState?.openComposer();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final builders = <Widget Function()>[
      () => _LoveMixFeed(
        key: _feedKey,
        onDiscover: () => open(2),
        onRooms: () => _push(const _RoomsRoute()),
        onVip: () => _push(const VipNicknameScreen()),
      ),
      () => const MessagesScreen(),
      () => const _DiscoverRoute(),
      () => ProfileViewScreen(userId: FirebaseAuth.instance.currentUser?.uid ?? ''),
    ];
    // Posição da barra: Início, Chats, (coração central), Descobrir, VIP.
    final pages = [
      for (var i = 0; i < builders.length; i++)
        _visitedTabs.contains(i) ? builders[i]() : const SizedBox.shrink(),
    ];
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: null,
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: _bottomBar(),
    );
  }

  static const _neon = Color(0xFFE05CFF);

  Widget _navItem(int page, IconData icon, IconData activeIcon, String label,
      {Widget? custom, Color? tint}) {
    final selected = index == page;
    final color = tint ?? (selected ? Colors.white : _neon);
    return Expanded(child: InkWell(
      onTap: () => open(page),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        custom ?? Icon(selected ? activeIcon : icon, color: selected ? const Color(0xFFFF5CC8) : color, size: 34,
            shadows: [Shadow(color: (selected ? pink : purple).withOpacity(.9), blurRadius: 12)]),
        const SizedBox(height: 3),
        Text(label, style: TextStyle(color: tint ?? (selected ? Colors.white : _neon), fontSize: 14,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w600)),
        const SizedBox(height: 3),
        Container(height: 3, width: 54, decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(3),
          color: selected ? pink : Colors.transparent,
          boxShadow: selected ? [BoxShadow(color: pink.withOpacity(.9), blurRadius: 8)] : null,
        )),
      ]),
    ));
  }

  Widget _bottomBar() => SafeArea(top: false, child: SizedBox(height: 100, child: Stack(clipBehavior: Clip.none, children: [
    Positioned(left: 0, right: 0, bottom: 0, height: 78, child: Container(
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(34)),
        border: Border(top: BorderSide(color: purple.withOpacity(.95), width: 1.4)),
        boxShadow: const [BoxShadow(color: Color(0x889B00FF), blurRadius: 18)],
      ),
      child: Row(children: [
        _navItem(0, Icons.home_outlined, Icons.home_rounded, 'Início'),
        _navItem(1, Icons.chat_bubble_outline, Icons.chat_bubble, 'Chats',
            custom: _ChatNavIcon(selected: index == 1)),
        const Expanded(child: SizedBox.shrink()),
        _navItem(2, Icons.people_outline, Icons.people, 'Descobrir'),
        _navItem(3, Icons.person_outline, Icons.person, 'Perfil'),
      ]),
    )),
    Positioned(top: 0, left: 0, right: 0, child: Center(child: GestureDetector(
      onTap: _showCreateMenu,
      child: SizedBox(
        width: 116, height: 82,
        child: Image.asset('assets/home/center_heart.png', fit: BoxFit.contain),
      ),
    ))),
  ])));

  Future<void> _createRoom(BuildContext context) async {
    final name = TextEditingController();
    final description = TextEditingController();
    final password = TextEditingController();
    bool isPublic = true;
    bool isVipRoom = false;
    String category = 'Amizades';
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context, isScrollControlled: true, backgroundColor: panel,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Criar sua sala 👑', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          TextField(controller: name, maxLength: 40, decoration: const InputDecoration(hintText: 'Nome da sala')),
          TextField(controller: description, maxLength: 120, decoration: const InputDecoration(hintText: 'Descrição (opcional)')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'Categoria'),
            items: const ['Amizades', 'Namoro', 'Música', 'Jogos', 'Conversas'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) { if (v != null) setSheet(() => category = v); },
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: isVipRoom,
            activeColor: const Color(0xFFFFD45C),
            title: const Text('Sala VIP com animações 👑'),
            subtitle: const Text('Ativa destaque dourado e efeitos especiais na sala'),
            onChanged: (v) => setSheet(() => isVipRoom = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: isPublic,
            activeColor: pink,
            title: Text(isPublic ? 'Sala pública' : 'Sala privada'),
            subtitle: Text(isPublic ? 'Qualquer pessoa pode entrar' : 'Sala privada, não aparece na lista pública'),
            onChanged: (v) => setSheet(() => isPublic = v),
          ),
          if (!isPublic) ...[
            const SizedBox(height: 8),
            TextField(controller: password, obscureText: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Senha da sala', hintText: 'Crie uma senha para compartilhar')),
          ],
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pop(ctx, {
            'name': name.text.trim(), 'description': description.text.trim(),
            'category': category, 'isPublic': isPublic, 'isVipRoom': isVipRoom, 'password': password.text.trim(),
          }), child: const Text('Criar Sala ✨'))),
        ]),
      )),
    );
    if (result == null || (result['name'] as String).isEmpty) return;
    try {
      final roomName = result['name'] as String;
      final id = await DataService.instance.createRoom(
        roomName,
        isPublic: result['isPublic'] as bool,
        category: result['category'] as String,
        description: result['description'] as String,
        password: result['password'] as String,
        isVipRoom: result['isVipRoom'] as bool? ?? false,
        isLive: true,
        mediaMode: 'audio',
      );
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => LoveRoomScreen(roomId: id, roomName: roomName)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }
}


class _ChatNavIcon extends StatelessWidget {
  const _ChatNavIcon({required this.selected});
  final bool selected;

  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: DataService.instance.myChats(),
    builder: (context, snapshot) {
      final uid = DataService.instance.uid;
      var unread = 0;
      for (final doc in snapshot.data?.docs ?? const []) {
        final data = doc.data();
        if ((data['hiddenFor'] as List<dynamic>? ?? const []).contains(uid)) continue;
        final counts = data['unreadCounts'];
        final value = counts is Map ? counts[uid] : null;
        if (value is num) unread += value.toInt();
      }
      return Stack(clipBehavior: Clip.none, children: [
        Icon(selected ? Icons.chat_bubble : Icons.chat_bubble_outline, size: 34, color: selected ? const Color(0xFFFF5CC8) : const Color(0xFFE05CFF), shadows: [Shadow(color: (selected ? const Color(0xFFFF19B8) : const Color(0xFF8D35FF)).withOpacity(.9), blurRadius: 12)]),
        if (unread > 0) Positioned(
          right: -10, top: -8,
          child: Container(
            constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
            decoration: const BoxDecoration(color: Color(0xFFFF2DAB), shape: BoxShape.circle),
            alignment: Alignment.center,
            child: Text(unread > 99 ? '99+' : '$unread', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
          ),
        ),
      ]);
    },
  );
}


class _LoveMixFeed extends StatefulWidget {
  const _LoveMixFeed({super.key, required this.onDiscover, required this.onRooms, required this.onVip});
  final VoidCallback onDiscover;
  final VoidCallback onRooms;
  final VoidCallback onVip;
  @override
  State<_LoveMixFeed> createState() => _LoveMixFeedState();
}

class _LoveMixFeedState extends State<_LoveMixFeed> {
  static const pink = Color(0xFFFF19B8);
  static const purple = Color(0xFF8D35FF);
  final _message = TextEditingController();
  bool _publishing = false;
  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';
  final _db = FirebaseFirestore.instance;

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  Future<bool> _publish({bool withPhoto = false}) async {
    if (_publishing) return false;
    XFile? photo;
    if (withPhoto) {
      photo = await ImagePicker().pickImage(
        source: ImageSource.gallery, imageQuality: 82, maxWidth: 1440,
      );
      if (photo == null) return false;
    }
    final text = _message.text.trim();
    if (text.isEmpty && photo == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escreva uma mensagem ou escolha uma foto.')),
      );
      return false;
    }
    setState(() => _publishing = true);
    try {
      final profile = await _db.collection('users').doc(_uid).get();
      String photoUrl = '';
      if (photo != null) {
        final bytes = await photo.readAsBytes();
        if (bytes.length > 5 * 1024 * 1024) {
          throw Exception('A foto deve ter no máximo 5 MB.');
        }
        final ext = photo.name.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
        photoUrl = await SupabaseService.instance.uploadPhoto(
          path: 'feed_posts/$_uid/${DateTime.now().millisecondsSinceEpoch}.$ext',
          bytes: bytes,
          contentType: ext == 'png' ? 'image/png' : 'image/jpeg',
        );
      }
      await _db.collection('feed_posts').add({
        'ownerId': _uid,
        'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
        'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
        'imageUrl': photoUrl,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
      });
      _message.clear();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Publicação compartilhada!')),
      );
      return true;
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível publicar: $e')),
      );
      return false;
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  Future<void> _deletePost(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF21132E),
        title: const Text('Apagar publicação?'),
        content: const Text('Essa publicação será removida do feed.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      final imageUrl = (doc.data()['imageUrl'] ?? '').toString();
      // Se a publicação veio da galeria do perfil (mesmo id), remove de lá
      // também; assim a foto não fica quebrada no perfil nem volta ao feed.
      final owner = (doc.data()['ownerId'] ?? '').toString();
      final batch = _db.batch();
      batch.delete(doc.reference);
      if (owner.isNotEmpty) {
        batch.delete(_db.collection('users').doc(owner).collection('posts').doc(doc.id));
      }
      await batch.commit();
      if (imageUrl.isNotEmpty) {
        await SupabaseService.instance.deletePublicUrl(imageUrl);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível apagar: $e')),
      );
    }
  }

  CollectionReference<Map<String, dynamic>> _postLikes(String postId) =>
      _db.collection('feed_posts').doc(postId).collection('likes');
  CollectionReference<Map<String, dynamic>> _postComments(String postId) =>
      _db.collection('feed_posts').doc(postId).collection('comments');

  Future<void> _toggleCommunityLike(String postId) async {
    if (_uid.isEmpty) return;
    final ref = _postLikes(postId).doc(_uid);
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (snap.exists) {
          tx.delete(ref);
        } else {
          tx.set(ref, {'uid': _uid, 'createdAt': FieldValue.serverTimestamp()});
        }
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível curtir: $e')),
      );
    }
  }

  Future<void> _openCommunityComments(String postId) async {
    final controller = TextEditingController();
    Future<void> send(StateSetter setSheet) async {
      final text = controller.text.trim();
      if (text.isEmpty || _uid.isEmpty) return;
      try {
        final profile = await _db.collection('users').doc(_uid).get();
        await _postComments(postId).add({
          'uid': _uid,
          'name': (profile.data()?['name'] ?? 'Pessoa').toString(),
          'photoUrl': (profile.data()?['photoUrl'] ?? '').toString(),
          'text': text,
          'createdAt': FieldValue.serverTimestamp(),
        });
        controller.clear();
        setSheet(() {});
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível comentar: $e')),
        );
      }
    }
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF171022),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (sheetContext) => StatefulBuilder(builder: (ctx, setSheet) =>
        Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: SizedBox(height: MediaQuery.of(ctx).size.height * .65, child: Column(children: [
            const Padding(padding: EdgeInsets.all(16), child: Text('Comentários da comunidade', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
            Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: _postComments(postId).orderBy('createdAt', descending: true).limit(100).snapshots(),
              builder: (ctx, snap) {
                if (snap.hasError) return const Center(child: Text('Não foi possível carregar os comentários.'));
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                if (snap.data!.docs.isEmpty) return const Center(child: Text('Seja a primeira pessoa a comentar!'));
                return ListView(children: snap.data!.docs.map((doc) {
                  final c = doc.data();
                  return ListTile(
                    leading: CircleAvatar(backgroundImage: (c['photoUrl'] ?? '').toString().isNotEmpty ? NetworkImage(c['photoUrl']) : null, child: (c['photoUrl'] ?? '').toString().isEmpty ? const Icon(Icons.person) : null),
                    title: Text((c['name'] ?? 'Pessoa').toString(), style: const TextStyle(color: Color(0xFFFF8BD5), fontWeight: FontWeight.bold)),
                    subtitle: Text((c['text'] ?? '').toString()),
                    trailing: c['uid'] == _uid ? IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white54), onPressed: () => doc.reference.delete()) : null,
                  );
                }).toList());
              },
            )),
            Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 14), child: Row(children: [
              Expanded(child: TextField(controller: controller, maxLength: 300, buildCounter: (_, {required currentLength, required isFocused, maxLength}) => null, decoration: const InputDecoration(hintText: 'Escreva um comentário...'))),
              IconButton(onPressed: () => send(setSheet), icon: const Icon(Icons.send, color: pink)),
            ])),
          ])),
        ),
      ),
    );
    controller.dispose();
  }

  Widget _communityInteractions(String postId) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Row(children: [
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postLikes(postId).snapshots(),
        builder: (context, snap) {
          final liked = snap.data?.docs.any((d) => d.id == _uid) ?? false;
          final count = snap.data?.docs.length ?? 0;
          return Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(visualDensity: VisualDensity.compact, onPressed: () => _toggleCommunityLike(postId),
              icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.redAccent : Colors.white70, size: 25)),
            Text('$count curtidas', style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ]);
        },
      ),
      const SizedBox(width: 12),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postComments(postId).snapshots(),
        builder: (context, snap) => TextButton.icon(
          onPressed: () => _openCommunityComments(postId),
          icon: const Icon(Icons.mode_comment_outlined, color: Colors.white70, size: 20),
          label: Text('${snap.data?.docs.length ?? 0} comentários', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ),
      ),
    ]),
  );

  String _tab = 'Início';

  void _selectTab(String value) {
    if (value == 'Descobrir') {
      widget.onDiscover();
      return;
    }
    if (value == 'Live') {
      widget.onRooms();
      return;
    }
    setState(() => _tab = value);
  }

  Future<void> openComposer() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF12041F),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(8, 14, 8, MediaQuery.of(ctx).viewInsets.bottom + 12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Nova publicação 💜', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFF1A0A2B), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF6B2FA8))),
            child: Column(children: [
              TextField(
                controller: _message, minLines: 1, maxLines: 5, maxLength: 1000, autofocus: true,
                decoration: const InputDecoration(hintText: 'O que você quer compartilhar?', counterText: '', border: InputBorder.none, filled: false),
              ),
              Row(children: [
                TextButton.icon(
                  onPressed: _publishing ? null : () async {
                    final nav = Navigator.of(ctx);
                    final ok = _publish(withPhoto: true);
                    setSheet(() {});
                    if (await ok && nav.mounted) nav.pop();
                    if (ctx.mounted) setSheet(() {});
                  },
                  icon: const Icon(Icons.photo_library_outlined, color: Color(0xFFE34CFF)),
                  label: const Text('Foto', style: TextStyle(color: Color(0xFFE34CFF))),
                ),
                const Spacer(),
                FilledButton(
                  onPressed: _publishing ? null : () async {
                    final nav = Navigator.of(ctx);
                    final ok = _publish();
                    setSheet(() {});
                    if (await ok && nav.mounted) nav.pop();
                    if (ctx.mounted) setSheet(() {});
                  },
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFFB000D9)),
                  child: _publishing
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Publicar'),
                ),
              ]),
            ]),
          ),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) => Stack(children: [
    Positioned.fill(child: DecoratedBox(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(-0.2, -1.05), radius: 1.15,
          colors: [Color(0xFF3A0A66), Color(0xFF12031F), Color(0xFF050008)],
          stops: [0, .45, 1],
        ),
      ),
    )),
    SafeArea(bottom: false, child: ListView(
      padding: const EdgeInsets.only(bottom: 96),
      children: [
        _homeHeader(),
        const StoriesStrip(),
        const SizedBox(height: 6),
        _tabsRow(),
        const SizedBox(height: 12),
        _feedList(),
      ],
    )),
    Positioned(right: 16, bottom: 14, child: GestureDetector(
      onTap: openComposer,
      child: Container(
        width: 58, height: 58,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF2A0A4A),
          border: Border.all(color: const Color(0xFFC25BFF), width: 2),
          boxShadow: const [BoxShadow(color: Color(0xAA9B00FF), blurRadius: 16)],
        ),
        child: const Icon(Icons.edit, color: Color(0xFFE9A6FF), size: 28),
      ),
    )),
  ]);

  Widget _homeHeader() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 10, 12, 6),
    child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
      const Icon(Icons.favorite_border, color: Color(0xFFD27BFF), size: 40),
      const SizedBox(width: 4),
      Expanded(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('👑', style: TextStyle(fontSize: 15, height: 1)),
        ShaderMask(
          shaderCallback: (r) => const LinearGradient(colors: [Color(0xFFE9A6FF), Color(0xFFB04DFF), Color(0xFFE34CFF)]).createShader(r),
          child: const Text('LoveMix', maxLines: 1, style: TextStyle(
            fontSize: 38, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, color: Colors.white, height: 1,
            letterSpacing: -1,
            shadows: [Shadow(color: Color(0xFF9B00FF), blurRadius: 14)],
          )),
        ),
        const SizedBox(height: 2),
        const FittedBox(fit: BoxFit.scaleDown, child: Text('Conecte-se • Faça Amigos • Encontre o Amor 💜',
          style: TextStyle(fontSize: 10.5, fontStyle: FontStyle.italic, color: Colors.white))),
      ])),
      IconButton(
        onPressed: widget.onDiscover,
        icon: const Icon(Icons.search, color: Color(0xFFE9C6FF), size: 30),
      ),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _db.collection('users').doc(_uid).collection('notifications').snapshots(),
        builder: (context, snap) {
          final unread = snap.data?.docs.where((d) => d.data()['read'] != true).length ?? 0;
          return IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
            icon: Stack(clipBehavior: Clip.none, children: [
              const Icon(Icons.notifications_none, color: Color(0xFFE9C6FF), size: 31),
              if (unread > 0) Positioned(right: -6, top: -7, child: Container(
                constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                padding: const EdgeInsets.symmetric(horizontal: 4),
                decoration: const BoxDecoration(color: Color(0xFFFF2D2D), shape: BoxShape.circle),
                alignment: Alignment.center,
                child: Text(unread > 9 ? '9+' : '$unread', style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w900)),
              )),
            ]),
          );
        },
      ),
      GestureDetector(
        onTap: widget.onVip,
        child: Container(
          width: 50, height: 52,
          decoration: BoxDecoration(
            color: const Color(0xFF2A0A4A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFB04DFF), width: 1.6),
            boxShadow: const [BoxShadow(color: Color(0x889B00FF), blurRadius: 10)],
          ),
          child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('👑', style: TextStyle(fontSize: 18, height: 1)),
            Text('VIP', style: TextStyle(color: Color(0xFFE9C6FF), fontWeight: FontWeight.w900, fontSize: 15, height: 1.1)),
          ]),
        ),
      ),
    ]),
  );

  Widget _tabsRow() {
    const items = [
      ('Início', Icons.home_filled),
      ('Descobrir', Icons.local_fire_department),
      ('Amizades', Icons.groups),
      ('Namoro', Icons.favorite),
      ('Live', Icons.play_arrow),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        for (final item in items) _tabPill(item.$1, item.$2, _tab == item.$1),
      ]),
    );
  }

  Widget _tabPill(String label, IconData icon, bool selected) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: InkWell(
      onTap: () => _selectTab(label),
      borderRadius: BorderRadius.circular(26),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: selected ? const LinearGradient(colors: [Color(0xFFC25BFF), Color(0xFF8D2BFF)], begin: Alignment.topCenter, end: Alignment.bottomCenter) : null,
          color: selected ? null : const Color(0xFF1A0A28),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: selected ? const Color(0xFFE9A6FF) : const Color(0xFF3A2150)),
          boxShadow: selected ? const [BoxShadow(color: Color(0x889B00FF), blurRadius: 12)] : null,
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: selected ? Colors.white : const Color(0xFFD9B8F2), size: 24),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: selected ? Colors.white : const Color(0xFFE6D2F5), fontWeight: FontWeight.w800, fontSize: 15)),
        ]),
      ),
    ),
  );

  Widget _feedList() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: _db.collection('feed_posts').orderBy('createdAt', descending: true).limit(60).snapshots(),
    builder: (context, snap) {
      if (snap.hasError) return _feedMessage('Não foi possível carregar as publicações agora.');
      if (!snap.hasData) {
        return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF))));
      }
      final docs = snap.data!.docs;
      if (_tab == 'Amizades') {
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _db.collection('alliances').where('members', arrayContains: _uid).snapshots(),
          builder: (context, allianceSnap) {
            if (!allianceSnap.hasData) {
              return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF))));
            }
            final ids = <String>{};
            for (final a in allianceSnap.data!.docs) {
              final data = a.data();
              if (data['invitationStatus'] != 'accepted') continue;
              if (!['Amigos', 'BFF', 'Namorados'].contains(data['relationshipType'])) continue;
              ids.addAll((data['members'] as List<dynamic>? ?? const []).map((v) => v.toString()).where((id) => id != _uid));
            }
            return _postsColumn(docs.where((d) => ids.contains((d.data()['ownerId'] ?? '').toString())).toList(),
                'Você ainda não tem amizades com publicações.');
          },
        );
      }
      if (_tab == 'Namoro') {
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _db.collection('users').doc(_uid).collection('following').snapshots(),
          builder: (context, followingSnap) {
            if (!followingSnap.hasData) {
              return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF))));
            }
            final ids = followingSnap.data!.docs.map((d) => d.id).toSet();
            return _postsColumn(docs.where((d) => ids.contains((d.data()['ownerId'] ?? '').toString())).toList(),
                'Siga pessoas para ver as publicações delas aqui.');
          },
        );
      }
      return _postsColumn(docs, 'Ainda não há publicações. Seja a primeira pessoa a postar!');
    },
  );

  Widget _feedMessage(String message) => Padding(
    padding: const EdgeInsets.all(32),
    child: Center(child: Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
  );

  Widget _postsColumn(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs, String empty) {
    if (docs.isEmpty) return _feedMessage(empty);
    return Column(children: [for (final doc in docs) _postCard(doc)]);
  }

  Widget _postCard(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final p = doc.data();
    final owner = (p['ownerId'] ?? '').toString();
    final text = (p['text'] ?? '').toString();
    final images = <String>[
      if (p['imageUrls'] is List) ...(p['imageUrls'] as List).map((e) => e.toString()).where((e) => e.isNotEmpty),
      if (p['imageUrls'] is! List && (p['imageUrl'] ?? '').toString().isNotEmpty) (p['imageUrl']).toString(),
    ];
    final ts = p['createdAt'];
    final when = ts is Timestamp ? _ago(ts) : 'agora';
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 14),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
      decoration: BoxDecoration(
        color: const Color(0xCC0B0214),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF7A2FC4), width: 1.3),
        boxShadow: const [BoxShadow(color: Color(0x553F00FF), blurRadius: 12)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: _db.collection('users').doc(owner).snapshots(),
          builder: (context, userSnap) {
            final u = userSnap.data?.data() ?? const <String, dynamic>{};
            final name = (u['name'] ?? p['name'] ?? 'Pessoa').toString();
            final avatar = (u['photoUrl'] ?? p['photoUrl'] ?? '').toString();
            final publicId = (u['publicId'] ?? '').toString();
            final verified = u['isVerified'] == true;
            final vip = u['isVip'] == true || u['nicknameDecorationActive'] == true;
            final mine = owner == _uid;
            return Row(children: [
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: owner))),
                child: Container(
                  width: 62, height: 62, padding: const EdgeInsets.all(2.5),
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFE34CFF), Color(0xFF7A2FFF)])),
                  child: ClipOval(child: avatar.isEmpty
                      ? Container(color: const Color(0xFF241333), child: const Icon(Icons.person, color: Colors.white70))
                      : CachedNetworkImage(imageUrl: avatar, fit: BoxFit.cover, memCacheWidth: 200,
                          errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white70))),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(child: VipNickname(name: name, isVip: vip, styleId: (u['vipNicknameStyle'] ?? 'royal_gold').toString(),
                      textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white))),
                  const SizedBox(width: 6),
                  const Text('💜', style: TextStyle(fontSize: 16)),
                  if (verified) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.verified, color: Color(0xFFB36BFF), size: 19)),
                ]),
                Text('${publicId.isNotEmpty ? 'ID: $publicId  •  ' : ''}$when',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xFFB9A3CC), fontSize: 13)),
              ])),
              if (!mine) _followButton(owner, name),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert, color: Colors.white70),
                color: const Color(0xFF21132E),
                onSelected: (v) {
                  if (v == 'profile') {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: owner)));
                  } else if (v == 'delete') {
                    _deletePost(doc);
                  }
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'profile', child: Text('Ver perfil')),
                  if (mine) const PopupMenuItem(value: 'delete', child: Text('Apagar publicação')),
                ],
              ),
            ]);
          },
        ),
        if (text.isNotEmpty) Padding(
          padding: const EdgeInsets.fromLTRB(4, 12, 4, 4),
          child: Text(text, style: const TextStyle(fontSize: 17, color: Colors.white)),
        ),
        if (images.isNotEmpty) Padding(
          padding: const EdgeInsets.only(top: 8),
          child: _PostImages(urls: images),
        ),
        _postActions(doc.id, owner, text),
      ]),
    );
  }

  Widget _followButton(String owner, String name) => StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
    stream: DataService.instance.followingStatus(owner),
    builder: (context, snap) {
      final following = snap.data?.exists ?? false;
      return GestureDetector(
        onTap: () async {
          try {
            final followed = await DataService.instance.toggleFollow(owner);
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(followed ? 'Você começou a seguir $name 💗' : 'Você deixou de seguir $name.')));
          } catch (e) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível seguir: ${e.toString().replaceFirst('Exception: ', '')}')));
          }
        },
        child: Container(
          margin: const EdgeInsets.only(left: 4),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
          decoration: BoxDecoration(
            color: following ? const Color(0xFF3A1A5C) : null,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFFB04DFF), width: 1.5),
          ),
          child: Text(following ? 'Seguindo' : 'Seguir', style: const TextStyle(color: Color(0xFFE9C6FF), fontWeight: FontWeight.w800, fontSize: 15)),
        ),
      );
    },
  );

  Widget _postActions(String postId, String owner, String text) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 10, 4, 4),
    child: Row(children: [
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postLikes(postId).snapshots(),
        builder: (context, snap) {
          final liked = snap.data?.docs.any((d) => d.id == _uid) ?? false;
          final count = snap.data?.docs.length ?? 0;
          return InkWell(
            onTap: () => _toggleCommunityLike(postId),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(liked ? Icons.favorite : Icons.favorite_border, color: const Color(0xFFFF2DE0), size: 30),
              const SizedBox(width: 6),
              Text('$count', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
            ]),
          );
        },
      ),
      const SizedBox(width: 18),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _postComments(postId).snapshots(),
        builder: (context, snap) => InkWell(
          onTap: () => _openCommunityComments(postId),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.mode_comment_outlined, color: Colors.white, size: 27),
            const SizedBox(width: 6),
            Text('${snap.data?.docs.length ?? 0}', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
      const SizedBox(width: 16),
      InkWell(
        onTap: () async {
          await Clipboard.setData(ClipboardData(text: text.isEmpty ? 'Veja essa publicação no LoveMix 💜' : '$text\n\nVeja no LoveMix 💜'));
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Texto copiado para compartilhar!')));
        },
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.share_outlined, color: Colors.white, size: 26),
          SizedBox(width: 5),
          Text('Compartilhar', style: TextStyle(color: Colors.white, fontSize: 14.5)),
        ]),
      ),
      const Spacer(),
      InkWell(
        onTap: () {
          if (owner == _uid) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Você não pode enviar presente para si mesmo.')));
            return;
          }
          Navigator.push(context, MaterialPageRoute(builder: (_) => GiftsScreen(initialUid: owner)));
        },
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.card_giftcard, color: Color(0xFFFF2DE0), size: 26),
          SizedBox(width: 5),
          Flexible(child: Text('Enviar Presente', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, fontSize: 14.5))),
        ]),
      ),
    ]),
  );

  static Widget _unusedKeepCategory(String emoji, String label, VoidCallback onTap) => const SizedBox.shrink();
  static Widget _unusedKeepQuick(String emoji, String title, VoidCallback onTap) => const SizedBox.shrink();

  static void _goDiscover(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _DiscoverRoute()));
  static void _goRooms(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => const _RoomsRoute()));

  Widget _composer() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFF4C2869))),
    child: Column(children: [
      TextField(
        controller: _message, minLines: 1, maxLines: 5, maxLength: 1000,
        decoration: const InputDecoration(
          hintText: 'O que você quer compartilhar?',
          counterText: '', border: InputBorder.none, filled: false,
        ),
      ),
      Row(children: [
        TextButton.icon(
          onPressed: _publishing ? null : () => _publish(withPhoto: true),
          icon: const Icon(Icons.photo_library_outlined, color: pink),
          label: const Text('Foto', style: TextStyle(color: pink)),
        ),
        const Spacer(),
        FilledButton(
          onPressed: _publishing ? null : () => _publish(),
          style: FilledButton.styleFrom(backgroundColor: pink),
          child: _publishing
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Text('Publicar'),
        ),
      ]),
    ]),
  );

  String _ago(Timestamp timestamp) {
    final d = DateTime.now().difference(timestamp.toDate());
    if (d.inMinutes < 1) return 'agora';
    if (d.inHours < 1) return '${d.inMinutes}min atrás';
    if (d.inDays < 1) return '${d.inHours}h atrás';
    return '${d.inDays}d atrás';
  }

  static Widget _category(String emoji, String label, VoidCallback onTap) => Expanded(child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(
      height: 78, decoration: BoxDecoration(color: const Color(0xFF1C1229), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF3C2456))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 25)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))]),
    )),
  ));

  static Widget _quick(String emoji, String title, VoidCallback onTap) => InkWell(onTap: onTap, child: Container(
    padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: const Color(0xFF1A1028), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF4C2869))),
    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text(emoji, style: const TextStyle(fontSize: 22)), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
  ));

}

class _PostImages extends StatefulWidget {
  const _PostImages({required this.urls});
  final List<String> urls;
  @override
  State<_PostImages> createState() => _PostImagesState();
}

class _PostImagesState extends State<_PostImages> {
  int _page = 0;
  @override
  Widget build(BuildContext context) {
    final urls = widget.urls;
    final width = MediaQuery.of(context).size.width - 40;
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(border: Border.all(color: const Color(0xFF7A2FC4))),
        height: width * 1.15,
        child: Stack(children: [
          PageView.builder(
            itemCount: urls.length,
            onPageChanged: (v) => setState(() => _page = v),
            itemBuilder: (_, i) => GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(
                backgroundColor: Colors.black,
                appBar: AppBar(backgroundColor: Colors.black),
                body: Center(child: InteractiveViewer(child: CachedNetworkImage(imageUrl: urls[i], fit: BoxFit.contain))),
              ))),
              child: CachedNetworkImage(
                imageUrl: urls[i], fit: BoxFit.cover, width: double.infinity, memCacheWidth: 1000,
                fadeInDuration: const Duration(milliseconds: 150),
                placeholder: (_, __) => const ColoredBox(color: Color(0xFF24102F), child: Center(child: CircularProgressIndicator(color: Color(0xFFE34CFF)))),
                errorWidget: (_, __, ___) => const ColoredBox(color: Color(0xFF24102F), child: Center(child: Icon(Icons.broken_image, color: Colors.white54, size: 48))),
              ),
            ),
          ),
          if (urls.length > 1) Positioned(right: 12, top: 12, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(18)),
            child: Text('${_page + 1}/${urls.length}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          )),
        ]),
      ),
    );
  }
}

class _OnlineBadge extends StatelessWidget {
  const _OnlineBadge({required this.isOnline});
  final bool isOnline;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: const Color(0xFF351052), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.circle, color: isOnline ? const Color(0xFF35E85A) : Colors.white38, size: 11),
      const SizedBox(width: 6),
      Text(isOnline ? 'Online' : 'OFF', style: TextStyle(
        color: isOnline ? Colors.greenAccent : Colors.white70,
        fontWeight: FontWeight.bold,
      )),
    ]),
  );
}

class _DiscoverRoute extends StatelessWidget {
  const _DiscoverRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Descobrir pessoas')), body: DiscoverScreen());
}
class _RoomsRoute extends StatelessWidget {
  const _RoomsRoute();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Salas LoveMix')), body: ChatRoomsScreen());
}
