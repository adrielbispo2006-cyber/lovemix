import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Recebe notificações push e também mostra notificações enquanto o app está aberto.
class NotificationService {
  NotificationService._();
  static final instance = NotificationService._();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  String? _registeredUid;
  StreamSubscription<String>? _tokenRefreshSubscription;

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'lovemix_updates',
    'LoveMix',
    description: 'Notificações de mensagens, convites e chamadas do LoveMix',
    importance: Importance.high,
  );

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _chatsSub;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _notifSub;
  final Map<String, Timestamp?> _lastChatStamp = {};
  bool _chatsPrimed = false;
  bool _notifPrimed = false;

  /// Conversa aberta no momento (não mostra alerta de quem você já está vendo).
  String? activeChatId;

  Future<void> initializeForUser(User user) async {
    if (!_initialized) {
      try {
        const android = AndroidInitializationSettings('@mipmap/ic_launcher');
        const settings = InitializationSettings(android: android);
        await _local.initialize(settings: settings);
        final androidImpl = _local.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
        await androidImpl?.createNotificationChannel(_channel);
        await androidImpl?.requestNotificationsPermission();
      } catch (_) {}
      try {
        FirebaseMessaging.onMessage.listen(_showForegroundNotification);
        FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationTap);
      } catch (_) {}
      _initialized = true;
    }

    // Escutas dentro do app: garantem o alerta de mensagens, story, curtidas e
    // convites mesmo que o push do servidor (Cloud Functions) não esteja ativo.
    _startLiveListeners(user.uid);

    try {
      final permission = await _messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );
      if (permission.authorizationStatus == AuthorizationStatus.denied) return;
    } catch (_) {}

    if (_registeredUid == user.uid) return;
    _registeredUid = user.uid;
    try {
      await _saveToken(user.uid);
    } catch (_) {
      _registeredUid = null;
    }
    await _tokenRefreshSubscription?.cancel();
    _tokenRefreshSubscription = _messaging.onTokenRefresh.listen((token) async {
      final current = FirebaseAuth.instance.currentUser;
      if (current != null && current.uid == user.uid) {
        await _saveToken(user.uid, token: token);
      }
    });
  }

  void stop() {
    _chatsSub?.cancel();
    _notifSub?.cancel();
    _chatsSub = null;
    _notifSub = null;
    _lastChatStamp.clear();
    _chatsPrimed = false;
    _notifPrimed = false;
    _registeredUid = null;
  }

  void _startLiveListeners(String uid) {
    stop();
    final db = FirebaseFirestore.instance;

    // Mensagens diretas: avisa quando o último movimento de uma conversa muda.
    _chatsSub = db
        .collection('chats')
        .where('users', arrayContains: uid)
        .snapshots()
        .listen((snap) async {
      for (final change in snap.docChanges) {
        final data = change.doc.data();
        if (data == null) continue;
        final stamp = data['lastMessageAt'] as Timestamp?;
        final previous = _lastChatStamp[change.doc.id];
        _lastChatStamp[change.doc.id] = stamp;
        if (!_chatsPrimed || change.type == DocumentChangeType.removed) continue;
        if (stamp == null || (previous != null && stamp.compareTo(previous) <= 0)) continue;
        if (activeChatId == change.doc.id) continue;
        try {
          final last = await db
              .collection('chats')
              .doc(change.doc.id)
              .collection('messages')
              .orderBy('createdAt', descending: true)
              .limit(1)
              .get();
          if (last.docs.isEmpty) continue;
          final m = last.docs.first.data();
          final sender = (m['senderId'] ?? '').toString();
          if (sender.isEmpty || sender == uid) continue;
          final profile = await db.collection('users').doc(sender).get();
          final name = (profile.data()?['name'] ?? 'Nova mensagem').toString();
          await _showLocal(
            title: 'Mensagem de $name',
            body: _messagePreview(m),
            tag: 'msg_${last.docs.first.id}',
            data: {'type': 'message', 'chatId': change.doc.id, 'fromUid': sender},
          );
        } catch (_) {}
      }
      _chatsPrimed = true;
    }, onError: (_) {});

    // Central de notificações: story, publicações, convites de sala etc.
    _notifSub = db
        .collection('users')
        .doc(uid)
        .collection('notifications')
        .orderBy('createdAt', descending: true)
        .limit(20)
        .snapshots()
        .listen((snap) async {
      if (!_notifPrimed) {
        _notifPrimed = true;
        return;
      }
      for (final change in snap.docChanges) {
        if (change.type != DocumentChangeType.added) continue;
        final d = change.doc.data();
        if (d == null || d['read'] == true) continue;
        final type = (d['type'] ?? '').toString();
        final from = (d['fromName'] ?? 'Alguém').toString();
        String title;
        switch (type) {
          case 'story_like':
            title = 'Curtiram seu story ❤️';
            break;
          case 'story_comment':
            title = 'Comentaram no seu story 💬';
            break;
          case 'post_like':
            title = 'Curtiram sua publicação ❤️';
            break;
          case 'post_comment':
            title = 'Comentaram na sua publicação 💬';
            break;
          case 'room_invite':
            title = 'Convite para sala 🎙️';
            break;
          default:
            title = 'LoveMix';
        }
        final body = (d['body'] ?? '$from enviou uma novidade.').toString();
        await _showLocal(
          title: title,
          body: body,
          tag: 'n_${change.doc.id}',
          data: {'type': type, 'fromUid': (d['fromUid'] ?? '').toString()},
        );
      }
    }, onError: (_) {});
  }

  String _messagePreview(Map<String, dynamic> m) {
    final type = (m['type'] ?? 'text').toString();
    if (type == 'image') return '📷 Enviou uma foto';
    if (type == 'gift') return '🎁 ${(m['text'] ?? 'Enviou um presente').toString()}';
    final text = (m['text'] ?? '').toString();
    if (text.isEmpty) return 'Nova mensagem';
    return text.length > 100 ? '${text.substring(0, 97)}...' : text;
  }

  Future<void> _showLocal({
    required String title,
    required String body,
    required String tag,
    Map<String, dynamic> data = const {},
  }) async {
    // Mesma tag + mesmo id = substitui o push do servidor, sem duplicar.
    await _local.show(
      id: 0,
      title: title,
      body: body,
      notificationDetails: NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
          tag: tag,
        ),
      ),
      payload: jsonEncode(data),
    );
  }

  Future<void> _saveToken(String uid, {String? token}) async {
    final value = token ?? await _messaging.getToken();
    if (value == null || value.isEmpty) return;
    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('fcmTokens')
        .doc(value)
        .set({
      'token': value,
      'updatedAt': FieldValue.serverTimestamp(),
      'platform': 'android',
    });
  }

  Future<void> _showForegroundNotification(RemoteMessage message) async {
    final notification = message.notification;
    final title = notification?.title ?? message.data['title']?.toString() ?? 'LoveMix';
    final body = notification?.body ?? message.data['body']?.toString() ?? 'Você tem uma novidade.';
    await _showLocal(
      title: title,
      body: body,
      tag: (message.data['tag'] ?? 'fcm_${message.hashCode}').toString(),
      data: message.data,
    );
  }

  void _handleNotificationTap(RemoteMessage message) {
    // A tela de destino pode ser aberta aqui quando a navegação global do app
    // estiver configurada. Por enquanto, tocar na notificação abre o LoveMix.
  }
}
