import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool busy = false;
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  DateTime? birthday;

  Future<void> submit() async {
    setState(() => busy = true);
    try {
      if (register) {
        if (birthday == null) throw Exception('Informe sua data de nascimento.');
        if (DateTime.now().difference(birthday!).inDays < 18 * 365) {
          throw Exception('O LoveMix é destinado somente a maiores de 18 anos.');
        }
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
        await cred.user!.updateDisplayName(name.text.trim());
        await DataService.instance.createUser(name: name.text, birthday: birthday!);
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      show(e.message ?? 'Não foi possível autenticar.');
    } catch (e) {
      show(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void show(String message) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(25),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                children: [
                  const Icon(Icons.favorite, color: Color(0xFFE7BD50), size: 65),
                  const SizedBox(height: 8),
                  const Text('LoveMix', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Color(0xFFE7BD50))),
                  const Text('Conecte pessoas, viva novas histórias!', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 38),
                  Text(register ? 'Criar uma conta' : 'Entrar', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  if (register) ...[
                    TextField(controller: name, decoration: const InputDecoration(hintText: 'Nome completo', prefixIcon: Icon(Icons.person_outline))),
                    const SizedBox(height: 12),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
                  const SizedBox(height: 12),
                  TextField(controller: password, obscureText: true, decoration: const InputDecoration(hintText: 'Senha', prefixIcon: Icon(Icons.lock_outline))),
                  if (register) ...[
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final d = await showDatePicker(context: context, firstDate: DateTime(1900), lastDate: DateTime.now(), initialDate: DateTime(2000));
                        if (d != null) setState(() => birthday = d);
                      },
                      icon: const Icon(Icons.calendar_month),
                      label: Text(birthday == null ? 'Data de nascimento' : '${birthday!.day}/${birthday!.month}/${birthday!.year}'),
                    ),
                  ],
                  const SizedBox(height: 22),
                  ElevatedButton(
                    onPressed: busy ? null : submit,
                    child: busy ? const CircularProgressIndicator(color: Colors.black) : Text(register ? 'Cadastrar' : 'Entrar'),
                  ),
                  TextButton(
                    onPressed: () => setState(() => register = !register),
                    child: Text(register ? 'Já tem uma conta? Entrar' : 'Não tem uma conta? Criar conta'),
                  ),
                  if (!register)
                    TextButton(
                      onPressed: () async {
                        if (email.text.trim().isEmpty) return show('Digite seu e-mail primeiro.');
                        try {
                          await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
                          show('Enviamos um link de recuperação para seu e-mail.');
                        } catch (e) { show('Não foi possível enviar o e-mail.'); }
                      },
                      child: const Text('Esqueci minha senha'),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
