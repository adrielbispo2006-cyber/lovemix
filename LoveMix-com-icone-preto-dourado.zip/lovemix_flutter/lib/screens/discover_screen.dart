import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'profile_view_screen.dart';

class DiscoverScreen extends StatelessWidget {
  const DiscoverScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return StreamBuilder(
      stream: service.discoverUsers(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snapshot.data!.docs.where((d) => d.id != service.uid).toList();
        if (docs.isEmpty) return const Center(child: Text('Ainda não há perfis para mostrar.'));
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          itemBuilder: (context, i) {
            final doc = docs[i];
            final p = doc.data();
            final birthday = (p['birthday'] as Timestamp?)?.toDate();
            final age = birthday == null ? '' : '${(DateTime.now().difference(birthday).inDays / 365.25).floor()}';
            final photo = (p['photoUrl'] ?? '') as String;
            return Card(
              color: const Color(0xFF17140E),
              clipBehavior: Clip.antiAlias,
              margin: const EdgeInsets.only(bottom: 18),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id))),
                  child: SizedBox(
                    height: 370, width: double.infinity,
                    child: photo.isEmpty
                        ? const ColoredBox(color: Color(0xFF292318), child: Icon(Icons.person, size: 100, color: Colors.white38))
                        : CachedNetworkImage(imageUrl: photo, fit: BoxFit.cover),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
                  child: Row(children: [
                    Expanded(
                      child: Text('${p['name'] ?? 'Pessoa'}${age.isEmpty ? '' : ', $age'}',
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    ),
                    if (p['isOnline'] == true)
                      const Row(children: [
                        Icon(Icons.circle, color: Color(0xFF45D483), size: 10),
                        SizedBox(width: 5),
                        Text('Online agora', style: TextStyle(color: Color(0xFF45D483), fontSize: 12)),
                      ]),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text((p['city'] ?? 'Localização não informada').toString(), style: const TextStyle(color: Colors.white60)),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    IconButton.filledTonal(
                      onPressed: () async {
                        await service.pass(doc.id);
                        if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Perfil ignorado.')),
                        );
                      },
                      icon: const Icon(Icons.close),
                    ),
                    IconButton.filledTonal(onPressed: () async {
                      final matched = await service.like(doc.id);
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(matched ? 'Deu match! 💛' : 'Curtida enviada!')),
                      );
                    }, icon: const Icon(Icons.star, color: Color(0xFFE7BD50))),
                    IconButton.filled(onPressed: () async {
                      final matched = await service.like(doc.id);
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(matched ? 'Deu match! 💛' : 'Curtida enviada!')),
                      );
                    }, icon: const Icon(Icons.favorite)),
                  ]),
                ),
              ]),
            );
          },
        );
      },
    );
  }
}
