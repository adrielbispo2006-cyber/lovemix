import 'package:flutter/material.dart';
import '../services/data_service.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final packages = [
      ('50 Moedas', 'R\$ 4,90'),
      ('100 Moedas', 'R\$ 8,90'),
      ('250 Moedas', 'R\$ 19,90'),
      ('500 Moedas', 'R\$ 30,90'),
      ('1.000 Moedas', 'R\$ 59,90'),
    ];
    return StreamBuilder(
      stream: DataService.instance.myProfile(),
      builder: (context, snap) {
        final p = snap.data?.data() ?? {};
        return ListView(padding: const EdgeInsets.all(18), children: [
          Text('Saldo: ${p['coins'] ?? 0} moedas', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Use moedas para recursos e presentes dentro do LoveMix.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          const Card(
            color: Color(0xFF211B0E),
            child: ListTile(
              leading: Icon(Icons.chat_bubble, color: Color(0xFFE7BD50)),
              title: Text('Chat sempre grátis'),
              subtitle: Text('Mensagens com seus matches não consomem moedas e não exigem VIP.'),
            ),
          ),
          const SizedBox(height: 20),
          ...packages.map((e) => Card(color: const Color(0xFF211B0E), child: ListTile(
            leading: const Icon(Icons.monetization_on, color: Color(0xFFE7BD50)),
            title: Text(e.$1), trailing: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
          ))),
          const SizedBox(height: 12),
          const Text('A compra de moedas será ativada após integrar um provedor de pagamento e validar as transações no servidor.', style: TextStyle(color: Colors.white54)),
          const SizedBox(height: 24),
          const Text('Seja VIP', style: TextStyle(fontSize: 24, color: Color(0xFFE7BD50), fontWeight: FontWeight.bold)),
          const Text('Mais destaque, filtros e recursos exclusivos.'),
          const SizedBox(height: 12),
          const Card(color: Color(0xFF211B0E), child: ListTile(title: Text('7 dias'), trailing: Text('R\$ 9,00'))),
          const Card(color: Color(0xFF211B0E), child: ListTile(title: Text('30 dias'), trailing: Text('R\$ 24,90'))),
          const Card(color: Color(0xFF211B0E), child: ListTile(title: Text('90 dias'), trailing: Text('R\$ 59,90'))),
          const Text('Assinaturas VIP precisam de integração com Google Play Billing / App Store e validação no backend.', style: TextStyle(color: Colors.white54)),
        ]);
      },
    );
  }
}
