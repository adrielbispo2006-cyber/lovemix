import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'discover_screen.dart';
import 'messages_screen.dart';
import 'profile_screen.dart';
import 'wallet_screen.dart';
import 'chat_rooms_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    DataService.instance.setOnlineStatus(true);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      DataService.instance.setOnlineStatus(true);
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      DataService.instance.setOnlineStatus(false);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    DataService.instance.setOnlineStatus(false);
    super.dispose();
  }

  int index = 0;
  final pages = const [DiscoverScreen(), MessagesScreen(), ChatRoomsScreen(), WalletScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.favorite, color: Color(0xFFE7BD50)),
          SizedBox(width: 8),
          Text('LoveMix', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFE7BD50))),
        ]),
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Mensagens'),
          NavigationDestination(icon: Icon(Icons.forum_outlined), label: 'Salas'),
          NavigationDestination(icon: Icon(Icons.monetization_on_outlined), label: 'Moedas'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Perfil'),
        ],
      ),
    );
  }
}
