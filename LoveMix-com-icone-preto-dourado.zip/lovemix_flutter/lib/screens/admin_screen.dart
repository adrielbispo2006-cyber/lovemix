import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Painel Administrativo')),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('users').snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final users = snap.data!.docs;
          final active = users.where((u) => u.data()['isActive'] == true).length;
          return ListView(padding: const EdgeInsets.all(16), children: [
            _stat('Total de usuários', '${users.length}', Icons.people),
            _stat('Usuários ativos', '$active', Icons.person),
            const SizedBox(height: 18),
            const Text('Usuários', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            ...users.map((u) => ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text((u.data()['name'] ?? 'Sem nome').toString()),
              subtitle: Text((u.data()['email'] ?? '').toString()),
              trailing: Text(u.data()['isAdmin'] == true ? 'Admin' : 'Usuário'),
            )),
          ]);
        },
      ),
    );
  }

  Widget _stat(String title, String value, IconData icon) => Card(
    color: const Color(0xFF211B0E),
    child: ListTile(leading: Icon(icon, color: const Color(0xFFE7BD50), size: 30),
      title: Text(title), trailing: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
  );
}
