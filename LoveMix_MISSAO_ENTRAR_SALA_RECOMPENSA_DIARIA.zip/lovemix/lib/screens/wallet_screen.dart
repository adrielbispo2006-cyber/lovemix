import 'package:flutter/material.dart';
import '../services/data_service.dart';

const _pink = Color(0xFFFF2DAB);
const _panel = Color(0xFF241333);

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});
  @override
  Widget build(BuildContext context) => MediaQuery(
    data: MediaQuery.of(context).copyWith(textScaler: const TextScaler.linear(1.0)),
    child: const _BalanceTab(),
  );
}

class _BalanceTab extends StatefulWidget {
  const _BalanceTab();
  @override
  State<_BalanceTab> createState() => _BalanceTabState();
}

class _BalanceTabState extends State<_BalanceTab> {
  final codeController = TextEditingController();
  bool loading = false;

  @override
  void dispose() {
    codeController.dispose();
    super.dispose();
  }

  Future<void> redeem() async {
    if (loading) return;
    final code = codeController.text.trim();
    if (code.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Digite um código de resgate.')));
      return;
    }
    setState(() => loading = true);
    try {
      final reward = await DataService.instance.redeemPromoCode(code);
      if (!mounted) return;
      codeController.clear();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(reward == 'coins' ? 'Resgatado com sucesso! 2.000 moedas adicionadas à sua conta.' : 'Código resgatado com sucesso!'),
        backgroundColor: Colors.green.shade700,
      ));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: DataService.instance.myProfile(),
    builder: (context, snap) {
      final profile = snap.data?.data() ?? {};
      return ListView(padding: const EdgeInsets.all(18), children: [
        Row(children: [
          Expanded(child: _currencyCard('Moedas', '${profile['coins'] ?? 0}', '🪙')),
          const SizedBox(width: 10),
          Expanded(child: _currencyCard('Diamantes', '${profile['diamonds'] ?? 0}', '💎')),
        ]),
        const SizedBox(height: 14),
        const Card(color: _panel, child: ListTile(
          leading: Icon(Icons.chat_bubble, color: _pink),
          title: Text('Chat sempre grátis'),
          subtitle: Text('Conversar com seus matches não consome moedas.'),
        )),
        const SizedBox(height: 22),
        const Text('RESGATAR MOEDAS', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: _pink)),
        const SizedBox(height: 6),
        const Text('Use um dos códigos oficiais do LoveMix para receber 2.000 moedas. Não é necessário fazer pagamento.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 14),
        TextField(
          controller: codeController,
          textCapitalization: TextCapitalization.characters,
          autocorrect: false,
          enableSuggestions: false,
          decoration: InputDecoration(
            hintText: 'Digite seu código',
            filled: true,
            fillColor: _panel,
            prefixIcon: const Icon(Icons.confirmation_number, color: _pink),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onSubmitted: (_) => redeem(),
        ),
        const SizedBox(height: 12),
        SizedBox(height: 50, child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white),
          onPressed: loading ? null : redeem,
          icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.card_giftcard),
          label: Text(loading ? 'Verificando código...' : 'RESGATAR 2.000 MOEDAS', style: const TextStyle(fontWeight: FontWeight.bold)),
        )),
        const SizedBox(height: 18),
        const Text('Cada código pode ser resgatado uma única vez por conta. Códigos diferentes podem ser usados na mesma conta. Códigos antigos e códigos que não estejam nesta versão não serão aceitos.', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ]);
    },
  );

  Widget _currencyCard(String title, String amount, String emoji) => Card(
    color: _panel,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 30)),
        Text(amount, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: _pink)),
        Text(title),
      ]),
    ),
  );
}
