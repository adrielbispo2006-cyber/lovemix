import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/data_service.dart';
import '../data/gift_catalog.dart';

const _pink = Color(0xFFFF2DAB);
const _purple = Color(0xFF8B35FF);
const _gold = Color(0xFFFFD45C);
const _panel = Color(0xFF171022);

class AllianceWallScreen extends StatefulWidget {
  const AllianceWallScreen({super.key});
  @override
  State<AllianceWallScreen> createState() => _AllianceWallScreenState();
}

class _AllianceWallScreenState extends State<AllianceWallScreen> {
  bool _creating = false;

  Future<void> _newAlliance() async {
    final id = TextEditingController();
    final note = TextEditingController();
    String kind = 'Namorados';
    DateTime date = DateTime.now();
    Map<String, dynamic>? selectedRing;
    await showDialog<void>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('Criar aliança 💍'),
        content: SizedBox(width: 520, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Escolha uma aliança para comprar e enviar junto com seu convite.'),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: kAllianceRings.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: .9),
            itemBuilder: (context, index) {
              final ring = kAllianceRings[index];
              final chosen = selectedRing?['id'] == ring['id'];
              final asset = ring['asset']?.toString() ?? '';
              return InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setDialogState(() => selectedRing = ring),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF10091A),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: chosen ? _gold : _purple.withOpacity(.65), width: chosen ? 2.2 : 1),
                  ),
                  child: Column(children: [
                    Expanded(child: asset.isNotEmpty ? Image.asset(asset, fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Center(child: Text(ring['emoji'].toString(), style: const TextStyle(fontSize: 42))))
                      : Center(child: Text(ring['emoji'].toString(), style: const TextStyle(fontSize: 42)))),
                    Text(ring['name'].toString(), textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                    const SizedBox(height: 3),
                    Text('${ring['cost']} 🪙', style: const TextStyle(color: _gold, fontWeight: FontWeight.w900)),
                    if (chosen) const Icon(Icons.check_circle, color: _gold, size: 19),
                  ]),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
          TextField(controller: id, textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(labelText: 'ID da pessoa (8 caracteres)'),
            onChanged: (_) => setDialogState(() {})),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: kind, decoration: const InputDecoration(labelText: 'Tipo de solicitação'),
            items: const ['Namorados', 'Amigos'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) => setDialogState(() => kind = v ?? kind)),
          const SizedBox(height: 8),
          ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.calendar_month, color: _gold),
            title: const Text('Data de início'), subtitle: Text(DateFormat('dd/MM/yyyy').format(date)),
            onTap: () async { final picked = await showDatePicker(context: context, initialDate: date,
              firstDate: DateTime(2000), lastDate: DateTime(2100), builder: (c, child) => Theme(data: ThemeData.dark(), child: child!));
              if (picked != null) setDialogState(() => date = picked); }),
          TextField(controller: note, maxLength: 100, decoration: const InputDecoration(labelText: 'Mensagem (opcional)')),
          if (selectedRing == null) const Padding(padding: EdgeInsets.only(top: 6), child: Text('Escolha uma aliança para liberar o envio do convite.', style: TextStyle(color: _gold, fontSize: 12))),
        ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
          ElevatedButton.icon(
            onPressed: (_creating || selectedRing == null || id.text.trim().isEmpty) ? null : () async {
              setState(() => _creating = true);
              try {
                await DataService.instance.createAllianceByPublicId(
                  id.text, kind, date, note.text, ringGiftId: selectedRing!['id'].toString());
                if (dialogContext.mounted) Navigator.pop(dialogContext);
                if (mounted) ScaffoldMessenger.of(this.context).showSnackBar(SnackBar(content: Text('${selectedRing!['name']} comprada! Convite enviado. A pessoa precisa aceitar para aparecer no mural. 💍')));
              } catch (e) {
                if (mounted) ScaffoldMessenger.of(this.context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
              } finally { if (mounted) setState(() => _creating = false); }
            },
            icon: const Icon(Icons.send),
            label: Text(_creating ? 'Enviando...' : selectedRing == null ? 'Escolha uma aliança' : 'Comprar e enviar'),
          ),
        ],
      ),
    ));
    id.dispose();
    note.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 8), child: Row(children: [
        const Expanded(child: Text('Mural de Aliança', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800))),
        IconButton(onPressed: _newAlliance, tooltip: 'Enviar aliança', icon: const Icon(Icons.add_circle, color: _pink, size: 30)),
      ])),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: Text(
        'Veja os casais e as alianças confirmadas pela comunidade.',
        style: TextStyle(color: Colors.white.withValues(alpha: .65)), textAlign: TextAlign.center)),
      const SizedBox(height: 8),
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: service.acceptedPublicAlliances(),
        builder: (context, publicSnap) {
          if (publicSnap.hasError) return const Center(child: Text('Não foi possível carregar as alianças públicas.'));
          if (!publicSnap.hasData) return const Center(child: CircularProgressIndicator(color: _pink));
          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: service.myPendingAlliances(),
            builder: (context, pendingSnap) {
              if (pendingSnap.hasError) return const Center(child: Text('Não foi possível carregar seus convites.'));
              if (!pendingSnap.hasData) return const Center(child: CircularProgressIndicator(color: _pink));
              final docs = <QueryDocumentSnapshot<Map<String, dynamic>>>[
                ...publicSnap.data!.docs,
                ...pendingSnap.data!.docs.where((d) => d.data()['invitationStatus'] == 'pending'),
              ];
              final seen = <String>{};
              final unique = docs.where((d) => seen.add(d.id)).toList()
                ..sort((a, b) => ((b.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0)
                  .compareTo((a.data()['createdAt'] as Timestamp?)?.millisecondsSinceEpoch ?? 0));
              if (unique.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(
                mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.favorite, size: 64, color: _purple), const SizedBox(height: 12),
                  const Text('Ainda não há alianças confirmadas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6), const Text('Envie uma aliança. Ela aparecerá para todos quando a outra pessoa aceitar.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
                  const SizedBox(height: 16), ElevatedButton.icon(onPressed: _newAlliance, icon: const Icon(Icons.favorite), label: const Text('Enviar aliança')),
                ])));
              return ListView.builder(padding: const EdgeInsets.fromLTRB(14, 8, 14, 24), itemCount: unique.length,
                itemBuilder: (context, i) => _AllianceCard(doc: unique[i]));
            },
          );
        },
      )),
    ]);
  }
}

class _AllianceCard extends StatelessWidget {
  const _AllianceCard({required this.doc});
  final QueryDocumentSnapshot<Map<String, dynamic>> doc;

  @override
  Widget build(BuildContext context) {
    final d = doc.data();
    final me = DataService.instance.uid;
    final invitedUid = (d['invitedUid'] ?? '').toString();
    final isInvited = invitedUid == me;
    final pending = d['invitationStatus'] == 'pending';
    final accepted = d['invitationStatus'] == 'accepted';
    final members = (d['members'] as List? ?? []).map((e) => e.toString()).toSet();
    final isMember = members.contains(me);
    final kind = (d['relationshipType'] ?? 'Amigos').toString();
    final start = d['startDate'] is Timestamp
        ? (d['startDate'] as Timestamp).toDate()
        : DateTime.now();
    final creatorName = (d['creatorName'] ?? 'Pessoa do LoveMix').toString();
    final invitedNameSaved = (d['invitedName'] ?? '').toString();
    final invitedPhotoSaved = (d['invitedPhotoUrl'] ?? '').toString();

    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: invitedNameSaved.isNotEmpty
          ? null
          : FirebaseFirestore.instance.collection('users').doc(invitedUid).get(),
      builder: (context, userSnap) {
        final invitedData = userSnap.data?.data() ?? {};
        final invitedName = invitedNameSaved.isNotEmpty
            ? invitedNameSaved
            : (invitedData['name'] ?? 'Pessoa do LoveMix').toString();
        final invitedPhoto = invitedPhotoSaved.isNotEmpty
            ? invitedPhotoSaved
            : (invitedData['photoUrl'] ?? '').toString();
        final status = pending ? 'Convite pendente' : accepted ? 'Aliança confirmada' : 'Aliança encerrada';
        final statusColor = pending ? _gold : accepted ? const Color(0xFFE34BFF) : Colors.white54;

        return Container(
          margin: const EdgeInsets.only(bottom: 18),
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(
              colors: [Color(0xFFFF43D0), Color(0xFF9B35FF), Color(0xFFFF43D0)],
            ),
            boxShadow: [
              BoxShadow(color: _pink.withOpacity(.22), blurRadius: 18, spreadRadius: 1),
            ],
          ),
          child: Container(
            padding: const EdgeInsets.fromLTRB(14, 16, 14, 14),
            decoration: BoxDecoration(
              color: const Color(0xFF120B1D),
              borderRadius: BorderRadius.circular(26),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Fotos e aliança no centro, como na prévia enviada.
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _avatar(d['creatorPhotoUrl']?.toString() ?? '', creatorName, size: 68),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Icon(Icons.favorite, color: _pink, size: 23),
                    ),
                    _ringArtwork(d['ringGiftId']?.toString() ?? '', size: 88),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5),
                      child: Icon(Icons.favorite, color: _pink, size: 23),
                    ),
                    _avatar(invitedPhoto, invitedName, size: 68),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  '$creatorName & $invitedName',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    _pill('${_kindEmoji(kind)} $kind', _purple),
                    if ((d['ringGiftName'] ?? '').toString().isNotEmpty)
                      _pill('💍 ${d['ringGiftName']}', _gold),
                  ],
                ),
                const SizedBox(height: 10),
                if (!pending)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.calendar_month, color: _gold, size: 21),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          'Desde: ${DateFormat('dd/MM/yyyy').format(start)}',
                          style: const TextStyle(color: Colors.white, fontSize: 14),
                        ),
                      ),
                    ],
                  )
                else
                  Text(
                    isInvited
                        ? 'Você recebeu um convite de aliança.'
                        : 'Aguardando a outra pessoa aceitar.',
                    style: const TextStyle(color: Colors.white70),
                  ),
                if ((d['message'] ?? '').toString().trim().isNotEmpty) ...[
                  const SizedBox(height: 9),
                  Text(
                    '“${d['message']}”',
                    style: const TextStyle(color: Colors.white60, fontStyle: FontStyle.italic),
                  ),
                ],
                const SizedBox(height: 13),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: statusColor, width: 1.5),
                    color: statusColor.withOpacity(.08),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(pending ? Icons.hourglass_top : Icons.check_circle,
                          color: statusColor, size: 20),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(status,
                          textAlign: TextAlign.center,
                          style: TextStyle(color: statusColor, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                ),
                if (accepted && isMember) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFFFF7B9C),
                        side: const BorderSide(color: Color(0xFFFF7B9C)),
                      ),
                      icon: const Icon(Icons.heart_broken_outlined),
                      label: const Text('Terminar aliança'),
                      onPressed: () async {
                        final confirm = await showDialog<bool>(
                          context: context,
                          builder: (dialogContext) => AlertDialog(
                            backgroundColor: const Color(0xFF171022),
                            title: const Text('Terminar aliança?'),
                            content: const Text('A aliança será encerrada e deixará de aparecer no mural público. Essa ação não devolve as moedas da compra.'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancelar')),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF4D78)),
                                onPressed: () => Navigator.pop(dialogContext, true),
                                child: const Text('Sim, terminar'),
                              ),
                            ],
                          ),
                        );
                        if (confirm != true) return;
                        try {
                          await DataService.instance.endAlliance(doc.id);
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Aliança encerrada.')),
                            );
                          }
                        } catch (e) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                          }
                        }
                      },
                    ),
                  ),
                ],
                if (pending && isInvited) ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: OutlinedButton(
                      onPressed: () async {
                        try {
                          await DataService.instance.respondAlliance(doc.id, false);
                        } catch (e) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                          }
                        }
                      },
                      child: const Text('Recusar'),
                    )),
                    const SizedBox(width: 10),
                    Expanded(child: ElevatedButton(
                      onPressed: () async {
                        try {
                          await DataService.instance.respondAlliance(doc.id, true);
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Aliança aceita! Agora aparece no mural. 💍')),
                            );
                          }
                        } catch (e) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
                          }
                        }
                      },
                      child: const Text('Aceitar 💍'),
                    )),
                  ]),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _ringArtwork(String ringId, {double size = 88}) {
    final ring = kAllianceRings.cast<Map<String, dynamic>?>().firstWhere(
      (item) => item?['id'] == ringId,
      orElse: () => null,
    );
    final asset = ring?['asset']?.toString() ?? '';
    final emoji = ring?['emoji']?.toString() ?? '💍';
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: const Color(0xFF160B24),
        boxShadow: [BoxShadow(color: _purple.withOpacity(.35), blurRadius: 14)],
      ),
      child: asset.isEmpty
          ? Center(child: Text(emoji, style: TextStyle(fontSize: size * .48)))
          : Image.asset(asset, fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => Center(
                child: Text(emoji, style: TextStyle(fontSize: size * .48)),
              )),
    );
  }

  Widget _avatar(String url, String name, {double size = 68}) => Container(
    width: size,
    height: size,
    padding: const EdgeInsets.all(2),
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      border: Border.all(color: const Color(0xFFD94BFF), width: 2.2),
      boxShadow: [BoxShadow(color: _purple.withOpacity(.25), blurRadius: 8)],
    ),
    child: ClipOval(
      child: url.isEmpty
          ? Container(color: Colors.white10,
              child: const Icon(Icons.person, size: 34, color: Colors.white70))
          : CachedNetworkImage(imageUrl: url, fit: BoxFit.cover,
              errorWidget: (_, __, ___) => const Icon(Icons.person)),
    ),
  );

  Widget _pill(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
    decoration: BoxDecoration(
      color: color.withOpacity(.18),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: color, width: 1.2),
    ),
    child: Text(label, style: TextStyle(
      color: color == _gold ? _gold : Colors.white,
      fontWeight: FontWeight.w800,
      fontSize: 12,
    )),
  );

  String _kindEmoji(String kind) => switch (kind) {
    'Namorados' => '❤️',
    'BFF' => '💜',
    'Irmãos' => '💛',
    _ => '💙',
  };
}
