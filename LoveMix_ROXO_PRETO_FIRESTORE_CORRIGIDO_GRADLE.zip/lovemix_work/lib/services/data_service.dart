import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';

class DataService {
  DataService._();
  static final instance = DataService._();
  final db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> createUser({
    required String name,
    required DateTime birthday,
    String bio = '',
  }) async {
    final user = FirebaseAuth.instance.currentUser!;
    await db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'name': name.trim(),
      'birthday': Timestamp.fromDate(birthday),
      'bio': bio,
      'photoUrl': '',
      'city': '',
      'country': '',
      'interests': <String>[],
      'coins': 100,
      'diamonds': 0,
      'profileVisibility': 'public',
      'postVisibility': 'public',
      'isVip': false,
      'isAdmin': false,
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': true,
      'isOnline': false,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }


  Future<void> setOnlineStatus(bool online) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(user.uid).set({
      'isOnline': online,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() =>
      db.collection('users').doc(uid).snapshots();

  Future<void> updateProfile(Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set(data, SetOptions(merge: true));

  Stream<QuerySnapshot<Map<String, dynamic>>> discoverUsers() =>
      db.collection('users')
          .where('isActive', isEqualTo: true)
          .where('profileVisibility', isEqualTo: 'public')
          .limit(500)
          .snapshots();

  Future<void> pass(String targetUid) async {
    if (targetUid == uid) return;
    await db.collection('users').doc(uid).collection('passed').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<bool> like(String targetUid) async {
    final callable = FirebaseFunctions.instance.httpsCallable('likeUser');
    final result = await callable.call({'targetUid': targetUid});
    return result.data is Map && result.data['matched'] == true;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myMatches() => db
      .collection('matches')
      .where('users', arrayContains: uid)
      .orderBy('lastMessageAt', descending: true)
      .snapshots();

  CollectionReference<Map<String, dynamic>> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages');



  CollectionReference<Map<String, dynamic>> roomMessages(String roomId) =>
      db.collection('rooms').doc(roomId).collection('messages');

  Stream<QuerySnapshot<Map<String, dynamic>>> publicRooms() => db
      .collection('rooms').where('isPublic', isEqualTo: true)
      .orderBy('createdAt', descending: true).limit(50).snapshots();

  Future<String> createRoom(String name, {bool isPublic = true, String category = 'Amizades', String description = '', String password = ''}) async {
    final clean = name.trim();
    if (clean.length < 3 || clean.length > 40) {
      throw Exception('O nome da sala deve ter entre 3 e 40 caracteres.');
    }
    if (!isPublic && password.trim().length < 4) {
      throw Exception('A senha da sala privada deve ter pelo menos 4 caracteres.');
    }
    final ref = await db.collection('rooms').add({
      'name': clean,
      'ownerId': uid,
      'members': [uid],
      'isPublic': isPublic,
      'category': category,
      'description': description.trim(),
      'passwordHash': isPublic ? null : sha256.convert(utf8.encode(password.trim())).toString(),
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': 'Sala criada. Dê boas-vindas!',
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> joinRoom(String roomId) async {
    await db.collection('rooms').doc(roomId).update({
      'members': FieldValue.arrayUnion([uid]),
    });
  }

  Future<void> sendRoomMessage(String roomId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 1000) return;
    final room = db.collection('rooms').doc(roomId);
    await roomMessages(roomId).add({
      'senderId': uid, 'text': clean, 'type': 'text',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await room.update({'lastMessage': clean, 'lastMessageAt': FieldValue.serverTimestamp()});
  }

  Future<void> sendRoomGift(String roomId, String recipientUid, String giftId,
      String emoji, String giftName) async {
    if (recipientUid == uid) throw Exception('Escolha outra pessoa para receber o presente.');
    final roomRef = db.collection('rooms').doc(roomId);
    final roomSnap = await roomRef.get();
    final members = List<String>.from(roomSnap.data()?['members'] ?? []);
    if (!members.contains(uid) || !members.contains(recipientUid)) {
      throw Exception('Você e a pessoa precisam estar na sala.');
    }
    await roomMessages(roomId).add({
      'senderId': uid, 'recipientUid': recipientUid,
      'giftId': giftId, 'emoji': emoji, 'giftName': giftName,
      'text': '$emoji Presente: $giftName', 'type': 'gift',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await roomRef.update({'lastMessage': '$emoji Presente enviado', 'lastMessageAt': FieldValue.serverTimestamp()});
  }

  Future<void> blockUser(String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode bloquear sua própria conta.');
    await db.collection('users').doc(uid).collection('blocked').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> reportUser(String targetUid, String reason, {String details = ''}) async {
    final cleanReason = reason.trim();
    if (targetUid == uid || cleanReason.isEmpty) {
      throw Exception('Selecione um motivo válido para a denúncia.');
    }
    await db.collection('reports').add({
      'reporterId': uid,
      'reportedUserId': targetUid,
      'reason': cleanReason,
      'details': details.trim(),
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteMyAccount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(uid).delete();
    await user.delete();
  }

  Future<void> sendMessage(String chatId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    final chat = db.collection('chats').doc(chatId);
    // O chat é criado pela Cloud Function no momento do match.
    // Aqui atualizamos somente o chat existente; não criamos conversas arbitrárias.
    await chat.update({
      'lastMessage': clean,
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
    await messages(chatId).add({
      'senderId': uid,
      'text': clean,
      'createdAt': FieldValue.serverTimestamp(),
      'type': 'text',
    });
  }
}
