import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class ChatRoomsScreen extends StatelessWidget {
  const ChatRoomsScreen({super.key});
  static const gold = Color(0xFFFF2DAB);

  Future<void> _newRoom(BuildContext context) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Criar sala de bate-papo'),
      content: TextField(controller: controller, maxLength: 40, decoration: const InputDecoration(hintText: 'Ex.: Amizades, Música, Conversas')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Criar'))],
    ));
    if (name == null || name.trim().isEmpty) return;
    try {
      final id = await DataService.instance.createRoom(name);
      if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => RoomChatScreen(roomId: id, roomName: name.trim())));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _newRoom(context),
        backgroundColor: const Color(0xFFFF2DAB),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Criar sala', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.fromLTRB(16, 12, 16, 14),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF40105E), Color(0xFF1B1230), Color(0xFF321044)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFB33CFF).withOpacity(.65)),
            boxShadow: [BoxShadow(color: const Color(0xFF9B27FF).withOpacity(.16), blurRadius: 20, offset: const Offset(0, 7))],
          ),
          child: const Row(children: [
            Icon(Icons.graphic_eq_rounded, color: Color(0xFFFF54C4), size: 34),
            SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Salas LoveMix', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white)),
              SizedBox(height: 4),
              Text('Entre, converse e conheça pessoas novas 💜', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
          child: Row(children: [
            const Text('Salas públicas', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const Spacer(),
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: const Color(0xFF351044), borderRadius: BorderRadius.circular(20)), child: const Text('AO VIVO', style: TextStyle(color: Color(0xFFFF64C8), fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: .8))),
          ]),
        ),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream: DataService.instance.publicRooms(), builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Não foi possível carregar as salas.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB)));
          final rooms = snap.data!.docs;
          if (rooms.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.forum_outlined, size: 48, color: Color(0xFFB65BDB)), SizedBox(height: 12), Text('Ainda não há salas', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('Crie a primeira sala e comece uma conversa!', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60))])));
          return ListView.builder(padding: const EdgeInsets.fromLTRB(14, 4, 14, 90), itemCount: rooms.length, itemBuilder: (context, i) {
            final room = rooms[i].data(); final members = List<String>.from(room['members'] ?? []);
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF251333), Color(0xFF171022)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: const Color(0xFF65358B).withOpacity(.8)),
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                leading: Container(width: 48, height: 48, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFFF2DAB), Color(0xFF793BFF)]), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.forum_rounded, color: Colors.white)),
                title: Text((room['name'] ?? 'Sala').toString(), style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text('${members.length} participantes • ${(room['lastMessage'] ?? 'Entre para conversar').toString()}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 11))),
                trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFFFF54C4), size: 17),
                onTap: () async {
                  try { if (!members.contains(DataService.instance.uid)) await DataService.instance.joinRoom(rooms[i].id); if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => RoomChatScreen(roomId: rooms[i].id, roomName: (room['name'] ?? 'Sala').toString()))); }
                  catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
                },
              ),
            );
          });
        }))
      ]),
    );
  }
}


class RoomChatScreen extends StatefulWidget {
  final String roomId, roomName;
  const RoomChatScreen({super.key, required this.roomId, required this.roomName});
  @override State<RoomChatScreen> createState() => _RoomChatScreenState();
}

class _RoomChatScreenState extends State<RoomChatScreen> {
  final input = TextEditingController();
  bool micOn = false;
  bool speakerOn = true;
  String? giftChoice = 'heart';
  String? recipientChoice;

  static const gifts = [
    {'id':'rose','emoji':'🌹','name':'Rosa'},
    {'id':'crown','emoji':'👑','name':'Coroa'},
    {'id':'heart','emoji':'💗','name':'Coração'},
    {'id':'gift','emoji':'🎁','name':'Presente'},
  ];

  @override
  void dispose() { input.dispose(); super.dispose(); }

  Future<void> _send() async {
    final value = input.text.trim();
    if (value.isEmpty) return;
    input.clear();
    try { await DataService.instance.sendRoomMessage(widget.roomId, value); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível enviar: $e'))); }
  }

  Future<void> _gift({String? quickEmoji}) async {
    final room = await FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).get();
    final members = List<String>.from(room.data()?['members'] ?? [])
        .where((id) => id != DataService.instance.uid).toList();
    if (members.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Convide alguém para a sala primeiro.')));
      return;
    }
    if (quickEmoji != null) {
      final target = members.first;
      final gift = gifts.firstWhere((g) => g['emoji'] == quickEmoji,
          orElse: () => gifts.first);
      try {
        await DataService.instance.sendRoomGift(widget.roomId, target,
            gift['id']!, gift['emoji']!, gift['name']!);
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
      return;
    }
    String chosenGift = 'heart';
    String? chosenRecipient;
    final selected = await showDialog<Map<String,String>>(context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
        title: const Text('Enviar presente'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(
            value: chosenGift,
            decoration: const InputDecoration(labelText: 'Presente'),
            items: gifts.map((g) => DropdownMenuItem(value: g['id'],
              child: Text('${g['emoji']} ${g['name']}'))).toList(),
            onChanged: (v) => setDialog(() => chosenGift = v ?? 'heart')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(labelText: 'Enviar para'),
            items: members.map((id) => DropdownMenuItem(value: id,
              child: FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
                future: FirebaseFirestore.instance.collection('users').doc(id).get(),
                builder: (_, s) => Text((s.data?.data()?['name'] ?? 'Participante').toString())))).toList(),
            onChanged: (v) => setDialog(() => chosenRecipient = v)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          ElevatedButton(onPressed: () {
            if (chosenRecipient == null) return;
            final g = gifts.firstWhere((e) => e['id'] == chosenGift);
            Navigator.pop(ctx, {'id':g['id']!, 'emoji':g['emoji']!,
              'name':g['name']!, 'recipient':chosenRecipient!});
          }, child: const Text('Enviar')),
        ],
      )));
    if (selected == null) return;
    try {
      await DataService.instance.sendRoomGift(widget.roomId, selected['recipient']!,
        selected['id']!, selected['emoji']!, selected['name']!);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  Widget _participant(String id, bool isOwner) {
    return FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
      future: FirebaseFirestore.instance.collection('users').doc(id).get(),
      builder: (context, snap) {
        final data = snap.data?.data() ?? {};
        final name = (data['name'] ?? 'Pessoa').toString().split(' ').first;
        final photo = (data['photoUrl'] ?? '').toString();
        return SizedBox(width: 66, child: Column(mainAxisSize: MainAxisSize.min, children: [
          Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
            Container(width: 58, height: 58, padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(shape: BoxShape.circle,
                border: Border.all(color: isOwner ? const Color(0xFFFFD45C) : const Color(0xFFB64CFF), width: isOwner ? 2.5 : 1.7),
                boxShadow: [BoxShadow(color: (isOwner ? const Color(0xFFFFC94A) : const Color(0xFF9B35FF)).withOpacity(.3), blurRadius: 10)]),
              child: CircleAvatar(backgroundColor: const Color(0xFF29143B),
                backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white70, size: 27) : null)),
            if (isOwner) const Positioned(bottom: -7, child: Text('👑', style: TextStyle(fontSize: 17))),
            if (data['isOnline'] == true) Positioned(right: 0, top: 1,
              child: Container(width: 11, height: 11, decoration: BoxDecoration(
                color: const Color(0xFF25E58A), shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 1.5)))),
          ]),
          const SizedBox(height: 9),
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          const Icon(Icons.mic, size: 13, color: Color(0xFFD6B8FF)),
        ]));
      });
  }

  Widget _chatLine(Map<String,dynamic> message) {
    final sender = (message['senderId'] ?? '').toString();
    final text = (message['text'] ?? '').toString();
    final isGift = message['type'] == 'gift';
    return FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
      future: FirebaseFirestore.instance.collection('users').doc(sender).get(),
      builder: (context, snap) {
        final name = (snap.data?.data()?['name'] ?? 'Participante').toString();
        return Padding(padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Flexible(child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(color: const Color(0xFF211333),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: const Color(0xFF542A79).withOpacity(.55))),
              child: RichText(text: TextSpan(children: [
                TextSpan(text: '$name: ', style: const TextStyle(color: Color(0xFFD99BFF), fontWeight: FontWeight.w900)),
                TextSpan(text: text, style: TextStyle(color: Colors.white, fontSize: isGift ? 17 : 14,
                  fontWeight: isGift ? FontWeight.bold : FontWeight.normal)),
              ])))),
          ]));
      });
  }

  @override
  Widget build(BuildContext context) {
    final currentUid = DataService.instance.uid;
    return Scaffold(
      backgroundColor: const Color(0xFF05030B),
      appBar: AppBar(
        backgroundColor: const Color(0xFF080510),
        leading: const BackButton(),
        centerTitle: true,
        title: const Text('Sala de Voz', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        actions: [
          IconButton(tooltip: 'Opções da sala', icon: const Icon(Icons.more_vert),
            onPressed: () => showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1B1028),
              builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(leading: const Icon(Icons.volume_up, color: Color(0xFFD85BFF)),
                  title: const Text('Áudio da sala'), subtitle: const Text('A integração de voz precisa ser ativada')),
                ListTile(leading: const Icon(Icons.card_giftcard, color: Color(0xFFFF2DAB)),
                  title: const Text('Enviar presente'), onTap: () { Navigator.pop(ctx); _gift(); }),
              ]))),
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
        stream: FirebaseFirestore.instance.collection('rooms').doc(widget.roomId).snapshots(),
        builder: (context, roomSnap) {
          final room = roomSnap.data?.data() ?? {};
          final members = List<String>.from(room['members'] ?? [currentUid]);
          final owner = (room['ownerId'] ?? '').toString();
          return Column(children: [
            Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(16, 12, 16, 7),
              padding: const EdgeInsets.fromLTRB(16, 15, 16, 13),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF25104C), Color(0xFF10091F), Color(0xFF210C3A)]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFF8B35D4).withOpacity(.65)),
                boxShadow: [BoxShadow(color: const Color(0xFF9A27FF).withOpacity(.16), blurRadius: 18)]),
              child: Row(children: [
                const Text('👑', style: TextStyle(fontSize: 36)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(widget.roomName, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text('ID: ${widget.roomId.length > 7 ? widget.roomId.substring(0,7).toUpperCase() : widget.roomId.toUpperCase()}',
                    style: const TextStyle(color: Colors.white60, fontSize: 11)),
                ])),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(color: const Color(0xFF063C2A), borderRadius: BorderRadius.circular(20)),
                  child: Row(children: const [
                    Icon(Icons.circle, size: 7, color: Color(0xFF25E58A)),
                    SizedBox(width: 5),
                    Text('AO VIVO', style: TextStyle(color: Color(0xFF45E99A), fontWeight: FontWeight.w900, fontSize: 10)),
                  ])),
              ]),
            ),
            Padding(padding: const EdgeInsets.fromLTRB(15, 10, 15, 6),
              child: Row(children: [
                const Text('PARTICIPANTES', style: TextStyle(color: Colors.white60, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 1)),
                const Spacer(),
                Text('${members.length} pessoas', style: const TextStyle(color: Color(0xFFDDA6FF), fontSize: 11)),
              ])),
            SizedBox(height: 174, child: members.isEmpty
              ? const Center(child: Text('Seja a primeira pessoa a falar!'))
              : GridView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: members.length.clamp(0, 10),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5, mainAxisSpacing: 8, crossAxisSpacing: 5, childAspectRatio: .72),
                  itemBuilder: (_, i) => _participant(members[i], members[i] == owner),
                )),
            Container(margin: const EdgeInsets.symmetric(vertical: 4),
              child: Column(children: [
                GestureDetector(
                  onTap: () => setState(() => micOn = !micOn),
                  child: Container(width: 94, height: 94,
                    decoration: BoxDecoration(shape: BoxShape.circle,
                      gradient: const RadialGradient(colors: [Color(0xFF4B176F), Color(0xFF180A2C)]),
                      border: Border.all(color: const Color(0xFFC65BFF), width: 2),
                      boxShadow: [BoxShadow(color: const Color(0xFFB12CFF).withOpacity(.38), blurRadius: 22)]),
                    child: Icon(micOn ? Icons.mic : Icons.mic_none,
                      color: const Color(0xFFFF55D0), size: 43)),
                ),
                const SizedBox(height: 5),
                Text(micOn ? 'Microfone ligado' : 'Falar',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              ]),
            ),
            Expanded(child: Stack(children: [
              StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
                stream: DataService.instance.roomMessages(widget.roomId)
                  .orderBy('createdAt', descending: true).limit(60).snapshots(),
                builder: (context, snap) {
                  if (snap.hasError) return const Center(child: Text('Não foi possível carregar o chat.'));
                  if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB)));
                  final docs = snap.data!.docs;
                  return ListView.builder(reverse: true, padding: const EdgeInsets.fromLTRB(14, 8, 82, 8),
                    itemCount: docs.length, itemBuilder: (_, i) => _chatLine(docs[i].data()));
                }),
              Positioned(right: 12, top: 24, child: Column(children: [
                _quickGift('🌹'),
                const SizedBox(height: 12),
                _quickGift('👑'),
                const SizedBox(height: 12),
                _quickGift('💗'),
                const SizedBox(height: 12),
                _quickGift('🎁'),
              ])),
            ])),
            SafeArea(top: false, child: Container(
              padding: const EdgeInsets.fromLTRB(8, 7, 9, 9),
              decoration: const BoxDecoration(color: Color(0xFF080510),
                border: Border(top: BorderSide(color: Color(0xFF422052)))),
              child: Row(children: [
                IconButton(onPressed: () => showModalBottomSheet(context: context,
                  backgroundColor: const Color(0xFF1B1028), builder: (ctx) => Padding(
                    padding: const EdgeInsets.all(18), child: Wrap(spacing: 15, runSpacing: 15,
                      children: ['😀','😍','🥰','😘','😂','🔥','💜','🌹','🎁','👑','💗','👏']
                        .map((e) => InkWell(onTap: () { Navigator.pop(ctx); input.text += e; },
                          child: Text(e, style: const TextStyle(fontSize: 29)))).toList()))),
                  icon: const Icon(Icons.sentiment_satisfied_alt, color: Colors.white)),
                Expanded(child: TextField(controller: input, minLines: 1, maxLines: 3,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(hintText: 'Digite uma mensagem...',
                    filled: true, fillColor: const Color(0xFF21152F),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none)))),
                const SizedBox(width: 7),
                Container(width: 49, height: 49,
                  decoration: const BoxDecoration(shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [Color(0xFFFF2DAB), Color(0xFF9D22E8)])),
                  child: IconButton(onPressed: _send, icon: const Icon(Icons.send_rounded, color: Colors.white))),
              ]),
            )),
          ]);
        },
      ),
    );
  }

  Widget _quickGift(String emoji) => GestureDetector(
    onTap: () => _gift(quickEmoji: emoji),
    child: Container(width: 54, height: 54, alignment: Alignment.center,
      decoration: BoxDecoration(color: const Color(0xFF1C0D2C).withOpacity(.9),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF7C35A8).withOpacity(.7)),
        boxShadow: [BoxShadow(color: const Color(0xFFB12CFF).withOpacity(.18), blurRadius: 12)]),
      child: Text(emoji, style: const TextStyle(fontSize: 29))),
  );
}
