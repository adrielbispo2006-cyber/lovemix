import 'package:flutter/material.dart';

class ResourcesScreen extends StatelessWidget {
  const ResourcesScreen({super.key});

  static const pink = Color(0xFFFF2DAB);
  static const purple = Color(0xFF8B35FF);
  static const panel = Color(0xFF1B1028);

  static const features = <Map<String, dynamic>>[
    {'icon': Icons.mic_rounded, 'title': 'Salas de Voz', 'subtitle': 'Até 50 pessoas', 'color': Color(0xFFE45BFF), 'detail': 'Espaço para conversar por voz com a comunidade. A integração de áudio em tempo real precisa de um provedor de chamadas.'},
    {'icon': Icons.videocam_rounded, 'title': 'Salas de Vídeo', 'subtitle': 'Converse ao vivo', 'color': Color(0xFFB43CFF), 'detail': 'Encontros por vídeo em grupo. A transmissão de câmera exige integração de vídeo em tempo real.'},
    {'icon': Icons.live_tv_rounded, 'title': 'Lives', 'subtitle': 'Transmita agora', 'color': Color(0xFFFF4EC8), 'detail': 'Área para transmissões ao vivo. A publicação de vídeo ao vivo será ativada após configurar o serviço de streaming.'},
    {'icon': Icons.sports_esports_rounded, 'title': 'Jogos', 'subtitle': 'Divirta-se juntos', 'color': Color(0xFF38A7FF), 'detail': 'Espaço para jogos e desafios entre amigos. Novos minijogos podem ser adicionados aqui.'},
    {'icon': Icons.card_giftcard_rounded, 'title': 'Presentes Virtuais', 'subtitle': 'Surpreenda alguém', 'color': Color(0xFFFFC34D), 'detail': 'Envie presentes virtuais nas conversas e salas. Os presentes disponíveis aparecem na loja do LoveMix.'},
    {'icon': Icons.favorite_rounded, 'title': 'Compatibilidade', 'subtitle': 'Descubra seu match', 'color': Color(0xFFFF43B9), 'detail': 'Descubra afinidades com base nos interesses informados nos perfis.'},
    {'icon': Icons.groups_rounded, 'title': 'Comunidades', 'subtitle': 'Encontre grupos', 'color': Color(0xFF9B70FF), 'detail': 'Conheça pessoas por interesses e participe de salas temáticas.'},
    {'icon': Icons.event_rounded, 'title': 'Eventos', 'subtitle': 'Participe de eventos', 'color': Color(0xFFFF55B9), 'detail': 'Área para divulgar encontros e eventos da comunidade.'},
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Recursos Incríveis')),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF32104D), Color(0xFF170D25)]),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: purple.withOpacity(.8)),
          ),
          child: const Row(children: [
            Icon(Icons.auto_awesome, color: Color(0xFFFFD76A), size: 34),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Viva o LoveMix por completo', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              SizedBox(height: 4),
              Text('Converse, participe e descubra novas conexões.', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
          ]),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: features.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.05,
          ),
          itemBuilder: (context, index) {
            final f = features[index];
            return InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => showModalBottomSheet(
                context: context, backgroundColor: panel, shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
                builder: (ctx) => Padding(
                  padding: const EdgeInsets.fromLTRB(22, 24, 22, 30),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(f['icon'] as IconData, color: f['color'] as Color, size: 48),
                    const SizedBox(height: 12),
                    Text(f['title'] as String, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                    const SizedBox(height: 8),
                    Text(f['detail'] as String, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 18),
                    SizedBox(width: double.infinity, child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx), child: const Text('Entendi'))),
                  ]),
                ),
              ),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: [Color(0xFF28133D), Color(0xFF160D22)]),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: (f['color'] as Color).withOpacity(.55)),
                  boxShadow: [BoxShadow(color: (f['color'] as Color).withOpacity(.10), blurRadius: 14)],
                ),
                padding: const EdgeInsets.all(12),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(f['icon'] as IconData, color: f['color'] as Color, size: 34),
                  const SizedBox(height: 10),
                  Text(f['title'] as String, textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text(f['subtitle'] as String, textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white60, fontSize: 11)),
                ]),
              ),
            );
          },
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF40200E), Color(0xFF211323)]),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFFFC34D)),
          ),
          child: const Row(children: [
            Icon(Icons.workspace_premium, color: Color(0xFFFFD76A), size: 38),
            SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Seja VIP', style: TextStyle(color: Color(0xFFFFD76A), fontWeight: FontWeight.w900, fontSize: 18)),
              Text('Desbloqueie benefícios exclusivos!', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
            Icon(Icons.arrow_forward_ios, color: Color(0xFFFFD76A), size: 17),
          ]),
        ),
      ],
    ),
  );
}
