import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  @override void dispose() { input.dispose(); super.dispose(); }

  Future<void> _send(String value) async {
    final text = value.trim();
    if (text.isEmpty) return;
    input.clear();
    try { await DataService.instance.sendMessage(widget.chatId, text); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível enviar: $e'))); }
  }

  void _quickReactions() {
    const reactions = ['❤️','😍','🥰','😘','😂','🔥','💜','🌹','🎁','🧸','💎','👑'];
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => Padding(padding: const EdgeInsets.all(18), child: Wrap(
        spacing: 12, runSpacing: 12,
        children: reactions.map((emoji) => InkWell(
          onTap: () { Navigator.pop(ctx); _send(emoji); },
          child: Container(width: 52, height: 52, alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF321846), borderRadius: BorderRadius.circular(14)),
            child: Text(emoji, style: const TextStyle(fontSize: 27))),
        )).toList(),
      )));
  }

  @override Widget build(BuildContext context) {
    final service = DataService.instance;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId).snapshots(),
            builder: (context, snap) {
              final ids = List<String>.from(snap.data?.data()?['users'] ?? const []);
              final others = ids.where((id) => id != uid).toList();
              final other = others.isEmpty ? null : others.first;
              if (other == null) return const CircleAvatar(radius: 18, child: Icon(Icons.person));
              return FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
                future: FirebaseFirestore.instance.collection('users').doc(other).get(),
                builder: (context, userSnap) {
                  final photo = (userSnap.data?.data()?['photoUrl'] ?? '').toString();
                  return CircleAvatar(radius: 18, backgroundColor: const Color(0xFF47205F),
                    backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                    child: photo.isEmpty ? const Icon(Icons.person, color: Color(0xFFFF2DAB), size: 19) : null);
                });
            },
          ),
          const SizedBox(width: 9),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.otherName, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            const Text('Conversa privada', style: TextStyle(fontSize: 10, color: Colors.white60)),
          ]),
        ]),
        actions: [
          IconButton(tooltip: 'Chamada de voz', onPressed: () => _notAvailable('Chamada de voz'), icon: const Icon(Icons.call, color: Color(0xFFFF2DAB))),
          IconButton(tooltip: 'Chamada de vídeo', onPressed: () => _notAvailable('Chamada de vídeo'), icon: const Icon(Icons.videocam, color: Color(0xFFFF2DAB))),
        ],
      ),
      body: Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
          stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Não foi possível carregar as mensagens.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs;
            if (docs.isEmpty) return const Center(child: Text('Diga oi e comece uma nova conversa! 💗'));
            return ListView.builder(padding: const EdgeInsets.all(14), itemCount: docs.length,
              itemBuilder: (context, i) {
                final m = docs[i].data();
                final mine = m['senderId'] == uid;
                final value = (m['text'] ?? '').toString();
                final isGift = m['type'] == 'gift';
                return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                    constraints: const BoxConstraints(maxWidth: 290),
                    decoration: BoxDecoration(
                      gradient: mine ? const LinearGradient(colors: [Color(0xFF8B22D4), Color(0xFF541A91)]) : null,
                      color: mine ? null : const Color(0xFF241A31),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(17), topRight: const Radius.circular(17),
                        bottomLeft: Radius.circular(mine ? 17 : 4), bottomRight: Radius.circular(mine ? 4 : 17)),
                      border: isGift ? Border.all(color: const Color(0xFFFF2DAB)) : null,
                    ),
                    child: Text(value, style: TextStyle(color: Colors.white, fontSize: isGift ? 20 : 15)),
                  ),
                );
              });
          },
        )),
        SafeArea(top: false, child: Container(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
          decoration: const BoxDecoration(color: Color(0xFF100A19), border: Border(top: BorderSide(color: Color(0xFF422052)))),
          child: Row(children: [
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white70)),
            Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4,
              decoration: InputDecoration(hintText: 'Digite uma mensagem...', isDense: true,
                filled: true, fillColor: const Color(0xFF21162D), contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.card_giftcard, color: Color(0xFFFF2DAB))),
            IconButton(onPressed: () => _send(input.text), icon: const Icon(Icons.send_rounded, color: Color(0xFFFF2DAB))),
          ]),
        )),
      ]),
    );
  }

  void _notAvailable(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$feature: conecte um serviço de chamadas em tempo real para ativar esse recurso.'),
    ));
  }
}
