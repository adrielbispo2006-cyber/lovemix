import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'live_broadcast_screen.dart';
import 'love_room_screen.dart';

class ZegoLiveHubScreen extends StatelessWidget {
  const ZegoLiveHubScreen({super.key, required this.mediaMode});
  final String mediaMode; // audio, video ou live

  String get _title => mediaMode == 'audio'
      ? 'Salas de Voz'
      : mediaMode == 'video' ? 'Salas de Vídeo' : 'Lives LoveMix';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: Text(_title)),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFFFF2DAB),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: Text(mediaMode == 'audio' ? 'Criar sala de voz' : 'Começar live de vídeo'),
        onPressed: () => _create(context),
      ),
      body: Column(children: [
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF35104F), Color(0xFF170D25)],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFF9B35FF)),
          ),
          child: Row(children: [
            Icon(mediaMode == 'audio' ? Icons.mic : Icons.live_tv,
                color: const Color(0xFFFF55D0), size: 34),
            const SizedBox(width: 12),
            Expanded(child: Text(
              mediaMode == 'audio'
                  ? 'Entre no palco, peça para falar e converse ao vivo.'
                  : 'Crie uma transmissão ou entre em uma live da comunidade.',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            )),
          ]),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: DataService.instance.publicLiveRooms(mediaMode: mediaMode),
            builder: (context, snap) {
              if (snap.hasError) {
                return const Center(child: Text('Erro ao carregar transmissões. Confira as regras e índices do Firestore.'));
              }
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator(color: Color(0xFFFF2DAB)));
              }
              final docs = snap.data!.docs;
              if (docs.isEmpty) {
                return Center(child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.sensors, size: 54, color: Color(0xFFB65BDB)),
                    const SizedBox(height: 12),
                    const Text('Nenhuma transmissão agora',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                    const SizedBox(height: 6),
                    const Text('Seja a primeira pessoa a criar uma sala!',
                      textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
                  ]),
                ));
              }
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 100),
                itemCount: docs.length,
                itemBuilder: (context, index) {
                  final doc = docs[index];
                  final data = doc.data();
                  final members = List<String>.from(data['members'] ?? []);
                  return Card(
                    color: const Color(0xFF1A1028),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: const BorderSide(color: Color(0xFF71349B)),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      leading: CircleAvatar(
                        backgroundColor: const Color(0xFF7027A5),
                        child: Icon(mediaMode == 'audio' ? Icons.mic : Icons.videocam,
                          color: Colors.white),
                      ),
                      title: Text((data['name'] ?? 'Sala LoveMix').toString(),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${members.length} participantes • AO VIVO',
                        style: const TextStyle(color: Colors.white60)),
                      trailing: const Icon(Icons.play_circle_fill,
                        color: Color(0xFFFF45C4), size: 30),
                      onTap: () async {
                        try {
                          if (mediaMode == 'audio') {
                            await Navigator.push(context, MaterialPageRoute(
                              builder: (_) => LoveRoomScreen(
                                roomId: doc.id,
                                roomName: (data['name'] ?? 'Sala LoveMix').toString(),
                              ),
                            ));
                            return;
                          }
                          await Navigator.push(context, MaterialPageRoute(
                            builder: (_) => LiveBroadcastScreen(
                              roomId: doc.id,
                              roomName: (data['name'] ?? 'Sala LoveMix').toString(),
                            ),
                          ));
                        } catch (e) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Não foi possível entrar: $e')));
                          }
                        }
                      },
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }

  Future<void> _create(BuildContext context) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF21132F),
        title: Text(mediaMode == 'audio' ? 'Criar sala de voz' : 'Criar live de vídeo'),
        content: TextField(
          controller: controller,
          maxLength: 40,
          autofocus: true,
          textInputAction: TextInputAction.done,
          decoration: const InputDecoration(labelText: 'Nome da sala'),
          onSubmitted: (value) {
            if (value.trim().length >= 3) Navigator.pop(ctx, value.trim());
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () {
              final value = controller.text.trim();
              if (value.length >= 3) Navigator.pop(ctx, value);
            },
            child: const Text('Entrar ao vivo'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || !context.mounted) return;

    String? createdRoomId;
    try {
      if (mediaMode == 'audio') {
        final audioId = await DataService.instance.createRoom(
          name,
          category: 'Salas de Voz',
          description: 'Sala pública de voz do LoveMix',
          isLive: true,
          mediaMode: 'audio',
        );
        if (!context.mounted) return;
        await Navigator.push(context, MaterialPageRoute(
          builder: (_) => LoveRoomScreen(roomId: audioId, roomName: name),
        ));
        return;
      }
      final id = await DataService.instance.createRoom(
        name,
        category: 'Lives',
        description: 'Live pública de vídeo do LoveMix',
        isLive: true,
        mediaMode: mediaMode,
      );
      createdRoomId = id;
      if (!context.mounted) return;
      await Navigator.push(context, MaterialPageRoute(
        builder: (_) => LiveBroadcastScreen(roomId: id, roomName: name),
      ));
    } catch (e) {
      if (createdRoomId != null) {
        try { await DataService.instance.endLiveRoom(createdRoomId); } catch (_) {}
      }
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao iniciar transmissão: $e')),
        );
      }
    }
  }

}
