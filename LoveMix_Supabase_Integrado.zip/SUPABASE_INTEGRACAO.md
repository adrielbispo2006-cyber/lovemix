# Integração Supabase — LoveMix

O app inicializa o projeto Supabase `pcruxbtuimndtjtuclhf` e usa o bucket `lovemix-photos` para fotos de perfil, capas, publicações, fotos do chat e fotos de stories. Vídeos de stories e os recursos já existentes de login/dados continuam no Firebase.

## Ativar o armazenamento

1. Abra o projeto `pcruxbtuimndtjtuclhf` no painel Supabase.
2. Entre em **SQL Editor**.
3. Abra o arquivo `SUPABASE_SETUP.sql` deste ZIP, copie o conteúdo e execute.
4. Confira em **Storage** se existe o bucket `lovemix-photos`.

## Segurança importante

O LoveMix atual autentica usuários pelo Firebase. O Supabase não recebe automaticamente a identidade Firebase. Para permitir que o envio funcione sem migrar o login, o SQL acima permite uploads anônimos no bucket, com limite de 30 MB e tipos de arquivo de imagem. Isso significa que terceiros que conheçam o endpoint público também podem tentar enviar imagens. Antes de publicar amplamente, o ideal é proteger os uploads com uma Supabase Edge Function que valide o token Firebase, ou migrar a autenticação para Supabase Auth. Nunca coloque uma chave `service_role` no aplicativo.

A chave `sb_publishable_...` fica no app e é própria para uso público. Regras de acesso aos dados do Firebase continuam sendo controladas pelas regras Firebase existentes.
