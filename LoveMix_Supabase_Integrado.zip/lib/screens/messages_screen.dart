import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'profile_view_screen.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = DataService.instance;
    return StreamBuilder(
      stream: service.myMatches(),
      builder: (context, snap) {
        if (snap.hasError) return const Center(child: Text('Não foi possível carregar as conversas.'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final matches = snap.data!.docs;
        if (matches.isEmpty) {
          return const Center(child: Text('Curta pessoas para criar combinações e começar a conversar.'));
        }
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 10),
          itemCount: matches.length,
          itemBuilder: (context, i) {
            final match = matches[i];
            final data = match.data();
            final users = List<String>.from(data['users'] ?? const []);
            final other = users.firstWhere((id) => id != service.uid, orElse: () => '');
            return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              future: FirebaseFirestore.instance.collection('users').doc(other).get(),
              builder: (context, userSnap) {
                final profile = userSnap.data?.data() ?? <String, dynamic>{};
                final photo = (profile['photoUrl'] ?? '').toString();
                final name = (profile['name'] ?? 'Novo match').toString();
                return Card(
                  color: const Color(0xFF1B1225),
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                    side: const BorderSide(color: Color(0xFF382044)),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                    leading: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: other.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => ProfileViewScreen(userId: other),
                      )),
                      child: CircleAvatar(
                        radius: 25,
                        backgroundColor: const Color(0xFF45205F),
                        backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                        child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white70) : null,
                      ),
                    ),
                    title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text((data['lastMessage'] ?? 'Vocês combinaram!').toString(), maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: const Icon(Icons.chevron_right, color: Color(0xFFFF2DAB)),
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ChatScreen(chatId: match.id, otherName: name),
                    )),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
