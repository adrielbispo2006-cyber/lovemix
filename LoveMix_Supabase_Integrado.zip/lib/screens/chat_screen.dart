import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'profile_view_screen.dart';
import '../services/data_service.dart';
import '../services/supabase_service.dart';
import '../widgets/profile_frame.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId, required this.otherName});
  final String chatId;
  final String otherName;
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  bool sendingImage = false;
  @override void dispose() { input.dispose(); super.dispose(); }

  Future<void> _send(String value) async {
    final text = value.trim();
    if (text.isEmpty) return;
    input.clear();
    try { await DataService.instance.sendMessage(widget.chatId, text); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível enviar: $e'))); }
  }

  Future<void> _sendPhoto() async {
    if (sendingImage) return;
    try {
      final source = await showModalBottomSheet<ImageSource>(
        context: context,
        backgroundColor: const Color(0xFF1B1028),
        builder: (sheetContext) => SafeArea(
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFFFF2DAB)),
              title: const Text('Escolher da galeria'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Color(0xFFFF2DAB)),
              title: const Text('Tirar uma foto agora'),
              onTap: () => Navigator.pop(sheetContext, ImageSource.camera),
            ),
          ]),
        ),
      );
      if (source == null || !mounted) return;
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 78,
        maxWidth: 1600,
      );
      if (picked == null || !mounted) return;
      setState(() => sendingImage = true);
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) throw Exception('Entre na sua conta novamente.');
      final bytes = await picked.readAsBytes();
      if (bytes.isEmpty) throw Exception('A foto selecionada está vazia.');
      if (bytes.length > 8 * 1024 * 1024) {
        throw Exception('A foto deve ter no máximo 8 MB.');
      }
      final fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
      final url = await SupabaseService.instance.uploadPhoto(
        path: 'chats/${widget.chatId}/$uid/$fileName',
        bytes: bytes, contentType: 'image/jpeg',
      );
      final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatId);
      await chatRef.update({
        'lastMessage': '📷 Foto',
        'lastMessageAt': FieldValue.serverTimestamp(),
      });
      await DataService.instance.messages(widget.chatId).add({
        'senderId': uid,
        'text': '📷 Foto',
        'imageUrl': url,
        'type': 'image',
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível enviar a foto: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sendingImage = false);
    }
  }


  Future<void> _deleteMessage(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final data = doc.data();
    final mine = data['senderId'] == FirebaseAuth.instance.currentUser?.uid;
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('Apagar mensagem', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
        ListTile(leading: const Icon(Icons.delete_outline, color: Colors.white70), title: const Text('Apagar somente para mim'), onTap: () => Navigator.pop(ctx, 'me')),
        if (mine) ListTile(leading: const Icon(Icons.delete_forever, color: Colors.redAccent), title: const Text('Apagar para todos'), subtitle: const Text('A mensagem será removida da conversa'), onTap: () => Navigator.pop(ctx, 'all')),
        ListTile(title: const Text('Cancelar'), onTap: () => Navigator.pop(ctx)),
      ])),
    );
    if (choice == null) return;
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      if (choice == 'me') {
        await doc.reference.update({'hiddenFor': FieldValue.arrayUnion([uid])});
      } else {
        final imageUrl = (data['imageUrl'] ?? '').toString();
        await doc.reference.delete();
        if (imageUrl.isNotEmpty) {
          try { final removed = await SupabaseService.instance.deletePublicUrl(imageUrl); if (!removed) await FirebaseStorage.instance.refFromURL(imageUrl).delete(); } catch (_) {}
        }
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mensagem apagada.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Não foi possível apagar: $e')));
    }
  }

  void _quickReactions() {
    const reactions = ['❤️','😍','🥰','😘','😂','🔥','💜','🌹','🎁','🧸','💎','👑'];
    showModalBottomSheet(context: context, backgroundColor: const Color(0xFF1B1028),
      builder: (ctx) => Padding(padding: const EdgeInsets.all(18), child: Wrap(
        spacing: 12, runSpacing: 12,
        children: reactions.map((emoji) => InkWell(
          onTap: () { Navigator.pop(ctx); _send(emoji); },
          child: Container(width: 52, height: 52, alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF321846), borderRadius: BorderRadius.circular(14)),
            child: Text(emoji, style: const TextStyle(fontSize: 27))),
        )).toList(),
      )));
  }

  @override Widget build(BuildContext context) {
    final service = DataService.instance;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(children: [
          StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats').doc(widget.chatId).snapshots(),
            builder: (context, snap) {
              final ids = List<String>.from(snap.data?.data()?['users'] ?? const []);
              final others = ids.where((id) => id != uid).toList();
              final other = others.isEmpty ? null : others.first;
              if (other == null) return const CircleAvatar(radius: 18, child: Icon(Icons.person));
              return FutureBuilder<DocumentSnapshot<Map<String,dynamic>>>(
                future: FirebaseFirestore.instance.collection('users').doc(other).get(),
                builder: (context, userSnap) {
                  final userData = userSnap.data?.data() ?? <String, dynamic>{};
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                      builder: (_) => ProfileViewScreen(userId: other),
                    )),
                    child: ProfileFrameAvatar(photoUrl: (userData['photoUrl'] ?? '').toString(),
                      frameId: (userData['selectedProfileFrame'] ?? 'classic').toString(), size: 34),
                  );
                });
            },
          ),
          const SizedBox(width: 9),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.otherName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const Text('Disponível para conversar', style: TextStyle(fontSize: 10, color: Color(0xFFB7A9C4))),
          ]),
        ]),
        actions: [
          IconButton(tooltip: 'Chamada de voz', onPressed: () => _notAvailable('Chamada de voz'), icon: const Icon(Icons.call, color: Color(0xFFFF2DAB))),
          IconButton(tooltip: 'Chamada de vídeo', onPressed: () => _notAvailable('Chamada de vídeo'), icon: const Icon(Icons.videocam, color: Color(0xFFFF2DAB))),
        ],
      ),
      body: Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
          stream: service.messages(widget.chatId).orderBy('createdAt').snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Não foi possível carregar as mensagens.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snap.data!.docs.where((d) { final hidden = List<String>.from(d.data()['hiddenFor'] ?? const []); return !hidden.contains(uid); }).toList();
            if (docs.isEmpty) return const Center(child: Text('Diga oi e comece uma nova conversa! 💗'));
            return ListView.builder(padding: const EdgeInsets.all(14), itemCount: docs.length,
              itemBuilder: (context, i) {
                final m = docs[i].data();
                final mine = m['senderId'] == uid;
                final value = (m['text'] ?? '').toString();
                final isGift = m['type'] == 'gift';
                final isImage = m['type'] == 'image' && (m['imageUrl'] ?? '').toString().isNotEmpty;
                return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: GestureDetector(
                    onLongPress: () => _deleteMessage(docs[i]),
                    child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                    constraints: const BoxConstraints(maxWidth: 290),
                    decoration: BoxDecoration(
                      gradient: mine ? const LinearGradient(colors: [Color(0xFF8B22D4), Color(0xFF541A91)]) : null,
                      color: mine ? null : const Color(0xFF241A31),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(17), topRight: const Radius.circular(17),
                        bottomLeft: Radius.circular(mine ? 17 : 4), bottomRight: Radius.circular(mine ? 4 : 17)),
                      border: isGift ? Border.all(color: const Color(0xFFFF2DAB)) : null,
                    ),
                    child: isImage
                        ? GestureDetector(
                            onTap: () => showDialog<void>(
                              context: context,
                              builder: (dialogContext) => Dialog(
                                backgroundColor: const Color(0xFF100A19),
                                child: InteractiveViewer(
                                  child: Image.network(
                                    (m['imageUrl'] ?? '').toString(),
                                    fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => const Padding(
                                      padding: EdgeInsets.all(24),
                                      child: Text('Não foi possível carregar esta foto.'),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Image.network(
                                (m['imageUrl'] ?? '').toString(),
                                width: 230,
                                height: 250,
                                fit: BoxFit.cover,
                                loadingBuilder: (context, child, progress) => progress == null
                                    ? child
                                    : const SizedBox(
                                        width: 230, height: 180,
                                        child: Center(child: CircularProgressIndicator()),
                                      ),
                                errorBuilder: (_, __, ___) => const SizedBox(
                                  width: 230, height: 100,
                                  child: Center(child: Text('Foto indisponível')),
                                ),
                              ),
                            ),
                          )
                        : Text(value, style: TextStyle(color: Colors.white, fontSize: isGift ? 20 : 15)),
                  ),
                  ),
                );
              });
          },
        )),
        SafeArea(top: false, child: Container(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
          decoration: const BoxDecoration(color: Color(0xFF100A19), border: Border(top: BorderSide(color: Color(0xFF422052)))),
          child: Row(children: [
            IconButton(
              tooltip: 'Enviar foto',
              onPressed: sendingImage ? null : _sendPhoto,
              icon: sendingImage
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.photo_library_outlined, color: Color(0xFFFF2DAB)),
            ),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white70)),
            Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, textInputAction: TextInputAction.send, onSubmitted: _send,
              decoration: InputDecoration(hintText: 'Envie uma mensagem...', isDense: true,
                filled: true, fillColor: const Color(0xFF21162D), contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
            IconButton(onPressed: _quickReactions, icon: const Icon(Icons.card_giftcard, color: Color(0xFFFF2DAB))),
            IconButton(onPressed: () => _send(input.text), icon: const Icon(Icons.send_rounded, color: Color(0xFFFF2DAB))),
          ]),
        )),
      ]),
    );
  }

  void _notAvailable(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$feature: conecte um serviço de chamadas em tempo real para ativar esse recurso.'),
    ));
  }
}
