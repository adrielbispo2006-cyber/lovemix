import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../widgets/vip_nickname.dart';

class VipNicknameScreen extends StatelessWidget {
  const VipNicknameScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(backgroundColor: const Color(0xFF080510), appBar: AppBar(title: const Text('Nick VIP'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(), builder: (context, snap) {
        final data = snap.data?.data() ?? <String,dynamic>{};
        if (data['isVip'] != true) return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('As decorações de nick são exclusivas para membros VIP 👑', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 17))));
        final selected = (data['vipNicknameStyle'] ?? 'royal_gold').toString();
        final name = (data['name'] ?? 'Seu nome').toString();
        return ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Escolha sua decoração VIP', style: TextStyle(color: Colors.white70)), const SizedBox(height: 12),
          ...VipNickname.styles.entries.map((entry) => Card(color: const Color(0xFF171022), child: ListTile(
            leading: const Icon(Icons.workspace_premium, color: Color(0xFFFFD56A)),
            title: VipNickname(name: name, isVip: true, styleId: entry.key),
            subtitle: Text(entry.value['label'] as String, style: const TextStyle(color: Colors.white54)),
            trailing: selected == entry.key ? const Icon(Icons.check_circle, color: Color(0xFFFF19B8)) : const Icon(Icons.chevron_right),
            onTap: () async { await FirebaseFirestore.instance.collection('users').doc(uid).set({'vipNicknameStyle': entry.key}, SetOptions(merge: true)); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nick VIP atualizado!'))); },
          ))),
        ]);
      }));
  }
}
