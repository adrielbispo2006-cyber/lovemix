import 'package:cached_network_image/cached_network_image.dart';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

class ProfileFrameAvatar extends StatefulWidget {
  const ProfileFrameAvatar({super.key, required this.photoUrl, required this.frameId, this.size = 86});
  final String photoUrl;
  final String frameId;
  final double size;

  /// Ajuste fino de cada arte: [diâmetro interno do aro / largura da imagem, desvio x, desvio y].
  static const Map<String, List<double>> _fit = {
    'asas_reais': [0.54, 0.018, 0.015],
    'gatinho_gamer': [0.502, -0.001, 0.002],
    'coroa_louros': [0.524, 0.006, 0.005],
    'neon_coracao': [0.515, -0.007, 0.003],
    'rosa_negra_real': [0.514, 0.016, -0.003],
    'orbita_amor': [0.511, 0.01, -0.004],
    'vip_dourado': [0.516, -0.001, 0.004],
    'jardim_roxo': [0.505, -0.006, 0.003],
    'gatinha_neon': [0.508, 0.002, 0.006],
    'rosas_rosa': [0.54, -0.003, 0.002],
    'gotica_sombria': [0.504, 0.003, -0.0],
    'chamas_reais': [0.517, 0.005, -0.005],
    'laco_real': [0.539, -0.003, 0.005],
    'galaxia_roxa': [0.509, 0.007, -0.004],
    'asas_celestiais': [0.508, 0.004, 0.004],
    'cadeado_amor': [0.501, 0.0, 0.0],
    'ouro_alado': [0.485, 0.002, 0.011],
    'coracoes_laco': [0.479, 0.001, -0.002],
    'rosas_rubi': [0.478, -0.001, -0.001],
    'borboletas_azuis': [0.499, -0.006, 0.002],
    'anjo_halo': [0.498, -0.003, 0.005],
    'borboletas_roxas': [0.486, 0.002, 0.002],
    'gatinho_fofo': [0.487, 0.001, 0.001],
    'correntes_prata': [0.479, -0.005, 0.009],
    'rosas_prata': [0.496, 0.0, 0.0],
    'estrelas_ouro': [0.481, 0.002, 0.0],
    'realeza_gotas': [0.491, 0.004, 0.006],
    'paraiso_tropical': [0.468, 0.0, 0.001],
    'sakura': [0.488, -0.004, 0.002],
    'amor_vermelho': [0.486, -0.001, -0.0],
    'coroa_rubi': [0.486, 0.001, -0.0],
    'borboletas_lilas': [0.474, 0.007, 0.003],
    'inverno_gelo': [0.488, 0.003, -0.0],
    'arco_iris': [0.491, 0.002, -0.007],
    'rosas_poker': [0.474, 0.01, -0.02],
    'lua_planetas': [0.485, 0.0, 0.0],
    'asas_cristal': [0.512, 0.001, -0.004],
    'vip_imperial': [0.493, 0.021, 0.01],
    'lovemix_neon': [0.525, 0.008, -0.018],
    'dragao_rubro': [0.49, 0.0, -0.02],
    'rainha_gelo': [0.524, 0.004, 0.036],
    'meow_neon': [0.54, 0.007, -0.03],
    'anjo_dourado': [0.46, 0.023, -0.05],
    'princesa_borboletas': [0.49, 0.0, -0.02],
    'verao_pordosol': [0.605, 0.031, -0.055],
    'music_neon': [0.49, 0.0, -0.02],
    'amor_ouro': [0.5, 0.02, -0.03],
    'rainha_asas': [0.49, 0.0, -0.02],
    'love_perolas': [0.47, 0.03, 0.0],
    'halloween': [0.49, 0.026, -0.058],
    'elite_negra': [0.495, 0.031, -0.061],
    'mar_azul': [0.533, 0.012, -0.062],
    'love_arcoiris': [0.474, 0.029, 0.004],
    // Coleção Corações Neon
    'coroa_alada': [0.51, 0.0, 0.0],
    'lovemix_coracoes': [0.51, 0.0, 0.0],
    'vip_rosas_roxas': [0.51, 0.0, 0.0],
    'coracao_laco_pink': [0.51, 0.0, 0.0],
    'anjo_coroado': [0.51, 0.0, 0.0],
    'coracao_sombrio': [0.46, 0.0, 0.0],
    'ouro_infinito': [0.51, 0.0, 0.0],
    'casal_neon': [0.51, 0.0, 0.0],
    'jardim_real': [0.51, 0.0, 0.0],
  };

  /// Molduras em imagem (arte real). id -> arquivo.
  static const Map<String, String> imageFrames = {
    'asas_reais': 'assets/frames/frame_01.webp',
    'gatinho_gamer': 'assets/frames/frame_02.webp',
    'coroa_louros': 'assets/frames/frame_03.webp',
    'neon_coracao': 'assets/frames/frame_04.webp',
    'rosa_negra_real': 'assets/frames/frame_05.webp',
    'orbita_amor': 'assets/frames/frame_06.webp',
    'vip_dourado': 'assets/frames/frame_07.webp',
    'jardim_roxo': 'assets/frames/frame_08.webp',
    'gatinha_neon': 'assets/frames/frame_09.webp',
    'rosas_rosa': 'assets/frames/frame_10.webp',
    'gotica_sombria': 'assets/frames/frame_11.webp',
    'chamas_reais': 'assets/frames/frame_12.webp',
    'laco_real': 'assets/frames/frame_13.webp',
    'galaxia_roxa': 'assets/frames/frame_14.webp',
    'asas_celestiais': 'assets/frames/frame_15.webp',
    'cadeado_amor': 'assets/frames/frame_16.webp',
    'ouro_alado': 'assets/frames/frame_17.webp',
    'coracoes_laco': 'assets/frames/frame_18.webp',
    'rosas_rubi': 'assets/frames/frame_19.webp',
    'borboletas_azuis': 'assets/frames/frame_20.webp',
    'anjo_halo': 'assets/frames/frame_21.webp',
    'borboletas_roxas': 'assets/frames/frame_22.webp',
    'dragao_verde': 'assets/frames/frame_23.webp',
    'gatinho_fofo': 'assets/frames/frame_24.webp',
    'correntes_prata': 'assets/frames/frame_25.webp',
    'leao_fogo': 'assets/frames/frame_26.webp',
    'rosas_prata': 'assets/frames/frame_27.webp',
    'estrelas_ouro': 'assets/frames/frame_28.webp',
    'realeza_gotas': 'assets/frames/frame_29.webp',
    'paraiso_tropical': 'assets/frames/frame_30.webp',
    'sakura': 'assets/frames/frame_31.webp',
    'gamer_neon': 'assets/frames/frame_32.webp',
    'amor_vermelho': 'assets/frames/frame_33.webp',
    'coroa_rubi': 'assets/frames/frame_34.webp',
    'hacker_verde': 'assets/frames/frame_35.webp',
    'borboletas_lilas': 'assets/frames/frame_36.webp',
    'inverno_gelo': 'assets/frames/frame_37.webp',
    'arco_iris': 'assets/frames/frame_38.webp',
    'rosas_poker': 'assets/frames/frame_39.webp',
    'lua_planetas': 'assets/frames/frame_40.webp',
    'asas_cristal': 'assets/frames/frame_41.webp',
    'vip_imperial': 'assets/frames/frame_42.webp',
    'lovemix_neon': 'assets/frames/frame_43.webp',
    'dragao_rubro': 'assets/frames/frame_44.webp',
    'rainha_gelo': 'assets/frames/frame_45.webp',
    'meow_neon': 'assets/frames/frame_46.webp',
    'anjo_dourado': 'assets/frames/frame_47.webp',
    'princesa_borboletas': 'assets/frames/frame_48.webp',
    'verao_pordosol': 'assets/frames/frame_49.webp',
    'music_neon': 'assets/frames/frame_50.webp',
    'amor_ouro': 'assets/frames/frame_51.webp',
    'rainha_asas': 'assets/frames/frame_52.webp',
    'love_perolas': 'assets/frames/frame_53.webp',
    'halloween': 'assets/frames/frame_54.webp',
    'elite_negra': 'assets/frames/frame_55.webp',
    'mar_azul': 'assets/frames/frame_56.webp',
    'love_arcoiris': 'assets/frames/frame_57.webp',
    'coroa_alada': 'assets/frames/frame_58.webp',
    'lovemix_coracoes': 'assets/frames/frame_59.webp',
    'vip_rosas_roxas': 'assets/frames/frame_60.webp',
    'coracao_laco_pink': 'assets/frames/frame_61.webp',
    'anjo_coroado': 'assets/frames/frame_62.webp',
    'coracao_sombrio': 'assets/frames/frame_63.webp',
    'ouro_infinito': 'assets/frames/frame_64.webp',
    'casal_neon': 'assets/frames/frame_65.webp',
    'jardim_real': 'assets/frames/frame_66.webp',
  };


  /// Molduras com coração: ganham bolhas de coração subindo e estourando.
  static const Set<String> heartFrames = {
    'orbita_amor', 'neon_coracao', 'rosas_rosa', 'coroa_louros', 'asas_celestiais', 'asas_reais', 'ouro_alado',
    'coracoes_laco', 'anjo_halo', 'correntes_prata', 'cadeado_amor', 'realeza_gotas', 'amor_vermelho', 'arco_iris',
    'asas_cristal', 'lovemix_neon', 'meow_neon', 'anjo_dourado', 'music_neon', 'amor_ouro', 'rainha_asas',
    'love_perolas', 'love_arcoiris', 'verao_pordosol', 'gatinha_neon', 'gatinho_fofo',
    // Coleção Corações Neon: corações subindo e explodindo
    'coroa_alada', 'lovemix_coracoes', 'vip_rosas_roxas', 'coracao_laco_pink', 'anjo_coroado', 'coracao_sombrio', 'ouro_infinito', 'casal_neon', 'jardim_real',
  };

  /// Molduras desenhadas numa malha animada: 'dragon' (ondula) ou 'fire' (fogo mexendo).
  static const Map<String, String> warpFrames = {'dragao_verde': 'dragon', 'halloween': 'fire', 'mar_azul': 'dolphins', 'verao_pordosol': 'palms',
    // Chamas mexendo de verdade (labaredas ondulando para cima)
    'chamas_reais': 'flames_royal', 'hacker_verde': 'flames_hacker'};

  @override
  State<ProfileFrameAvatar> createState() => _ProfileFrameAvatarState();
}

class _ProfileFrameAvatarState extends State<ProfileFrameAvatar> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final double _phase;

  // Tipo de movimento de cada moldura (as que não estão aqui usam 'pulse').
  static const Map<String, String> _motion = {
    'asas_reais': 'flap', 'ouro_alado': 'flap', 'anjo_halo': 'flap', 'asas_celestiais': 'flap', 'asas_cristal': 'flap',
    'borboletas_azuis': 'flutter', 'borboletas_roxas': 'flutter', 'borboletas_lilas': 'flutter', 'jardim_roxo': 'flutter',
    'chamas_reais': 'none', 'leao_fogo': 'flame', 'dragao_verde': 'none', 'hacker_verde': 'none', 'gotica_sombria': 'flame',
    'coroa_alada': 'flap', 'anjo_coroado': 'flap', 'jardim_real': 'flutter',
    'gatinha_neon': 'bounce', 'gatinho_gamer': 'bounce', 'gatinho_fofo': 'bounce', 'gamer_neon': 'bounce',
    'cadeado_amor': 'sway', 'correntes_prata': 'sway', 'sakura': 'sway', 'paraiso_tropical': 'sway', 'inverno_gelo': 'sway',
    'orbita_amor': 'orbit', 'galaxia_roxa': 'orbit', 'estrelas_ouro': 'orbit', 'lua_planetas': 'orbit', 'arco_iris': 'spin',
    'vip_imperial': 'flap',
    'dragao_rubro': 'flame',
    'rainha_gelo': 'sway',
    'meow_neon': 'bounce',
    'anjo_dourado': 'flap',
    'princesa_borboletas': 'flutter',
    'verao_pordosol': 'none',
    'rainha_asas': 'flap',
    'love_perolas': 'sway',
    'halloween': 'none',
    'mar_azul': 'none',
    'love_arcoiris': 'spin',
  };

  @override
  void initState() {
    super.initState();
    _phase = math.Random().nextDouble();
    // Ciclo longo: a moldura fica parada e, de vez em quando, faz um movimento.
    final orbit = _motion[widget.frameId] == 'orbit';
    // Órbita: uma volta completa em 18 s (contínua). Demais: gesto a cada 7 s.
    _ctrl = AnimationController(vsync: this, duration: Duration(seconds: orbit ? 18 : 7), value: _phase);
    if (ProfileFrameAvatar.imageFrames.containsKey(widget.frameId)) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(covariant ProfileFrameAvatar old) {
    super.didUpdateWidget(old);
    final animate = ProfileFrameAvatar.imageFrames.containsKey(widget.frameId);
    if (animate && !_ctrl.isAnimating) _ctrl.repeat();
    if (!animate) _ctrl.stop();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  /// 0..1 durante o "gesto" (primeiros ~30% do ciclo), depois 0 (parada).
  double get _gesture {
    final t = _ctrl.value;
    if (t > .30) return 0;
    return math.sin(t / .30 * math.pi); // sobe e desce suave
  }

  Widget _animated(Widget child) {
    final t = _ctrl.value;
    final kind = _motion[widget.frameId] ?? 'pulse';
    final g = (kind == 'orbit' || kind == 'none') ? 0.0 : _gesture;
    double scale = 1, dx = 0, dy = 0, rot = 0;
    double scaleX = 1;
    switch (kind) {
      case 'flap':    // asas batem: abre e fecha na horizontal
        scaleX = 1 + .045 * math.sin(t / .30 * math.pi * 4) * g; scale = 1 + .02 * g; break;
      case 'flutter': // borboletas: tremem e balançam
        rot = .035 * math.sin(t / .30 * math.pi * 6) * g; dy = -2.5 * g; break;
      case 'flame':   // chamas: pulsa rápido
        scale = 1 + .03 * math.sin(t / .30 * math.pi * 5).abs() * g; dy = -1.5 * g; break;
      case 'bounce':  // gatinhos: pulinho
        dy = -5 * math.sin(t / .30 * math.pi * 2).abs() * g; scale = 1 + .015 * g; break;
      case 'sway':    // balança de um lado pro outro
        rot = .07 * math.sin(t / .30 * math.pi * 2) * g; break;
      case 'orbit':   // planetas/estrelas giram ao redor do aro (volta completa)
        rot = 2 * math.pi * t; break;
      case 'none':    // movimento próprio (ex.: dragão com malha ondulante)
        break;
      case 'spin':    // gira de leve
        rot = .16 * g; break;
      default:        // coração batendo
        scale = 1 + .05 * math.sin(t / .30 * math.pi * 2).abs() * g; break;
    }
    final pf = ProfileFrameAvatar._fit[widget.frameId];
    final pivot = pf == null ? Alignment.center : Alignment(pf[1] * 2, pf[2] * 2); // gira em torno do centro do aro
    return Transform(alignment: pivot,
      transform: Matrix4.identity()..translate(dx, dy)..rotateZ(rot)..scale(scale * scaleX, scale),
      child: ColorFiltered(colorFilter: ColorFilter.mode(Colors.white.withOpacity(.16 * g), BlendMode.srcATop), child: child));
  }

  Widget _photo() => widget.photoUrl.isEmpty
      ? Container(color: const Color(0xFF21132E), child: const Center(child: Icon(Icons.person, color: Colors.white70, size: 42)))
      : CachedNetworkImage(imageUrl: widget.photoUrl, fit: BoxFit.cover,
          placeholder: (_, __) => const Center(child: CircularProgressIndicator(strokeWidth: 1)),
          errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white70, size: 42));

  static const Map<String, List<Color>> _palettes = {
    'neon': [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFF35D7FF)],
    'hearts': [Color(0xFFFF5A9E), Color(0xFFFF19B8), Color(0xFFFFB0D2)],
    'gold': [Color(0xFFFFE08A), Color(0xFFB87918), Color(0xFFFFF0B5)],
    'cosmic': [Color(0xFF39D9FF), Color(0xFF8D35FF), Color(0xFFFF19B8)],
    'royal_crown': [Color(0xFFFFD56A), Color(0xFF9D5B13), Color(0xFFFFF0A8)],
    'kitty': [Color(0xFFFF9DDE), Color(0xFF9B4DFF)],
    'butterfly': [Color(0xFFB65CFF), Color(0xFFFF65D4), Color(0xFF67DFFF)],
    'rose': [Color(0xFF40102F), Color(0xFFFF247F), Color(0xFF9B174D)],
    'headphones': [Color(0xFF9B55FF), Color(0xFFEF43D0), Color(0xFF55D9FF)],
    'pink_bow': [Color(0xFFFF78C8), Color(0xFFFF20A8)],
    'flame': [Color(0xFFFF4A32), Color(0xFFB324FF), Color(0xFFFF9B32)],
    'angel': [Color(0xFFFFE9FF), Color(0xFFB78AFF), Color(0xFFFFFFFF)],
    'love_wings': [Color(0xFFFF35C8), Color(0xFF8D35FF), Color(0xFFFFB6E8)],
    'flower': [Color(0xFFFF83C8), Color(0xFF9B55FF), Color(0xFFFFD66B)],
    'sparkle': [Color(0xFF9D75FF), Color(0xFF4DDFFF), Color(0xFFFFFFFF)],
    'diamond_heart': [Color(0xFF72E5FF), Color(0xFFB45BFF), Color(0xFFFF5FB8)],
    'broken_heart': [Color(0xFFFF4B8B), Color(0xFF6B24C9)],
    'royal_purple': [Color(0xFFB45BFF), Color(0xFF5B20A8), Color(0xFFFFD56A)],
    'couple': [Color(0xFFFF4DAD), Color(0xFF9B45E8), Color(0xFFFFA8C9)],
    'butterfly_royal': [Color(0xFF72E5FF), Color(0xFF9B45E8), Color(0xFFFFD56A)],
    'rose_gold': [Color(0xFFFFD56A), Color(0xFF9B174D), Color(0xFFFFF0B5)],
    'celestial': [Color(0xFFFFFFFF), Color(0xFFB45BFF), Color(0xFF72DFFF)],
    'royal_wings': [Color(0xFFFFE08A), Color(0xFF8D35FF), Color(0xFFFFF0B5)],
    'diamond_crown': [Color(0xFF72E5FF), Color(0xFFFFD56A), Color(0xFFFFFFFF)],
    'lovemix_deluxe': [Color(0xFFFF19B8), Color(0xFF8D35FF), Color(0xFFFFD56A)],
  };

  static const Map<String, String> _ornaments = {
    'hearts': '♥', 'gold': '👑', 'cosmic': '✦', 'royal_crown': '👑',
    'kitty': '🐱', 'butterfly': '🦋', 'rose': '🌹', 'headphones': '🎧',
    'pink_bow': '🎀', 'flame': '🔥', 'angel': '🪽', 'love_wings': '💞',
    'flower': '🌸', 'sparkle': '⭐', 'diamond_heart': '💎',
    'broken_heart': '💔', 'royal_purple': '👑', 'couple': '💕',
    'butterfly_royal': '🦋', 'rose_gold': '🌹', 'celestial': '😇',
    'royal_wings': '🪽', 'diamond_crown': '💎', 'lovemix_deluxe': '💖',
  };

  @override
  Widget build(BuildContext context) {
    final isDefault = widget.frameId.isEmpty || widget.frameId == 'classic';
    final imagePath = ProfileFrameAvatar.imageFrames[widget.frameId];
    if (imagePath != null) {
      // A arte tem o buraco do aro em 50% da largura da imagem.
      final box = widget.size + 14;
      final hole = box * 0.80;
      final fit = ProfileFrameAvatar._fit[widget.frameId];
      final canvas = hole / (fit?[0] ?? 0.5);
      final shift = fit == null ? Offset.zero : Offset(-fit[1] * canvas, -fit[2] * canvas);
      return SizedBox(width: box, height: box, child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
        SizedBox(width: hole * 1.04, height: hole * 1.04,
          child: ClipOval(child: ColoredBox(color: const Color(0xFF21132E), child: _photo()))),
        IgnorePointer(child: Transform.translate(offset: shift, child: RepaintBoundary(child: AnimatedBuilder(animation: _ctrl, builder: (context, child) => _animated(child!),
          child: SizedBox(width: canvas, height: canvas,
            child: ProfileFrameAvatar.warpFrames.containsKey(widget.frameId)
                ? _WarpArt(asset: imagePath, animation: _ctrl, kind: ProfileFrameAvatar.warpFrames[widget.frameId]!)
                : Image.asset(imagePath, fit: BoxFit.contain, filterQuality: FilterQuality.medium, gaplessPlayback: true)))))),
        if (ProfileFrameAvatar.heartFrames.contains(widget.frameId))
          IgnorePointer(child: SizedBox(width: box, height: box,
            child: CustomPaint(painter: _HeartBubblePainter(_ctrl, _phase)))),
      ]));
    }
    final colors = _palettes[widget.frameId] ?? const [Color(0xFF8D35FF), Color(0xFFFF19B8)];
    final ornament = _ornaments[widget.frameId];
    final total = widget.size + (isDefault ? 0 : 14);
    return SizedBox(width: total, height: total, child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
      Container(width: total, height: total, padding: EdgeInsets.all(isDefault ? 1.5 : 5),
        decoration: BoxDecoration(shape: BoxShape.circle,
          gradient: isDefault ? null : SweepGradient(colors: [...colors, colors.first]),
          border: isDefault ? Border.all(color: Colors.white24, width: 1.5) : null,
          boxShadow: isDefault ? null : [BoxShadow(color: colors.first.withOpacity(.48), blurRadius: 13, spreadRadius: 1)]),
        child: ClipOval(child: Container(color: const Color(0xFF21132E), child: widget.photoUrl.isEmpty
          ? const Icon(Icons.person, color: Colors.white70, size: 42)
          : CachedNetworkImage(imageUrl: widget.photoUrl, fit: BoxFit.cover,
              placeholder: (_, __) => const Center(child: CircularProgressIndicator(strokeWidth: 1)),
              errorWidget: (_, __, ___) => const Icon(Icons.person, color: Colors.white70, size: 42)))),
      ),
      if (!isDefault && ornament != null)
        Positioned(top: -5, right: -3, child: Text(ornament, style: TextStyle(fontSize: widget.size * .25,
          shadows: [Shadow(color: colors.first, blurRadius: 9)]))),
      if (widget.frameId == 'butterfly_royal') ...[
        Positioned(left: -4, top: widget.size * .12, child: Text('✦', style: TextStyle(color: colors.last, fontSize: widget.size * .22))),
        Positioned(bottom: -5, left: widget.size * .16, child: Text('🦋', style: TextStyle(fontSize: widget.size * .19))),
      ],
      if (widget.frameId == 'rose_gold')
        Positioned(bottom: -5, left: -2, child: Text('🌹', style: TextStyle(fontSize: widget.size * .23))),
      if (widget.frameId == 'celestial') ...[
        Positioned(top: -8, left: widget.size * .25, child: Text('☾', style: TextStyle(color: colors.first, fontSize: widget.size * .25))),
        Positioned(bottom: -4, right: widget.size * .12, child: Text('✧', style: TextStyle(color: colors.last, fontSize: widget.size * .22))),
      ],
      if (widget.frameId == 'royal_wings') ...[
        Positioned(left: -8, top: widget.size * .28, child: Text('❧', style: TextStyle(color: colors.first, fontSize: widget.size * .28))),
        Positioned(right: -8, top: widget.size * .28, child: Text('❧', style: TextStyle(color: colors.first, fontSize: widget.size * .28))),
      ],
      if (widget.frameId == 'diamond_crown')
        Positioned(bottom: -5, child: Text('💎', style: TextStyle(fontSize: widget.size * .2))),
      if (widget.frameId == 'lovemix_deluxe') ...[
        Positioned(left: -5, bottom: widget.size * .2, child: Text('💕', style: TextStyle(fontSize: widget.size * .19))),
        Positioned(right: -5, bottom: widget.size * .2, child: Text('✨', style: TextStyle(fontSize: widget.size * .19))),
      ],
      if (widget.frameId == 'angel' || widget.frameId == 'love_wings' || widget.frameId == 'royal_purple' ||
          widget.frameId == 'celestial' || widget.frameId == 'royal_wings' || widget.frameId == 'lovemix_deluxe')
        Positioned(bottom: -3, child: Text(widget.frameId == 'angel' ? '✨' : widget.frameId == 'love_wings' ? '💗' : '💜',
          style: TextStyle(fontSize: widget.size * .2))),
      if (widget.frameId == 'couple')
        Positioned(bottom: -3, right: 1, child: Text('♥', style: TextStyle(color: Colors.pinkAccent, fontSize: widget.size * .23))),
    ]));
  }
}


/// Dragão vivo: a arte é desenhada numa malha que ondula (cabeça balança, corpo
/// serpenteia e as chamas tremem). Tudo em loop perfeito a cada ciclo.
class _WarpArt extends StatefulWidget {
  const _WarpArt({required this.asset, required this.animation, this.kind = 'dragon'});
  final String asset;
  final String kind;
  final Animation<double> animation;
  @override
  State<_WarpArt> createState() => _WarpArtState();
}

class _WarpArtState extends State<_WarpArt> {
  static final Map<String, Future<ui.Image>> _cache = {};
  ui.Image? _img;

  static Future<ui.Image> _load(String asset) => _cache.putIfAbsent(asset, () async {
        final data = await rootBundle.load(asset);
        final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
        return (await codec.getNextFrame()).image;
      });

  @override
  void initState() {
    super.initState();
    _load(widget.asset).then((i) { if (mounted) setState(() => _img = i); });
  }

  @override
  Widget build(BuildContext context) {
    final img = _img;
    if (img == null) {
      return Image.asset(widget.asset, fit: BoxFit.contain, gaplessPlayback: true);
    }
    return CustomPaint(painter: _WarpPainter(img, widget.animation, widget.kind));
  }
}

class _WarpPainter extends CustomPainter {
  _WarpPainter(this.img, this.anim, this.kind) : super(repaint: anim);
  final String kind;
  final ui.Image img;
  final Animation<double> anim;
  int get _n => (kind == 'fire' || kind.startsWith('flames_')) ? 30 : 20;

  @override
  void paint(Canvas canvas, Size size) {
    final w = 2 * math.pi * anim.value;
    if (kind == 'fire') { _paintFire(canvas, size, w); return; }
    if (kind.startsWith('flames_')) { _paintFlames(canvas, size, w); return; }
    if (kind == 'dolphins') { _paintDolphins(canvas, size); return; }
    if (kind == 'palms') { _paintPalms(canvas, size, w); return; }
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final pos = Float32List((_n + 1) * (_n + 1) * 2);
    final tex = Float32List((_n + 1) * (_n + 1) * 2);
    final idx = Uint16List(_n * _n * 6);
    var k = 0;
    for (var j = 0; j <= _n; j++) {
      for (var i = 0; i <= _n; i++) {
        final u = i / _n, v = j / _n;
        final cx = u - .5, cy = v - .5;
        final r = math.sqrt(cx * cx + cy * cy);
        double dx = 0, dy = 0;
        // chamas (esquerda e embaixo) tremem; longe do buraco da foto
        final away = ((r - .26) / .12).clamp(0.0, 1.0);
        final flames = (((v - .4) / .2).clamp(0.0, 1.0) + ((.35 - u) / .2).clamp(0.0, 1.0)).clamp(0.0, 1.0);
        dx += .006 * math.sin(w * 3 + v * 9 + u * 3) * away * flames;
        dy += .007 * math.cos(w * 3 + u * 8) * away * flames;
        // cabeça: balança e vira
        final hx = u - .64, hy = v - .38;
        final head = math.exp(-(hx * hx + hy * hy) / .014);
        dx += .017 * math.sin(w * 2) * head;
        dy += .024 * math.sin(w * 2 + 1.1) * head;
        // corpo (direita/embaixo) serpenteia
        final bx = u - .78, by = v - .55;
        final body = math.exp(-(bx * bx) / .012) * math.exp(-(by * by) / .07);
        dx += .010 * math.sin(w * 3 + v * 14) * body;
        final tail = math.exp(-((u - .6) * (u - .6)) / .05) * math.exp(-((v - .76) * (v - .76)) / .006);
        dy += .012 * math.sin(w * 3 + u * 12) * tail;
        pos[k] = (u + dx) * size.width;
        pos[k + 1] = (v + dy) * size.height;
        tex[k] = u * iw;
        tex[k + 1] = v * ih;
        k += 2;
      }
    }
    var t = 0;
    for (var j = 0; j < _n; j++) {
      for (var i = 0; i < _n; i++) {
        final a = j * (_n + 1) + i, b = a + 1, c = a + _n + 1, d = c + 1;
        idx[t++] = a; idx[t++] = b; idx[t++] = c;
        idx[t++] = b; idx[t++] = d; idx[t++] = c;
      }
    }
    final paint = Paint()
      ..isAntiAlias = true
      ..filterQuality = FilterQuality.medium
      ..shader = ui.ImageShader(img, TileMode.clamp, TileMode.clamp, Matrix4.identity().storage, filterQuality: FilterQuality.medium);
    final vertices = ui.Vertices.raw(ui.VertexMode.triangles, pos, textureCoordinates: tex, indices: idx);
    canvas.drawVertices(vertices, BlendMode.srcOver, paint);
    vertices.dispose();
  }

  /// Verão: as duas palmeiras balançam como se o vento empurrasse as folhas.
  /// Só as copas se movem (o tronco fica preso na base); aro, flor e placa ficam parados.
  /// Usa apenas senos de frequência inteira em [w], então o loop é perfeito.
  void _paintPalms(Canvas canvas, Size size, double w) {
    const n = 32;
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final pos = Float32List((n + 1) * (n + 1) * 2);
    final tex = Float32List((n + 1) * (n + 1) * 2);
    final idx = Uint16List(n * n * 6);
    // Palmeiras: (centro u, centro v da copa, abertura u, abertura v, v da base, fase)
    const palms = [
      [.27, .20, .17, .16, .60, 0.0],   // esquerda
      [.86, .20, .11, .17, .62, 1.7],   // direita
    ];
    var k = 0;
    for (var j = 0; j <= n; j++) {
      for (var i = 0; i <= n; i++) {
        final u = i / n, v = j / n;
        double dx = 0, dy = 0;
        for (final p in palms) {
          final gx = (u - p[0]) / p[2], gy = (v - p[1]) / p[3];
          final region = math.exp(-(gx * gx + gy * gy));
          // quanto mais longe da base do tronco, mais balança
          final lift = ((p[4] - v) / (p[4] - .02)).clamp(0.0, 1.0);
          final free = lift * lift;
          final ph = p[5];
          // rajada lenta + tremor mais rápido nas pontas das folhas
          final gust = math.sin(w + ph) + .45 * math.sin(2 * w + ph * 1.3);
          final flutter = math.sin(3 * w + ph + u * 14 + v * 6);
          final f = region * free;
          dx += (.020 * gust + .006 * flutter) * f;
          dy += (.006 * math.sin(2 * w + ph + 0.8) + .004 * flutter) * f;
        }
        pos[k] = (u + dx) * size.width;
        pos[k + 1] = (v + dy) * size.height;
        tex[k] = u * iw;
        tex[k + 1] = v * ih;
        k += 2;
      }
    }
    var t = 0;
    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        final a = j * (n + 1) + i, b = a + 1, c = a + n + 1, d = c + 1;
        idx[t++] = a; idx[t++] = b; idx[t++] = c;
        idx[t++] = b; idx[t++] = d; idx[t++] = c;
      }
    }
    final paint = Paint()
      ..isAntiAlias = true
      ..filterQuality = FilterQuality.medium
      ..shader = ui.ImageShader(img, TileMode.clamp, TileMode.clamp, Matrix4.identity().storage, filterQuality: FilterQuality.medium);
    final vertices = ui.Vertices.raw(ui.VertexMode.triangles, pos, textureCoordinates: tex, indices: idx);
    canvas.drawVertices(vertices, BlendMode.srcOver, paint);
    vertices.dispose();
  }

  /// Golfinhos do Mar Azul: um pula em arco por cima do aro e mergulha de volta,
  /// depois o outro faz o mesmo do lado oposto (ciclo de 7 s, loop perfeito).
  /// A água embaixo ondula de leve; coroa, concha e texto ficam parados.
  void _paintDolphins(Canvas canvas, Size size) {
    final t = anim.value; // 0..1
    const n = 28;
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final pos = Float32List((n + 1) * (n + 1) * 2);
    final tex = Float32List((n + 1) * (n + 1) * 2);
    final idx = Uint16List(n * n * 6);

    // s = progresso do pulo (0..1) dentro da janela de cada golfinho; fora dela fica em repouso.
    double jump(double start) {
      final s = ((t - start) % 1.0) / .42;
      return s >= 1 ? 0 : s;
    }
    final sL = jump(0.0), sR = jump(.5);
    // sobe e desce suave
    double arc(double s) => math.sin(s * math.pi);

    // Golfinho: (centro u, centro v, abertura u, abertura v, sentido horizontal do pulo, sentido da rotação)
    const dolphins = [
      [.26, .40, .030, .060, 1.0, 1.0],  // esquerdo: salta para a direita (para o centro)
      [.84, .36, .028, .055, -1.0, -1.0], // direito: salta para a esquerda
    ];
    final prog = [sL, sR];

    var k = 0;
    for (var j = 0; j <= n; j++) {
      for (var i = 0; i <= n; i++) {
        final u = i / n, v = j / n;
        double dx = 0, dy = 0;

        for (var d = 0; d < 2; d++) {
          final c = dolphins[d];
          final s = prog[d];
          if (s <= 0) continue;
          final wgt = math.exp(-(math.pow(u - c[0], 2) / c[2] + math.pow(v - c[1], 2) / c[3]));
          final a = arc(s);
          // translação em arco: sobe e avança em direção ao meio
          final tx = c[4] * .055 * a;
          final ty = -.075 * a;
          // inclinação do corpo: bico sobe na ida e desce na volta
          final th = c[5] * .30 * math.sin(s * 2 * math.pi) * -1;
          final px = u - c[0], py = v - c[1];
          final rx = px * math.cos(th) - py * math.sin(th) - px;
          final ry = px * math.sin(th) + py * math.cos(th) - py;
          dx += wgt * (tx + rx);
          dy += wgt * (ty + ry);
        }

        // água embaixo: ondula, bem longe do aro da foto e do texto
        final cx = u - .5, cy = v - .5;
        final r = math.sqrt(cx * cx + cy * cy);
        final water = ((v - .62) / .12).clamp(0.0, 1.0) * ((r - .30) / .08).clamp(0.0, 1.0);
        final textZone = math.exp(-(math.pow(u - .56, 2) / .02 + math.pow(v - .83, 2) / .004));
        final ww = water * (1 - .85 * textZone);
        dx += ww * .004 * math.sin(2 * math.pi * t * 2 + v * 20 + u * 6);
        dy += ww * .004 * math.cos(2 * math.pi * t * 2 + u * 18);

        pos[k] = (u + dx) * size.width;
        pos[k + 1] = (v + dy) * size.height;
        tex[k] = u * iw;
        tex[k + 1] = v * ih;
        k += 2;
      }
    }
    var q = 0;
    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        final a = j * (n + 1) + i, b = a + 1, c = a + n + 1, d = c + 1;
        idx[q++] = a; idx[q++] = b; idx[q++] = c;
        idx[q++] = b; idx[q++] = d; idx[q++] = c;
      }
    }
    final paint = Paint()
      ..isAntiAlias = true
      ..filterQuality = FilterQuality.medium
      ..shader = ui.ImageShader(img, TileMode.clamp, TileMode.clamp, Matrix4.identity().storage, filterQuality: FilterQuality.medium);
    final vertices = ui.Vertices.raw(ui.VertexMode.triangles, pos, textureCoordinates: tex, indices: idx);
    canvas.drawVertices(vertices, BlendMode.srcOver, paint);
    vertices.dispose();
  }

  /// Fogo roxo vivo: as labaredas ondulam para cima, com vários ritmos misturados
  /// e brilho que pisca. A abóbora, o chapéu e o aro ficam quase parados.
  void _paintFire(Canvas canvas, Size size, double w) {
    final n = _n;
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final pos = Float32List((n + 1) * (n + 1) * 2);
    final tex = Float32List((n + 1) * (n + 1) * 2);
    final idx = Uint16List(n * n * 6);
    var k = 0;
    for (var j = 0; j <= n; j++) {
      for (var i = 0; i <= n; i++) {
        final u = i / n, v = j / n;
        final cx = u - .5, cy = v - .5;
        final r = math.sqrt(cx * cx + cy * cy);
        // longe do buraco da foto
        final away = ((r - .27) / .10).clamp(0.0, 1.0);
        // pumpkins (embaixo) e chapéu (em cima à esquerda) mexem pouco
        final pumpL = math.exp(-(math.pow(u - .14, 2) + math.pow(v - .86, 2)) / .012);
        final pumpR = math.exp(-(math.pow(u - .84, 2) + math.pow(v - .88, 2)) / .012);
        final hat = math.exp(-(math.pow(u - .2, 2) + math.pow(v - .12, 2)) / .018);
        final calm = 1 - .75 * (pumpL + pumpR + hat).clamp(0.0, 1.0);
        final a = away * calm;
        // labaredas sobem: a fase anda com v, então a onda "corre" para cima
        final dx = a * (.011 * math.sin(w * 3 + v * 22 + u * 5) +
            .007 * math.sin(w * 5 + v * 35 - u * 9) +
            .004 * math.sin(w * 8 + v * 50 + u * 14));
        final dy = a * (-.010 * (.5 + .5 * math.sin(w * 3 + u * 18 + v * 6)) +
            .006 * math.sin(w * 5 + u * 26) -
            .004 * math.sin(w * 8 + u * 40 + v * 10));
        pos[k] = (u + dx) * size.width;
        pos[k + 1] = (v + dy) * size.height;
        tex[k] = u * iw;
        tex[k + 1] = v * ih;
        k += 2;
      }
    }
    var t = 0;
    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        final a = j * (n + 1) + i, b = a + 1, c = a + n + 1, d = c + 1;
        idx[t++] = a; idx[t++] = b; idx[t++] = c;
        idx[t++] = b; idx[t++] = d; idx[t++] = c;
      }
    }
    // brilho que pisca como brasa
    final flick = 1.0 + .10 * math.sin(w * 3) + .06 * math.sin(w * 8 + 1.3) + .04 * math.sin(w * 13 + .4);
    final paint = Paint()
      ..isAntiAlias = true
      ..filterQuality = FilterQuality.medium
      ..colorFilter = ColorFilter.matrix(<double>[
        flick, 0, 0, 0, 0,
        0, flick, 0, 0, 0,
        0, 0, flick, 0, 0,
        0, 0, 0, 1, 0,
      ])
      ..shader = ui.ImageShader(img, TileMode.clamp, TileMode.clamp, Matrix4.identity().storage, filterQuality: FilterQuality.medium);
    final vertices = ui.Vertices.raw(ui.VertexMode.triangles, pos, textureCoordinates: tex, indices: idx);
    canvas.drawVertices(vertices, BlendMode.srcOver, paint);
    vertices.dispose();
  }

  /// Partes que NÃO são fogo em cada moldura (ficam paradas): [u, v, raio²].
  static const Map<String, List<List<double>>> _flameCalm = {
    'flames_royal': [[.30, .22, .012]],                         // coroa dourada
    'flames_hacker': [[.50, .14, .010], [.82, .45, .045], [.27, .82, .008]], // coroa, hacker, caveira
  };

  /// Labaredas vivas: a arte ondula para cima em vários ritmos (como fogo de
  /// verdade), as pontas balançam mais que a base e o brilho pisca como brasa.
  /// Coroa, hacker e caveira ficam parados. Loop perfeito a cada ciclo.
  void _paintFlames(Canvas canvas, Size size, double w) {
    final n = _n;
    final calmZones = _flameCalm[kind] ?? const <List<double>>[];
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final pos = Float32List((n + 1) * (n + 1) * 2);
    final tex = Float32List((n + 1) * (n + 1) * 2);
    final idx = Uint16List(n * n * 6);
    var k = 0;
    for (var j = 0; j <= n; j++) {
      for (var i = 0; i <= n; i++) {
        final u = i / n, v = j / n;
        final cx = u - .5, cy = v - .5;
        final r = math.sqrt(cx * cx + cy * cy);
        final away = ((r - .265) / .08).clamp(0.0, 1.0); // aro e foto parados
        var calm = 0.0;
        for (final z in calmZones) {
          calm += math.exp(-(math.pow(u - z[0], 2) + math.pow(v - z[1], 2)) / z[2]);
        }
        final a = away * (1 - calm.clamp(0.0, 1.0));
        // as pontas (mais longe do centro / mais para cima) tremem mais
        final tip = .7 + .6 * ((r - .3) / .2).clamp(0.0, 1.0);
        final dx = a * tip * (.012 * math.sin(w * 3 + v * 24 + u * 5) +
            .007 * math.sin(w * 5 + v * 38 - u * 9) +
            .004 * math.sin(w * 9 + v * 55 + u * 13));
        final dy = a * tip * (-.013 * (.5 + .5 * math.sin(w * 4 + u * 20 + v * 7)) +
            .006 * math.sin(w * 6 + u * 28) -
            .004 * math.sin(w * 10 + u * 42 + v * 11));
        pos[k] = (u + dx) * size.width;
        pos[k + 1] = (v + dy) * size.height;
        tex[k] = u * iw;
        tex[k + 1] = v * ih;
        k += 2;
      }
    }
    var t = 0;
    for (var j = 0; j < n; j++) {
      for (var i = 0; i < n; i++) {
        final a = j * (n + 1) + i, b = a + 1, c = a + n + 1, d = c + 1;
        idx[t++] = a; idx[t++] = b; idx[t++] = c;
        idx[t++] = b; idx[t++] = d; idx[t++] = c;
      }
    }
    final flick = 1.0 + .09 * math.sin(w * 4) + .06 * math.sin(w * 9 + 1.3) + .04 * math.sin(w * 15 + .4);
    final paint = Paint()
      ..isAntiAlias = true
      ..filterQuality = FilterQuality.medium
      ..colorFilter = ColorFilter.matrix(<double>[
        flick, 0, 0, 0, 0,
        0, flick, 0, 0, 0,
        0, 0, flick, 0, 0,
        0, 0, 0, 1, 0,
      ])
      ..shader = ui.ImageShader(img, TileMode.clamp, TileMode.clamp, Matrix4.identity().storage, filterQuality: FilterQuality.medium);
    final vertices = ui.Vertices.raw(ui.VertexMode.triangles, pos, textureCoordinates: tex, indices: idx);
    canvas.drawVertices(vertices, BlendMode.srcOver, paint);
    vertices.dispose();
  }

  @override
  bool shouldRepaint(covariant _WarpPainter old) => old.img != img || old.kind != kind;
}


/// Bolhas de coração: sobem balançando, crescem um pouco e estouram
/// (anel que abre + faíscas). Loop perfeito a cada ciclo do controlador (7 s).
class _HeartBubblePainter extends CustomPainter {
  _HeartBubblePainter(this.anim, this.phase) : super(repaint: anim);
  final Animation<double> anim;
  final double phase;
  static const int _count = 7;

  double _rnd(int a, int b) {
    final x = math.sin(a * 127.1 + b * 311.7 + 17.3) * 43758.5453;
    return x - x.floorToDouble();
  }

  Path _heart(Offset c, double s) {
    final p = Path();
    p.moveTo(c.dx, c.dy + s * .85);
    p.cubicTo(c.dx - s * 1.5, c.dy - s * .1, c.dx - s * .85, c.dy - s * 1.1, c.dx, c.dy - s * .4);
    p.cubicTo(c.dx + s * .85, c.dy - s * 1.1, c.dx + s * 1.5, c.dy - s * .1, c.dx, c.dy + s * .85);
    p.close();
    return p;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final box = size.width;
    final c = Offset(box / 2, box / 2);
    final ringR = box * .40;
    final t = anim.value;
    for (var i = 0; i < _count; i++) {
      final f = t * 2 + i / _count;
      final cycle = f.floor();
      final p = f - cycle; // 0..1 vida da bolha
      final seed = (cycle % 2) * 31 + i;
      // nasce na metade de baixo do aro, mais para os lados
      final side = _rnd(seed, 1) < .5 ? -1.0 : 1.0;
      final ang = (.12 + .30 * _rnd(seed, 2)) * math.pi; // 0.12π..0.42π a partir do eixo x
      final start = Offset(c.dx + side * math.cos(ang) * ringR, c.dy + math.sin(ang) * ringR);
      final rise = box * (.38 + .14 * _rnd(seed, 3));
      final life = .80; // depois disso estoura
      final base = box * (.035 + .02 * _rnd(seed, 4));
      if (p < life) {
        final q = p / life;
        final e = Curves.easeOut.transform(q);
        final pos = Offset(
          start.dx + math.sin(q * math.pi * 2 * (1 + _rnd(seed, 5)) + seed) * box * .035 + side * box * .05 * q,
          start.dy - rise * e);
        final grow = base * (.55 + .55 * Curves.easeOut.transform((q * 3).clamp(0.0, 1.0)));
        final fade = q < .12 ? q / .12 : 1.0;
        // coração com brilho rosa
        final glow = Paint()..color = const Color(0xFFFF5FB8).withOpacity(.55 * fade)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
        canvas.drawPath(_heart(pos, grow), glow);
        final fill = Paint()..shader = ui.Gradient.linear(pos - Offset(0, grow), pos + Offset(0, grow),
            [Color.lerp(const Color(0xFFFFB6DD), Colors.white, .2)!.withOpacity(.95 * fade), const Color(0xFFFF2EA6).withOpacity(.95 * fade)]);
        canvas.drawPath(_heart(pos, grow), fill);
        // bolha em volta
        final br = grow * 1.9;
        canvas.drawCircle(pos, br, Paint()..color = Colors.white.withOpacity(.10 * fade));
        canvas.drawCircle(pos, br, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.1..color = Colors.white.withOpacity(.65 * fade));
        // reflexo
        canvas.drawCircle(pos + Offset(-br * .4, -br * .45), br * .16, Paint()..color = Colors.white.withOpacity(.9 * fade));
      } else {
        // estouro
        final q = (p - life) / (1 - life); // 0..1
        final qe = Curves.easeOutCubic.transform(q);
        final endPos = Offset(start.dx + side * box * .05 + math.sin(math.pi * 2 * (1 + _rnd(seed, 5)) + seed) * box * .035 * 0, start.dy - rise);
        final br = base * 1.9 * (1 + .9 * qe);
        final op = (1 - q).clamp(0.0, 1.0);
        canvas.drawCircle(endPos, br, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.6 * (1 - q) + .3..color = Colors.white.withOpacity(.85 * op));
        for (var k = 0; k < 7; k++) {
          final a = k / 7 * math.pi * 2 + _rnd(seed, 9) * 2;
          final d = br * (.9 + 1.6 * qe);
          final pp = endPos + Offset(math.cos(a), math.sin(a)) * d;
          if (k.isEven) {
            canvas.drawPath(_heart(pp, base * .38 * (1 - .5 * q)), Paint()..color = const Color(0xFFFF5FB8).withOpacity(.9 * op));
          } else {
            canvas.drawCircle(pp, base * .16 * (1 - q), Paint()..color = Colors.white.withOpacity(.9 * op));
          }
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant _HeartBubblePainter old) => false;
}
