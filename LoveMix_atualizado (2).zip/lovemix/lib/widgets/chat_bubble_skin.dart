import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

import '../data/chat_bubble_catalog.dart';

/// Carrega cada arte de bolha uma única vez e guarda em memória.
class _BubbleImages {
  static final Map<String, ui.Image> _ready = {};
  static final Map<String, Future<ui.Image?>> _pending = {};

  static ui.Image? peek(String asset) => _ready[asset];

  static Future<ui.Image?> load(String asset) {
    final done = _ready[asset];
    if (done != null) return Future.value(done);
    return _pending.putIfAbsent(asset, () async {
      try {
        final data = await rootBundle.load(asset);
        final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
        final frame = await codec.getNextFrame();
        _ready[asset] = frame.image;
        return frame.image;
      } catch (_) {
        _pending.remove(asset);
        return null;
      }
    });
  }
}

/// Moldura de mensagem com a arte de uma bolha comprada na loja.
///
/// [pxPerDp] diz quantos pixels da arte cabem em 1 pixel lógico: 3 deixa a
/// bolha com ~208 de largura (chat), 4.5 deixa menor (comentários de live).
/// A arte é esticada em 9 partes, então cresce com mensagens longas sem
/// deformar coroas, laços, borboletas etc. nos cantos.
class ChatBubbleSkinBox extends StatefulWidget {
  const ChatBubbleSkinBox({
    super.key,
    required this.skin,
    required this.child,
    this.pxPerDp = 3.0,
    this.maxWidth,
  });

  final ChatBubbleSkin skin;
  final Widget child;
  final double pxPerDp;
  final double? maxWidth;

  @override
  State<ChatBubbleSkinBox> createState() => _ChatBubbleSkinBoxState();
}

class _ChatBubbleSkinBoxState extends State<ChatBubbleSkinBox> {
  ui.Image? _img;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant ChatBubbleSkinBox old) {
    super.didUpdateWidget(old);
    if (old.skin.asset != widget.skin.asset) {
      _img = _BubbleImages.peek(widget.skin.asset);
      _load();
    }
  }

  Future<void> _load() async {
    final cached = _BubbleImages.peek(widget.skin.asset);
    if (cached != null) {
      _img = cached;
      return;
    }
    final asset = widget.skin.asset;
    final img = await _BubbleImages.load(asset);
    if (mounted && img != null && asset == widget.skin.asset) setState(() => _img = img);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.skin;
    final k = widget.pxPerDp;
    final pad = s.padding(k);
    final minW = (s.centerLeft + (s.imageW - s.centerRight)) / k + 8;
    final minH = s.imageH / k;
    final minInnerH = (minH - pad.vertical).clamp(0.0, double.infinity).toDouble();
    final maxW = widget.maxWidth == null ? double.infinity : (widget.maxWidth! < minW ? minW : widget.maxWidth!);
    return ConstrainedBox(
      constraints: BoxConstraints(minWidth: minW, maxWidth: maxW, minHeight: minH),
      child: CustomPaint(
        painter: _NinePatchPainter(_img, s, k),
        child: Padding(
          padding: pad,
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: minInnerH),
            child: Align(alignment: Alignment.centerLeft, widthFactor: 1, child: widget.child),
          ),
        ),
      ),
    );
  }
}

class _NinePatchPainter extends CustomPainter {
  _NinePatchPainter(this.image, this.skin, this.k);
  final ui.Image? image;
  final ChatBubbleSkin skin;
  final double k;

  @override
  void paint(Canvas canvas, Size size) {
    final img = image;
    if (img == null) {
      // Enquanto a arte carrega, desenha uma bolha simples para o layout não pular.
      final r = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(24));
      canvas.drawRRect(r, Paint()..color = const Color(0x99120A1E));
      canvas.drawRRect(
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = const Color(0xFFB45CFF),
      );
      return;
    }
    canvas.save();
    canvas.scale(1 / k);
    final dst = Rect.fromLTWH(0, 0, size.width * k, size.height * k);
    canvas.drawImageNine(
      img,
      skin.center,
      dst,
      Paint()
        ..filterQuality = FilterQuality.medium
        ..isAntiAlias = true,
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _NinePatchPainter old) => old.image != image || old.skin.id != skin.id || old.k != k;
}
