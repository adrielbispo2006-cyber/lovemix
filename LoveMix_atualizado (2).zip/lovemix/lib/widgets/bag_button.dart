import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../data/gift_catalog.dart';
import '../services/data_service.dart';

const _pink = Color(0xFFFF2DAB);
const _violet = Color(0xFFB62CFF);
const _panel = Color(0xFF0B0314);

/// Bolsinha pequena no canto: presentes e alianças recebidos.
class BagButton extends StatelessWidget {
  const BagButton({super.key});

  @override
  Widget build(BuildContext context) {
    final me = FirebaseAuth.instance.currentUser?.uid;
    if (me == null) return const SizedBox.shrink();
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('alliances')
          .where('members', arrayContains: me)
          .snapshots(),
      builder: (context, snap) {
        final docs = snap.data?.docs ?? const [];
        var badge = 0;
        for (final d in docs) {
          final a = d.data();
          if (a['invitedUid'] == me && a['invitationStatus'] == 'pending') badge++;
          if (DataService.allianceIsKeptByMe(a, me) &&
              !DataService.allianceIsAlreadyAForward(a) &&
              !DataService.allianceWasForwarded(d.id, docs)) {
            badge++;
          }
        }
        return Stack(clipBehavior: Clip.none, children: [
          Material(
            color: Colors.black.withOpacity(.45),
            shape: const CircleBorder(side: BorderSide(color: _violet, width: 1.2)),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: _panel,
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
                builder: (_) => const _BagSheet(),
              ),
              child: const Padding(
                padding: EdgeInsets.all(7),
                child: Icon(Icons.shopping_bag_outlined, size: 20, color: Colors.white),
              ),
            ),
          ),
          if (badge > 0)
            Positioned(
              right: -2,
              top: -2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(color: _pink, borderRadius: BorderRadius.circular(10)),
                child: Text('$badge',
                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Colors.white)),
              ),
            ),
        ]);
      },
    );
  }
}

class _BagSheet extends StatefulWidget {
  const _BagSheet();
  @override
  State<_BagSheet> createState() => _BagSheetState();
}

class _BagSheetState extends State<_BagSheet> {
  int _tab = 0;
  String get _me => FirebaseAuth.instance.currentUser?.uid ?? '';

  void _snack(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  String _err(Object e) => e.toString().replaceFirst('Exception: ', '');

  Widget _ringImage(String ringId) {
    final ring = kAllianceRings.firstWhere((r) => r['id'] == ringId, orElse: () => const {});
    final asset = ring['asset']?.toString();
    final emoji = (ring['emoji'] ?? '💍').toString();
    if (asset == null) return Text(emoji, style: const TextStyle(fontSize: 30));
    return Image.asset(asset, width: 42, height: 42,
        errorBuilder: (_, __, ___) => Text(emoji, style: const TextStyle(fontSize: 30)));
  }

  Future<void> _respond(String id, bool accept) async {
    try {
      await DataService.instance.respondAlliance(id, accept);
      _snack(accept
          ? 'Aliança aceita 💍'
          : 'Você recusou. A aliança ficou guardada na sua bolsinha.');
    } catch (e) {
      _snack(_err(e));
    }
  }

  Future<void> _send(String id) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        backgroundColor: const Color(0xFF171022),
        title: const Text('Enviar aliança guardada'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Digite o ID da pessoa. Só dá para enviar esta aliança UMA vez.',
              style: TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 12),
          TextField(
              controller: c,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(hintText: 'ID (8 letras/números)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancelar')),
          TextButton(
              onPressed: () => Navigator.pop(d, true),
              child: const Text('Enviar', style: TextStyle(color: _pink))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await DataService.instance.forwardKeptRing(id, c.text);
      _snack('Aliança enviada 💍');
    } catch (e) {
      _snack(_err(e));
    }
  }

  Widget _tabBtn(int i, String label) => Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _tab = i),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: _tab == i ? _violet.withOpacity(.35) : Colors.transparent,
              border: Border.all(color: _tab == i ? _pink : Colors.white24),
            ),
            child: Center(
                child: Text(label,
                    style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.white))),
          ),
        ),
      );

  Widget _gifts() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: DataService.instance.myReceivedGifts(),
      builder: (context, snap) {
        if (snap.hasError) return _empty('Não foi possível carregar os presentes.');
        final docs = snap.data?.docs ?? const [];
        if (docs.isEmpty) return _empty('Nenhum presente recebido ainda 🎁');
        return ListView.separated(
          shrinkWrap: true,
          itemCount: docs.length,
          separatorBuilder: (_, __) => const Divider(height: 1, color: Colors.white12),
          itemBuilder: (_, i) {
            final g = docs[i].data();
            return ListTile(
              leading: Text((g['emoji'] ?? '🎁').toString(), style: const TextStyle(fontSize: 28)),
              title: Text((g['giftName'] ?? 'Presente').toString(),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('de ${(g['senderName'] ?? 'alguém').toString()}',
                  style: const TextStyle(color: Colors.white60)),
            );
          },
        );
      },
    );
  }

  Widget _rings() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('alliances')
          .where('members', arrayContains: _me)
          .snapshots(),
      builder: (context, snap) {
        if (snap.hasError) return _empty('Não foi possível carregar as alianças.');
        final docs = snap.data?.docs ?? const [];
        final pending = docs
            .where((d) => d.data()['invitedUid'] == _me && d.data()['invitationStatus'] == 'pending')
            .toList();
        final kept = docs.where((d) => DataService.allianceIsKeptByMe(d.data(), _me)).toList();
        if (pending.isEmpty && kept.isEmpty) return _empty('Nenhuma aliança por aqui 💍');
        final children = <Widget>[];
        for (final d in pending) {
          final a = d.data();
          children.add(_ringTile(
            a,
            subtitle: 'Convite de ${(a['creatorName'] ?? 'alguém').toString()}',
            actions: Row(mainAxisSize: MainAxisSize.min, children: [
              TextButton(onPressed: () => _respond(d.id, false), child: const Text('Recusar')),
              TextButton(
                  onPressed: () => _respond(d.id, true),
                  child: const Text('Aceitar', style: TextStyle(color: _pink))),
            ]),
          ));
        }
        for (final d in kept) {
          final a = d.data();
          final sent = DataService.allianceWasForwarded(d.id, docs);
          final isForward = DataService.allianceIsAlreadyAForward(a);
          final label = sent
              ? 'Já enviada'
              : isForward
                  ? 'Não pode reenviar'
                  : null;
          children.add(_ringTile(
            a,
            subtitle: 'Guardada • de ${(a['creatorName'] ?? 'alguém').toString()}',
            actions: label != null
                ? Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12))
                : TextButton(
                    onPressed: () => _send(d.id),
                    child: const Text('Enviar', style: TextStyle(color: _pink))),
          ));
        }
        return ListView(shrinkWrap: true, children: children);
      },
    );
  }

  Widget _ringTile(Map<String, dynamic> a, {required String subtitle, required Widget actions}) => ListTile(
        leading: _ringImage((a['ringGiftId'] ?? '').toString()),
        title: Text((a['ringGiftName'] ?? 'Aliança').toString(),
            style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        trailing: actions,
      );

  Widget _empty(String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(child: Text(t, style: const TextStyle(color: Colors.white54))),
      );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .72),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(4))),
            const SizedBox(height: 12),
            const Text('Minha bolsinha',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.white)),
            const SizedBox(height: 12),
            Row(children: [_tabBtn(0, '🎁 Presentes'), const SizedBox(width: 8), _tabBtn(1, '💍 Alianças')]),
            const SizedBox(height: 8),
            Flexible(child: _tab == 0 ? _gifts() : _rings()),
          ]),
        ),
      ),
    );
  }
}
