import 'dart:async';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

/// Formata milissegundos como 0:07, 1:23...
String formatVoiceDuration(int ms) {
  final s = (ms / 1000).round().clamp(0, 5999);
  return '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';
}

/// Só um áudio toca por vez no chat: ao dar play em outro, o anterior pausa.
class _VoiceNow {
  static AudioPlayer? playing;
}

/// Bolha de mensagem de voz: botão play/pause, barra de progresso e tempo.
class VoiceMessagePlayer extends StatefulWidget {
  const VoiceMessagePlayer({
    super.key,
    required this.url,
    required this.durationMs,
    this.accent = const Color(0xFFFF2DAB),
  });

  final String url;
  final int durationMs;
  final Color accent;

  @override
  State<VoiceMessagePlayer> createState() => _VoiceMessagePlayerState();
}

class _VoiceMessagePlayerState extends State<VoiceMessagePlayer> {
  AudioPlayer? _player;
  StreamSubscription<PlayerState>? _stateSub;
  StreamSubscription<Duration>? _posSub;
  bool _loading = false;
  bool _playing = false;
  bool _error = false;
  Duration _pos = Duration.zero;
  Duration? _total;

  Future<AudioPlayer> _ensure() async {
    final existing = _player;
    if (existing != null) return existing;
    final p = AudioPlayer();
    _player = p;
    _stateSub = p.playerStateStream.listen((s) {
      if (!mounted) return;
      if (s.processingState == ProcessingState.completed) {
        p.pause();
        p.seek(Duration.zero);
        setState(() { _playing = false; _pos = Duration.zero; });
        return;
      }
      setState(() => _playing = s.playing);
    });
    _posSub = p.positionStream.listen((d) { if (mounted) setState(() => _pos = d); });
    final d = await p.setUrl(widget.url);
    _total = d;
    return p;
  }

  Future<void> _toggle() async {
    if (_loading) return;
    try {
      if (_player == null) setState(() { _loading = true; _error = false; });
      final p = await _ensure();
      if (mounted) setState(() => _loading = false);
      if (p.playing) {
        await p.pause();
      } else {
        final other = _VoiceNow.playing;
        if (other != null && other != p) { try { await other.pause(); } catch (_) {} }
        _VoiceNow.playing = p;
        unawaited(p.play());
      }
    } catch (_) {
      await _disposePlayer();
      if (mounted) setState(() { _loading = false; _error = true; });
    }
  }

  Future<void> _disposePlayer() async {
    await _stateSub?.cancel();
    await _posSub?.cancel();
    final p = _player;
    _player = null;
    if (_VoiceNow.playing == p) _VoiceNow.playing = null;
    try { await p?.dispose(); } catch (_) {}
  }

  @override
  void dispose() {
    _disposePlayer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final totalMs = (_total?.inMilliseconds ?? 0) > 0 ? _total!.inMilliseconds : widget.durationMs;
    final progress = totalMs <= 0 ? 0.0 : (_pos.inMilliseconds / totalMs).clamp(0.0, 1.0);
    final shownMs = _playing || _pos > Duration.zero ? _pos.inMilliseconds : totalMs;
    return SizedBox(
      width: 210,
      child: Row(children: [
        GestureDetector(
          onTap: _toggle,
          child: Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(colors: [widget.accent, widget.accent.withOpacity(.65)]),
              boxShadow: [BoxShadow(color: widget.accent.withOpacity(.55), blurRadius: 10)],
            ),
            child: _loading
                ? const Padding(padding: EdgeInsets.all(11), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Icon(_error ? Icons.refresh_rounded : (_playing ? Icons.pause_rounded : Icons.play_arrow_rounded), color: Colors.white, size: 28),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          _Wave(progress: progress, color: widget.accent),
          const SizedBox(height: 4),
          Row(children: [
            Icon(Icons.mic_rounded, size: 13, color: widget.accent),
            const SizedBox(width: 3),
            Text(_error ? 'Toque para tentar de novo' : formatVoiceDuration(shownMs),
                style: const TextStyle(fontSize: 11.5, color: Colors.white70)),
          ]),
        ])),
      ]),
    );
  }
}

/// Barrinhas de "onda sonora" que vão sendo preenchidas conforme o áudio toca.
class _Wave extends StatelessWidget {
  const _Wave({required this.progress, required this.color});
  final double progress;
  final Color color;
  static const _heights = [6.0, 10, 14, 9, 18, 12, 7, 16, 20, 11, 8, 15, 19, 10, 6, 13, 17, 9, 12, 7, 15, 10, 6, 11];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 22,
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        for (var i = 0; i < _heights.length; i++)
          Expanded(child: Center(child: Container(
            width: 3, height: _heights[i].toDouble(),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(2),
              color: (i + 0.5) / _heights.length <= progress ? color : Colors.white30,
            ),
          ))),
      ]),
    );
  }
}
