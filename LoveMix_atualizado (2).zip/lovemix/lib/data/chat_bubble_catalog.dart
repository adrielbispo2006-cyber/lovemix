import 'dart:ui' show Rect;
import 'package:flutter/painting.dart' show Color, EdgeInsets;

/// Bolhas de chat vendidas na loja. Cada bolha é uma arte PNG/WebP transparente
/// desenhada em 9 partes: os cantos (coroas, laços, borboletas...) mantêm o
/// tamanho e o meio estica conforme o tamanho da mensagem.
class ChatBubbleSkin {
  const ChatBubbleSkin({
    required this.id,
    required this.name,
    required this.description,
    required this.emoji,
    required this.cost,
    required this.imageW,
    required this.imageH,
    required this.centerLeft,
    required this.centerTop,
    required this.centerRight,
    required this.centerBottom,
    required this.padLeft,
    required this.padTop,
    required this.padRight,
    required this.padBottom,
    required this.textColor,
  });

  final String id;
  final String name;
  final String description;
  final String emoji;
  final int cost;
  final int imageW, imageH;
  final int centerLeft, centerTop, centerRight, centerBottom;
  final int padLeft, padTop, padRight, padBottom;
  final Color textColor;

  String get asset => 'assets/chat_bubbles/$id.webp';

  /// Área esticável da imagem, em pixels da própria imagem.
  Rect get center => Rect.fromLTRB(centerLeft.toDouble(), centerTop.toDouble(), centerRight.toDouble(), centerBottom.toDouble());

  /// Espaço entre a borda da arte e o texto, em pixels lógicos.
  EdgeInsets padding(double pxPerDp) => EdgeInsets.fromLTRB(
      padLeft / pxPerDp, padTop / pxPerDp, padRight / pxPerDp, padBottom / pxPerDp);
}

/// Id usado quando a pessoa não tem (ou removeu) a bolha: o chat usa o visual padrão.
const String kDefaultChatBubble = 'none';

const List<ChatBubbleSkin> chatBubbleCatalog = [
  ChatBubbleSkin(id: 'realeza_roxa', name: 'Realeza Roxa', description: 'Coroa de prata, cristais e corações roxos', emoji: '💜', cost: 900,
    imageW: 626, imageH: 222, centerLeft: 267, centerTop: 132, centerRight: 430, centerBottom: 140,
    padLeft: 156, padTop: 92, padRight: 84, padBottom: 42, textColor: Color(0xFFFBFAFC)),
  ChatBubbleSkin(id: 'laco_rosa', name: 'Laço Rosa', description: 'Laço de cetim rosa com corações brilhantes', emoji: '🎀', cost: 500,
    imageW: 619, imageH: 212, centerLeft: 291, centerTop: 123, centerRight: 435, centerBottom: 131,
    padLeft: 193, padTop: 85, padRight: 86, padBottom: 43, textColor: Color(0xFFFCFAFB)),
  ChatBubbleSkin(id: 'borboleta_azul', name: 'Borboleta Azul', description: 'Borboletas azuis e coroa de cristal', emoji: '🦋', cost: 800,
    imageW: 626, imageH: 212, centerLeft: 295, centerTop: 130, centerRight: 437, centerBottom: 138,
    padLeft: 199, padTop: 92, padRight: 92, padBottom: 36, textColor: Color(0xFFFAFAFC)),
  ChatBubbleSkin(id: 'estrela_dourada', name: 'Estrela Dourada', description: 'Estrela cintilante com fitas de ouro', emoji: '⭐', cost: 700,
    imageW: 622, imageH: 202, centerLeft: 300, centerTop: 116, centerRight: 448, centerBottom: 124,
    padLeft: 200, padTop: 80, padRight: 73, padBottom: 42, textColor: Color(0xFFFBFAFA)),
  ChatBubbleSkin(id: 'coracao_rebelde', name: 'Coração Rebelde', description: 'Coração com chifres e correntes roxas', emoji: '😈', cost: 1000,
    imageW: 622, imageH: 193, centerLeft: 307, centerTop: 109, centerRight: 452, centerBottom: 117,
    padLeft: 209, padTop: 75, padRight: 71, padBottom: 42, textColor: Color(0xFFFBFAFB)),
  ChatBubbleSkin(id: 'gatinha_rosa', name: 'Gatinha Rosa', description: 'Gatinha piscando com coração pink', emoji: '🐱', cost: 600,
    imageW: 617, imageH: 207, centerLeft: 328, centerTop: 110, centerRight: 470, centerBottom: 118,
    padLeft: 232, padTop: 73, padRight: 50, padBottom: 52, textColor: Color(0xFFFCFAFC)),
  ChatBubbleSkin(id: 'coroa_dourada', name: 'Coroa Dourada', description: 'Coroa real com corações de ouro', emoji: '👑', cost: 1200,
    imageW: 612, imageH: 230, centerLeft: 251, centerTop: 139, centerRight: 402, centerBottom: 147,
    padLeft: 148, padTop: 97, padRight: 106, padBottom: 41, textColor: Color(0xFFFBFAFA)),
  ChatBubbleSkin(id: 'rosa_vermelha', name: 'Rosa Vermelha', description: 'Rosas vermelhas e pétalas ao vento', emoji: '🌹', cost: 800,
    imageW: 619, imageH: 206, centerLeft: 269, centerTop: 117, centerRight: 419, centerBottom: 125,
    padLeft: 166, padTop: 80, padRight: 96, padBottom: 44, textColor: Color(0xFFFBFAFB)),
  ChatBubbleSkin(id: 'gatinho_preto', name: 'Gatinho Preto', description: 'Gatinho preto fofo com patinhas roxas', emoji: '🐱', cost: 700,
    imageW: 619, imageH: 205, centerLeft: 282, centerTop: 129, centerRight: 428, centerBottom: 137,
    padLeft: 182, padTop: 92, padRight: 90, padBottom: 31, textColor: Color(0xFFFBFAFB)),
  ChatBubbleSkin(id: 'nuvem_arco_iris', name: 'Nuvem Arco-Íris', description: 'Nuvenzinhas, estrelas e arco-íris', emoji: '☁️', cost: 900,
    imageW: 618, imageH: 215, centerLeft: 265, centerTop: 127, centerRight: 411, centerBottom: 135,
    padLeft: 167, padTop: 88, padRight: 108, padBottom: 41, textColor: Color(0xFFFAFAFC)),
  ChatBubbleSkin(id: 'rosa_verde', name: 'Rosa Verde', description: 'Rosa neon verde com folhas e corações', emoji: '💚', cost: 800,
    imageW: 618, imageH: 187, centerLeft: 283, centerTop: 98, centerRight: 424, centerBottom: 106,
    padLeft: 187, padTop: 65, padRight: 97, padBottom: 48, textColor: Color(0xFFFBFBFB)),
  ChatBubbleSkin(id: 'coracoes_rubi', name: 'Corações Rubi', description: 'Corações de rubi com rosas vermelhas', emoji: '❤️', cost: 700,
    imageW: 615, imageH: 201, centerLeft: 292, centerTop: 112, centerRight: 438, centerBottom: 120,
    padLeft: 194, padTop: 76, padRight: 78, padBottom: 45, textColor: Color(0xFFFBFAFA)),
  ChatBubbleSkin(id: 'principe_violeta', name: 'Príncipe Violeta', description: 'Coroa dourada e coração violeta', emoji: '👑', cost: 600,
    imageW: 615, imageH: 237, centerLeft: 257, centerTop: 137, centerRight: 416, centerBottom: 145,
    padLeft: 149, padTop: 94, padRight: 90, padBottom: 49, textColor: Color(0xFFFBFAFC)),
  ChatBubbleSkin(id: 'ouro_real', name: 'Ouro Real', description: 'Coroa, diamantes e coração de ouro', emoji: '💛', cost: 1500,
    imageW: 613, imageH: 213, centerLeft: 255, centerTop: 102, centerRight: 415, centerBottom: 110,
    padLeft: 146, padTop: 64, padRight: 88, padBottom: 65, textColor: Color(0xFFFCFAE5)),
  ChatBubbleSkin(id: 'fita_vermelha', name: 'Fita Vermelha', description: 'Fitas vermelhas com corações de rubi', emoji: '🎀', cost: 600,
    imageW: 620, imageH: 201, centerLeft: 267, centerTop: 120, centerRight: 418, centerBottom: 128,
    padLeft: 164, padTop: 84, padRight: 98, padBottom: 37, textColor: Color(0xFFFCFAFA)),
  ChatBubbleSkin(id: 'rosas_brancas', name: 'Rosas Brancas', description: 'Rosas brancas, prata e laço rosa', emoji: '🤍', cost: 1000,
    imageW: 618, imageH: 198, centerLeft: 275, centerTop: 108, centerRight: 425, centerBottom: 116,
    padLeft: 174, padTop: 73, padRight: 91, padBottom: 47, textColor: Color(0xFF1E1E26)),
  ChatBubbleSkin(id: 'gatinha_branca', name: 'Gatinha Branca', description: 'Gatinha branca com laço e corações', emoji: '🐱', cost: 650,
    imageW: 610, imageH: 193, centerLeft: 300, centerTop: 114, centerRight: 436, centerBottom: 122,
    padLeft: 208, padTop: 80, padRight: 82, padBottom: 37, textColor: Color(0xFF6A1B7A)),
  ChatBubbleSkin(id: 'arco_iris_neon', name: 'Arco-Íris Neon', description: 'Arco-íris neon e nuvens sorridentes', emoji: '🌈', cost: 1100,
    imageW: 615, imageH: 193, centerLeft: 249, centerTop: 109, centerRight: 395, centerBottom: 117,
    padLeft: 149, padTop: 75, padRight: 119, padBottom: 42, textColor: Color(0xFFFAFAFC)),
  ChatBubbleSkin(id: 'coracao_laco', name: 'Coração e Laço', description: 'Coração pink gigante com laço', emoji: '💗', cost: 500,
    imageW: 602, imageH: 231, centerLeft: 261, centerTop: 141, centerRight: 409, centerBottom: 149,
    padLeft: 160, padTop: 99, padRight: 91, padBottom: 40, textColor: Color(0xFFFDFAFB)),
  ChatBubbleSkin(id: 'gelo_diamante', name: 'Gelo e Diamante', description: 'Coroa de gelo, flocos e diamantes', emoji: '💎', cost: 1300,
    imageW: 615, imageH: 217, centerLeft: 265, centerTop: 126, centerRight: 416, centerBottom: 134,
    padLeft: 162, padTop: 87, padRight: 95, padBottom: 44, textColor: Color(0xFFF2FBFC)),
  ChatBubbleSkin(id: 'rei_gamer', name: 'Rei Gamer', description: 'Coroa verde neon com controle de jogo', emoji: '🎮', cost: 1000,
    imageW: 607, imageH: 203, centerLeft: 240, centerTop: 119, centerRight: 392, centerBottom: 127,
    padLeft: 137, padTop: 83, padRight: 111, padBottom: 40, textColor: Color(0xFFF9FCFA)),
  ChatBubbleSkin(id: 'borboletas_laranja', name: 'Borboletas Laranja', description: 'Borboletas e flores em tons de âmbar', emoji: '🦋', cost: 900,
    imageW: 602, imageH: 196, centerLeft: 248, centerTop: 108, centerRight: 400, centerBottom: 116,
    padLeft: 144, padTop: 73, padRight: 97, padBottom: 45, textColor: Color(0xFFFBFAED)),
  ChatBubbleSkin(id: 'chamas_roxas', name: 'Chamas Roxas', description: 'Coroa sombria com chamas violeta', emoji: '🔥', cost: 1100,
    imageW: 598, imageH: 197, centerLeft: 256, centerTop: 118, centerRight: 397, centerBottom: 126,
    padLeft: 161, padTop: 83, padRight: 105, padBottom: 36, textColor: Color(0xFFFAFAFB)),
  ChatBubbleSkin(id: 'borboletas_lilas', name: 'Borboletas Lilás', description: 'Borboletas e rosa roxa luminosas', emoji: '🦋', cost: 1000,
    imageW: 600, imageH: 193, centerLeft: 246, centerTop: 107, centerRight: 382, centerBottom: 115,
    padLeft: 154, padTop: 73, padRight: 125, padBottom: 44, textColor: Color(0xFFFBFAFC)),
  // ── Coleção Neon Premium (20 bolhas novas) ──
  ChatBubbleSkin(id: 'coroa_ametista', name: 'Coroa de Ametista', description: 'Coroa dourada, coração de ametista e rosas roxas', emoji: '👑', cost: 1500,
    imageW: 620, imageH: 209, centerLeft: 237, centerTop: 106, centerRight: 367, centerBottom: 114,
    padLeft: 232, padTop: 81, padRight: 140, padBottom: 69, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'anjo_aureola', name: 'Anjo com Auréola', description: 'Asas de anjo, auréola dourada e coração rubi', emoji: '😇', cost: 1400,
    imageW: 620, imageH: 189, centerLeft: 365, centerTop: 102, centerRight: 450, centerBottom: 110,
    padLeft: 360, padTop: 79, padRight: 163, padBottom: 55, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'gatinho_real', name: 'Gatinho Real', description: 'Gatinho preto coroado com laço e patinha', emoji: '🐱', cost: 1100,
    imageW: 620, imageH: 213, centerLeft: 344, centerTop: 115, centerRight: 474, centerBottom: 123,
    padLeft: 208, padTop: 83, padRight: 138, padBottom: 57, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'rosa_de_ouro', name: 'Rosa de Ouro', description: 'Rosa vermelha com folhas de ouro e coração', emoji: '🌹', cost: 1300,
    imageW: 620, imageH: 174, centerLeft: 308, centerTop: 85, centerRight: 438, centerBottom: 93,
    padLeft: 238, padTop: 49, padRight: 123, padBottom: 44, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'lua_encantada', name: 'Lua Encantada', description: 'Lua dourada, estrelas e nuvens lilás', emoji: '🌙', cost: 1200,
    imageW: 620, imageH: 191, centerLeft: 237, centerTop: 99, centerRight: 367, centerBottom: 107,
    padLeft: 225, padTop: 72, padRight: 150, padBottom: 57, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'laco_apaixonado', name: 'Laço Apaixonado', description: 'Coração neon e grande laço pink com joia', emoji: '🎀', cost: 1100,
    imageW: 620, imageH: 206, centerLeft: 233, centerTop: 102, centerRight: 363, centerBottom: 110,
    padLeft: 197, padTop: 76, padRight: 250, padBottom: 69, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'rosa_negra_coroa', name: 'Rosa Negra Coroada', description: 'Coroa dourada, rosa negra e pérolas', emoji: '🖤', cost: 1600,
    imageW: 620, imageH: 196, centerLeft: 297, centerTop: 90, centerRight: 427, centerBottom: 98,
    padLeft: 262, padTop: 54, padRight: 133, padBottom: 61, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'jardim_borboletas', name: 'Jardim de Borboletas', description: 'Borboleta neon com rosas roxas e pink', emoji: '🦋', cost: 1300,
    imageW: 620, imageH: 193, centerLeft: 251, centerTop: 99, centerRight: 381, centerBottom: 107,
    padLeft: 238, padTop: 70, padRight: 172, padBottom: 56, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'diamante_cosmico', name: 'Diamante Cósmico', description: 'Diamante com anel de ouro e coroa real', emoji: '💎', cost: 1800,
    imageW: 620, imageH: 169, centerLeft: 347, centerTop: 81, centerRight: 477, centerBottom: 89,
    padLeft: 258, padTop: 54, padRight: 88, padBottom: 52, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'batida_coracao', name: 'Batida do Coração', description: 'Corações pink e roxo com batimento neon', emoji: '💓', cost: 1000,
    imageW: 620, imageH: 165, centerLeft: 256, centerTop: 76, centerRight: 386, centerBottom: 84,
    padLeft: 251, padTop: 49, padRight: 223, padBottom: 54, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'coracao_coroado', name: 'Coração Coroado', description: 'Coroa de ouro sobre coração de cristal roxo', emoji: '👑', cost: 1300,
    imageW: 620, imageH: 207, centerLeft: 283, centerTop: 102, centerRight: 413, centerBottom: 110,
    padLeft: 208, padTop: 57, padRight: 109, padBottom: 51, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'anjo_apaixonado', name: 'Anjo Apaixonado', description: 'Asas brancas, coroa e coração pink', emoji: '😇', cost: 1200,
    imageW: 620, imageH: 219, centerLeft: 304, centerTop: 99, centerRight: 434, centerBottom: 107,
    padLeft: 217, padTop: 65, padRight: 108, padBottom: 77, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'gatinho_neon', name: 'Gatinho Neon', description: 'Gatinho preto espiando na bolha pink', emoji: '🐱', cost: 1000,
    imageW: 620, imageH: 221, centerLeft: 285, centerTop: 126, centerRight: 415, centerBottom: 134,
    padLeft: 146, padTop: 102, padRight: 95, padBottom: 62, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'majestade_dourada', name: 'Majestade Dourada', description: 'Coroa, coração de ametista e fitas de ouro', emoji: '💛', cost: 1500,
    imageW: 620, imageH: 179, centerLeft: 288, centerTop: 83, centerRight: 418, centerBottom: 91,
    padLeft: 206, padTop: 41, padRight: 124, padBottom: 46, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'anjo_violeta', name: 'Anjo Violeta', description: 'Asas de anjo e coração violeta coroado', emoji: '💜', cost: 1200,
    imageW: 620, imageH: 162, centerLeft: 340, centerTop: 81, centerRight: 470, centerBottom: 89,
    padLeft: 226, padTop: 50, padRight: 94, padBottom: 41, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'doce_paixao', name: 'Doce Paixão', description: 'Corações pink brilhantes com laço rosa', emoji: '💗', cost: 900,
    imageW: 620, imageH: 215, centerLeft: 245, centerTop: 98, centerRight: 375, centerBottom: 106,
    padLeft: 203, padTop: 64, padRight: 171, padBottom: 74, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'rosa_eterna', name: 'Rosa Eterna', description: 'Rosa vermelha, ouro e coração dourado', emoji: '🌹', cost: 1400,
    imageW: 620, imageH: 201, centerLeft: 364, centerTop: 97, centerRight: 494, centerBottom: 105,
    padLeft: 174, padTop: 58, padRight: 93, padBottom: 56, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'diamante_real', name: 'Diamante Real', description: 'Diamante em órbita dourada com coroa', emoji: '💎', cost: 1700,
    imageW: 620, imageH: 188, centerLeft: 290, centerTop: 89, centerRight: 420, centerBottom: 97,
    padLeft: 264, padTop: 46, padRight: 124, padBottom: 47, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'borboleta_sakura', name: 'Borboleta Sakura', description: 'Borboleta lilás com flores de cerejeira', emoji: '🌸', cost: 1100,
    imageW: 620, imageH: 181, centerLeft: 314, centerTop: 84, centerRight: 444, centerBottom: 92,
    padLeft: 233, padTop: 48, padRight: 142, padBottom: 52, textColor: Color(0xFFFFFFFF)),
  ChatBubbleSkin(id: 'coracoes_de_ouro', name: 'Corações de Ouro', description: 'Corações pink com moldura e coroa de ouro', emoji: '💖', cost: 1300,
    imageW: 620, imageH: 159, centerLeft: 298, centerTop: 83, centerRight: 428, centerBottom: 91,
    padLeft: 204, padTop: 52, padRight: 101, padBottom: 37, textColor: Color(0xFFFFFFFF)),
];

final Map<String, ChatBubbleSkin> _chatBubbleById = {for (final s in chatBubbleCatalog) s.id: s};

ChatBubbleSkin? chatBubbleById(Object? id) => id == null ? null : _chatBubbleById[id.toString()];
