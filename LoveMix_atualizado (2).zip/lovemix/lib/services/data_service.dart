import 'dart:async';
import 'dart:math';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'local_xp.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/gift_catalog.dart';

class DataService {
  DataService._();
  static final instance = DataService._();

  /// Converte qualquer valor vindo do Firestore em lista de textos, sem nunca
  /// lançar exceção (salas antigas podem ter `members` nulo, mapa ou misto).
  static List<String> stringList(dynamic value) {
    if (value is Iterable) {
      return value.where((e) => e != null).map((e) => e.toString()).toList();
    }
    return <String>[];
  }
  final db = FirebaseFirestore.instance;
  String get uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> createUser({
    required String name,
    required DateTime birthday,
    String bio = '',
  }) async {
    final user = FirebaseAuth.instance.currentUser!;
    final ref = db.collection('users').doc(user.uid);
    // Conta que já existe: NUNCA reescreve moedas, diamantes nem molduras
    // compradas (antes, entrar de novo podia zerar as molduras e o saldo).
    final existing = await ref.get();
    if (existing.exists) {
      await ref.set({
        'name': name.trim(),
        'birthday': Timestamp.fromDate(birthday),
        'isActive': true,
      }, SetOptions(merge: true));
      return;
    }
    final publicId = await _allocateShortPublicId();
    await ref.set({
      'uid': user.uid,
      'publicId': publicId,
      'name': name.trim(),
      'birthday': Timestamp.fromDate(birthday),
      'bio': bio,
      'photoUrl': '',
      'city': '',
      'country': '',
      'interests': <String>[],
      'coins': 200,
      'diamonds': 0,
      'ownedProfileFrames': <String>['classic'],
      'selectedProfileFrame': 'classic',
      'profileVisibility': 'public',
      'postVisibility': 'public',
      'isVip': false,
      'isAdmin': false,
      'createdAt': FieldValue.serverTimestamp(),
      'isActive': true,
      'isOnline': false,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }


  // Carisma por uso: +1 a cada minuto com o app aberto (em primeiro plano).
  // As regras do Firestore aceitam no máximo +1 a cada ~50 segundos por conta.
  Timer? _charismaTimer;

  void startCharismaTicker() {
    _charismaTimer?.cancel();
    _charismaTimer = Timer.periodic(const Duration(seconds: 60), (_) async {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;
      try {
        await db.collection('users').doc(user.uid).update({
          'charisma': FieldValue.increment(1),
          'charismaTickAt': FieldValue.serverTimestamp(),
        });
      } catch (_) {
        // Regras ainda não publicadas ou sem conexão: tenta de novo no próximo minuto.
      }
    });
  }

  void stopCharismaTicker() {
    _charismaTimer?.cancel();
    _charismaTimer = null;
  }

  Future<void> setMyLiveStatus({required bool live, String? roomId, String mediaMode = 'video'}) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final ref = db.collection('users').doc(user.uid);
    if (live) {
      await ref.update({
        'isLive': true,
        'liveRoomId': roomId,
        'liveMediaMode': mediaMode,
        'liveStartedAt': FieldValue.serverTimestamp(),
      });
    } else {
      await ref.update({
        'isLive': false,
        'liveRoomId': FieldValue.delete(),
        'liveMediaMode': FieldValue.delete(),
        'liveStartedAt': FieldValue.delete(),
      });
    }
  }

  Future<void> setOnlineStatus(bool online) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(user.uid).set({
      'isOnline': online,
      'lastSeen': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  // ID público curto. O UID original continua sendo usado internamente.
  static const String _publicIdAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  String _randomShortPublicId() {
    final random = Random.secure();
    return List.generate(8, (_) =>
      _publicIdAlphabet[random.nextInt(_publicIdAlphabet.length)]).join();
  }

  Future<String> _allocateShortPublicId() async {
    for (var attempt = 0; attempt < 20; attempt++) {
      final candidate = _randomShortPublicId();
      final exists = await db.collection('users')
          .where('profileVisibility', isEqualTo: 'public')
          .where('publicId', isEqualTo: candidate).limit(1).get();
      if (exists.docs.isEmpty) return candidate;
    }
    throw Exception('Não foi possível gerar um ID. Tente novamente.');
  }

  Future<void> ensurePublicId() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para carregar seu ID LoveMix.');
    final ref = db.collection('users').doc(user.uid);
    final snap = await ref.get();
    final current = (snap.data()?['publicId'] ?? '').toString().trim().toUpperCase();
    if (RegExp(r'^[A-Z0-9]{8}$').hasMatch(current)) return;

    final publicId = await _allocateShortPublicId();
    if (!snap.exists) {
      // Conta autenticada sem documento de perfil: cria o registro mínimo
      // compatível com as regras atuais, para a sala não bloquear o usuário.
      final fallbackName = (user.displayName ?? '').trim().isNotEmpty
          ? user.displayName!.trim()
          : (user.email?.split('@').first ?? 'LoveMix');
      await ref.set({
        'uid': user.uid,
        'publicId': publicId,
        'name': fallbackName,
        'coins': 100,
        'diamonds': 0,
        'profileVisibility': 'public',
        'postVisibility': 'public',
        'isVip': false,
        'isAdmin': false,
        'isActive': true,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      await ref.set({'publicId': publicId}, SetOptions(merge: true));
    }
  }

  Future<QuerySnapshot<Map<String, dynamic>>> findUserByPublicId(String value) {
    // A consulta inclui a visibilidade para que as regras do Firestore
    // consigam garantir que nenhum perfil privado seja retornado.
    var publicId = value.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9-]'), '');
    if (publicId.startsWith('LM-')) publicId = publicId.substring(3);
    return db.collection('users')
        .where('publicId', isEqualTo: publicId)
        .where('profileVisibility', isEqualTo: 'public')
        .limit(1)
        .get();
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> myProfile() =>
      db.collection('users').doc(uid).snapshots();

  Future<void> updateProfile(Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set(data, SetOptions(merge: true));

  Stream<QuerySnapshot<Map<String, dynamic>>> discoverUsers() =>
      db.collection('users')
          // Não exigir isActive == true: contas antigas podem não ter esse
          // campo. A tela remove explicitamente apenas quem está inativo.
          .where('profileVisibility', isEqualTo: 'public')
          .limit(1000)
          .snapshots();

  // Convites pendentes só aparecem para os dois participantes.
  Stream<QuerySnapshot<Map<String, dynamic>>> myPendingAlliances() => db
      .collection('alliances')
      .where('members', arrayContains: uid)
      .snapshots();

  // O mural público mostra exclusivamente alianças já aceitas.
  Stream<QuerySnapshot<Map<String, dynamic>>> acceptedPublicAlliances() => db
      .collection('alliances')
      .where('invitationStatus', isEqualTo: 'accepted')
      .snapshots();

  Future<void> createAllianceByPublicId(
    String publicId,
    String relationshipType,
    DateTime startDate,
    String message, {
    required String ringGiftId,
  }) async {
    final cleanId = publicId.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9-]'), '');
    if (!RegExp(r'^(?:[A-Z0-9]{8}|LM-[A-F0-9]{12})$').hasMatch(cleanId)) {
      throw Exception('Informe o ID curto de 8 letras e números.');
    }
    const allowed = ['Namorados', 'BFF', 'Amigos'];
    if (!allowed.contains(relationshipType)) {
      throw Exception('Escolha Namorados, BFF ou Amigos.');
    }
    final ring = kAllianceRings.firstWhere(
      (item) => item['id'] == ringGiftId,
      orElse: () => throw Exception('Escolha uma aliança antes de enviar o convite.'),
    );
    final found = await findUserByPublicId(cleanId);
    if (found.docs.isEmpty) throw Exception('Não encontramos uma pessoa com esse ID.');
    final partner = found.docs.first;
    if (partner.id == uid) throw Exception('Você não pode criar uma aliança consigo mesmo.');
    if (partner.data()['isActive'] == false) throw Exception('Essa conta não está disponível.');

    // Cada usuário pode manter no máximo uma relação ativa/pendente de cada
    // tipo (um Namorados, um BFF e um Amigos). Tipos diferentes continuam
    // permitidos, inclusive com pessoas diferentes.
    final senderAlliances = await db.collection('alliances')
        .where('members', arrayContains: uid).get();
    final recipientAlliances = await db.collection('alliances')
        .where('members', arrayContains: partner.id).get();
    bool hasRelationshipType(Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
        String memberUid, String type) {
      return docs.any((doc) {
        final data = doc.data();
        final members = stringList(data['members']);
        final status = (data['invitationStatus'] ?? '').toString();
        return members.contains(memberUid) &&
            data['relationshipType'] == type &&
            (status == 'pending' || status == 'accepted');
      });
    }
    if (hasRelationshipType(senderAlliances.docs, uid, relationshipType)) {
      throw Exception('Você já tem uma aliança de $relationshipType ativa ou pendente. Encerre ou recuse a atual antes de enviar outra.');
    }
    if (hasRelationshipType(recipientAlliances.docs, partner.id, relationshipType)) {
      throw Exception('Essa pessoa já tem uma aliança de $relationshipType ativa ou pendente.');
    }

    final senderRef = db.collection('users').doc(uid);
    final recipientRef = db.collection('users').doc(partner.id);
    final allianceRef = db.collection('alliances').doc();
    final cost = (ring['cost'] as num).toInt();
    await db.runTransaction((tx) async {
      // Todas as leituras acontecem antes das gravações da transação.
      final senderSnap = await tx.get(senderRef);
      final recipientSnap = await tx.get(recipientRef);
      if (!senderSnap.exists || !recipientSnap.exists) {
        throw Exception('Perfil não encontrado.');
      }
      final senderData = senderSnap.data() ?? <String, dynamic>{};
      final recipientData = recipientSnap.data() ?? <String, dynamic>{};
      final currency = (ring['currency'] ?? 'coins').toString();
      final balanceField = currency == 'diamonds' ? 'diamonds' : 'coins';
      final balance = (senderData[balanceField] as num?)?.toInt() ?? 0;
      if (balance < cost) {
        throw Exception(currency == 'diamonds'
            ? 'Diamantes insuficientes para comprar esta aliança.'
            : 'Moedas insuficientes para comprar esta aliança.');
      }
      if (recipientData['profileVisibility'] != 'public') {
        throw Exception('A pessoa precisa ter perfil público para receber o convite.');
      }

      tx.update(senderRef, {balanceField: balance - cost});
      tx.set(allianceRef, {
        'createdBy': uid,
        'invitedUid': partner.id,
        'members': [uid, partner.id],
        'creatorName': (senderData['name'] ?? 'LoveMix').toString(),
        'creatorPhotoUrl': (senderData['photoUrl'] ?? '').toString(),
        'invitedName': (recipientData['name'] ?? 'Pessoa do LoveMix').toString(),
        'invitedPhotoUrl': (recipientData['photoUrl'] ?? '').toString(),
        'relationshipType': relationshipType,
        'message': message.trim(),
        'ringGiftId': ringGiftId,
        'ringGiftName': (ring['name'] ?? 'Aliança').toString(),
        'ringGiftCost': cost,
        'startDate': Timestamp.fromDate(DateTime(startDate.year, startDate.month, startDate.day)),
        'status': startDate.isAfter(DateTime.now()) ? 'planned' : 'active',
        'invitationStatus': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> respondAlliance(String allianceId, bool accept) async {
    final ref = db.collection('alliances').doc(allianceId);
    final snap = await ref.get();
    if (!snap.exists || snap.data()?['invitedUid'] != uid ||
        snap.data()?['invitationStatus'] != 'pending') {
      throw Exception('Este convite não está mais disponível.');
    }
    await ref.update({
      'invitationStatus': accept ? 'accepted' : 'rejected',
      'respondedAt': FieldValue.serverTimestamp(),
    });
  }

  // ───────────────────────── bolsinha: presentes e alianças ─────────────────────────

  /// Presentes que eu recebi (mais recentes primeiro).
  Stream<QuerySnapshot<Map<String, dynamic>>> myReceivedGifts() => db
      .collection('users').doc(uid).collection('receivedGifts')
      .orderBy('createdAt', descending: true).limit(40).snapshots();

  /// Alianças recusadas por mim que ficaram guardadas comigo.
  /// Uma aliança guardada só pode ser reenviada UMA vez:
  ///  - se já existe um reenvio dela, ela fica marcada como enviada;
  ///  - se ela mesma já era um reenvio, não pode ser reenviada de novo.
  static bool allianceIsKeptByMe(Map<String, dynamic> a, String me) =>
      a['invitedUid'] == me && a['invitationStatus'] == 'rejected';

  static bool allianceWasForwarded(
      String allianceId, Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> mine) =>
      mine.any((d) => d.data()['forwardedFromAllianceId'] == allianceId);

  static bool allianceIsAlreadyAForward(Map<String, dynamic> a) =>
      (a['forwardedFromAllianceId'] ?? '').toString().isNotEmpty;

  /// Envia uma aliança que eu recusei para outra pessoa (uma única vez).
  /// Não cobra moedas: a aliança já foi paga por quem a enviou primeiro.
  /// Só funciona se eu não tiver namorado(a)/convite de namoro ativo.
  Future<void> forwardKeptRing(String allianceId, String publicId) async {
    final cleanId = publicId.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9-]'), '');
    if (!RegExp(r'^(?:[A-Z0-9]{8}|LM-[A-F0-9]{12})$').hasMatch(cleanId)) {
      throw Exception('Informe o ID curto de 8 letras e números.');
    }
    final oldRef = db.collection('alliances').doc(allianceId);
    final oldSnap = await oldRef.get();
    final old = oldSnap.data();
    if (old == null || !allianceIsKeptByMe(old, uid)) {
      throw Exception('Esta aliança não está guardada com você.');
    }
    if (allianceIsAlreadyAForward(old)) {
      throw Exception('Esta aliança já foi reenviada uma vez e não pode ser enviada de novo.');
    }
    final mine = await db.collection('alliances').where('members', arrayContains: uid).get();
    if (allianceWasForwarded(allianceId, mine.docs)) {
      throw Exception('Você já enviou esta aliança uma vez.');
    }
    bool hasDating(Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> docs, String who) =>
        docs.any((doc) {
          final d = doc.data();
          final st = (d['invitationStatus'] ?? '').toString();
          return stringList(d['members']).contains(who) &&
              d['relationshipType'] == 'Namorados' &&
              (st == 'pending' || st == 'accepted');
        });
    if (hasDating(mine.docs, uid)) {
      throw Exception('Você já tem namorado(a) ou um convite de namoro. Só dá para enviar a aliança guardada se você não tiver.');
    }
    final found = await findUserByPublicId(cleanId);
    if (found.docs.isEmpty) throw Exception('Não encontramos uma pessoa com esse ID.');
    final partner = found.docs.first;
    if (partner.id == uid) throw Exception('Você não pode enviar a aliança para si mesmo.');
    if (partner.id == (old['createdBy'] ?? '').toString()) {
      throw Exception('Escolha outra pessoa: esta aliança veio dessa pessoa.');
    }
    if (partner.data()['isActive'] == false) throw Exception('Essa conta não está disponível.');
    if (partner.data()['profileVisibility'] != 'public') {
      throw Exception('A pessoa precisa ter perfil público para receber a aliança.');
    }
    final type = (old['relationshipType'] ?? 'Namorados').toString();
    final theirs = await db.collection('alliances').where('members', arrayContains: partner.id).get();
    final theirBusy = theirs.docs.any((doc) {
      final d = doc.data();
      final st = (d['invitationStatus'] ?? '').toString();
      return stringList(d['members']).contains(partner.id) &&
          d['relationshipType'] == type && (st == 'pending' || st == 'accepted');
    });
    if (theirBusy) throw Exception('Essa pessoa já tem uma aliança de $type ativa ou pendente.');

    final meSnap = await db.collection('users').doc(uid).get();
    final me = meSnap.data() ?? <String, dynamic>{};
    final partnerData = partner.data();
    await db.collection('alliances').doc().set({
      'createdBy': uid,
      'invitedUid': partner.id,
      'members': [uid, partner.id],
      'creatorName': (me['name'] ?? 'LoveMix').toString(),
      'creatorPhotoUrl': (me['photoUrl'] ?? '').toString(),
      'invitedName': (partnerData['name'] ?? 'Pessoa do LoveMix').toString(),
      'invitedPhotoUrl': (partnerData['photoUrl'] ?? '').toString(),
      'relationshipType': type,
      'message': 'Aliança reenviada 💍',
      'ringGiftId': (old['ringGiftId'] ?? '').toString(),
      'ringGiftName': (old['ringGiftName'] ?? 'Aliança').toString(),
      'forwardedFromAllianceId': allianceId,
      'startDate': Timestamp.fromDate(DateTime.now()),
      'status': 'active',
      'invitationStatus': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Qualquer participante pode encerrar uma aliança já aceita.
  /// A atualização é atômica e registra quem encerrou e quando.
  Future<void> endAlliance(String allianceId) async {
    final ref = db.collection('alliances').doc(allianceId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Esta aliança não existe mais.');
      final data = snap.data() ?? <String, dynamic>{};
      final members = (data['members'] as List? ?? []).map((e) => e.toString()).toSet();
      if (!members.contains(uid)) {
        throw Exception('Somente os participantes podem encerrar esta aliança.');
      }
      if (data['invitationStatus'] != 'accepted') {
        throw Exception('Somente uma aliança aceita pode ser encerrada.');
      }
      tx.update(ref, {
        'invitationStatus': 'ended',
        'endedAt': FieldValue.serverTimestamp(),
        'endedBy': uid,
      });
    });
  }

  Future<void> pass(String targetUid) async {
    if (targetUid == uid) return;
    await db.collection('users').doc(uid).collection('passed').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<Set<String>> getPassedUserIds() async {
    final snapshot = await db.collection('users').doc(uid)
        .collection('passed').get();
    return snapshot.docs.map((doc) => doc.id).toSet();
  }

  Future<bool> like(String targetUid) async {
    final callable = FirebaseFunctions.instance.httpsCallable('likeUser');
    final result = await callable.call({'targetUid': targetUid});
    return result.data is Map && result.data['matched'] == true;
  }

  DocumentReference<Map<String, dynamic>> followingRef(String targetUid) =>
      db.collection('users').doc(uid).collection('following').doc(targetUid);

  Stream<DocumentSnapshot<Map<String, dynamic>>> followingStatus(String targetUid) =>
      followingRef(targetUid).snapshots();

  Future<bool> toggleFollow(String targetUid) async {
    if (targetUid.isEmpty || targetUid == uid) {
      throw Exception('Perfil inválido.');
    }
    final targetRef = db.collection('users').doc(targetUid);
    final mineRef = followingRef(targetUid);
    final theirsRef = targetRef.collection('followers').doc(uid);
    final blockedByMe = db.collection('users').doc(uid).collection('blocked').doc(targetUid);
    final blockedMe = targetRef.collection('blocked').doc(uid);

    return db.runTransaction<bool>((transaction) async {
      final target = await transaction.get(targetRef);
      final current = await transaction.get(mineRef);
      final blocked1 = await transaction.get(blockedByMe);
      final blocked2 = await transaction.get(blockedMe);
      if (!target.exists || target.data()?['isActive'] == false) {
        throw Exception('Este perfil não está disponível.');
      }
      if (blocked1.exists || blocked2.exists) {
        throw Exception('Não é possível seguir este perfil.');
      }
      if (current.exists) {
        transaction.delete(mineRef);
        transaction.delete(theirsRef);
        return false;
      }
      transaction.set(mineRef, {
        'uid': targetUid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      transaction.set(theirsRef, {
        'uid': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      return true;
    });
  }

  /// Abre uma conversa usada exclusivamente para entregar presentes por UID.
  /// Exige perfil público e respeita bloqueios dos dois lados.
  Future<String> openGiftChat(String otherUid) async {
    if (otherUid.isEmpty || otherUid == uid) {
      throw Exception('Digite o UID de outra pessoa.');
    }
    final target = await db.collection('users').doc(otherUid).get();
    if (!target.exists) throw Exception('Nenhum perfil encontrado com esse UID.');
    if ((target.data()?['profileVisibility'] ?? 'public') != 'public') {
      throw Exception('Esse perfil não permite receber presentes de quem não segue.');
    }
    final blocked1 = await db.collection('users').doc(uid)
        .collection('blocked').doc(otherUid).get();
    final blocked2 = await db.collection('users').doc(otherUid)
        .collection('blocked').doc(uid).get();
    if (blocked1.exists || blocked2.exists) {
      throw Exception('Não é possível enviar presentes para esse perfil.');
    }
    final users = [uid, otherUid]..sort();
    final chatId = users.join('_');
    await db.collection('chats').doc(chatId).set({
      'users': users,
      'lastMessage': '',
      'lastMessageAt': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
      'chatType': 'direct',
      'giftOnly': true,
    }, SetOptions(merge: true));
    return chatId;
  }

  Future<String> openDirectChat(String otherUid) async {
    if (otherUid.isEmpty || otherUid == uid) {
      throw Exception('Perfil inválido.');
    }
    final followsTarget = await followingRef(otherUid).get();
    if (!followsTarget.exists) {
      throw Exception('Siga essa pessoa antes de enviar uma mensagem.');
    }
    final blocked1 = await db.collection('users').doc(uid)
        .collection('blocked').doc(otherUid).get();
    final blocked2 = await db.collection('users').doc(otherUid)
        .collection('blocked').doc(uid).get();
    if (blocked1.exists || blocked2.exists) {
      throw Exception('Não é possível iniciar conversa com este perfil.');
    }
    final users = [uid, otherUid]..sort();
    final chatId = users.join('_');
    final chatRef = db.collection('chats').doc(chatId);
    await chatRef.set({
      'users': users,
      'lastMessage': '',
      'lastMessageAt': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
      'chatType': 'direct',
    }, SetOptions(merge: true));
    return chatId;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myChats() => db
      .collection('chats')
      .where('users', arrayContains: uid)
      .snapshots();

  /// Oculta uma conversa somente para a conta atual; não apaga o histórico
  /// nem remove a conversa da outra pessoa.
  Future<void> hideChatForMe(String chatId) async {
    final ref = db.collection('chats').doc(chatId);
    final snap = await ref.get();
    if (!snap.exists) throw Exception('Conversa não encontrada.');
    final users = List<String>.from(snap.data()?['users'] ?? const []);
    if (!users.contains(uid)) throw Exception('Você não participa desta conversa.');
    final otherUid = users.firstWhere((id) => id != uid, orElse: () => '');
    await ref.update({'hiddenFor': FieldValue.arrayUnion([uid])});
    // Ao apagar a conversa, a pessoa também deixa de aparecer no carrossel
    // Online desta conta. A preferência fica salva no aparelho entre sessões.
    if (otherUid.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      final key = 'lovemix_hidden_online_users_$uid';
      final hidden = prefs.getStringList(key) ?? <String>[];
      if (!hidden.contains(otherUid)) {
        hidden.add(otherUid);
        await prefs.setStringList(key, hidden);
      }
    }
  }

  Future<Set<String>> hiddenOnlinePeople() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getStringList('lovemix_hidden_online_users_$uid') ?? <String>[]).toSet();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myMatches() => db
      .collection('matches')
      .where('users', arrayContains: uid)
      .orderBy('lastMessageAt', descending: true)
      .snapshots();

  CollectionReference<Map<String, dynamic>> messages(String chatId) =>
      db.collection('chats').doc(chatId).collection('messages');



  CollectionReference<Map<String, dynamic>> roomMessages(String roomId) =>
      db.collection('rooms').doc(roomId).collection('messages');

  /// Tenta a consulta ordenada; se o índice do Firestore não existir (erro),
  /// cai para a consulta simples, que não precisa de índice. Assim a tela nunca
  /// fica com o carregamento girando para sempre.
  Stream<QuerySnapshot<Map<String, dynamic>>> _withIndexFallback(
    Query<Map<String, dynamic>> ordered,
    Query<Map<String, dynamic>> simple,
  ) async* {
    try {
      await for (final snap in ordered.snapshots()) {
        yield snap;
      }
    } catch (_) {
      yield* simple.snapshots();
    }
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> publicRooms() {
    final base = db.collection('rooms').where('isPublic', isEqualTo: true);
    return _withIndexFallback(
      base.orderBy('createdAt', descending: true).limit(50),
      base.limit(50),
    );
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> publicLiveRooms({String? mediaMode}) {
    // Busca somente salas públicas. Os campos isLive/mediaMode são filtrados
    // no cliente para evitar consultas compostas que podem falhar quando o
    // índice ainda não foi publicado no projeto Firebase.
    final base = db.collection('rooms').where('isPublic', isEqualTo: true);
    return _withIndexFallback(
      base.orderBy('createdAt', descending: true).limit(100),
      base.limit(100),
    );
  }

  /// Salas de voz com gente dentro agora (campo `voiceLive`, mantido pela
  /// Cloud Function `syncRoomPresence`). Só usa igualdade: não precisa de índice.
  Stream<QuerySnapshot<Map<String, dynamic>>> publicVoiceLiveRooms() => db
      .collection('rooms')
      .where('isPublic', isEqualTo: true)
      .where('voiceLive', isEqualTo: true)
      .limit(50)
      .snapshots();

  Future<Map<String, String>> liveIdentityDefaults() async {
    await ensurePublicId();
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para participar da live.');

    final profile = await db.collection('users').doc(user.uid).get();
    final data = profile.data() ?? <String, dynamic>{};
    final publicId = (data['publicId'] ?? '').toString().trim();
    if (!RegExp(r'^[A-Z0-9]{8}$').hasMatch(publicId)) {
      throw Exception('Não foi possível carregar seu ID LoveMix. Complete seu perfil e tente novamente.');
    }

    final profileName = (data['name'] ?? '').toString().trim();
    final accountName = (user.displayName ?? '').trim();
    final emailName = (user.email?.split('@').first ?? '').trim();
    final displayName = profileName.isNotEmpty
        ? profileName
        : accountName.isNotEmpty
            ? accountName
            : emailName.isNotEmpty
                ? emailName
                : 'LoveMix';

    return {'publicId': publicId, 'displayName': displayName};
  }

  CollectionReference<Map<String, dynamic>> liveParticipants(String roomId) =>
      db.collection('rooms').doc(roomId).collection('participants');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchLiveParticipants(String roomId) =>
      liveParticipants(roomId).where('isActive', isEqualTo: true).limit(50).snapshots();

  Future<void> registerLiveParticipant({
    required String roomId,
    required String publicId,
    required String displayName,
  }) async {
    final cleanName = displayName.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (cleanName.isEmpty || cleanName.length > 32) {
      throw Exception('Escolha um nome de 1 a 32 caracteres para a live.');
    }
    final identity = await liveIdentityDefaults();
    if (identity['publicId'] != publicId) {
      throw Exception('Seu ID LoveMix mudou. Feche e entre na live novamente.');
    }
    await liveParticipants(roomId).doc(uid).set({
      'uid': uid,
      'publicId': publicId,
      'displayName': cleanName,
      'isActive': true,
      'joinedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<void> leaveLiveParticipant(String roomId) async {
    await liveParticipants(roomId).doc(uid).set({
      'isActive': false,
      'leftAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  /// Filtra as salas que realmente estão ao vivo agora e devolve NO MÁXIMO
  /// 1 sala por pessoa (dono) para o tipo pedido: `audio` (voz) ou `video`.
  /// Regras:
  ///  - isLive == true e o tipo da sala bate com o pedido;
  ///  - se a sala já tem `onlineCount` (mantido pela Cloud Function
  ///    `syncRoomPresence`) e ele for 0, ninguém está dentro => não aparece;
  ///  - se a mesma pessoa tiver mais de uma sala, fica só a mais recente.
  static List<QueryDocumentSnapshot<Map<String, dynamic>>> activeLivesOnePerOwner(
    Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
    String mediaMode,
  ) {
    final wantAudio = mediaMode == 'audio';
    final list = docs.where((d) {
      final data = d.data();
      if (data['isLive'] != true) return false;
      final mode = (data['mediaMode'] ?? '').toString();
      if (wantAudio ? mode != 'audio' : (mode != 'video' && mode != 'live')) return false;
      final online = data['onlineCount'];
      if (online is num && online <= 0) return false;
      return true;
    }).toList();

    int millis(QueryDocumentSnapshot<Map<String, dynamic>> d) {
      final t = d.data()['createdAt'];
      return t is Timestamp ? t.millisecondsSinceEpoch : 0;
    }

    list.sort((a, b) => millis(b).compareTo(millis(a)));
    final seenOwners = <String>{};
    final result = <QueryDocumentSnapshot<Map<String, dynamic>>>[];
    for (final d in list) {
      final owner = (d.data()['ownerId'] ?? d.id).toString();
      if (seenOwners.add(owner)) result.add(d);
    }
    return result;
  }

  /// Encerra as outras lives da própria pessoa do mesmo tipo (voz ou vídeo),
  /// para que ela nunca tenha mais de 1 live de voz e 1 live de vídeo ao vivo.
  Future<void> endMyOtherLives(String mediaMode) async {
    try {
      final snap = await db
          .collection('rooms')
          .where('ownerId', isEqualTo: uid)
          .where('isLive', isEqualTo: true)
          .get();
      for (final d in snap.docs) {
        final mode = (d.data()['mediaMode'] ?? '').toString();
        final sameKind = mediaMode == 'audio'
            ? mode == 'audio'
            : (mode == 'video' || mode == 'live');
        if (sameKind) {
          try {
            await d.reference.update({'isLive': false});
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  Future<void> endLiveRoom(String roomId) async {
    final roomRef = db.collection('rooms').doc(roomId);
    final roomSnap = await roomRef.get();
    final ownerId = (roomSnap.data()?['ownerId'] ?? '').toString();
    await roomRef.update({'isLive': false});
    if (ownerId.isNotEmpty) {
      // A mesma conta pode manter uma sala de voz e uma live de vídeo.
      // Ao encerrar uma delas, preserva o indicador da outra transmissão ativa.
      try {
        final remaining = await db.collection('rooms')
            .where('ownerId', isEqualTo: ownerId)
            .where('isLive', isEqualTo: true)
            .get();
        final active = remaining.docs.where((doc) {
          final mode = (doc.data()['mediaMode'] ?? '').toString();
          return mode == 'audio' || mode == 'video' || mode == 'live';
        }).toList()
          ..sort((a, b) {
            final at = a.data()['createdAt'];
            final bt = b.data()['createdAt'];
            final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
            final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
            return bm.compareTo(am);
          });
        final userRef = db.collection('users').doc(ownerId);
        if (active.isNotEmpty) {
          final nextRoom = active.first;
          final nextData = nextRoom.data();
          await userRef.update({
            'isLive': true,
            'liveRoomId': nextRoom.id,
            'liveMediaMode': (nextData['mediaMode'] ?? 'video').toString(),
            'liveStartedAt': nextData['createdAt'] is Timestamp
                ? nextData['createdAt']
                : FieldValue.serverTimestamp(),
          });
        } else {
          await userRef.update({
            'isLive': false,
            'liveRoomId': FieldValue.delete(),
            'liveMediaMode': FieldValue.delete(),
            'liveStartedAt': FieldValue.delete(),
          });
        }
      } catch (_) {
        // Se não for possível consultar as outras salas, não bloqueia o
        // encerramento da sala atual; a próxima atualização de presença corrige.
      }
    }
    // Limpa o chat da live ao encerrar (precisa das regras novas publicadas;
    // se não estiverem, o chat já fica oculto para quem entra depois).
    try {
      while (true) {
        final snap = await roomMessages(roomId).limit(400).get();
        if (snap.docs.isEmpty) break;
        final batch = db.batch();
        for (final d in snap.docs) { batch.delete(d.reference); }
        await batch.commit();
        if (snap.docs.length < 400) break;
      }
    } catch (_) {}
  }

  Future<void> renameRoom(String roomId, String name) async {
    final clean = name.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (clean.length < 3 || clean.length > 40) {
      throw Exception('O nome da sala deve ter entre 3 e 40 caracteres.');
    }
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      if (!_isRoomStaff(snap.data() ?? <String, dynamic>{})) {
        throw Exception('Somente dono e administradores podem alterar o nome da sala.');
      }
      tx.update(ref, {'name': clean});
    });
  }

  Future<String> createRoom(String name, {bool isPublic = true, String category = 'Amizades', String description = '', String password = '', bool isLive = false, String mediaMode = 'text', bool isVipRoom = false}) async {
    final clean = name.trim();
    if (clean.length < 3 || clean.length > 40) {
      throw Exception('O nome da sala deve ter entre 3 e 40 caracteres.');
    }
    if (isLive && (mediaMode == 'audio' || mediaMode == 'video')) {
      await endMyOtherLives(mediaMode);
    }
    if (!isPublic && password.trim().length < 4) {
      throw Exception('A senha da sala privada deve ter pelo menos 4 caracteres.');
    }
    final payload = <String, dynamic>{
      'name': clean,
      'ownerId': uid,
      'members': [uid],
      'isPublic': isPublic,
      'category': category,
      'description': description.trim(),
      'isLive': isLive,
      'isVipRoom': isVipRoom,
      'isLocked': false,
      'mediaMode': mediaMode,
      'passwordHash': isPublic ? null : sha256.convert(utf8.encode(password.trim())).toString(),
      'createdAt': FieldValue.serverTimestamp(),
      'lastMessage': 'Sala criada. Dê boas-vindas!',
      'lastMessageAt': FieldValue.serverTimestamp(),
    };

    // Papel de parede salvo do dono: volta junto com a sala nova e só muda
    // quando ele escolher outro.
    try {
      final prefs = await SharedPreferences.getInstance();
      final wType = prefs.getString('lovemix_room_wallpaper_type_$uid') ?? '';
      final wUrl = prefs.getString('lovemix_room_wallpaper_url_$uid') ?? '';
      if (wType.isNotEmpty && wType != 'original') {
        payload['wallpaperType'] = wType;
        payload['wallpaperUrl'] = wUrl;
      }
    } catch (_) {}

    // Falhas "unavailable" são normalmente temporárias (rede/Firestore).
    // Repetimos apenas erros transitórios; nunca repetimos permission-denied.
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final ref = await db.collection('rooms').add(payload);
        return ref.id;
      } on FirebaseException catch (e) {
        final transient = e.code == 'unavailable' ||
            e.code == 'deadline-exceeded' || e.code == 'network-request-failed';
        if (!transient || attempt == 2) rethrow;
        await Future<void>.delayed(Duration(seconds: attempt + 1));
      }
    }
    throw Exception('Não foi possível criar a sala. Verifique sua conexão e tente novamente.');
  }

  /// Admin do app (mesma claim usada nas regras do Firestore).
  Future<bool> _isAdminClaim() async {
    try {
      final token = await FirebaseAuth.instance.currentUser?.getIdTokenResult(true);
      return token?.claims?['admin'] == true;
    } catch (_) {
      return false;
    }
  }

  /// O dono da sala pode promover ou remover administradores.
  /// Dono ou administrador da sala: mesmos poderes de gerenciamento.
  bool _isRoomStaff(Map<String, dynamic> data) {
    if ((data['ownerId'] ?? '').toString() == uid) return true;
    return List<String>.from(data['roomAdmins'] ?? const []).contains(uid);
  }

  Future<void> setRoomAdmin(String roomId, String targetUid, bool makeAdmin) async {
    if (targetUid == uid) throw Exception('Você não pode alterar o seu próprio cargo.');
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      final data = snap.data() ?? <String, dynamic>{};
      if ((data['ownerId'] ?? '').toString() != uid) throw Exception('Somente o dono pode dar ou tirar administrador.');
      if (data['ownerId'] == targetUid) throw Exception('O dono da sala já tem controle total.');
      final members = List<String>.from(data['members'] ?? const []);
      if (!members.contains(targetUid)) throw Exception('A pessoa não está mais na sala.');
      final admins = List<String>.from(data['roomAdmins'] ?? const []);
      if (makeAdmin) {
        // Não vira admin na hora: a pessoa recebe o convite e precisa aceitar.
        if (admins.contains(targetUid)) throw Exception('Essa pessoa já é administradora.');
        tx.set(ref.collection('adminInvites').doc(targetUid), {
          'fromUid': uid,
          'status': 'pending',
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        admins.remove(targetUid);
        tx.update(ref, {'roomAdmins': admins});
        tx.delete(ref.collection('adminInvites').doc(targetUid));
      }
    });
  }

  /// A pessoa convidada aceita virar administradora da sala.
  Future<void> acceptRoomAdminInvite(String roomId) async {
    final ref = db.collection('rooms').doc(roomId);
    final invite = ref.collection('adminInvites').doc(uid);
    final batch = db.batch();
    batch.update(ref, {'roomAdmins': FieldValue.arrayUnion([uid])});
    batch.delete(invite);
    await batch.commit();
  }

  /// A pessoa convidada recusa; o convite some e ela segue como participante.
  Future<void> declineRoomAdminInvite(String roomId) async {
    await db.collection('rooms').doc(roomId).collection('adminInvites').doc(uid).delete();
  }

  /// Remove e bane um participante (privilégios e assento também). O dono não pode ser expulso.
  Future<void> kickRoomMember(String roomId, String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode expulsar a si mesmo.');
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      final data = snap.data() ?? <String, dynamic>{};
      if (!_isRoomStaff(data)) throw Exception('Somente dono e administradores podem expulsar participantes.');
      if (data['ownerId'] == targetUid) throw Exception('O dono da sala não pode ser expulso.');
      final targetIsAdmin = List<String>.from(data['roomAdmins'] ?? const []).contains(targetUid);
      if (targetIsAdmin && data['ownerId'] != uid) {
        throw Exception('Somente o dono pode expulsar um administrador.');
      }
      final members = List<String>.from(data['members'] ?? const []);
      if (!members.contains(targetUid)) throw Exception('A pessoa não está mais na sala.');
      members.remove(targetUid);
      final admins = List<String>.from(data['roomAdmins'] ?? const [])..remove(targetUid);
      // Expulsar = banir: a pessoa só volta se o dono desbanir.
      tx.update(ref, {
        'members': members,
        'roomAdmins': admins,
        'bannedUsers': FieldValue.arrayUnion([targetUid]),
      });
    });
    // Limpeza complementar: libera assento e marca a presença como encerrada.
    final seats = roomSeats(roomId);
    final occupied = await seats.where('uid', isEqualTo: targetUid).get();
    for (final seat in occupied.docs) { await seat.reference.delete(); }
    final participantRef = liveParticipants(roomId).doc(targetUid);
    final participantSnap = await participantRef.get();
    if (participantSnap.exists) {
      await participantRef.update({'isActive': false, 'leftAt': FieldValue.serverTimestamp()});
    }
  }

  /// Desbanir: a pessoa volta a poder entrar na sala. Somente o dono.
  Future<void> unbanRoomMember(String roomId, String targetUid) async {
    final ref = db.collection('rooms').doc(roomId);
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      if (!snap.exists) throw Exception('Sala não encontrada.');
      if (!_isRoomStaff(snap.data() ?? <String, dynamic>{})) throw Exception('Somente dono e administradores podem desbanir.');
      tx.update(ref, {'bannedUsers': FieldValue.arrayRemove([targetUid])});
    });
  }

  Future<Map<String, dynamic>> claimRoomEntryMission({String? roomId, bool checkOnly = false}) async {
    final callable = FirebaseFunctions.instance.httpsCallable('claimRoomEntryMission');
    final result = await callable.call(<String, dynamic>{
      if (roomId != null) 'roomId': roomId,
      'checkOnly': checkOnly,
    });
    return Map<String, dynamic>.from(result.data as Map);
  }

  Future<void> joinRoom(String roomId) async {
    final roomRef = db.collection('rooms').doc(roomId);
    await db.runTransaction((transaction) async {
      final snapshot = await transaction.get(roomRef);
      if (!snapshot.exists) throw Exception('Sala não encontrada.');
      final data = snapshot.data() ?? <String, dynamic>{};
      final members = List<String>.from(data['members'] ?? const []);
      // A verificação de banimento precisa vir antes do retorno para membros
      // antigos; caso contrário, alguém expulso poderia reabrir a live.
      final banned = List<String>.from(data['bannedUsers'] ?? const []);
      if (banned.contains(uid) && (data['ownerId'] ?? '').toString() != uid) {
        throw Exception('Você foi banido desta sala pelo anfitrião. Peça ao dono para remover o banimento.');
      }
      // Sala bloqueada: só o dono e os admins entram, inclusive quem já
      // participou antes do bloqueio e está tentando retornar à live.
      final isRoomOwner = (data['ownerId'] ?? '').toString() == uid;
      final isRoomAdminHere = List<String>.from(data['roomAdmins'] ?? const []).contains(uid);
      if (data['isLocked'] == true && !isRoomOwner && !isRoomAdminHere && !await _isAdminClaim()) {
        throw Exception('Esta sala está bloqueada pelo anfitrião.');
      }
      if (members.contains(uid)) return;
      transaction.update(roomRef, {
        'members': FieldValue.arrayUnion([uid]),
      });
    });
  }

  CollectionReference<Map<String, dynamic>> roomSeats(String roomId) =>
      db.collection('rooms').doc(roomId).collection('seats');

  Stream<QuerySnapshot<Map<String, dynamic>>> watchRoomSeats(String roomId) =>
      roomSeats(roomId).snapshots();

  Future<void> takeRoomSeat(String roomId, int seatNumber) async {
    if (seatNumber < 1 || seatNumber > 10) {
      throw Exception('Assento inválido.');
    }

    // Entrada e ocupação do assento na MESMA transação. Antes eram duas
    // transações separadas e as 10 leituras dos assentos eram sequenciais,
    // acrescentando várias viagens de rede ao toque do usuário.
    final roomRef = db.collection('rooms').doc(roomId);
    final seats = roomSeats(roomId);
    await db.runTransaction((transaction) async {
      final refs = List.generate(10, (i) => seats.doc('${i + 1}'));

      // Todas as leituras são iniciadas juntas para reduzir a latência.
      final roomFuture = transaction.get(roomRef);
      final seatFutures = refs.map((ref) => transaction.get(ref)).toList();
      final roomSnapshot = await roomFuture;
      final snapshots = await Future.wait(seatFutures);

      if (!roomSnapshot.exists) throw Exception('Sala não encontrada.');
      final roomData = roomSnapshot.data() ?? <String, dynamic>{};
      final members = List<String>.from(roomData['members'] ?? const []);
      final ownerId = (roomData['ownerId'] ?? '').toString();
      final banned = List<String>.from(roomData['bannedUsers'] ?? const []);
      if (banned.contains(uid) && ownerId != uid) {
        throw Exception('Você foi banido desta sala pelo anfitrião. Peça ao dono para remover o banimento.');
      }
      final roomAdmins = List<String>.from(roomData['roomAdmins'] ?? const []);
      if (roomData['isLocked'] == true && ownerId != uid &&
          !roomAdmins.contains(uid) && !await _isAdminClaim()) {
        throw Exception('Esta sala está bloqueada pelo anfitrião.');
      }

      final targetIndex = seatNumber - 1;
      final targetData = snapshots[targetIndex].data();
      if (targetData != null && targetData['uid'] != uid) {
        throw Exception('Esse assento já está ocupado. Escolha outro.');
      }

      // Só grava a associação se for a primeira entrada do usuário na sala.
      if (!members.contains(uid)) {
        transaction.update(roomRef, {
          'members': FieldValue.arrayUnion([uid]),
        });
      }

      if (targetData?['uid'] == uid) {
        for (var i = 0; i < snapshots.length; i++) {
          if (i != targetIndex && snapshots[i].data()?['uid'] == uid) {
            transaction.delete(refs[i]);
          }
        }
        return;
      }

      for (var i = 0; i < snapshots.length; i++) {
        if (snapshots[i].data()?['uid'] == uid) {
          transaction.delete(refs[i]);
        }
      }
      transaction.set(refs[targetIndex], {
        'uid': uid,
        'seatNumber': seatNumber,
        'micOn': false,
        'joinedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> leaveRoomSeat(String roomId) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    for (final seat in ownSeat.docs) {
      await seat.reference.delete();
    }
  }

  Future<void> setRoomSeatMic(String roomId, bool enabled) async {
    final seats = roomSeats(roomId);
    final ownSeat = await seats.where('uid', isEqualTo: uid).limit(1).get();
    if (ownSeat.docs.isEmpty) return;
    await ownSeat.docs.first.reference.update({'micOn': enabled});
  }

  /// Bloqueia/libera o bate-papo da sala (somente o anfitrião; as regras também exigem isso).
  Future<void> setRoomChatLocked(String roomId, bool locked) async {
    await db.collection('rooms').doc(roomId).update({'chatLocked': locked});
  }

  /// Pessoas que eu sigo, que ainda não estão na sala e sem bloqueio entre nós.
  Future<List<Map<String, dynamic>>> loadFriendsToInvite(String roomId) async {
    final roomSnap = await db.collection('rooms').doc(roomId).get();
    final members = List<String>.from(roomSnap.data()?['members'] ?? const []);
    final following = await db.collection('users').doc(uid).collection('following').get();
    final blocked = await db.collection('users').doc(uid).collection('blocked').get();
    final blockedIds = blocked.docs.map((d) => d.id).toSet();
    final result = <Map<String, dynamic>>[];
    for (final doc in following.docs) {
      final id = doc.id;
      if (members.contains(id) || blockedIds.contains(id)) continue;
      try {
        final u = await db.collection('users').doc(id).get();
        final data = u.data();
        if (data == null || data['isActive'] == false) continue;
        result.add({
          'uid': id,
          'name': data['name'] ?? 'Usuário',
          'photoUrl': data['photoUrl'] ?? '',
        });
      } catch (_) {
        // Perfil privado ou indisponível: simplesmente não aparece na lista.
      }
    }
    return result;
  }

  /// Envia um convite para a sala como notificação dentro do app (e push via Cloud Function).
  Future<void> sendRoomInvite({
    required String roomId,
    required String roomName,
    required String targetUid,
  }) async {
    if (targetUid.isEmpty || targetUid == uid) throw Exception('Pessoa inválida.');
    final me = await db.collection('users').doc(uid).get();
    final myName = (me.data()?['name'] ?? 'Alguém').toString();
    await db.collection('users').doc(targetUid).collection('notifications').add({
      'type': 'room_invite',
      'fromUid': uid,
      'fromName': myName,
      'roomId': roomId,
      'roomName': roomName,
      'body': '$myName convidou você para a sala "$roomName".',
      'read': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // Moderação preventiva do chat da Live/sala. A lista usa termos adultos
  // comuns em português e variações simples; a palavra é censurada antes de gravar.
  static final List<RegExp> _adultWordPatterns = [
    RegExp(r'\bsexo\s+(oral|anal|grupal|selvagem)\b', caseSensitive: false),
    RegExp(r'\b(fazer|fazendo|transar|quero|vamos)\s+sexo\b', caseSensitive: false),
    RegExp(r'\bnudes?\b', caseSensitive: false),
    RegExp(r'\bporn\w*', caseSensitive: false),
    RegExp(r'\bpornografia\w*', caseSensitive: false),
    RegExp(r'\ber[oó]tic\w*', caseSensitive: false),
    RegExp(r'\btransar\w*', caseSensitive: false),
    RegExp(r'\bf0d[ae]r\w*', caseSensitive: false),
    RegExp(r'\bputaria\w*', caseSensitive: false),
    RegExp(r'\bconte[uú]do\s+adulto\b', caseSensitive: false),
  ];

  Future<String?> sendRoomMessage(String roomId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 1000) return null;
    // Mensagem +18 não é enviada (é descartada). Mensagem normal passa direto.
    if (containsAdultText(clean)) {
      throw Exception('Mensagem +18 não enviada. Só mensagens normais são permitidas.');
    }
    final room = db.collection('rooms').doc(roomId);
    await roomMessages(roomId).add({
      'senderId': uid, 'text': clean, 'type': 'text',
      'createdAt': FieldValue.serverTimestamp(),
    });
    await room.update({'lastMessage': clean, 'lastMessageAt': FieldValue.serverTimestamp()});
    return null;
  }

  Future<void> sendRoomGift(String roomId, String recipientUid, String giftId,
      String emoji, String giftName) async {
    if (recipientUid.isEmpty) throw Exception('Escolha uma pessoa para receber o presente.');
    // Presentes continuam sendo enviados diretamente pelo Firestore. Não chama
    // sendRoomGift no Firebase e, portanto, não ativa recompensa de moedas da Live.
    await _sendRoomGiftDirect(roomId, recipientUid, giftId);
  }

  Future<void> _sendRoomGiftDirect(String roomId, String recipientUid, String giftId) async {
    Map<String, dynamic>? item;
    for (final g in kRoomGifts) {
      if (g['id'] == giftId) { item = g; break; }
    }
    if (item == null) throw Exception('Presente não encontrado.');
    final currency = item['currency'].toString();
    final cost = (item['cost'] as num).toInt();
    final emoji = item['emoji'].toString();
    final name = item['name'].toString();
    final me = uid;
    final roomRef = db.collection('rooms').doc(roomId);
    final meRef = db.collection('users').doc(me);
    final msgRef = roomRef.collection('messages').doc();
    String receivedTarget = '';
    String receivedSenderName = 'Usuário';
    await db.runTransaction((tx) async {
      final roomSnap = await tx.get(roomRef);
      final meSnap = await tx.get(meRef);
      if (!roomSnap.exists) throw Exception('A sala desta transmissão não foi encontrada. Saia e entre novamente.');
      if (!meSnap.exists) throw Exception('Seu perfil não foi encontrado. Entre novamente na sua conta.');
      final room = roomSnap.data() ?? {};
      final ownerId = (room['ownerId'] ?? '').toString();
      final members = List<String>.from((room['members'] as List?) ?? const []);
      if (!members.contains(me) && ownerId != me) throw Exception('Entre na sala antes de enviar presentes.');
      final target = recipientUid == me ? ownerId : recipientUid;
      receivedTarget = target;
      receivedSenderName = (meSnap.data()?['name'] ?? 'Usuário').toString();
      if (target.isEmpty || (target != ownerId && !members.contains(target))) {
        throw Exception('Quem recebe precisa estar na sala.');
      }
      final balance = ((meSnap.data()?[currency]) as num?)?.toInt() ?? 0;
      if (balance < cost) {
        throw Exception('Saldo insuficiente de ${currency == 'coins' ? 'moedas' : 'diamantes'}.');
      }
      tx.update(meRef, {currency: balance - cost});
      tx.set(msgRef, {
        'senderId': me,
        'recipientUid': target,
        'giftId': giftId,
        'giftName': name,
        'emoji': emoji,
        'currency': currency,
        'cost': cost,
        'type': 'gift',
        'text': '$emoji $name',
        'createdAt': FieldValue.serverTimestamp(),
      });
      tx.update(roomRef, {
        'lastMessage': '$emoji Presente enviado',
        'lastMessageAt': FieldValue.serverTimestamp(),
      });
    });
    // XP de quem envia: 1 por moeda, 10 por diamante (guardado no aparelho).
    await LocalXp.add(me, currency == 'diamonds' ? cost * 10 : cost);
    // Histórico é complementar: se as regras ainda não foram publicadas,
    // não impede o envio normal do presente na Live.
    try {
      await db.collection('users').doc(receivedTarget).collection('receivedGifts').doc(msgRef.id).set({
        'senderId': me,
        'senderName': receivedSenderName,
        'giftId': giftId,
        'giftName': name,
        'emoji': emoji,
        'currency': currency,
        'cost': cost,
        'source': 'live',
        'roomId': roomId,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  /// Última chuva de alianças do baú da sala (aberta, resgatada ou expirada).
  Stream<QuerySnapshot<Map<String, dynamic>>> watchLatestDrop(String roomId) =>
      db.collection('rooms').doc(roomId).collection('drops')
          .orderBy('createdAt', descending: true).limit(1).snapshots();

  /// Tenta pegar a aliança da chuva. O servidor garante que só 1 pessoa leva.
  Future<void> claimRoomDrop(String roomId, String dropId) async {
    final callable = FirebaseFunctions.instance.httpsCallable('claimRoomDrop');
    await callable.call(<String, dynamic>{'roomId': roomId, 'dropId': dropId});
  }

  Future<void> blockUser(String targetUid) async {
    if (targetUid == uid) throw Exception('Você não pode bloquear sua própria conta.');
    await db.collection('users').doc(uid).collection('blocked').doc(targetUid).set({
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> reportUser(String targetUid, String reason, {String details = ''}) async {
    final cleanReason = reason.trim();
    if (targetUid == uid || cleanReason.isEmpty) {
      throw Exception('Selecione um motivo válido para a denúncia.');
    }
    await db.collection('reports').add({
      'reporterId': uid,
      'reportedUserId': targetUid,
      'reason': cleanReason,
      'details': details.trim(),
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteMyAccount() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await db.collection('users').doc(uid).delete();
    await user.delete();
  }

  /// Resgata um código promocional diretamente no Firestore, sem Cloud Functions.
  /// O claim e o crédito de moedas são gravados na mesma transação; as regras
  /// do Firestore validam a lista oficial e impedem reutilização por conta.
  Future<String> redeemPromoCode(String raw) async {
    final code = raw.trim().toUpperCase().replaceAll(RegExp(r'\s+'), '');
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception('Entre na sua conta para resgatar.');
    if (code.isEmpty) throw Exception('Digite o código.');

    const officialCodes = <String>{
      'LMX-7KQ2-M9XA',
      'LMX-4PZ8-R3WB',
      'LMX-9T6N-2KCY',
      'LMX-5XQ7-D4JA',
      'LMX-2H8W-6RTP',
      'LMX-8C3M-5YQF',
      'LMX-6J4V-9K2P',
      'LMX-3R7X-2N8D',
      'LMX-W5K9-T3Q2',
      'LMX-Q8D4-M7X1',
      'LMX-N2P6-R9W3',
      'LMX-Y7C5-K2J8',
      'LMX-D4T9-X6M1',
      'LMX-R8W3-Q5N2',
      'LMX-K6J2-P9V4',
      'LMX-X3M7-D5R8',
      'LMX-T9Q4-N6C2',
      'LMX-H5V8-K3P7',
      'LMX-M2R6-X9D4',
      'LMX-C7W3-J8Q5',
      'LMX-83GJ-WC8T-ACFJ',
      'LMX-ACN7-ZRCT-4XL7',
      'LMX-B85G-GBNG-5QCT',
      'LMX-V34D-ZLFT-L94C',
      'LMX-WZC5-APJT-LBDK',
      'LMX-FTVR-WM49-4L89',
      'LMX-82R6-KGWG-LY7D',
      'LMX-M9PB-XNPB-5TTH',
      'LMX-7DMT-KPRE-QB74',
      'LMX-69XS-HJK3-GGFB',
      'LMX-FDFD-RNWH-QZMC',
      'LMX-8SVT-2CLF-V2ZJ',
      'LMX-NWLZ-WFH7-7NZW',
      'LMX-FKTT-BUQX-4LYK',
      'LMX-VCLP-7L2A-SZR9',
      'LMX-T6YE-8H6U-ZKXU',
      'LMX-X5ND-KRXN-NBXT',
      'LMX-ZTCS-25RV-MEZN',
      'LMX-FT52-AVGA-WM9W',
      'LMX-GHGC-GL8Q-NZ9V',
      'LMX-SZ3M-MYR4-4NC2',
      'LMX-HQUL-9QDC-DHBY',
      'LMX-2QYD-XHKQ-3AZL',
      'LMX-NDE8-625J-K5PF',
      'LMX-PNW5-U649-7VQ2',
      'LMX-LTWZ-9PAQ-9SKY',
      'LMX-GNQC-ZDZA-7SNJ',
      'LMX-5WXM-7B5L-RBFX',
      'LMX-6ZQG-TMFE-9YSQ',
      'LMX-VSCL-CWLD-NJGF',
      'LMX-37SY-LVHF-Y9X7',
      'LMX-RNG3-C9VX-JCY9',
      'LMX-87VY-3SBA-4PJ2',
      'LMX-FMHA-6KBJ-DB8M',
      'LMX-GQM4-FDY3-CULR',
      'LMX-C5JR-QNKV-LAQP',
      'LMX-SCKZ-6AU8-FWMY',
      'LMX-HVA3-WGJ9-R8PZ',
      'LMX-DBWJ-KSAN-BELT',
      'LMX-2JBG-PP9F-WK5A',
      'LMX-2ZAX-FQ4L-VVDA',
      'LMX-M56P-YNEQ-EEYB',
      'LMX-F8V9-T7QY-RG3U',
      'LMX-H896-BXK4-SDHW',
      'LMX-94UQ-ZV4L-8Z24',
      'LMX-KVQ9-DJW6-CGZ3',
      'LMX-VD4P-GJX4-AJTT',
      'LMX-G8Q6-WKML-LD9P',
      'LMX-ERQS-KVNA-DRXB',
      'LMX-57ZC-4GWD-3W69',
      'LMX-5NHX-XHYG-KKH4',
      'LMX-GDGB-VUMR-NH54',
      'LMX-AE8N-QK7Y-2ZRD',
      'LMX-NWUT-ZD3G-9JLF',
      'LMX-5CHF-STVU-VTM5',
      'LMX-6A75-73QP-4SXG',
      'LMX-P7AR-2M8E-F78Y',
      'LMX-7MWB-7LS8-NRKP',
      'LMX-G7A8-59WM-H7Z5',
      'LMX-4VNS-RJAK-9FX9',
      'LMX-A9L8-URY5-LVD5',
      'LMX-2CS3-N3LV-LQAA',
      'LMX-DF54-92AF-7BRR',
      'LMX-ZBVS-UR26-H97D',
      'LMX-95TJ-8VGD-L7HC',
      'LMX-EMT2-9N2G-C8C6',
      'LMX-T52R-5NLE-VTKP',
      'LMX-R5BT-28BR-P2QY',
      'LMX-TM6G-SQ94-NA3C',
      'LMX-M5WU-WJXW-NPCT',
      'LMX-28JL-QBW8-XFVK',
      'LMX-YNCS-6ZKG-4QMF',
      'LMX-BHSX-4L3R-944S',
      'LMX-KXXP-JE4J-7V96',
      'LMX-X2HZ-G5AW-C8KY',
      'LMX-9KN7-B6TP-MYSU',
      'LMX-BDU8-C2CG-42V8',
      'LMX-T3QU-UYBE-ZBCJ',
      'LMX-BR9E-LALT-4GHX',
      'LMX-R2F5-3U6C-7J46',
      'LMX-9AAH-PX6R-CQBK',
      'LMX-S3LG-S4EU-S96W',
      'LMX-R65F-GS4S-BXCP',
      'LMX-6SJG-BKFB-EU82',
      'LMX-XEM9-LQP5-AJ6D',
      'LMX-XSXG-3BW8-JY7G',
      'LMX-3J3D-JAZC-9CPL',
      'LMX-R3DK-SPE8-A3W5',
      'LMX-9UWD-3BZS-UXP8',
      'LMX-3Q3X-3WTC-6DZU',
      'LMX-5T2V-325G-KV8Z',
      'LMX-NVYJ-Q94C-WZJR',
      'LMX-7TJG-KBZ2-EAJ7',
      'LMX-CLNQ-RWGD-WEE5',
      'LMX-XZK6-X6WL-KBBF',
      'LMX-PFBY-9H9K-HXHE',
      'LMX-P6M8-5FDW-XNZD',
      'LMX-9WS7-F7FX-YPBM',
      'LMX-G937-Q6ES-ZQA8',
      'LMX-TL4U-YC6P-Y3Y3',
      'LMD-3T7J-A53A-BH6U',
      'LMD-Z6P5-ASMK-AH2T',
      'LMD-785E-ZFN8-VTUA',
      'LMD-GYLR-3UWE-GG7N',
      'LMD-EV69-UUVA-BT6K',
      'LMD-7F3X-S5SX-ZSK9',
      'LMD-E9GX-HD3D-YM7H',
      'LMD-EEMX-4DF5-L8LC',
      'LMD-JLHF-S86M-3WVV',
      'LMD-ZX3X-6R8T-MVLM',
      'LMD-HTWU-CKCG-9238',
      'LMD-LQ8M-GAKC-68D6',
      'LMD-ZDNY-NYMD-VPCY',
      'LMD-UAPJ-USPW-685U',
      'LMD-YM7F-QZGU-FE4X',
      'LMD-H2V9-UNHN-9LG5',
      'LMD-NWPZ-GFJL-X2W4',
      'LMD-NV4Z-SREK-3W22',
      'LMD-9G37-EJ3R-EU4H',
      'LMD-X3MP-RKHR-UA5U',
      'LMD-TRL8-9M7Z-GN6F',
      'LMD-B3UH-P2H2-BGQF',
      'LMD-34QQ-YX6R-KU86',
      'LMD-7T9G-H23K-P298',
      'LMD-ADQU-R7GX-R4WP',
      'LMD-UKP9-FBQT-C39F',
      'LMD-U9HZ-SQAW-3L79',
      'LMD-JD9E-8EYA-KQVK',
      'LMD-R3VB-6BEU-DFFX',
      'LMD-V26A-HARJ-PTTB',
      'LMD-J8GG-83AC-8T29',
      'LMD-YT5H-873R-N5SZ',
      'LMD-5W2S-F8VX-8QMN',
      'LMD-EJWK-A5L2-JFR3',
      'LMD-H8W7-X3WC-XPZ6',
      'LMD-8CUX-Y5GH-EUTM',
      'LMD-LH3C-NBX2-2AFD',
      'LMD-7HTF-F87V-CZBL',
      'LMD-JFZM-Y4AV-GSUF',
      'LMD-EVCB-KDTQ-TUCV',
      'LMD-7Y27-Z2LM-2FEH',
      'LMD-AG78-JM7P-F6G9',
      'LMD-FTXD-HMQN-DLFN',
      'LMD-G6NF-NLNH-HZWJ',
      'LMD-37HF-D333-BB4V',
      'LMD-NYLE-XJSP-6ZHK',
      'LMD-JM7R-GZUR-SELW',
      'LMD-KBDX-CK2C-U57D',
      'LMD-H4NY-FXRL-SLMR',
      'LMD-7MB2-R6RC-VHTC',
      'LMD-PB97-FHU5-8YVN',
      'LMD-8BAQ-53QY-687L',
      'LMD-6A8V-VZS2-YK2T',
      'LMD-BEJ4-C9ZR-BDJF',
      'LMD-8SUP-SYVV-SKJG',
      'LMD-NEBW-N28D-CHTR',
      'LMD-U864-DMYS-V9KE',
      'LMD-6S2A-T66A-7TA7',
      'LMD-7QMZ-6QYW-PGLT',
      'LMD-JYCZ-AEG5-WYE8',
      'LMD-YJK8-XUKF-4GB4',
      'LMD-YPWF-QSA8-WTPV',
      'LMD-E8HR-3RE5-QHSJ',
      'LMD-AJAM-5AR8-ZZZ8',
      'LMD-YXC5-6THV-22VW',
      'LMD-Q3RK-E4YK-Z6SF',
      'LMD-BDGU-F25T-ZX3U',
      'LMD-4X6L-6H4J-XADJ',
      'LMD-FZVS-4MMC-ZUJJ',
      'LMD-9NZ9-55NF-3XLX',
      'LMD-T66N-2SGL-UM5L',
      'LMD-WUC5-M7RD-WGA3',
      'LMD-36K5-AE6W-YYYJ',
      'LMD-Z852-6PXX-LL3Q',
      'LMD-XWSR-BALE-X5DJ',
      'LMD-9J5N-MQDW-67J4',
      'LMD-LPLP-C3GL-VGJP',
      'LMD-JNR4-CR4A-HESM',
      'LMD-ZH5M-UGT7-AGQ6',
      'LMD-Y22M-JYWM-EEH9',
      'LMD-BAJN-XLN9-5KZ7',
      'LMD-WUKH-VMVZ-UDTQ',
      'LMD-CMBB-GQ9C-9R5Q',
      'LMD-ULPT-QGJ9-RHL2',
      'LMD-EK2E-9E27-JHNV',
      'LMD-ULWA-NX72-C7PE',
      'LMD-JGUK-72JS-TP8X',
      'LMD-2QJM-Y7A3-4Z2P',
      'LMD-JC8J-B59C-GQ5T',
      'LMD-6XW6-HEUD-VXK2',
      'LMD-WFPP-WT4S-98ML',
      'LMD-YNYC-745N-NWZB',
      'LMD-MJFJ-P2HR-7HAA',
      'LMD-BLZE-788C-8UPL',
      'LMD-YSLE-Q624-WCVQ',
      'LMD-G3ZE-BZZ5-V6JY',
      'LMD-EQLX-Y4WE-WVYD',
      'LMD-GZ7T-ABHL-YCY4',
      'LMD-SVLH-3RGA-CRV6',
      'LMD-9Z9K-KJZ7-LTNF',

    };
    if (!officialCodes.contains(code)) throw Exception('Código inválido. Confira e tente novamente.');

    final userRef = db.collection('users').doc(user.uid);
    final claimRef = db.collection('promoCodeClaims').doc('${user.uid}_$code');
    try {
      await db.runTransaction((tx) async {
        final claim = await tx.get(claimRef);
        if (claim.exists) {
          throw Exception('Você já resgatou este código nesta conta.');
        }
        final profile = await tx.get(userRef);
        if (!profile.exists) throw Exception('Perfil não encontrado.');
        final data = profile.data() ?? <String, dynamic>{};
        final isDiamondCode = code.startsWith('LMD-');
        final field = isDiamondCode ? 'diamonds' : 'coins';
        final currentBalance = (data[field] as num?)?.toInt() ?? 0;
        tx.set(claimRef, {
          'uid': user.uid,
          'code': code,
          if (isDiamondCode) 'rewardDiamonds': 2000 else 'rewardCoins': 2000,
          'redeemedAt': FieldValue.serverTimestamp(),
        });
        tx.update(userRef, {field: currentBalance + 2000, 'lastRedeemCode': code});
      });
      return code.startsWith('LMD-') ? 'diamonds' : 'coins';
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw Exception('O Firebase bloqueou o resgate. Publique as novas regras do Firestore e tente novamente.');
      }
      rethrow;
    }
  }

  /// Envia um presente diretamente para o UID do perfil e registra o presente
  /// como mensagem especial na conversa privada. O débito e a mensagem são
  /// gravados na mesma transação para evitar cobrança sem entrega.
  Future<void> sendDirectGift({
    required String chatId,
    required String recipientUid,
    required String giftId,
  }) async {
    if (recipientUid.isEmpty || recipientUid == uid) {
      throw Exception('Escolha outra pessoa para receber o presente.');
    }
    final allGifts = <Map<String, dynamic>>[...kRoomGifts, ...kAllianceRings];
    final gift = allGifts.firstWhere(
      (item) => item['id'] == giftId,
      orElse: () => throw Exception('Presente não encontrado.'),
    );
    final cost = (gift['cost'] as num).toInt();
    final currency = (gift['currency'] ?? 'coins').toString();
    final giftName = (gift['name'] ?? 'Presente').toString();
    final senderRef = db.collection('users').doc(uid);
    final recipientRef = db.collection('users').doc(recipientUid);
    final chatRef = db.collection('chats').doc(chatId);
    final messageRef = chatRef.collection('messages').doc();
    final receivedGiftRef = recipientRef.collection('receivedGifts').doc(messageRef.id);
    String receivedSenderName = 'Usuário';

    // Enviar uma aliança também cria um convite de relacionamento no mural.
    // A pessoa destinatária ainda precisa aceitar para o casal ser formado.
    final isAllianceRing = giftId.startsWith('ring_');
    DocumentReference<Map<String, dynamic>>? allianceRef;
    if (isAllianceRing) {
      final senderPrevious = await db.collection('alliances')
          .where('members', arrayContains: uid).get();
      final recipientPrevious = await db.collection('alliances')
          .where('members', arrayContains: recipientUid).get();
      bool hasActiveDating(Iterable<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
          String memberUid) => docs.any((doc) {
        final data = doc.data();
        final status = (data['invitationStatus'] ?? '').toString();
        return stringList(data['members']).contains(memberUid) &&
            data['relationshipType'] == 'Namorados' &&
            (status == 'pending' || status == 'accepted');
      });
      if (hasActiveDating(senderPrevious.docs, uid)) {
        throw Exception('Você já tem um convite ou namoro ativo. Não é possível enviar outra aliança de Namorados.');
      }
      if (hasActiveDating(recipientPrevious.docs, recipientUid)) {
        throw Exception('Essa pessoa já tem um convite ou namoro ativo.');
      }
      allianceRef = db.collection('alliances').doc();
    }

    await db.runTransaction((tx) async {
      final senderSnap = await tx.get(senderRef);
      final recipientSnap = await tx.get(recipientRef);
      final chatSnap = await tx.get(chatRef);
      if (!senderSnap.exists || !recipientSnap.exists || !chatSnap.exists) {
        throw Exception('Perfil ou conversa não encontrado.');
      }
      receivedSenderName = (senderSnap.data()?['name'] ?? 'Usuário').toString();
      final chatUsers = List<String>.from(chatSnap.data()?['users'] ?? const []);
      if (!chatUsers.contains(uid) || !chatUsers.contains(recipientUid)) {
        throw Exception('Esta conversa não pertence a essas pessoas.');
      }
      final balanceField = currency == 'diamonds' ? 'diamonds' : 'coins';
      final balance = (senderSnap.data()?[balanceField] as num?)?.toInt() ?? 0;
      if (balance < cost) {
        throw Exception(currency == 'diamonds'
            ? 'Diamantes insuficientes.' : 'Moedas insuficientes.');
      }
      final emoji = (gift['emoji'] ?? '🎁').toString();
      final label = '$emoji $giftName';
      tx.update(senderRef, {balanceField: balance - cost});
      tx.update(chatRef, {
        'lastMessage': '🎁 Você enviou $label',
        'lastMessageAt': FieldValue.serverTimestamp(),
      });
      tx.set(messageRef, {
        'senderId': uid,
        'recipientUid': recipientUid,
        'type': 'gift',
        'text': '🎁 Você recebeu $label',
        'giftId': giftId,
        'giftEmoji': emoji,
        'giftName': giftName,
        'giftCost': cost,
        'giftCurrency': currency,
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (allianceRef != null) {
        final senderData = senderSnap.data() ?? <String, dynamic>{};
        tx.set(allianceRef, {
          'createdBy': uid,
          'invitedUid': recipientUid,
          'members': [uid, recipientUid],
          'creatorName': (senderData['name'] ?? 'LoveMix').toString(),
          'creatorPhotoUrl': (senderData['photoUrl'] ?? '').toString(),
          'relationshipType': 'Namorados',
          'message': 'Convite enviado com a aliança $giftName 💍',
          'ringGiftId': giftId,
          'ringGiftName': giftName,
          'startDate': Timestamp.fromDate(DateTime.now()),
          'status': 'active',
          'invitationStatus': 'pending',
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
    });
    // O registro do histórico não pode bloquear a entrega do presente.
    try {
      await receivedGiftRef.set({
        'senderId': uid,
        'senderName': receivedSenderName,
        'giftId': giftId,
        'giftName': giftName,
        'emoji': (gift['emoji'] ?? '🎁').toString(),
        'currency': currency,
        'cost': cost,
        'source': 'profile',
        'chatId': chatId,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  // A interface mascara os termos imediatamente; a Cloud Function analisa o
  // texto original no servidor, registra avisos e grava a versão censurada.
  static final List<RegExp> _privateAdultPatterns = [
    RegExp(r'\bsexo\s+(oral|anal|grupal|selvagem)\b', caseSensitive: false),
    RegExp(r'\b(fazer|fazendo|transar|quero|vamos)\s+sexo\b', caseSensitive: false),
    RegExp(r'\bnudes?\b', caseSensitive: false),
    RegExp(r'\bporn\w*', caseSensitive: false),
    RegExp(r'\ber[oó]tic\w*', caseSensitive: false),
    RegExp(r'\btransar\w*', caseSensitive: false),
    RegExp(r'\bf[0o]d[ae]r\w*', caseSensitive: false),
    RegExp(r'\bputaria\w*', caseSensitive: false),
    RegExp(r'\bconte[uú]do\s+adulto\b', caseSensitive: false),
    RegExp(r'\bboquete\w*', caseSensitive: false),
    RegExp(r'\bmasturba\w*', caseSensitive: false),
    RegExp(r'\btes[aã]o\b', caseSensitive: false),
    RegExp(r'\bp[eê]nis\b', caseSensitive: false),
    RegExp(r'\bvagina\b', caseSensitive: false),
    RegExp(r'\bseios?\s+de\s+fora\b', caseSensitive: false),
  ];

  /// true se o texto tem palavra +18 explícita.
  static bool containsAdultText(String text) =>
      _privateAdultPatterns.any((p) => p.hasMatch(text)) ||
      _adultWordPatterns.any((p) => p.hasMatch(text));

  static String maskPrivateAdultText(String text) {
    var masked = text;
    for (final pattern in _privateAdultPatterns) {
      masked = masked.replaceAllMapped(pattern, (_) => '•••');
    }
    return masked;
  }

  Future<void> sendMessage(String chatId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    if (clean.length > 4000) throw Exception('A mensagem é muito longa.');
    // Mensagem +18 não é enviada (é descartada). Mensagem normal passa direto.
    if (containsAdultText(clean)) {
      throw Exception('Mensagem +18 não enviada. Só mensagens normais são permitidas.');
    }
    final chat = db.collection('chats').doc(chatId);
    // A mensagem começa pendente para análise no servidor; a interface mostra
    // imediatamente uma prévia já mascarada, sem travar conversas normais.
    final messageRef = messages(chatId).doc();
    await messageRef.set({
      'senderId': uid,
      'text': clean,
      'createdAt': FieldValue.serverTimestamp(),
      'type': 'text',
      'moderationStatus': 'pending',
    });
    await chat.update({
      'lastMessage': maskPrivateAdultText(clean),
      'lastMessageAt': FieldValue.serverTimestamp(),
    });
  }
}
