import 'package:shared_preferences/shared_preferences.dart';

/// XP ganho ao enviar presentes. Fica salvo neste aparelho (não precisa publicar
/// nada no Firebase) e é somado ao carisma do uso do app para formar o nível.
class LocalXp {
  static String _key(String uid) => 'lovemix_xp_gifts_$uid';

  static Future<int> get(String uid) async {
    if (uid.isEmpty) return 0;
    try {
      return (await SharedPreferences.getInstance()).getInt(_key(uid)) ?? 0;
    } catch (_) {
      return 0;
    }
  }

  static Future<void> add(String uid, int xp) async {
    if (uid.isEmpty || xp <= 0) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_key(uid), (prefs.getInt(_key(uid)) ?? 0) + xp);
    } catch (_) {}
  }
}
