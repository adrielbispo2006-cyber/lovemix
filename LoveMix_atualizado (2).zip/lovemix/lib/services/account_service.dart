import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

/// Sair, adicionar outra conta e apagar conta.
class AccountService {
  AccountService._();

  static const _pink = Color(0xFFFF2DAB);

  /// Sai da conta atual. O app volta sozinho para a tela de login.
  static Future<void> signOut() => FirebaseAuth.instance.signOut();

  /// Sai da conta atual e abre o login para entrar com outra conta
  /// (o login do Google já força o seletor de contas).
  static Future<void> addAnotherAccount() => FirebaseAuth.instance.signOut();

  static Future<bool> _confirm(BuildContext context, {
    required String title,
    required String message,
    required String action,
    bool danger = false,
  }) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: const Color(0xFF171022),
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          TextButton(
            onPressed: () => Navigator.pop(c, true),
            child: Text(action, style: TextStyle(color: danger ? Colors.redAccent : _pink)),
          ),
        ],
      ),
    );
    return ok == true;
  }

  static Future<bool> confirmSignOut(BuildContext context) => _confirm(context,
      title: 'Sair da conta',
      message: 'Deseja sair da sua conta neste aparelho?',
      action: 'Sair');

  static Future<bool> confirmAddAccount(BuildContext context) => _confirm(context,
      title: 'Adicionar outra conta',
      message: 'Você vai sair desta conta e entrar com outra. Sua conta atual continua salva e você pode voltar a ela quando quiser.',
      action: 'Continuar');

  static Future<String?> _askPassword(BuildContext context) {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        backgroundColor: const Color(0xFF171022),
        title: const Text('Confirme sua senha'),
        content: TextField(
          controller: c,
          obscureText: true,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Senha'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('Confirmar')),
        ],
      ),
    );
  }

  /// Confirma a identidade (exigido pelo Firebase para apagar a conta).
  /// Retorna false se a pessoa cancelou.
  static Future<bool> _reauthenticate(BuildContext context, User user) async {
    if (user.isAnonymous) return true;
    final ids = user.providerData.map((p) => p.providerId).toList();
    if (ids.contains('google.com')) {
      await user.reauthenticateWithProvider(
        GoogleAuthProvider()..setCustomParameters({'prompt': 'select_account'}),
      );
      return true;
    }
    if (ids.contains('password') && user.email != null) {
      final pass = await _askPassword(context);
      if (pass == null || pass.isEmpty) return false;
      await user.reauthenticateWithCredential(
        EmailAuthProvider.credential(email: user.email!, password: pass),
      );
      return true;
    }
    return true;
  }

  static Future<void> _deleteSub(DocumentReference<Map<String, dynamic>> ref, String name) async {
    try {
      final snap = await ref.collection(name).get();
      for (final d in snap.docs) {
        await d.reference.delete();
      }
    } catch (_) {}
  }

  /// Apaga a conta de forma definitiva. Retorna true se foi apagada.
  static Future<bool> deleteAccount(BuildContext context) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return false;
    final ok = await _confirm(context,
        title: 'Apagar conta',
        message: 'Isso apaga sua conta e seu perfil do LoveMix para sempre. Moedas, diamantes e molduras serão perdidos. Essa ação não pode ser desfeita.',
        action: 'Apagar',
        danger: true);
    if (!ok || !context.mounted) return false;
    final messenger = ScaffoldMessenger.of(context);
    try {
      // 1) confirma a identidade antes de apagar qualquer dado
      if (!await _reauthenticate(context, user)) return false;

      // 2) apaga os dados do perfil (melhor esforço)
      final ref = FirebaseFirestore.instance.collection('users').doc(user.uid);
      for (final s in const ['following', 'followers', 'blocked', 'passed', 'profileLikes']) {
        await _deleteSub(ref, s);
      }
      try {
        await ref.delete();
      } catch (_) {}

      // 3) apaga o login
      await user.delete();
      await FirebaseAuth.instance.signOut();
      return true;
    } on FirebaseAuthException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(
        e.code == 'wrong-password' || e.code == 'invalid-credential'
            ? 'Senha incorreta.'
            : e.code == 'requires-recent-login'
                ? 'Por segurança, saia e entre de novo antes de apagar a conta.'
                : e.code == 'web-context-canceled' || e.code == 'user-cancelled'
                    ? 'Confirmação cancelada.'
                    : 'Não foi possível apagar a conta (${e.code}).',
      )));
    } catch (_) {
      messenger.showSnackBar(const SnackBar(content: Text('Não foi possível apagar a conta agora.')));
    }
    return false;
  }
}
