import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../data/gift_catalog.dart';
import '../services/data_service.dart';

const _pink = Color(0xFFFF19B8);
const _purple = Color(0xFF8D35FF);
const _panel = Color(0xFF171022);

class GiftsScreen extends StatefulWidget {
  const GiftsScreen({super.key, this.initialUid = ''});
  final String initialUid;
  @override
  State<GiftsScreen> createState() => _GiftsScreenState();
}

class _GiftsScreenState extends State<GiftsScreen> {
  late final TextEditingController _uidController;
  Map<String, dynamic>? _recipient;
  String? _recipientUid;
  Map<String, dynamic>? _selectedGift;
  bool _searching = false;
  bool _sending = false;

  List<Map<String, dynamic>> get _catalog => [...kRoomGifts, ...kAllianceRings];

  @override
  void initState() {
    super.initState();
    _uidController = TextEditingController(text: widget.initialUid);
    if (widget.initialUid.isNotEmpty) WidgetsBinding.instance.addPostFrameCallback((_) => _findRecipient());
  }

  @override
  void dispose() { _uidController.dispose(); super.dispose(); }

  Future<void> _findRecipient() async {
    final id = _uidController.text.trim();
    if (id.isEmpty) return;
    if (id == FirebaseAuth.instance.currentUser?.uid) {
      _toast('Você não pode enviar presente para si mesmo.'); return;
    }
    FocusScope.of(context).unfocus();
    setState(() { _searching = true; _recipient = null; _recipientUid = null; _selectedGift = null; });
    try {
      final db = FirebaseFirestore.instance;
      var snap = await db.collection('users').doc(id).get();
      var foundUid = id;
      // Aceita também o ID público curto (ex.: LM-AB12CD34 ou AB12CD34).
      if (!snap.exists) {
        final publicId = id.toUpperCase().replaceFirst(RegExp(r'^LM-'), '').replaceAll(RegExp(r'[^A-Z0-9]'), '');
        if (publicId.isNotEmpty) {
          final q = await db.collection('users').where('publicId', isEqualTo: publicId).limit(1).get();
          if (q.docs.isNotEmpty) { snap = q.docs.first; foundUid = snap.id; }
        }
      }
      if (!snap.exists) throw Exception('Perfil não encontrado. Confira o UID.');
      if (foundUid == FirebaseAuth.instance.currentUser?.uid) {
        throw Exception('Você não pode enviar presente para si mesmo.');
      }
      final data = snap.data() ?? <String, dynamic>{};
      if ((data['profileVisibility'] ?? 'public') != 'public') {
        throw Exception('Esse perfil é privado e não pode receber presentes por UID.');
      }
      if (!mounted) return;
      setState(() { _recipient = data; _recipientUid = foundUid; });
    } on FirebaseException catch (e) {
      _toast(e.code == 'permission-denied'
          ? 'Sem permissão para ler esse perfil. Publique as regras do Firestore.'
          : 'Erro ao buscar: ${e.message ?? e.code}');
    } catch (e) { _toast(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => _searching = false); }
  }

  Future<void> _send() async {
    final recipientUid = _recipientUid;
    final gift = _selectedGift;
    if (recipientUid == null || gift == null || _sending) return;
    setState(() => _sending = true);
    try {
      final chatId = await DataService.instance.openGiftChat(recipientUid);
      await DataService.instance.sendDirectGift(
        chatId: chatId, recipientUid: recipientUid, giftId: gift['id'].toString());
      if (!mounted) return;
      _toast('Presente enviado para ${( _recipient?['name'] ?? 'o perfil').toString()}! 💜');
      setState(() { _selectedGift = null; });
    } catch (e) { _toast(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => _sending = false); }
  }

  void _toast(String message) => ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(message), backgroundColor: _panel));

  @override
  Widget build(BuildContext context) {
    final name = (_recipient?['name'] ?? 'Usuário').toString();
    final photo = (_recipient?['photoUrl'] ?? '').toString();
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Presentes 💍'), backgroundColor: const Color(0xFF160925)),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(colors: [Color(0xFF3B075C), Color(0xFF170A2B)]),
          border: Border.all(color: _purple)),
          child: const Row(children: [Text('🎁', style: TextStyle(fontSize: 42)), SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Envie um presente', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
            SizedBox(height: 5), Text('Envie para alguém pelo UID do perfil, mesmo fora de uma sala ao vivo.', style: TextStyle(color: Colors.white70)),
          ]))]),
        ),
        const SizedBox(height: 18),
        const Text('UID do perfil', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(child: TextField(
            controller: _uidController,
            style: const TextStyle(color: Colors.white),
            textInputAction: TextInputAction.search,
            autocorrect: false,
            enableSuggestions: false,
            onSubmitted: (_) => _findRecipient(),
            decoration: InputDecoration(
              hintText: 'Cole o UID da pessoa', hintStyle: const TextStyle(color: Colors.white54),
              filled: true, fillColor: _panel,
              prefixIcon: const Icon(Icons.person_search, color: _purple),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _purple)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _purple)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _pink, width: 1.6)),
            ),
          )),
          const SizedBox(width: 8),
          SizedBox(width: 92, height: 54, child: ElevatedButton(
            onPressed: _searching ? null : _findRecipient,
            style: ElevatedButton.styleFrom(
              backgroundColor: _pink, foregroundColor: Colors.white,
              minimumSize: const Size(92, 54), padding: EdgeInsets.zero),
            child: _searching
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Text('Buscar'),
          )),
        ]),
        if (_recipient != null) ...[
          const SizedBox(height: 14),
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: _purple)), child: Row(children: [
            CircleAvatar(radius: 27, backgroundColor: _purple, backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null, child: photo.isEmpty ? const Icon(Icons.person, color: Colors.white) : null),
            const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)), Text('UID: $_recipientUid', style: const TextStyle(color: Colors.white60, fontSize: 11))])),
            const Icon(Icons.verified, color: Colors.greenAccent),
          ])),
          const SizedBox(height: 18),
          const Text('Escolha o presente', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)),
          const SizedBox(height: 10),
          GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: _catalog.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 9, mainAxisSpacing: 9, childAspectRatio: .88),
            itemBuilder: (context, index) {
              final item = _catalog[index]; final selected = _selectedGift?['id'] == item['id'];
              return InkWell(onTap: () => setState(() => _selectedGift = item), borderRadius: BorderRadius.circular(13), child: Container(
                padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(13), border: Border.all(color: selected ? _pink : _purple.withOpacity(.55), width: selected ? 2.5 : 1)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text((item['emoji'] ?? '🎁').toString(), style: const TextStyle(fontSize: 28)), const SizedBox(height: 4),
                  Text((item['name'] ?? 'Presente').toString(), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 3), Text('${item['cost']} ${item['currency'] == 'diamonds' ? '💎' : '🪙'}', style: const TextStyle(color: Color(0xFFFFD45C), fontWeight: FontWeight.w900, fontSize: 10))]),
              ));
            }),
          const SizedBox(height: 16),
          SizedBox(height: 52, child: ElevatedButton.icon(onPressed: _selectedGift == null || _sending ? null : _send,
            style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28))),
            icon: _sending ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send),
            label: Text(_sending ? 'Enviando...' : 'Enviar presente'))),
        ],
      ])),
    );
  }
}
