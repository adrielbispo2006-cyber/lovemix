import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../services/data_service.dart';
import '../widgets/profile_frame.dart';
import '../widgets/vip_nickname.dart';
import 'profile_view_screen.dart';

/// Busca de pessoas pela lupa: por ID público (ex.: MUSHB756) ou por nome.
class PeopleSearchScreen extends StatefulWidget {
  const PeopleSearchScreen({super.key});
  @override
  State<PeopleSearchScreen> createState() => _PeopleSearchScreenState();
}

class _PeopleSearchScreenState extends State<PeopleSearchScreen> {
  static const _pink = Color(0xFFFF19B8);
  final _ctrl = TextEditingController();
  List<QueryDocumentSnapshot<Map<String, dynamic>>> _all = [];
  List<DocumentSnapshot<Map<String, dynamic>>> _exact = [];
  StreamSubscription? _sub;
  bool _searching = false;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _sub = DataService.instance.discoverUsers().listen((s) {
      if (mounted) setState(() => _all = s.docs);
    }, onError: (_) {});
  }

  @override
  void dispose() { _sub?.cancel(); _ctrl.dispose(); super.dispose(); }

  String _clean(String v) {
    var id = v.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9-]'), '');
    if (id.startsWith('LM-')) id = id.substring(3);
    return id;
  }

  Future<void> _onChanged(String v) async {
    setState(() => _q = v.trim());
    final id = _clean(v);
    if (id.length < 4) { setState(() => _exact = []); return; }
    setState(() => _searching = true);
    try {
      final r = await DataService.instance.findUserByPublicId(id);
      if (mounted && _clean(_ctrl.text) == id) setState(() => _exact = r.docs);
    } catch (_) {
      if (mounted) setState(() => _exact = []);
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _q.toLowerCase();
    final id = _clean(_q);
    final seen = <String>{};
    final results = <DocumentSnapshot<Map<String, dynamic>>>[];
    for (final d in _exact) { if (seen.add(d.id)) results.add(d); }
    if (q.isNotEmpty) {
      for (final d in _all) {
        final data = d.data();
        if (data['isActive'] == false) continue;
        final name = (data['name'] ?? '').toString().toLowerCase();
        final pid = (data['publicId'] ?? '').toString().toUpperCase();
        if ((name.contains(q) || (id.isNotEmpty && pid.contains(id))) && seen.add(d.id)) results.add(d);
      }
    }
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(
        backgroundColor: const Color(0xFF080510),
        titleSpacing: 0,
        title: TextField(
          controller: _ctrl,
          autofocus: true,
          onChanged: _onChanged,
          textInputAction: TextInputAction.search,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Buscar por ID ou nome',
            hintStyle: TextStyle(color: Colors.white54),
            border: InputBorder.none,
          ),
        ),
        actions: [
          if (_q.isNotEmpty)
            IconButton(icon: const Icon(Icons.close), onPressed: () { _ctrl.clear(); _onChanged(''); }),
        ],
      ),
      body: _q.isEmpty
          ? const Center(child: Padding(padding: EdgeInsets.all(28), child: Text(
              'Digite o ID da pessoa (ex.: MUSHB756) ou o nome para encontrar o perfil.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white60))))
          : results.isEmpty
              ? Center(child: _searching
                  ? const CircularProgressIndicator(color: _pink)
                  : const Text('Nenhuma pessoa encontrada.', style: TextStyle(color: Colors.white60)))
              : ListView.separated(
                  padding: const EdgeInsets.all(14),
                  itemCount: results.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) {
                    final doc = results[i];
                    final p = doc.data() ?? <String, dynamic>{};
                    final name = (p['name'] ?? 'Pessoa').toString();
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: doc.id))),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF171022),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFF8D35FF).withOpacity(.35))),
                        child: Row(children: [
                          ProfileFrameAvatar(photoUrl: (p['photoUrl'] ?? '').toString(), frameId: (p['selectedProfileFrame'] ?? 'classic').toString(), size: 54),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            VipNickname(name: name, isVip: (p['isVip'] == true || p['nicknameDecorationActive'] == true), styleId: (p['vipNicknameStyle'] ?? 'royal_gold').toString(), textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 3),
                            Text('ID: ${(p['publicId'] ?? '—')}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
                          ])),
                          const Icon(Icons.chevron_right, color: _pink),
                        ]),
                      ),
                    );
                  },
                ),
    );
  }
}
