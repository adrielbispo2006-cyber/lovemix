import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../widgets/profile_frame.dart';

class ProfileFramesScreen extends StatefulWidget {
  const ProfileFramesScreen({super.key});
  @override
  State<ProfileFramesScreen> createState() => _ProfileFramesScreenState();
}

class _ProfileFramesScreenState extends State<ProfileFramesScreen> {
  static const _pink = Color(0xFFFF19B8);
  static const _purple = Color(0xFF8D35FF);
  bool busy = false;
  bool migrated = false;
  /// Molduras compradas que ficaram salvas só neste celular (versões antigas).
  Set<String> _localOwned = {};

  Future<Set<String>> _readLocalOwned(String uid) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final valid = items.map((e) => e['id'] as String).toSet();
      return (prefs.getStringList('lovemix_frames_${uid}_owned') ?? const <String>[]).where(valid.contains).toSet();
    } catch (_) {
      return <String>{};
    }
  }

  /// Guarda também no celular cada moldura comprada (cópia de segurança).
  Future<void> _rememberLocal(String uid, Iterable<String> owned) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'lovemix_frames_${uid}_owned';
      final merged = <String>{...(prefs.getStringList(key) ?? const <String>[]), ...owned}.toList();
      await prefs.setStringList(key, merged);
    } catch (_) {}
  }

  @override
  void initState() {
    super.initState();
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) _readLocalOwned(uid).then((v) { if (mounted) setState(() => _localOwned = v); });
  }

  /// Molduras compradas antes desta correção ficavam só no aparelho.
  /// Na primeira abertura elas são enviadas para a conta, sem cobrar de novo.
  Future<void> _migrateLocal(String uid, List<String> remoteOwned) async {
    if (migrated) return;
    migrated = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final local = prefs.getStringList('lovemix_frames_${uid}_owned') ?? const <String>[];
      final valid = items.map((e) => e['id'] as String).toSet();
      final merged = <String>{...remoteOwned, ...local.where(valid.contains)}.toList();
      if (merged.length != remoteOwned.length) {
        await FirebaseFirestore.instance.collection('users').doc(uid)
            .set({'ownedProfileFrames': merged}, SetOptions(merge: true));
      }
    } catch (_) {}
  }

  final items = const [
    {'id':'classic','name':'Clássica','description':'Moldura padrão do LoveMix','emoji':'💜','currency':'free','cost':0},
    {'id':'gatinha_neon','name':'Gatinha Neon','description':'Orelhinhas, bigodes e patinhas em neon','emoji':'🐱','currency':'coins','cost':500},
    {'id':'gatinho_gamer','name':'Gatinho Gamer','description':'Fones com orelhas de gato e patinha','emoji':'🎧','currency':'coins','cost':600},
    {'id':'orbita_amor','name':'Órbita do Amor','description':'Corações em órbita com brilho violeta','emoji':'💞','currency':'coins','cost':700},
    {'id':'neon_coracao','name':'Neon Coração','description':'Neon rosa com coroa pingando e corações','emoji':'💗','currency':'coins','cost':800},
    {'id':'galaxia_roxa','name':'Galáxia Roxa','description':'Planetas e anéis cósmicos luminosos','emoji':'🪐','currency':'coins','cost':900},
    {'id':'rosas_rosa','name':'Rosas Rosa','description':'Rosas rosa com corações dourados','emoji':'🌹','currency':'coins','cost':1000},
    {'id':'jardim_roxo','name':'Jardim Roxo','description':'Rosas roxas, folhas de ouro e correntes','emoji':'🌸','currency':'coins','cost':1200},
    {'id':'chamas_reais','name':'Chamas Reais','description':'Chamas violeta com coroa dourada','emoji':'🔥','currency':'coins','cost':1400},
    {'id':'laco_real','name':'Laço Real','description':'Fita roxa e dourada com laço e coroa','emoji':'🎀','currency':'coins','cost':1500},
    {'id':'rosa_negra_real','name':'Rosa Negra Real','description':'Coroa negra, rosas escuras e cristais','emoji':'🖤','currency':'coins','cost':1700},
    {'id':'gotica_sombria','name':'Gótica Sombria','description':'Correntes, cruz, rosas e chamas roxas','emoji':'⛓️','currency':'coins','cost':1800},
    {'id':'cadeado_amor','name':'Cadeado do Amor','description':'Correntes de prata com coração-cadeado','emoji':'🔒','currency':'coins','cost':2000},
    {'id':'coroa_louros','name':'Coroa de Louros','description':'Coroa, louros dourados e coração de cristal','emoji':'👑','currency':'coins','cost':2300},
    {'id':'asas_celestiais','name':'Asas Celestiais','description':'Asas violeta, coroa e coração dourado','emoji':'🪽','currency':'coins','cost':2600},
    {'id':'asas_reais','name':'Asas Reais','description':'Asas de ouro, coroa e coração de cristal','emoji':'💜','currency':'diamonds','cost':1700},
    {'id':'vip_dourado','name':'VIP Dourado','description':'Aro de pincel dourado com placa VIP','emoji':'⭐','currency':'diamonds','cost':2000},
    {'id':'ouro_alado','name':'Asas de Ouro','description':'Coroa dourada, asas de ouro e coração','emoji':'👑','currency':'diamonds','cost':2400},
    {'id':'coracoes_laco','name':'Corações e Laço','description':'Corações rosa brilhantes com laço pink','emoji':'🎀','currency':'coins','cost':700},
    {'id':'rosas_rubi','name':'Rosas Rubi','description':'Coroa prateada, rosas vermelhas e cristais','emoji':'🌹','currency':'coins','cost':1600},
    {'id':'borboletas_azuis','name':'Borboletas Azuis','description':'Rosas azuis, borboletas e coroa de gelo','emoji':'🦋','currency':'coins','cost':1900},
    {'id':'anjo_halo','name':'Anjo com Halo','description':'Asas brancas, halo dourado e coração','emoji':'😇','currency':'diamonds','cost':1800},
    {'id':'borboletas_roxas','name':'Borboletas Roxas','description':'Chamas violeta com borboletas neon','emoji':'🦋','currency':'coins','cost':1300},
    {'id':'dragao_verde','name':'Dragão Verde','description':'Dragão em chamas verdes com coroa','emoji':'🐲','currency':'diamonds','cost':2100},
    {'id':'gatinho_fofo','name':'Gatinho Fofo','description':'Orelhinhas, patinhas e gatinho sorridente','emoji':'🐱','currency':'coins','cost':650},
    {'id':'correntes_prata','name':'Correntes de Prata','description':'Correntes com coração-cadeado','emoji':'🔗','currency':'coins','cost':2100},
    {'id':'leao_fogo','name':'Leão de Fogo','description':'Leão dourado com chamas e coroa real','emoji':'🦁','currency':'diamonds','cost':2600},
    {'id':'rosas_prata','name':'Rosas de Prata','description':'Rosas prateadas, borboletas e coroa','emoji':'🤍','currency':'coins','cost':1500},
    {'id':'estrelas_ouro','name':'Estrelas de Ouro','description':'Estrelas douradas girando em órbita','emoji':'⭐','currency':'coins','cost':800},
    {'id':'realeza_gotas','name':'Realeza Roxa','description':'Coroa roxa pingando com corações','emoji':'💜','currency':'coins','cost':1750},
    {'id':'paraiso_tropical','name':'Paraíso Tropical','description':'Palmeira, hibisco e pássaros em neon','emoji':'🌴','currency':'coins','cost':1100},
    {'id':'sakura','name':'Sakura','description':'Flores de cerejeira com lanterna vermelha','emoji':'🌸','currency':'coins','cost':1250},
    {'id':'gamer_neon','name':'Gamer Neon','description':'Fones, controle e raios elétricos','emoji':'🎮','currency':'coins','cost':1450},
    {'id':'amor_vermelho','name':'Amor Vermelho','description':'Laço vermelho, rosas e corações','emoji':'❤️','currency':'coins','cost':900},
    {'id':'coroa_rubi','name':'Coroa Rubi','description':'Fita vermelha, louros e coroa dourada','emoji':'👑','currency':'coins','cost':2400},
    {'id':'hacker_verde','name':'Hacker Verde','description':'Capuz, caveira e chamas verdes','emoji':'💀','currency':'coins','cost':2200},
    {'id':'borboletas_lilas','name':'Borboletas Lilás','description':'Borboletas e rosas roxas luminosas','emoji':'🦋','currency':'coins','cost':1350},
    {'id':'inverno_gelo','name':'Inverno de Gelo','description':'Flocos de neve e boneco de neve','emoji':'⛄','currency':'coins','cost':950},
    {'id':'arco_iris','name':'Arco-Íris','description':'Aro arco-íris com corações coloridos','emoji':'🌈','currency':'coins','cost':1650},
    {'id':'rosas_poker','name':'Rosas e Pôquer','description':'Rosas vermelhas com carta de ás','emoji':'🃏','currency':'coins','cost':2000},
    {'id':'lua_planetas','name':'Lua e Planetas','description':'Lua, planetas e estrelas douradas','emoji':'🪐','currency':'coins','cost':1050},
    {'id':'asas_cristal','name':'Asas de Cristal','description':'Asas de gelo, coroa e coração de cristal','emoji':'💎','currency':'diamonds','cost':2300},
    {'id':'vip_imperial','name':'VIP Imperial','description':'Asas de ouro, coroa, diamantes e placa VIP','emoji':'👑','currency':'diamonds','cost':2800},
    {'id':'lovemix_neon','name':'LoveMix Neon','description':'Laço roxo, rosa e corações em neon','emoji':'💜','currency':'coins','cost':1800},
    {'id':'dragao_rubro','name':'Dragão Rubro','description':'Dragão negro e vermelho com rosas rubi','emoji':'🐉','currency':'diamonds','cost':3000},
    {'id':'rainha_gelo','name':'Rainha de Gelo','description':'Cristais de gelo, flocos e coroa azul','emoji':'❄️','currency':'coins','cost':3000},
    {'id':'meow_neon','name':'Meow Neon','description':'Orelhinhas, laço e patinhas rosa em neon','emoji':'🐾','currency':'coins','cost':900},
    {'id':'anjo_dourado','name':'Anjo Dourado','description':'Asas brancas, halo e nuvens com placa Anjo','emoji':'😇','currency':'diamonds','cost':2000},
    {'id':'princesa_borboletas','name':'Princesa Borboletas','description':'Borboletas roxas, cristais e coroinha','emoji':'🦋','currency':'coins','cost':1500},
    {'id':'verao_pordosol','name':'Verão','description':'Pôr do sol, palmeiras e hibisco tropical','emoji':'🌅','currency':'coins','cost':1300},
    {'id':'music_neon','name':'Music Neon','description':'Fones neon, notas musicais e equalizador','emoji':'🎧','currency':'coins','cost':1400},
    {'id':'amor_ouro','name':'Amor Ouro','description':'Rosas vermelhas, coroa dourada e diamantes','emoji':'🌹','currency':'coins','cost':2500},
    {'id':'rainha_asas','name':'Rainha Asas','description':'Asas azul e rosa, coroa e coração de cristal','emoji':'👸','currency':'diamonds','cost':2200},
    {'id':'love_perolas','name':'Love Pérolas','description':'Rosas champanhe, pérolas e correntes de ouro','emoji':'🤍','currency':'coins','cost':2700},
    {'id':'halloween','name':'Halloween','description':'Chapéu de bruxa, abóboras e chamas roxas','emoji':'🎃','currency':'coins','cost':1900},
    {'id':'elite_negra','name':'Elite','description':'Rosas negras, coroa e diamantes com placa Elite','emoji':'🖤','currency':'diamonds','cost':1900},
    {'id':'mar_azul','name':'Mar Azul','description':'Golfinhos, ondas, conchas e coroa dourada','emoji':'🐬','currency':'coins','cost':2200},
    {'id':'love_arcoiris','name':'Love Arco-Íris','description':'Arco-íris neon, nuvens e corações','emoji':'🌈','currency':'coins','cost':1700},
    // Coleção Corações Neon (corações subindo e explodindo)
    {'id':'coroa_alada','name':'Coroa Alada','description':'Coroa de ouro, asas douradas e coração de ametista','emoji':'👑','currency':'coins','cost':2400},
    {'id':'lovemix_coracoes','name':'LoveMix Corações','description':'Aro neon com corações e assinatura LoveMix','emoji':'💗','currency':'coins','cost':1200},
    {'id':'vip_rosas_roxas','name':'VIP Rosas Roxas','description':'Coroa, rosas roxas e brasão VIP dourado','emoji':'💜','currency':'diamonds','cost':2200},
    {'id':'coracao_laco_pink','name':'Coração e Laço Pink','description':'Aro em forma de coração com laço pink','emoji':'🎀','currency':'coins','cost':1100},
    {'id':'anjo_coroado','name':'Anjo Coroado','description':'Asas violeta, coroa e coração de cristal','emoji':'😇','currency':'diamonds','cost':2000},
    {'id':'coracao_sombrio','name':'Coração Sombrio','description':'Correntes, rosa negra e coração batendo','emoji':'🖤','currency':'coins','cost':1600},
    {'id':'ouro_infinito','name':'Ouro Infinito','description':'Aro de ouro, corações brilhantes e infinito','emoji':'♾️','currency':'diamonds','cost':2500},
    {'id':'casal_neon','name':'Casal Neon','description':'Corações neon e casal apaixonado','emoji':'💑','currency':'coins','cost':1500},
    {'id':'jardim_real','name':'Jardim Real','description':'Rosas roxas, borboletas e coroa de ouro','emoji':'🦋','currency':'diamonds','cost':2300},
  ];

  Future<void> _buyOrEquip(Map<String, Object> item) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (busy || uid == null) return;
    final id = item['id'] as String;
    final currency = item['currency'] as String;
    final cost = (item['cost'] as num).toInt();
    setState(() => busy = true);
    try {
      final localOwned = await _readLocalOwned(uid);
      final ref = FirebaseFirestore.instance.collection('users').doc(uid);
      var charged = false;
      // Compra e equipa numa única transação: o saldo da conta é descontado e a
      // moldura fica salva como comprada no perfil, mesmo se reinstalar o app.
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final snap = await tx.get(ref);
        final data = snap.data() ?? <String, dynamic>{};
        // Moldura já comprada (na conta OU salva no celular) não cobra de novo.
        final owned = <String>{
          'classic',
          ...((data['ownedProfileFrames'] as List?)?.map((e) => e.toString()) ?? const <String>[]),
          ...localOwned,
        }.toList();
        final update = <String, dynamic>{};
        charged = false;
        if (!owned.contains(id)) {
          charged = currency != 'free';
          final coins = (data['coins'] as num?)?.toInt() ?? 0;
          final diamonds = (data['diamonds'] as num?)?.toInt() ?? 0;
          if (currency == 'coins') {
            if (coins < cost) throw Exception('Você não tem moedas suficientes.');
            update['coins'] = coins - cost;
          } else if (currency == 'diamonds') {
            if (diamonds < cost) throw Exception('Você não tem diamantes suficientes. Esta moldura é paga com 💎.');
            update['diamonds'] = diamonds - cost;
          }
          owned.add(id);
        }
        update['ownedProfileFrames'] = owned;
        update['selectedProfileFrame'] = id;
        tx.update(ref, update);
      });
      await _rememberLocal(uid, [id]);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(charged
          ? '${item['name']} comprada e equipada!'
          : '${item['name']} equipada! (já era sua, nada foi cobrado)')));
    } catch (e) {
      if (mounted) {
        final msg = e.toString().replaceFirst('Exception: ', '');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
          msg.contains('permission-denied')
              ? 'O Firebase bloqueou a compra. Publique as regras atualizadas (firestore.rules).'
              : msg)));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Molduras de perfil'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData || !snap.data!.exists) {
            return const Center(child: CircularProgressIndicator(color: _pink));
          }
          final data = snap.data!.data() ?? <String, dynamic>{};
          final remoteOwned = <String>{
            'classic',
            ...((data['ownedProfileFrames'] as List?)?.map((e) => e.toString()) ?? const <String>[]),
          }.toList();
          _migrateLocal(uid, remoteOwned);
          final owned = <String>{...remoteOwned, ..._localOwned}.toList();
          final selected = (data['selectedProfileFrame'] ?? 'classic').toString();
          final photo = (data['photoUrl'] ?? '').toString();
          final coins = (data['coins'] as num?)?.toInt() ?? 0;
          final diamonds = (data['diamonds'] as num?)?.toInt() ?? 0;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF32104D), Color(0xFF12091E)]),
              border: Border.all(color: _purple.withOpacity(.7))),
              child: Column(children: [
                const Text('Sua moldura atual', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                ProfileFrameAvatar(photoUrl: photo, frameId: selected, size: 110),
                const SizedBox(height: 10),
                Text(items.firstWhere((e) => e['id'] == selected, orElse: () => items.first)['name'] as String,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('🪙 $coins moedas', style: const TextStyle(color: Color(0xFFFFD56A), fontWeight: FontWeight.bold)),
                  const SizedBox(width: 18),
                  Text('💎 $diamonds diamantes', style: const TextStyle(color: Color(0xFF72E5FF), fontWeight: FontWeight.bold)),
                ]),
              ]),
            ),
            const SizedBox(height: 20),
            const SizedBox(height: 20),
            const Text('Loja de molduras' , style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Molduras compradas ficam salvas na sua conta e não se perdem ao reinstalar o app.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 12),
            // Molduras de diamante aparecem primeiro, depois as de moedas (do mais barato ao mais caro).
            ...([...items]..sort((a, b) {
              int rank(Map<String, Object> e) => e['currency'] == 'diamonds' ? 0 : (e['currency'] == 'free' ? 1 : 2);
              final r = rank(a).compareTo(rank(b));
              return r != 0 ? r : (a['cost'] as num).compareTo(b['cost'] as num);
            })).map((item) {
              final id = item['id'] as String;
              final has = owned.contains(id);
              final active = selected == id;
              final currency = item['currency'] as String;
              final cost = item['cost'];
              return Container(margin: const EdgeInsets.only(bottom: 18), padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 24),
                decoration: BoxDecoration(color: const Color(0xFF171022), borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: active ? _pink : (currency == 'diamonds' ? const Color(0xFF72E5FF).withOpacity(.55) : _purple.withOpacity(.35)))),
                child: Row(children: [
                  ProfileFrameAvatar(photoUrl: photo, frameId: id, size: 62),
                  const SizedBox(width: 13),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${item['emoji']} ${item['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(item['description'] as String, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                    const SizedBox(height: 4),
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(has ? '✅ Já é sua — usar é grátis' : currency == 'free' ? 'Grátis' : currency == 'diamonds' ? '💎 $cost diamantes' : '🪙 $cost moedas',
                        style: TextStyle(color: has ? const Color(0xFF6CF0A0) : currency == 'diamonds' ? const Color(0xFF72E5FF) : const Color(0xFFFFD56A), fontSize: 12, fontWeight: FontWeight.bold)),
                      if (currency == 'diamonds' && !has) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(8),
                            gradient: const LinearGradient(colors: [Color(0xFF3AA8FF), Color(0xFFB45BFF)])),
                          child: const Text('PREMIUM', style: TextStyle(fontSize: 8.5, fontWeight: FontWeight.w900, color: Colors.white)),
                        ),
                      ],
                    ]),
                  ])),
                  const SizedBox(width: 8),
                  SizedBox(width: 100, child: ElevatedButton(
                    onPressed: busy || active ? null : () => _buyOrEquip(item),
                    style: ElevatedButton.styleFrom(backgroundColor: _pink, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10)),
                    child: Text(active ? 'Ativa' : has ? 'Equipar' : 'Comprar', style: const TextStyle(fontSize: 12)),
                  )),
                ]),
              );
            }),
            if (busy) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: _pink))),
          ]);
        },
      ),
    );
  }
}
