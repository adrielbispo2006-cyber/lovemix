import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/data_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool busy = false;
  bool obscurePassword = true;
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  DateTime? birthday;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  bool _isAdult(DateTime date) {
    final today = DateTime.now();
    final age = today.year - date.year -
        ((today.month < date.month ||
                (today.month == date.month && today.day < date.day))
            ? 1
            : 0);
    return age >= 18;
  }

  Future<DateTime?> _askBirthday() async {
    final now = DateTime.now();
    return showDatePicker(
      context: context,
      firstDate: DateTime(1900),
      lastDate: DateTime(now.year - 18, now.month, now.day),
      initialDate: DateTime(now.year - 25, now.month, now.day),
      helpText: 'Confirme que você tem 18 anos ou mais',
    );
  }

  Future<void> _claimFounderIfEligible() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email?.toLowerCase() != 'adrielbispo3009@gmail.com' || !user.emailVerified && user.providerData.every((p) => p.providerId != 'google.com')) return;
    try {
      await FirebaseFunctions.instance.httpsCallable('claimFounderAdmin').call();
    } catch (_) {
      // A função só fica disponível depois de publicar as Cloud Functions.
      // O login normal continua funcionando enquanto isso.
    }
  }

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      show('Informe seu e-mail e sua senha.');
      return;
    }
    if (register && name.text.trim().isEmpty) {
      show('Informe seu nome.');
      return;
    }
    if (register && birthday == null) {
      show('Informe sua data de nascimento.');
      return;
    }
    if (register && !_isAdult(birthday!)) {
      show('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }

    setState(() => busy = true);
    try {
      if (register) {
        final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await cred.user!.updateDisplayName(name.text.trim());
        await DataService.instance.createUser(
          name: name.text.trim(),
          birthday: birthday!,
        );
        await _claimFounderIfEligible();
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        // Tenta conceder a função de fundador e atualiza o token antes de
        // abrir o painel/perfil, para que a interface reconheça a permissão.
        await _claimFounderIfEligible();
        await FirebaseAuth.instance.currentUser?.getIdToken(true);
      }
    } on FirebaseAuthException catch (e) {
      show(_authError(e));
    } catch (e) {
      show('Não foi possível concluir. Verifique sua internet e tente novamente.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> signInGuest() async {
    if (busy) return;
    final guestName = TextEditingController();
    DateTime? guestBirthday;
    final details = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF16091E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: Color(0xFFB000FF)),
          ),
          title: const Text('Entrar como convidado', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: guestName,
                maxLength: 24,
                textCapitalization: TextCapitalization.words,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Como podemos te chamar?',
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  final date = await _askBirthday();
                  if (date != null) setDialogState(() => guestBirthday = date);
                },
                icon: const Icon(Icons.calendar_month),
                label: Text(guestBirthday == null
                    ? 'Data de nascimento (18+)'
                    : '${guestBirthday!.day.toString().padLeft(2, '0')}/${guestBirthday!.month.toString().padLeft(2, '0')}/${guestBirthday!.year}'),
              ),
              const SizedBox(height: 8),
              const Text(
                'O acesso de convidado cria um perfil temporário neste aparelho. Para não perder o acesso, depois vincule uma conta de e-mail.',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (guestName.text.trim().isEmpty || guestBirthday == null) return;
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Continuar'),
            ),
          ],
        ),
      ),
    );
    if (details != true) {
      guestName.dispose();
      return;
    }
    if (!_isAdult(guestBirthday!)) {
      guestName.dispose();
      show('O LoveMix é destinado somente a maiores de 18 anos.');
      return;
    }

    setState(() => busy = true);
    try {
      final credential = await FirebaseAuth.instance.signInAnonymously();
      final user = credential.user;
      if (user == null) throw Exception('Não foi possível criar a sessão de convidado.');
      await user.updateDisplayName(guestName.text.trim());
      await DataService.instance.createUser(
        name: guestName.text.trim(),
        birthday: guestBirthday!,
      );
      await DataService.instance.updateProfile({
        'isGuest': true,
        'guestCreatedAt': FieldValue.serverTimestamp(),
      });
    } on FirebaseAuthException catch (e) {
      show(e.code == 'operation-not-allowed'
          ? 'Ative o provedor Anônimo nas configurações de autenticação do Firebase para liberar o acesso como convidado.'
          : _authError(e));
      if (FirebaseAuth.instance.currentUser?.isAnonymous == true) {
        await FirebaseAuth.instance.signOut();
      }
    } catch (_) {
      if (FirebaseAuth.instance.currentUser?.isAnonymous == true) {
        await FirebaseAuth.instance.signOut();
      }
      show('Não foi possível entrar como convidado. Verifique sua internet e as regras do Firestore.');
    } finally {
      guestName.dispose();
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> signInGoogle() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      // Login Google pelo navegador (Chrome Custom Tab) via Firebase Auth.
      // Não depende do SHA-1 do APK, então funciona com qualquer chave de assinatura.
      final provider = GoogleAuthProvider()
        ..addScope('email')
        ..setCustomParameters({'prompt': 'select_account'});
      final result = await FirebaseAuth.instance.signInWithProvider(provider);
      final user = result.user;
      if (user == null) throw Exception('Não foi possível obter a conta Google.');

      // Cria o perfil no Firestore somente na primeira entrada e solicita
      // data de nascimento para respeitar a regra de uso para maiores de 18.
      final profile = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (!profile.exists) {
        if (!mounted) return;
        final date = await _askBirthday();
        if (date == null) {
          await FirebaseAuth.instance.signOut();
          show('Para criar sua conta, confirme sua data de nascimento.');
          return;
        }
        if (!_isAdult(date)) {
          await FirebaseAuth.instance.signOut();
          show('O LoveMix é destinado somente a maiores de 18 anos.');
          return;
        }
        final displayName = (user.displayName ?? '').trim();
        final fallbackName = user.email?.split('@').first ?? 'Pessoa LoveMix';
        await DataService.instance.createUser(
          name: displayName.isEmpty ? fallbackName : displayName,
          birthday: date,
        );
      }
      // Não bloqueia a transição para a tela principal aguardando uma função
      // administrativa opcional do Firebase.
      await _claimFounderIfEligible();
      await FirebaseAuth.instance.currentUser?.getIdToken(true);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'web-context-canceled' || e.code == 'canceled' || e.code == 'popup-closed-by-user') return;
      show(_authError(e));
    } on PlatformException catch (e) {
      final details = '${e.code}: ${e.message ?? e.details ?? 'sem detalhes'}';
      if (details.contains('10') ||
          details.contains('DEVELOPER_ERROR') ||
          details.contains('sign_in_failed')) {
        show('O Google recusou este APK (DEVELOPER_ERROR). O pacote deve ser com.example.lovemix e o SHA-1 da chave que assinou este APK precisa estar cadastrado no Firebase. Depois baixe um novo google-services.json e gere outro APK. Detalhe: $details');
      } else {
        show('Falha no seletor do Google ($details). Atualize o Google Play Services e tente novamente.');
      }
    } catch (e) {
      show('Não foi possível concluir o login Google: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _authError(FirebaseAuthException e) {
    switch (e.code) {
      case 'invalid-email':
        return 'O e-mail informado é inválido.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'E-mail ou senha incorretos.';
      case 'email-already-in-use':
        return 'Este e-mail já possui uma conta. Tente entrar.';
      case 'weak-password':
        return 'Escolha uma senha com pelo menos 6 caracteres.';
      case 'network-request-failed':
        return 'Sem conexão. Verifique sua internet e tente novamente.';
      case 'operation-not-allowed':
        return 'Este método de login ainda não foi ativado no Firebase.';
      case 'configuration-not-found':
        return 'Configuração de autenticação ausente no Firebase. Confira o provedor e as configurações do aplicativo.';
      default:
        return e.message ?? 'Não foi possível autenticar. Tente novamente.';
    }
  }

  void show(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _openEmailForm({bool createAccount = false}) async {
    register = createAccount;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final bottomInset = MediaQuery.of(context).viewInsets.bottom;
          return Padding(
            padding: EdgeInsets.only(bottom: bottomInset),
            child: Container(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .88),
              decoration: const BoxDecoration(
                color: Color(0xFF100719),
                borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
                border: Border(top: BorderSide(color: Color(0xFFB000FF), width: 1.5)),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(8))),
                    const SizedBox(height: 18),
                    Row(children: [
                      const Spacer(),
                      Text(register ? 'Criar uma conta' : 'Boas-vindas de volta', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
                      const Spacer(),
                      IconButton(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.close, color: Colors.white70)),
                    ]),
                    if (register) ...[
                      TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Nome completo', prefixIcon: Icon(Icons.person_outline))),
                      const SizedBox(height: 12),
                    ],
                    TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(hintText: 'E-mail', prefixIcon: Icon(Icons.email_outlined))),
                    const SizedBox(height: 12),
                    TextField(
                      controller: password,
                      obscureText: obscurePassword,
                      autofillHints: register ? const [AutofillHints.newPassword] : const [AutofillHints.password],
                      decoration: InputDecoration(
                        hintText: 'Senha',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setSheetState(() => obscurePassword = !obscurePassword),
                          icon: Icon(obscurePassword ? Icons.visibility : Icons.visibility_off),
                        ),
                      ),
                    ),
                    if (register) ...[
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: busy ? null : () async {
                          final d = await _askBirthday();
                          if (d != null && mounted) setSheetState(() => birthday = d);
                        },
                        icon: const Icon(Icons.calendar_month),
                        label: Text(birthday == null ? 'Data de nascimento (18+)' : '${birthday!.day}/${birthday!.month}/${birthday!.year}'),
                      ),
                    ],
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: busy ? null : () async {
                          setSheetState(() => busy = true);
                          await submit();
                          if (!mounted || !sheetContext.mounted) return;
                          // Fecha a folha assim que FirebaseAuth confirmar a
                          // sessão; o StreamBuilder raiz abre a Home/perfil.
                          if (FirebaseAuth.instance.currentUser != null) {
                            Navigator.of(sheetContext).pop();
                          } else {
                            setSheetState(() => busy = false);
                          }
                        },
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF22B7), shape: const StadiumBorder()),
                        child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(register ? 'Criar minha conta' : 'Entrar'),
                      ),
                    ),
                    TextButton(
                      onPressed: busy ? null : () => setSheetState(() => register = !register),
                      child: Text(register ? 'Já tem uma conta? Entrar' : 'Não tem uma conta? Criar conta', style: const TextStyle(color: Color(0xFFFF4CC7))),
                    ),
                    if (!register)
                      TextButton(
                        onPressed: busy ? null : () async {
                          if (email.text.trim().isEmpty) return show('Digite seu e-mail primeiro.');
                          try {
                            await FirebaseAuth.instance.sendPasswordResetEmail(email: email.text.trim());
                            show('Enviamos um link de recuperação para seu e-mail.');
                          } on FirebaseAuthException catch (e) { show(_authError(e)); }
                        },
                        child: const Text('Esqueci minha senha', style: TextStyle(color: Color(0xFFFF4CC7))),
                      ),
                    const SizedBox(height: 6),
                    const Text('Acesso exclusivo para maiores de 18 anos', style: TextStyle(color: Colors.white38, fontSize: 11)),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // Tela inicial idêntica ao layout de referência (852 x 1846).
  // Todas as medidas abaixo estão em pixels da referência e são escaladas
  // pela largura do aparelho, mantendo as proporções em qualquer tela.
  Widget _buildLanding(BuildContext context) {
    const refW = 852.0;
    const refH = 1846.0;
    final media = MediaQuery.of(context);
    final w = media.size.width;
    final s = w / refW;
    final totalH = (refH * s) > media.size.height ? refH * s : media.size.height;

    Widget box(double x, double y, double bw, double bh, Widget child) => Positioned(
          left: x * s,
          top: y * s,
          width: bw * s,
          height: bh * s,
          child: child,
        );

    Widget pill({
      required double x,
      required double y,
      required double bw,
      required double bh,
      required BoxDecoration decoration,
      required VoidCallback? onTap,
      required Widget child,
    }) {
      return box(
        x,
        y,
        bw,
        bh,
        DecoratedBox(
          decoration: decoration,
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              customBorder: const StadiumBorder(),
              onTap: onTap,
              child: child,
            ),
          ),
        ),
      );
    }

    Widget socialButton({
      required double y,
      required String logo,
      required String label,
      required VoidCallback onTap,
    }) {
      return pill(
        x: 108,
        y: y,
        bw: 635,
        bh: 72,
        decoration: BoxDecoration(
          color: const Color(0xFF12001A).withValues(alpha: .85),
          borderRadius: BorderRadius.circular(100),
          border: Border.all(color: const Color(0xFF573769), width: 2 * s),
        ),
        onTap: busy ? null : onTap,
        child: Stack(
          children: [
            Positioned(
              left: (210 - 108) * s,
              top: 11 * s,
              width: 46 * s,
              height: 50 * s,
              child: Image.asset(logo, fit: BoxFit.contain),
            ),
            Positioned.fill(
              child: Padding(
                padding: EdgeInsets.only(left: (322 - 108) * s),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    label,
                    style: TextStyle(color: Colors.white, fontSize: 28 * s, fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    Widget badge(double x0, double x1, IconData icon, String line1, String line2) {
      return box(
        x0,
        1632,
        x1 - x0,
        125,
        Column(
          children: [
            ShaderMask(
              shaderCallback: (r) => const LinearGradient(
                colors: [Color(0xFFD22BF0), Color(0xFF8E2BFF)],
              ).createShader(r),
              child: Icon(icon, size: 56 * s, color: Colors.white),
            ),
            SizedBox(height: 4 * s),
            Text(
              '$line1\n$line2',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 24 * s, height: 1.12, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      );
    }

    Widget vDivider(double x) => box(
          x - 1,
          1638,
          2,
          100,
          const DecoratedBox(decoration: BoxDecoration(color: Color(0xFF67507A))),
        );

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: MediaQuery(
        data: media.copyWith(textScaler: TextScaler.noScaling),
        child: Scaffold(
          backgroundColor: const Color(0xFF08000F),
          body: SingleChildScrollView(
            child: SizedBox(
              width: w,
              height: totalH,
              child: Stack(
                children: [
                  // Fundo
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFF0B0014), Color(0xFF09000F), Color(0xFF08010E)],
                        ),
                      ),
                    ),
                  ),
                  // Casal + logo + balões + slogan
                  Positioned(
                    left: 0,
                    top: 0,
                    width: w,
                    height: 1130 * s,
                    child: Image.asset(
                      'assets/auth/auth_hero.webp',
                      fit: BoxFit.fill,
                      filterQuality: FilterQuality.high,
                    ),
                  ),
                  // Corações decorativos dos cantos inferiores
                  Positioned(
                    left: 0,
                    top: 1740 * s,
                    width: 80 * s,
                    height: 106 * s,
                    child: IgnorePointer(child: Image.asset('assets/auth/corner_left.png', fit: BoxFit.fill)),
                  ),
                  Positioned(
                    left: 760 * s,
                    top: 1735 * s,
                    width: 92 * s,
                    height: 111 * s,
                    child: IgnorePointer(child: Image.asset('assets/auth/corner_right.png', fit: BoxFit.fill)),
                  ),
                  // "Pular" (visual já está na imagem; aqui fica a área de toque)
                  box(
                    661,
                    88,
                    157,
                    70,
                    Material(
                      type: MaterialType.transparency,
                      child: InkWell(
                        customBorder: const StadiumBorder(),
                        onTap: busy ? null : signInGuest,
                      ),
                    ),
                  ),
                  // Criar Conta
                  pill(
                    x: 58,
                    y: 1140,
                    bw: 735,
                    bh: 114,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFB0CB4), Color(0xFFD806E0), Color(0xFF7A03F6)],
                      ),
                      borderRadius: BorderRadius.circular(100),
                      boxShadow: [
                        BoxShadow(color: const Color(0xFFE000D0).withValues(alpha: .35), blurRadius: 22 * s),
                      ],
                    ),
                    onTap: busy ? null : () => _openEmailForm(createAccount: true),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.person_add_alt_1, color: Colors.white, size: 58 * s),
                            SizedBox(width: 26 * s),
                            Text(
                              'Criar Conta',
                              style: TextStyle(color: Colors.white, fontSize: 40 * s, fontWeight: FontWeight.w700),
                            ),
                          ],
                        ),
                        Positioned(
                          right: 44 * s,
                          child: Icon(Icons.chevron_right_rounded, color: Colors.white, size: 56 * s),
                        ),
                      ],
                    ),
                  ),
                  // Entrar
                  pill(
                    x: 58,
                    y: 1281,
                    bw: 735,
                    bh: 99,
                    decoration: BoxDecoration(
                      color: const Color(0xFF090111),
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(color: const Color(0xFFA630D6), width: 3 * s),
                    ),
                    onTap: busy ? null : () => _openEmailForm(createAccount: false),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.login_rounded, color: Colors.white, size: 52 * s),
                            SizedBox(width: 26 * s),
                            Text(
                              'Entrar',
                              style: TextStyle(color: Colors.white, fontSize: 40 * s, fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                        Positioned(
                          right: 44 * s,
                          child: Icon(Icons.chevron_right_rounded, color: const Color(0xFF9A86AA), size: 56 * s),
                        ),
                      ],
                    ),
                  ),
                  // Divisor "ou"
                  box(108, 1412, 279, 2, const DecoratedBox(decoration: BoxDecoration(color: Color(0xFF5D4369)))),
                  box(465, 1412, 278, 2, const DecoratedBox(decoration: BoxDecoration(color: Color(0xFF5D4369)))),
                  box(
                    387,
                    1392,
                    78,
                    44,
                    Center(
                      child: Text('ou', style: TextStyle(color: const Color(0xFFF1E8F6), fontSize: 27 * s, fontWeight: FontWeight.w500)),
                    ),
                  ),
                  // Google e Facebook
                  socialButton(
                    y: 1440,
                    logo: 'assets/auth/google_g.png',
                    label: 'Continuar com Google',
                    onTap: signInGoogle,
                  ),
                  // Selos de confiança
                  badge(35, 284, Icons.verified_user_outlined, 'Seguro', 'e Privado'),
                  badge(284, 557, Icons.bolt_outlined, 'Conexões', 'Rápidas'),
                  badge(557, 820, Icons.groups_outlined, 'Comunidade', 'Incrível'),
                  vDivider(284),
                  vDivider(557),
                  // Rodapé
                  box(
                    150,
                    1774,
                    38,
                    38,
                    Image.asset('assets/auth/footer_heart.png', fit: BoxFit.contain),
                  ),
                  box(
                    197,
                    1772,
                    460,
                    40,
                    Center(
                      child: Text.rich(
                        TextSpan(
                          style: TextStyle(color: const Color(0xFFD9CCE4), fontSize: 23 * s),
                          children: const [
                            TextSpan(text: 'LoveMix', style: TextStyle(color: Color(0xFFE7B8FF), fontWeight: FontWeight.w500)),
                            TextSpan(text: ' - Mais que um app, uma comunidade!'),
                          ],
                        ),
                        maxLines: 1,
                      ),
                    ),
                  ),
                  box(
                    663,
                    1774,
                    38,
                    38,
                    Image.asset('assets/auth/footer_heart.png', fit: BoxFit.contain),
                  ),
                  if (busy)
                    Positioned.fill(
                      child: AbsorbPointer(
                        child: ColoredBox(
                          color: Colors.black.withValues(alpha: .35),
                          child: const Center(
                            child: CircularProgressIndicator(strokeWidth: 3, color: Color(0xFFFF20C0)),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Tela inicial roxa/rosa do LoveMix; e-mail abre em formulário modal.
    return _buildLanding(context);
  }
}
