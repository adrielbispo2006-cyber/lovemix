import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/data_service.dart';
import 'chat_screen.dart';
import 'profile_view_screen.dart';

/// Aba "Chats" do LoveMix (design neon): cabeçalho com logo, busca e lista de
/// conversas em cartões roxos, com dados reais do Firebase.
class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});
  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  static const _panel = Color(0xFF160B20);
  static const _purple = Color(0xFFB52CFF);
  static const _violet = Color(0xFF8D35FF);
  static const _pink = Color(0xFFFF2DAB);
  static const _gold = Color(0xFFFFD36A);
  static const _lilac = Color(0xFFC9A0FF);
  static const _neonText = Color(0xFFE05CFF);
  static const _favKey = 'lovemix_favorite_chats';

  final _search = TextEditingController();
  // 0 Todos · 1 Online · 2 Não lidas · 3 Favoritos · 4 VIPs
  int _tab = 0;
  Set<String> _favorites = <String>{};

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getStringList(_favKey) ?? const <String>[];
      if (mounted) setState(() => _favorites = saved.toSet());
    } catch (_) {}
  }

  Future<void> _toggleFavorite(String chatId) async {
    setState(() {
      if (!_favorites.add(chatId)) _favorites.remove(chatId);
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(_favKey, _favorites.toList());
    } catch (_) {}
  }

  Future<void> _hideConversation(String chatId, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('Apagar conversa?', style: TextStyle(color: Colors.white)),
        content: Text(
            'A conversa com $name será removida somente da sua lista. A outra pessoa continuará vendo o histórico.',
            style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Apagar', style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await DataService.instance.hideChatForMe(chatId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Conversa apagada e pessoa removida do Online desta conta.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Não foi possível apagar a conversa: $e')));
      }
    }
  }

  String _ago(DateTime date) {
    final diff = DateTime.now().difference(date);
    if (diff.inMinutes < 1) return 'Agora';
    if (diff.inMinutes < 60) return 'Há ${diff.inMinutes} min';
    if (diff.inHours < 24) return 'Há ${diff.inHours} h';
    if (diff.inDays < 7) return 'Há ${diff.inDays} d';
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}';
  }

  int _unread(Map<String, dynamic> data) {
    final m = data['unreadCounts'];
    final v = m is Map ? m[DataService.instance.uid] : null;
    return v is num ? v.toInt() : 0;
  }

  void _setTab(int value) => setState(() => _tab = value);

  void _showOnline() {
    _setTab(1);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Mostrando quem está online. Abra a conversa e toque no telefone ou câmera para ligar.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF14041F), Colors.black, Color(0xFF0C0216)],
            stops: [0, .35, 1],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(children: [
            _header(),
            _searchBar(),
            if (_tab != 0) _activeFilter(),
            const SizedBox(height: 6),
            Expanded(child: _conversations()),
          ]),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- cabeçalho

  Widget _header() => SizedBox(
        height: 128,
        child: Stack(children: [
          Positioned(
            right: 0,
            bottom: 0,
            width: 128,
            child: Image.asset('assets/home/hearts.png', fit: BoxFit.contain),
          ),
          Positioned(
            left: 6,
            top: 4,
            bottom: 0,
            width: MediaQuery.of(context).size.width * .62,
            child: Image.asset('assets/home/logo.png',
                fit: BoxFit.contain, alignment: Alignment.centerLeft),
          ),
          Positioned(
            right: 10,
            top: 8,
            child: Row(children: [
              _circleButton(Icons.call_outlined, _showOnline),
              const SizedBox(width: 8),
              _circleButton(Icons.videocam_rounded, _showOnline),
              const SizedBox(width: 8),
              _circleButton(Icons.more_vert, _showFilters),
            ]),
          ),
        ]),
      );

  Widget _circleButton(IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black.withOpacity(.55),
            border: Border.all(color: _purple, width: 1.4),
            boxShadow: [BoxShadow(color: _purple.withOpacity(.45), blurRadius: 10)],
          ),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
      );

  // -------------------------------------------------------------------- busca

  Widget _searchBar() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(children: [
          Expanded(
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.6),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: _purple, width: 1.3),
                boxShadow: [BoxShadow(color: _purple.withOpacity(.35), blurRadius: 12)],
              ),
              child: TextField(
                controller: _search,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(color: Colors.white, fontSize: 15),
                decoration: const InputDecoration(
                  filled: false,
                  prefixIcon: Icon(Icons.search, color: Color(0xFFE5C5FF), size: 26),
                  hintText: 'Buscar conversas...',
                  hintStyle: TextStyle(color: _lilac, fontSize: 15),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          InkWell(
            onTap: _showFilters,
            customBorder: const CircleBorder(),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _tab != 0 ? _purple.withOpacity(.35) : Colors.black.withOpacity(.6),
                border: Border.all(color: _tab != 0 ? _pink : _purple, width: 1.3),
                boxShadow: [BoxShadow(color: _purple.withOpacity(.35), blurRadius: 12)],
              ),
              child: const Icon(Icons.tune, color: Color(0xFFE5C5FF), size: 24),
            ),
          ),
        ]),
      );

  static const _filterNames = ['Todos', 'Online', 'Não lidas', 'Favoritos', 'VIPs'];

  Widget _activeFilter() => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: Row(children: [
          Text('Filtro: ${_filterNames[_tab]}',
              style: const TextStyle(color: _neonText, fontWeight: FontWeight.w700)),
          const Spacer(),
          TextButton(
            onPressed: () => _setTab(0),
            child: const Text('Limpar', style: TextStyle(color: _pink)),
          ),
        ]),
      );

  void _showFilters() => showModalBottomSheet<void>(
        context: context,
        backgroundColor: _panel,
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Filtrar conversas',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              _filterTile(ctx, 0, Icons.forum, 'Todas', _pink),
              _filterTile(ctx, 1, Icons.people, 'Online', _pink),
              _filterTile(ctx, 2, Icons.mark_email_unread, 'Não lidas', _pink),
              _filterTile(ctx, 3, Icons.favorite, 'Favoritos', _pink),
              _filterTile(ctx, 4, Icons.workspace_premium, 'VIPs', _gold),
            ]),
          ),
        ),
      );

  Widget _filterTile(BuildContext ctx, int value, IconData icon, String label, Color color) => ListTile(
        leading: Icon(icon, color: color),
        title: Text(label, style: const TextStyle(color: Colors.white)),
        trailing: _tab == value ? const Icon(Icons.check, color: _pink) : null,
        onTap: () {
          Navigator.pop(ctx);
          _setTab(value);
        },
      );

  // ------------------------------------------------------------------ conversas

  Widget _conversations() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: DataService.instance.myChats(),
        builder: (context, snap) {
          if (snap.hasError) {
            return const Center(
              child: Text('Não foi possível carregar as conversas.',
                  style: TextStyle(color: Colors.white70)),
            );
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator(color: _pink));
          }
          final uid = DataService.instance.uid;
          final chats = [...snap.data!.docs]
            ..removeWhere((doc) =>
                List<String>.from(doc.data()['hiddenFor'] ?? const []).contains(uid))
            ..sort((a, b) {
              final at = a.data()['lastMessageAt'];
              final bt = b.data()['lastMessageAt'];
              final am = at is Timestamp ? at.millisecondsSinceEpoch : 0;
              final bm = bt is Timestamp ? bt.millisecondsSinceEpoch : 0;
              return bm.compareTo(am);
            });
          if (chats.isEmpty) return _empty();
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
            itemCount: chats.length,
            itemBuilder: (context, i) => _chatTile(chats[i]),
          );
        },
      );

  Widget _chatTile(QueryDocumentSnapshot<Map<String, dynamic>> chat) {
    final data = chat.data();
    final users = List<String>.from(data['users'] ?? const []);
    final other = users.firstWhere((id) => id != DataService.instance.uid, orElse: () => '');
    if (other.isEmpty) return const SizedBox.shrink();
    if (_tab == 3 && !_favorites.contains(chat.id)) return const SizedBox.shrink();
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').doc(other).snapshots(),
      builder: (context, userSnap) {
        final p = userSnap.data?.data() ?? <String, dynamic>{};
        if (!userSnap.hasData || !userSnap.data!.exists || p['isActive'] == false) {
          return const SizedBox.shrink();
        }
        final name = (p['name'] ?? 'Novo match').toString();
        final photo = (p['photoUrl'] ?? '').toString();
        final q = _search.text.trim().toLowerCase();
        if (q.isNotEmpty && !name.toLowerCase().contains(q)) return const SizedBox.shrink();
        final unread = _unread(data);
        if (_tab == 1 && p['isOnline'] != true) return const SizedBox.shrink();
        if (_tab == 2 && unread == 0) return const SizedBox.shrink();
        if (_tab == 4 && p['isVip'] != true) return const SizedBox.shrink();
        final online = p['isOnline'] == true;
        final live = p['isLive'] == true;
        final vip = p['isVip'] == true;
        final verified = p['isVerified'] == true;
        final preview = (data['lastMessage'] ?? '').toString();
        final stamp = data['lastMessageAt'];
        final time = stamp is Timestamp ? _ago(stamp.toDate()) : '';
        final fav = _favorites.contains(chat.id);
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(.72),
            borderRadius: BorderRadius.circular(34),
            border: Border.all(
                color: live ? _pink : _purple.withOpacity(.85), width: live ? 1.8 : 1.3),
            boxShadow: [
              BoxShadow(color: (live ? _pink : _purple).withOpacity(.32), blurRadius: 14),
              BoxShadow(color: _pink.withOpacity(.12), blurRadius: 20),
            ],
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(34),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChatScreen(chatId: chat.id, otherName: name)),
            ),
            onLongPress: () => _hideConversation(chat.id, name),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 14, 10),
              child: Row(children: [
                GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ProfileViewScreen(userId: other)),
                  ),
                  child: _avatar(photo: photo, crown: vip, online: online, live: live),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Flexible(
                        child: Text(name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                      ),
                      if (vip) ...[
                        const SizedBox(width: 4),
                        const Icon(Icons.workspace_premium, color: _gold, size: 19),
                      ],
                      if (verified) ...[
                        const SizedBox(width: 5),
                        const Icon(Icons.verified, color: _violet, size: 20),
                      ],
                    ]),
                    const SizedBox(height: 5),
                    Text(preview.isEmpty ? 'Comece uma conversa 💜' : preview,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _lilac, fontSize: 15)),
                    if (live)
                      const Padding(
                        padding: EdgeInsets.only(top: 3),
                        child: Text('AO VIVO agora',
                            style: TextStyle(color: _pink, fontSize: 11, fontWeight: FontWeight.w900)),
                      ),
                  ]),
                ),
                InkWell(
                  onTap: () => _toggleFavorite(chat.id),
                  customBorder: const CircleBorder(),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Icon(fav ? Icons.favorite : Icons.favorite_border,
                        color: fav ? _pink : _purple,
                        size: 34,
                        shadows: [Shadow(color: _purple.withOpacity(.8), blurRadius: 10)]),
                  ),
                ),
                const SizedBox(width: 4),
                Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(time,
                      style: const TextStyle(
                          color: _neonText, fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  if (unread > 0)
                    Container(
                      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: unread > 99 ? BoxShape.rectangle : BoxShape.circle,
                        borderRadius: unread > 99 ? BorderRadius.circular(16) : null,
                        color: _pink,
                        boxShadow: [BoxShadow(color: _pink.withOpacity(.8), blurRadius: 10)],
                      ),
                      child: Text(unread > 99 ? '99+' : '$unread',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    )
                  else if (preview.isNotEmpty)
                    const Icon(Icons.done_all, color: _neonText, size: 26)
                  else
                    const SizedBox(height: 32),
                ]),
              ]),
            ),
          ),
        );
      },
    );
  }

  Widget _avatar({
    required String photo,
    required bool crown,
    required bool online,
    required bool live,
  }) =>
      SizedBox(
        width: 74,
        height: 74,
        child: Stack(clipBehavior: Clip.none, children: [
          Container(
            width: 74,
            height: 74,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_pink, _purple],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [BoxShadow(color: _pink.withOpacity(.45), blurRadius: 12)],
            ),
            child: Container(
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black),
              padding: const EdgeInsets.all(2),
              child: CircleAvatar(
                backgroundColor: const Color(0xFF321846),
                backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
                child: photo.isEmpty
                    ? const Icon(Icons.person, color: Colors.white70, size: 34)
                    : null,
              ),
            ),
          ),
          if (crown)
            const Positioned(
              left: -4,
              top: -14,
              child: Icon(Icons.workspace_premium,
                  color: _gold, size: 32, shadows: [Shadow(color: Color(0xFFFFA000), blurRadius: 8)]),
            ),
          if (online || live)
            Positioned(
              right: 0,
              bottom: 2,
              child: Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                  color: live ? _pink : const Color(0xFF20E65A),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 2),
                  boxShadow: [
                    BoxShadow(
                        color: (live ? _pink : const Color(0xFF20E65A)).withOpacity(.7),
                        blurRadius: 8)
                  ],
                ),
              ),
            ),
        ]),
      );

  Widget _empty() => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.forum_outlined, color: _purple.withOpacity(.85), size: 58),
            const SizedBox(height: 12),
            const Text('Suas conversas aparecerão aqui',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text(
              'Toque em Descobrir para encontrar pessoas e enviar sua primeira mensagem.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, height: 1.4),
            ),
          ]),
        ),
      );
}
