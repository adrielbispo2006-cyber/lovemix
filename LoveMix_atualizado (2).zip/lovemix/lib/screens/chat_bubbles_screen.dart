import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../data/chat_bubble_catalog.dart';
import '../widgets/chat_bubble_skin.dart';

/// Loja de bolhas de conversa.
///
/// A bolha comprada fica salva em `users/{uid}.ownedChatBubbles` e a que está em
/// uso em `users/{uid}.selectedChatBubble`. Quem lê o chat, a sala de voz e a
/// live de vídeo busca esse campo do autor da mensagem e desenha a bolha.
class ChatBubblesScreen extends StatefulWidget {
  const ChatBubblesScreen({super.key});
  @override
  State<ChatBubblesScreen> createState() => _ChatBubblesScreenState();
}

class _ChatBubblesScreenState extends State<ChatBubblesScreen> {
  static const _pink = Color(0xFFFF19B8);
  static const _purple = Color(0xFF8D35FF);
  static const _gold = Color(0xFFFFD56A);
  bool busy = false;

  Future<void> _buy(ChatBubbleSkin skin) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (busy || uid == null) return;
    setState(() => busy = true);
    try {
      final ref = FirebaseFirestore.instance.collection('users').doc(uid);
      // Compra e equipa na mesma transação: o saldo só é descontado se a bolha
      // for gravada na conta, e ela continua da pessoa mesmo se reinstalar o app.
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final snap = await tx.get(ref);
        final data = snap.data() ?? <String, dynamic>{};
        final owned = <String>{
          ...((data['ownedChatBubbles'] as List?)?.map((e) => e.toString()) ?? const <String>[]),
        };
        final update = <String, dynamic>{};
        if (!owned.contains(skin.id)) {
          final coins = (data['coins'] as num?)?.toInt() ?? 0;
          if (coins < skin.cost) throw Exception('Você não tem moedas suficientes.');
          update['coins'] = coins - skin.cost;
          owned.add(skin.id);
        }
        update['ownedChatBubbles'] = owned.toList();
        update['selectedChatBubble'] = skin.id;
        tx.update(ref, update);
      });
      _snack('${skin.name} equipada! Ela já aparece no chat, na sala de voz e na live de vídeo.');
    } catch (e) {
      _snack(_errorText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _remove() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (busy || uid == null) return;
    setState(() => busy = true);
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).update({'selectedChatBubble': kDefaultChatBubble});
      _snack('Bolha removida. Suas bolhas compradas continuam salvas.');
    } catch (e) {
      _snack(_errorText(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _errorText(Object e) {
    final msg = e.toString().replaceFirst('Exception: ', '');
    return msg.contains('permission-denied')
        ? 'O Firebase bloqueou a compra. Publique as regras atualizadas (firestore.rules).'
        : msg;
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Widget _plainPreview(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF3B0F28), Color(0xFF1A0613)]),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: _pink, width: 1.6),
        ),
        child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 16)),
      );

  Widget _preview(ChatBubbleSkin? skin, {double pxPerDp = 3.0, String text = 'Olá, tudo bem?'}) {
    if (skin == null) return _plainPreview(text);
    return ChatBubbleSkinBox(
      skin: skin,
      pxPerDp: pxPerDp,
      child: Text(text, style: TextStyle(color: skin.textColor, fontSize: 16, fontWeight: FontWeight.w600)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Entre na sua conta.')));
    return Scaffold(
      backgroundColor: const Color(0xFF080510),
      appBar: AppBar(title: const Text('Bolhas de conversa'), backgroundColor: const Color(0xFF080510)),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData || !snap.data!.exists) {
            return const Center(child: CircularProgressIndicator(color: _pink));
          }
          final data = snap.data!.data() ?? <String, dynamic>{};
          final owned = <String>{
            ...((data['ownedChatBubbles'] as List?)?.map((e) => e.toString()) ?? const <String>[]),
          };
          final selected = (data['selectedChatBubble'] ?? kDefaultChatBubble).toString();
          final current = chatBubbleById(selected);
          final coins = (data['coins'] as num?)?.toInt() ?? 0;
          final sorted = [...chatBubbleCatalog]..sort((a, b) => a.cost.compareTo(b.cost));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(colors: [Color(0xFF32104D), Color(0xFF12091E)]),
                border: Border.all(color: _purple.withOpacity(.7)),
              ),
              child: Column(children: [
                const Text('Sua bolha atual', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                _preview(current),
                const SizedBox(height: 10),
                Text(current?.name ?? 'Padrão LoveMix', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('🪙 $coins moedas', style: const TextStyle(color: _gold, fontWeight: FontWeight.bold)),
                if (current != null) ...[
                  const SizedBox(height: 8),
                  TextButton(onPressed: busy ? null : _remove, child: const Text('Voltar para a bolha padrão')),
                ],
              ]),
            ),
            const SizedBox(height: 20),
            const Text('Loja de bolhas', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text(
              'A bolha que você está usando aparece nas suas mensagens do chat, da sala de voz ao vivo e da sala de vídeo ao vivo, para todo mundo ver.',
              style: TextStyle(color: Colors.white60),
            ),
            const SizedBox(height: 14),
            ...sorted.map((skin) {
              final has = owned.contains(skin.id);
              final active = selected == skin.id;
              final canAfford = coins >= skin.cost;
              return Container(
                margin: const EdgeInsets.only(bottom: 16),
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF171022),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: active ? _pink : _purple.withOpacity(.35), width: active ? 2 : 1),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Center(child: _preview(skin)),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${skin.emoji} ${skin.name}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 2),
                        Text(skin.description, style: const TextStyle(color: Colors.white60, fontSize: 11.5)),
                        const SizedBox(height: 4),
                        Text(
                          has ? (active ? 'Em uso' : 'Comprada') : '🪙 ${skin.cost} moedas',
                          style: TextStyle(
                            color: has ? const Color(0xFF7DFFB3) : (canAfford ? _gold : Colors.white38),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ]),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 104,
                      child: ElevatedButton(
                        onPressed: busy || active || (!has && !canAfford) ? null : () => _buy(skin),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _pink,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
                        ),
                        child: Text(active ? 'Em uso' : has ? 'Usar' : 'Comprar', style: const TextStyle(fontSize: 12)),
                      ),
                    ),
                  ]),
                ]),
              );
            }),
            if (busy) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: _pink))),
          ]);
        },
      ),
    );
  }
}
