# Nova tela inicial (login)

A tela de login antiga (preta/dourada, com "Bem-vindo de volta!") foi removida e substituída
por uma tela idêntica à imagem de referência (casal, logo LoveMix com coroa, balões
"Faça novas amizades!" / "Encontre seu amor!", slogan, botões e selos de confiança).

Arquivo alterado: `lib/screens/auth_screen.dart` (método `_buildLanding`).
Novos arquivos: `assets/auth/*` (já registrados no `pubspec.yaml`).

Ações dos botões
- Criar Conta -> abre o formulário de cadastro (nome, e-mail, senha, data de nascimento 18+)
- Entrar -> abre o formulário de login por e-mail e senha (com "Esqueci minha senha")
- Continuar com Google -> login Google já existente
- Pular -> entra como convidado (fluxo já existente)
- Continuar com Facebook -> só mostra aviso; não há integração com Facebook no projeto

Todas as medidas usam a proporção da imagem de referência (852 x 1846), escaladas pela
largura do aparelho.
