# 9 molduras novas, chamas vivas e visualização azul

## Molduras novas (total 66 + Clássica) — todas com corações subindo e explodindo
| Moldura | Preço |
|---|---|
| Coração e Laço Pink | 🪙 1100 |
| LoveMix Corações | 🪙 1200 |
| Casal Neon | 🪙 1500 |
| Coração Sombrio | 🪙 1600 |
| Anjo Coroado (asas batendo) | 💎 2000 |
| VIP Rosas Roxas | 💎 2200 |
| Jardim Real (borboletas) | 💎 2300 |
| Coroa Alada (asas batendo) | 🪙 2400 |
| Ouro Infinito | 💎 2500 |
Arquivos: `assets/frames/frame_58.webp` a `frame_66.webp`. Nenhuma moldura antiga foi removida.

## Chamas mexendo
**Chamas Reais** e **Hacker Verde** agora têm fogo de verdade: as labaredas ondulam para cima em ritmos diferentes, as pontas balançam mais que a base e o brilho pisca como brasa. A coroa, o hacker e a caveira ficam parados.
(Código: `_paintFlames` em `lib/widgets/profile_frame.dart`. Para ligar em outra moldura com fogo, adicione o id em `warpFrames`.)

## Traços azuis de visualização no chat
- 🕓 enviando · ✓✓ cinza = entregue · ✓✓ **azul** = a pessoa abriu a conversa e viu.
- Funciona na bolha normal e nas bolhas compradas da loja.
- Fica salvo no campo `readAt` da conversa (as regras atuais já permitem — não precisa publicar nada novo para isso).

Só gerar o APK novo.
