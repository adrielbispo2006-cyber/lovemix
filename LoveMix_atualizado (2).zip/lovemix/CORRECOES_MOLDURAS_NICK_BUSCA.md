# Correções: molduras, nick, busca e moldura Verão
- Molduras e decorações de nick compradas agora ficam salvas na CONTA (campos `ownedProfileFrames` e `ownedNicknameStyles`), não só no aparelho. Compras antigas locais são migradas na primeira abertura, sem cobrar de novo.
- A loja de molduras agora desconta as moedas da conta (antes usava um saldo local separado).
- O nick no perfil agora usa a cor/decoração escolhida.
- A lupa da Home abre a busca de pessoas (por ID ou nome).
- Moldura Verão: centro aberto (foto aparece) e palmeiras balançando.
- IMPORTANTE: publique o `firestore.rules` atualizado (Firebase Console > Firestore > Regras, ou `firebase deploy --only firestore:rules`), senão as compras serão bloqueadas.

## Moderação +18 mais precisa (functions/src/index.ts)
- Fotos: só são retidas quando o Google Vision indica nudez/conteúdo adulto (adult LIKELY ou VERY_LIKELY). O critério "sugestivo" (racy) foi removido; ele pegava fotos normais (sem camisa, praia etc.). Vale para PV e stories.
- Texto: removidas palavras comuns (rola, pack, gozar, "sexo"/"sexual" soltos). Continuam censurados termos explícitos (porn, nude, boquete, masturbação, transar, putaria, pênis, vagina, "fazer sexo", "sexo oral" etc.).
- Publicar: cd functions && npm install && npm run build && firebase deploy --only functions
