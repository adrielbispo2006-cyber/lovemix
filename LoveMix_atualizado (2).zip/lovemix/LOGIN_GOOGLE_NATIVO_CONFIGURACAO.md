# Login Google nativo — assinatura persistente

O login Google deste projeto usa o seletor nativo do Google Play Services e não abre o Chrome. Para o Android aceitar o APK, o SHA-1 do certificado que assina o APK precisa estar cadastrado no app Android `com.example.lovemix` do projeto Firebase `lovemix-73849`.

## Assinatura obrigatória

Os workflows `gerar-apk-do-zip.yml`, `lovemix-apk.yml` e `compilar-apk-sha.yml` agora usam a mesma chave persistente dos GitHub Actions Secrets e falham se ela não estiver configurada. Isso evita gerar um APK com SHA diferente em cada execução. Configure estes quatro secrets no repositório: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` e `ANDROID_KEY_PASSWORD`.

Depois execute o workflow e copie SHA-1 e SHA-256 do resumo. Cadastre ambos em Firebase Console → Configurações do projeto → Seus apps → Android `com.example.lovemix`. Em Authentication → Sign-in method, habilite Google. Em seguida baixe novamente o `google-services.json` e substitua os dois arquivos do projeto: `google-services.json` e `android/app/google-services.json`. O arquivo precisa conter um cliente OAuth Android (client_type 1) com o SHA-1 correto, além do cliente Web. Gere um novo APK.

**Importante:** não gere uma chave diferente para cada build. Se não tiver uma chave persistente configurada, o workflow vai parar e informar quais secrets faltam. Não coloque a keystore ou senhas dentro do ZIP ou do código-fonte.
