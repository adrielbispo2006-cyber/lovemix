# Otimização do chat privado (anti-travamento)

O que causava o travamento e o que foi corrigido em `lib/screens/chat_screen.dart`:

1. **A conversa inteira era baixada de novo várias vezes.** O stream das mensagens era criado dentro do `build`; qualquer atualização da tela (alguém ficar online, carisma subindo, timer do áudio) recriava a consulta. Agora o stream é criado uma vez só.
2. **Carregava o histórico todo de uma vez.** Agora abre só as últimas 40 mensagens. No topo aparece "Carregar mensagens anteriores" para buscar mais 40 por vez.
3. **O perfil da outra pessoa redesenhava o chat toda hora.** Agora só redesenha quando muda algo visível (nome, foto, moldura, VIP, bolha, online).
4. **Gravando áudio, o chat inteiro redesenhava 4 vezes por segundo.** Agora só o contador de tempo atualiza.
5. **Lista invertida:** a mensagem nova aparece embaixo sem rolar a lista inteira (antes dava um "pulo" a cada mensagem).
6. **Fotos em cache e no tamanho certo:** não baixam de novo ao rolar e gastam bem menos memória.
7. **Filtro +18 em cache:** o texto de cada mensagem é verificado uma vez só, não a cada rolagem.
8. Cada bolha e o fundo animado ficam em camadas separadas (`RepaintBoundary`), então rolar não redesenha o fundo.
9. Os convites de aliança deixaram de abrir uma segunda leitura da conversa.

Não precisa publicar regras nem rodar SQL para isso — só gerar o APK novo.
