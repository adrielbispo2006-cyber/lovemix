# Login Google pelo navegador (sem SHA-1)
O botão "Continuar com Google" abre o Chrome (Custom Tab) via Firebase Auth e volta para o app.
Não depende do SHA-1 do APK, então funciona mesmo se o GitHub gerar chave nova.
Requisitos no Firebase: Authentication > Método de login > Google ativado; Configurações > Domínios autorizados com lovemix-73849.firebaseapp.com (padrão).
