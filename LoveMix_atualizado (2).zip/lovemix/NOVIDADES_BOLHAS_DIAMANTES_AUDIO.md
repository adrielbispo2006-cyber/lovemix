# Novidades: +20 bolhas, molduras com diamante e mensagem de voz

## 1. 20 bolhas novas na loja (total: 44)
As 24 bolhas antigas continuam iguais. As 20 novas foram recortadas direto das duas artes enviadas (fundo transparente, mesmo brilho e enfeites da foto) e estão em `assets/chat_bubbles/`.
Preços (moedas): Doce Paixão 900 · Batida do Coração, Gatinho Neon 1000 · Gatinho Real, Laço Apaixonado, Borboleta Sakura 1100 · Lua Encantada, Anjo Apaixonado, Anjo Violeta 1200 · Rosa de Ouro, Jardim de Borboletas, Coração Coroado, Corações de Ouro 1300 · Anjo com Auréola, Rosa Eterna 1400 · Coroa de Ametista, Majestade Dourada 1500 · Rosa Negra Coroada 1600 · Diamante Real 1700 · Diamante Cósmico 1800.
Para mudar preço: `cost` em `lib/data/chat_bubble_catalog.dart`.

## 2. Molduras de perfil pagas com diamantes 💎
12 molduras premium agora custam diamantes (aparecem no topo da loja com selo PREMIUM):
Asas Reais 1700 · Anjo com Halo 1800 · Elite 1900 · VIP Dourado 2000 · Anjo Dourado 2000 · Dragão Verde 2100 · Rainha Asas 2200 · Asas de Cristal 2300 · Asas de Ouro 2400 · Leão de Fogo 2600 · VIP Imperial 2800 · Dragão Rubro 3000.
Quem já comprou alguma delas com moedas continua com ela. Para trocar a moeda de uma moldura, mude `'currency':'diamonds'` / `'coins'` em `lib/screens/profile_frames_screen.dart`.

## 3. Mensagem de voz no chat privado 🎤
- Com a caixa de texto vazia, o botão de enviar vira **microfone**. Toque para gravar, toque em ➤ para enviar ou na 🗑️ para cancelar. Máximo de 2 minutos.
- Quem recebe vê uma bolha com play/pause, onda sonora e duração. Só um áudio toca por vez.
- Apagar "para todos" também remove o arquivo do áudio.

## Publicar (obrigatório)
1. `flutter pub get` (novos pacotes: `record` e `path_provider`).
2. Publique o `firestore.rules` (libera mensagens `audio` e os ids das bolhas novas).
3. No Supabase, rode de novo o `SUPABASE_SETUP.sql` (o bucket agora aceita `audio/mp4`). Sem isso o upload do áudio é recusado.
4. Gere um APK novo. A permissão de microfone já estava no AndroidManifest.

Não consegui compilar aqui (sem Flutter SDK no ambiente): teste uma gravação e uma compra antes de publicar.
