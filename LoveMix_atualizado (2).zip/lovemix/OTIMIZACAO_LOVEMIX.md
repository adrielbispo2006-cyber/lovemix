# Otimização do LoveMix

## Alterações aplicadas
- Baú decorativo convertido de PNG para WebP, preservando o desenho e reduzindo o peso do recurso empacotado.
- Imagens do baú passam a solicitar dimensões de decodificação menores nos pontos em que são exibidas em miniatura, reduzindo pressão de memória.
- Miniaturas das fotos do perfil usam cache de imagem e limite de decodificação de 360 px.
- Arquivos-fonte dos ícones de lançamento redimensionados para 1024 px e salvos com compressão PNG otimizada.
- Upload de papel de parede da sala limitado a 1280 px, qualidade 76 e 4 MB para reduzir tráfego e armazenamento.
- Corrigidas duas sequências de escape literais acidentais em `lib/main.dart` e `lib/app.dart` que impediam a leitura normal do código Dart.

## Preservado
- Tema roxo/preto e decoração Sala Luxo.
- Funcionalidades e telas existentes, dependências, Firebase, Supabase e Zego.
- Ícones do aplicativo.

## Verificação
- ZIP e integridade dos arquivos verificados.
- O ambiente de edição não possui Flutter/Dart instalado; portanto `flutter pub get`, análise estática e compilação APK não puderam ser executados aqui. Execute esses passos no ambiente de build antes de publicar.

## Otimização da entrada do app (travamento na abertura)
- `main.dart`: Supabase deixou de bloquear a abertura (inicia em segundo plano; uploads/remoções aguardam a inicialização sozinhos em `SupabaseService`).
- `main.dart`: serviço de chamadas, notificações e escutas em tempo real só começam ~2,5 s após o login, depois da Home aparecer.
- `app.dart`: splash reduzido de 1,1 s para 650 ms (duração da animação); stream de login criado uma vez só.
- `home_screen.dart`: as 5 abas deixaram de ser montadas todas na entrada; cada uma é criada na primeira visita e mantida viva depois. Gravações de "online"/carisma esperam o primeiro frame.
- `quick_access_gate.dart`: leituras do armazenamento seguro e checagens de biometria em paralelo; falha no armazenamento não deixa mais o spinner infinito.
- Logo de 1536 px (2,8 MB) passa a ser decodificado em 480 px / 128 px nas telas.
- `auth_hero.png` (1,3 MB) convertido para WebP (141 KB).
- Não compilado aqui (sem Flutter no ambiente): rode `flutter pub get`, `flutter analyze` e teste no aparelho.

## Otimização do tamanho do APK (v1.0.3)
- `assets/icon/lovemix.png` (2,8 MB, 1536 px) deixou de ser empacotado no APK: só era usado como fonte dos ícones de lançamento (`flutter_launcher_icons`) e não é referenciado em nenhum ponto do código. O arquivo continua na pasta para gerar ícones. Economia: ~2,8 MB no APK.
- Não compilado aqui (sem Flutter no ambiente): confirme no build do GitHub.
