# Molduras já compradas não gastam mais moedas

## O que estava acontecendo
1. **Entrar de novo na conta podia apagar as molduras compradas.** A função `createUser` (usada no cadastro e no login com Google/convidado) regravava o perfil com `ownedProfileFrames: ['classic']` e `coins: 200`. Para quem já tinha conta, isso zerava as molduras (e podia baixar o saldo). Aí, ao tocar na moldura de novo, o app achava que não era sua e cobrava outra vez.
2. **Molduras de versões antigas ficavam salvas só no celular** e o botão de compra não levava isso em conta na hora de cobrar.

## Correções
- `createUser` agora verifica se a conta já existe. Se existir, só atualiza nome e data de nascimento — **nunca mexe em moedas, diamantes ou molduras**.
- Na hora de comprar/equipar, a moldura conta como sua se estiver na conta **ou** salva no celular. Se já é sua, só equipa — **nada é cobrado**.
- Toda moldura comprada também fica guardada no celular como cópia de segurança.
- Na loja, molduras que você já tem mostram **"✅ Já é sua — usar é grátis"** no lugar do preço, e o aviso diz "nada foi cobrado".

Observação: molduras que já tinham sido apagadas da conta por esse erro e que não estavam salvas no celular não dá para recuperar automaticamente. Se alguém reclamar, o admin pode devolver a moldura adicionando o id em `ownedProfileFrames` no Firestore.

Só gerar o APK novo.
