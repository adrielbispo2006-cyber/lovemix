# Bolhas de conversa na loja (44 bolhas neon — veja também NOVIDADES_BOLHAS_DIAMANTES_AUDIO.md)

## O que foi feito
- **Nova tela "Bolhas de conversa"** (`lib/screens/chat_bubbles_screen.dart`) com as 24 bolhas, prévia ao vivo, preço em moedas e botões Comprar / Usar / Voltar para a bolha padrão.
- **Onde achar a aba:** Loja de personalização (Loja VIP) > "Loja de bolhas", menu do perfil (⋮) > "Bolhas de conversa" e menu "+" da Home > "Bolhas de conversa".
- **Compra segura:** transação do Firestore que desconta as moedas e grava a bolha em `users/{uid}.ownedChatBubbles`; a bolha em uso fica em `users/{uid}.selectedChatBubble`. Fica salva na conta (não se perde ao reinstalar).
- **Onde a bolha aparece (para todo mundo que vê a mensagem):**
  - conversa privada (`chat_screen.dart`)
  - sala de voz ao vivo (`love_room_screen.dart`, chat da sala)
  - live de vídeo e de voz (`live_broadcast_screen.dart`, comentários sobre o vídeo)
  Presentes e fotos continuam com o visual normal. Quem não tem bolha continua com o visual de sempre.

## Arquivos novos
- `assets/chat_bubbles/*.webp` – as 24 bolhas recortadas (fundo transparente, sem o texto de exemplo).
- `lib/data/chat_bubble_catalog.dart` – nomes, preços, cores de texto e medidas de cada bolha.
- `lib/widgets/chat_bubble_skin.dart` – desenha a bolha em 9 partes: coroas/laços/borboletas dos cantos mantêm o tamanho e o meio estica conforme a mensagem.
- `lib/screens/chat_bubbles_screen.dart` – a loja.

## Publicar (obrigatório)
1. Publique o `firestore.rules` atualizado (ele libera os campos `ownedChatBubbles` e `selectedChatBubble` e só aceita ids do catálogo). Sem isso a compra mostra "O Firebase bloqueou a compra".
2. Gere um APK novo.

## Preços (moedas)
500: Laço Rosa, Coração e Laço · 600: Gatinha Rosa, Príncipe Violeta, Fita Vermelha · 650: Gatinha Branca · 700: Estrela Dourada, Gatinho Preto, Corações Rubi · 800: Borboleta Azul, Rosa Vermelha, Rosa Verde · 900: Realeza Roxa, Nuvem Arco-Íris, Borboletas Laranja · 1000: Coração Rebelde, Rosas Brancas, Rei Gamer, Borboletas Lilás · 1100: Arco-Íris Neon, Chamas Roxas · 1200: Coroa Dourada · 1300: Gelo e Diamante · 1500: Ouro Real.
Para mudar um preço, edite `cost` em `chat_bubble_catalog.dart`.

## Adicionar uma bolha nova
1. Coloque o `.webp` transparente em `assets/chat_bubbles/`.
2. Adicione uma linha em `chatBubbleCatalog` (medidas `center*` = área que estica; `pad*` = onde fica o texto, em pixels da imagem).
3. Acrescente o id na lista `ownedChatBubbles.hasOnly([...])` do `firestore.rules`.

## Limites conhecidos
- Como no resto do app (molduras), o preço é conferido pelo aplicativo; as regras do Firestore só aceitam ids válidos e saldo que diminui. Para travar o preço no servidor seria preciso uma Cloud Function, como a de molduras.
- Mensagens muito longas (várias linhas) esticam um pouco a decoração do lado esquerdo da bolha.
- Não consegui compilar o Flutter aqui (sem SDK no ambiente): rode `flutter pub get` e `flutter run` e teste uma compra antes de gerar o APK.
