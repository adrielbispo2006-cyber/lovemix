# Telas atuais

- **Início**: feed (stories, abas e publicações) — `_LoveMixFeed` em `lib/screens/home_screen.dart`.
- **Chats**: nova lista neon de conversas (logo, busca, cartões roxos) — `lib/screens/messages_screen.dart`.
  - Coração do cartão = favoritar (salvo no aparelho). Segurar o cartão = apagar conversa da sua lista.
  - Botão de filtro (ao lado da busca) e ⋮: Todas, Online, Não lidas, Favoritos, VIPs.
- Barra inferior: Início · Chats · coração com asas (menu) · Descobrir · Perfil. A Loja VIP abre pelo botão VIP do Início e pelo menu do coração.

# Molduras de perfil (16 novas, arte da imagem)

- Arquivos em `assets/frames/frame_01.webp` … `frame_16.webp` (fundo transparente, buraco do aro em 50% da largura).
- `lib/widgets/profile_frame.dart`: `imageFrames` liga cada id à imagem; a foto fica por baixo e o aro por cima.
- `lib/screens/profile_frames_screen.dart`: loja com Clássica (grátis) + 16 molduras de 500 a 3500 moedas.
- Molduras antigas (neon, gold, etc.) continuam aparecendo para quem já usa, mas saíram da loja.
