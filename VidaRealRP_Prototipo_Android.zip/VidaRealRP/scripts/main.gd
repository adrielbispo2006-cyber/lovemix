extends Node3D

const PLAYER_SCENE_SCRIPT = preload("res://scripts/player.gd")
const PORT := 2456
const MAX_PLAYERS := 32
var players: Dictionary = {}
var status_label: Label
var ip_input: LineEdit
var player_container: Node3D
var move_buttons: Array[Button] = []
var jump_button: Button

func _ready() -> void:
	_build_city()
	_build_ui()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	_spawn_player(multiplayer.get_unique_id())

func _build_city() -> void:
	# Atmosfera noturna cinematografica: ceu roxo, neblina e bloom neon.
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.008, 0.006, 0.035)
	sky_mat.sky_horizon_color = Color(0.19, 0.035, 0.22)
	sky_mat.ground_bottom_color = Color(0.008, 0.006, 0.018)
	sky_mat.ground_horizon_color = Color(0.075, 0.018, 0.09)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.38, 0.27, 0.52)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	env.glow_intensity = 0.8
	env.glow_bloom = 0.12
	env.fog_enabled = true
	env.fog_light_color = Color(0.13, 0.035, 0.17)
	env.fog_density = 0.006
	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-48, -28, 0)
	moon.light_energy = 0.55
	moon.light_color = Color(0.62, 0.65, 1.0)
	moon.shadow_enabled = true
	add_child(moon)

	_add_box("Asfalto cidade", Vector3(0, -0.35, 0), Vector3(190, 0.5, 190), Color(0.025, 0.022, 0.035), true)
	_add_box("Avenida principal", Vector3(0, -0.02, 0), Vector3(17, 0.08, 190), Color(0.055, 0.052, 0.065), true)
	_add_box("Avenida transversal", Vector3(0, 0.0, 0), Vector3(190, 0.08, 17), Color(0.055, 0.052, 0.065), true)
	for side in [-1, 1]:
		_add_box("Calcada", Vector3(side * 10.2, 0.12, 0), Vector3(3.2, 0.28, 190), Color(0.19, 0.16, 0.21), true)
		_add_box("Calcada", Vector3(0, 0.12, side * 10.2), Vector3(190, 0.28, 3.2), Color(0.19, 0.16, 0.21), true)
	for lane in range(-9, 10):
		_add_box("Faixa dourada", Vector3(0, 0.055, lane * 9.8), Vector3(0.16, 0.025, 3.8), Color(0.95, 0.72, 0.35), false, true)
		_add_box("Faixa dourada", Vector3(lane * 9.8, 0.055, 0), Vector3(3.8, 0.025, 0.16), Color(0.95, 0.72, 0.35), false, true)

	# Edificios em varios formatos, com fileiras de janelas acesas.
	for x in range(-5, 6):
		for z in range(-5, 6):
			if abs(x) <= 1 or abs(z) <= 1:
				continue
			var h := randf_range(13.0, 32.0)
			var w := randf_range(8.0, 11.0)
			var d := randf_range(8.0, 11.0)
			var p := Vector3(x * 17.5, h / 2.0, z * 17.5)
			var wall := [Color(0.045, 0.035, 0.075), Color(0.07, 0.055, 0.085), Color(0.035, 0.055, 0.085)][randi_range(0, 2)]
			_add_box("Edificio", p, Vector3(w, h, d), wall, true)
			_add_box("Cobertura", p + Vector3(0, h / 2.0 + 0.25, 0), Vector3(w + 0.5, 0.5, d + 0.5), Color(0.12, 0.08, 0.16))
			for floor in range(1, int(h / 3.2)):
				for col in range(3):
					var wx := p.x - w * 0.32 + col * w * 0.32
					var wy := floor * 3.0
					var glass := Color(0.95, 0.52, 0.24) if randf() > 0.48 else Color(0.12, 0.38, 0.58)
					_add_box("Janela", Vector3(wx, wy, p.z + d / 2.0 + 0.035), Vector3(1.25, 1.65, 0.08), glass, false, true)
			var neon := Color(0.95, 0.04, 0.58) if (x + z) % 2 == 0 else Color(0.12, 0.55, 1.0)
			_add_box("Letreiro neon", p + Vector3(0, -h * 0.25, d / 2.0 + 0.09), Vector3(w * 0.68, 0.42, 0.12), neon, false, true)

	# Postes de iluminacao azulada ao longo da avenida.
	for i in range(-4, 5):
		for side in [-1, 1]:
			var pole := MeshInstance3D.new()
			var pole_mesh := CylinderMesh.new()
			pole_mesh.top_radius = 0.07
			pole_mesh.bottom_radius = 0.11
			pole_mesh.height = 5.5
			pole.mesh = pole_mesh
			pole.position = Vector3(side * 11.5, 2.85, i * 20.0)
			var pole_mat := StandardMaterial3D.new()
			pole_mat.albedo_color = Color(0.08, 0.07, 0.1)
			pole.material_override = pole_mat
			add_child(pole)
			_add_box("Luminaria", pole.position + Vector3(-side * 0.65, 2.5, 0), Vector3(1.4, 0.16, 0.35), Color(0.55, 0.72, 1.0), false, true)
			var lamp := OmniLight3D.new()
			lamp.position = pole.position + Vector3(-side * 0.65, 2.25, 0)
			lamp.light_color = Color(0.35, 0.48, 1.0)
			lamp.light_energy = 1.4
			lamp.omni_range = 9.0
			add_child(lamp)

	# Praca central, clube e vegetacao.
	_add_box("Praca central", Vector3(25, 0.08, -24), Vector3(25, 0.2, 22), Color(0.075, 0.06, 0.095), true)
	_add_box("Clube fachada", Vector3(25, 3.2, -35), Vector3(18, 6.4, 1.5), Color(0.10, 0.025, 0.14), true)
	_add_box("Clube letreiro", Vector3(25, 5.25, -34.15), Vector3(11, 0.48, 0.14), Color(1.0, 0.025, 0.62), false, true)
	_add_box("Painel digital", Vector3(25, 3.3, -34.12), Vector3(8, 1.5, 0.12), Color(0.12, 0.025, 0.2), false, true)
	for i in range(8):
		var angle := TAU * float(i) / 8.0
		var tree_pos := Vector3(25 + cos(angle) * 10, 0, -24 + sin(angle) * 8)
		var trunk := MeshInstance3D.new()
		var trunk_mesh := CylinderMesh.new()
		trunk_mesh.top_radius = 0.18
		trunk_mesh.bottom_radius = 0.28
		trunk_mesh.height = 2.2
		trunk.mesh = trunk_mesh
		trunk.position = tree_pos + Vector3(0, 1.1, 0)
		add_child(trunk)
		var crown := MeshInstance3D.new()
		var crown_mesh := SphereMesh.new()
		crown_mesh.radius = 1.25
		crown_mesh.height = 2.4
		crown.mesh = crown_mesh
		crown.position = tree_pos + Vector3(0, 3.0, 0)
		var leaf_mat := StandardMaterial3D.new()
		leaf_mat.albedo_color = Color(0.025, 0.19, 0.12)
		crown.material_override = leaf_mat
		add_child(crown)

	player_container = Node3D.new()
	player_container.name = "Players"
	add_child(player_container)

func _add_box(label: String, pos: Vector3, size: Vector3, color: Color, collision := false, emissive := false) -> void:
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = label
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	if emissive:
		mat.emission_enabled = true
		mat.emission = color
		mat.emission_energy_multiplier = 2.8
		mat.roughness = 0.32
	mesh_node.material_override = mat
	add_child(mesh_node)
	if collision:
		var body := StaticBody3D.new()
		body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		body.add_child(shape_node)
		add_child(body)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := PanelContainer.new()
	panel.position = Vector2(16, 14)
	panel.custom_minimum_size = Vector2(310, 0)
	layer.add_child(panel)
	var box := VBoxContainer.new()
	panel.add_child(box)
	var title := Label.new()
	title.text = "VIDA REAL RP  •  ONLINE"
	title.add_theme_color_override("font_color", Color(1, 0.32, 0.82))
	box.add_child(title)
	status_label = Label.new()
	status_label.text = "Modo de teste: crie uma sala ou conecte-se"
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(status_label)
	var host := Button.new()
	host.text = "CRIAR SALA"
	host.pressed.connect(_host_game)
	box.add_child(host)
	ip_input = LineEdit.new()
	ip_input.placeholder_text = "IP do servidor"
	ip_input.text = "127.0.0.1"
	box.add_child(ip_input)
	var join := Button.new()
	join.text = "ENTRAR NA SALA"
	join.pressed.connect(_join_game)
	box.add_child(join)
	var help := Label.new()
	help.text = "Movimento: botões na tela ou WASD. Multiplayer de teste via IP/UDP."
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(help)
	var pad := GridContainer.new()
	pad.columns = 3
	pad.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	pad.position = Vector2(24, -205)
	pad.add_theme_constant_override("h_separation", 5)
	pad.add_theme_constant_override("v_separation", 5)
	layer.add_child(pad)
	_add_pad_spacer(pad)
	_add_move_button(pad, "▲", Vector2(0, -1))
	_add_pad_spacer(pad)
	_add_move_button(pad, "◀", Vector2(-1, 0))
	_add_move_button(pad, "▼", Vector2(0, 1))
	_add_move_button(pad, "▶", Vector2(1, 0))
	jump_button = Button.new()
	jump_button.text = "PULAR"
	jump_button.custom_minimum_size = Vector2(105, 72)
	jump_button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	jump_button.position = Vector2(-125, -105)
	jump_button.button_down.connect(func(): Input.action_press("jump"))
	jump_button.button_up.connect(func(): Input.action_release("jump"))
	layer.add_child(jump_button)

func _add_pad_spacer(parent: GridContainer) -> void:
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(64, 64)
	parent.add_child(spacer)

func _add_move_button(parent: GridContainer, caption: String, vector: Vector2) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(64, 64)
	button.button_down.connect(func(): _set_move(vector))
	button.button_up.connect(func(): _set_move(Vector2.ZERO))
	parent.add_child(button)
	move_buttons.append(button)

func _set_move(value: Vector2) -> void:
	var player: CharacterBody3D = players.get(multiplayer.get_unique_id())
	if player:
		player.set("move_input", value)

func _host_game() -> void:
	if multiplayer.has_multiplayer_peer():
		multiplayer.multiplayer_peer.close()
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_server(PORT, MAX_PLAYERS)
	if result != OK:
		status_label.text = "Erro ao criar sala: " + error_string(result)
		return
	multiplayer.multiplayer_peer = peer
	status_label.text = "Sala local criada. Para internet, use servidor público e UDP %d." % PORT
	_spawn_player(1)

func _join_game() -> void:
	var address := ip_input.text.strip_edges()
	if address.is_empty():
		status_label.text = "Digite o IP do servidor."
		return
	if multiplayer.has_multiplayer_peer():
		multiplayer.multiplayer_peer.close()
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_client(address, PORT)
	if result != OK:
		status_label.text = "Erro ao iniciar conexão: " + error_string(result)
		return
	multiplayer.multiplayer_peer = peer
	status_label.text = "Conectando a " + address + "..."

func _on_connected() -> void:
	status_label.text = "Conectado! Entrando na cidade..."
	request_spawn.rpc_id(1)

@rpc("any_peer", "call_remote", "reliable")
func request_spawn() -> void:
	if not multiplayer.is_server():
		return
	var id := multiplayer.get_remote_sender_id()
	for existing_id in players.keys():
		spawn_player.rpc_id(id, int(existing_id))
	spawn_player.rpc(id)

@rpc("authority", "call_local", "reliable")
func spawn_player(id: int) -> void:
	if players.has(id):
		return
	var player := CharacterBody3D.new()
	player.set_script(PLAYER_SCENE_SCRIPT)
	player.name = "Player_%d" % id
	player.set_multiplayer_authority(id)
	player.position = Vector3(randf_range(-2.0, 2.0), 0.15, randf_range(-2.0, 2.0))
	player_container.add_child(player)
	players[id] = player
	if id == multiplayer.get_unique_id():
		status_label.text = "Você está na cidade! Jogador #%d" % id

@rpc("any_peer", "call_remote", "unreliable")
func submit_transform(id: int, value: Transform3D) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != id:
		return
	relay_transform.rpc(id, value)

@rpc("authority", "call_remote", "unreliable")
func relay_transform(id: int, value: Transform3D) -> void:
	if id == multiplayer.get_unique_id():
		return
	var player: Node3D = players.get(id)
	if player:
		player.global_transform = value

func _on_peer_connected(id: int) -> void:
	if multiplayer.is_server():
		for existing_id in players.keys():
			spawn_player.rpc_id(id, int(existing_id))
		spawn_player.rpc(id)

func _on_peer_disconnected(id: int) -> void:
	if multiplayer.is_server():
		despawn_player.rpc(id)

@rpc("authority", "call_local", "reliable")
func despawn_player(id: int) -> void:
	if players.has(id):
		players[id].queue_free()
		players.erase(id)

func _on_connection_failed() -> void:
	status_label.text = "Falha ao conectar. Confira IP, servidor e porta UDP %d." % PORT
	multiplayer.multiplayer_peer = null

func _on_server_disconnected() -> void:
	status_label.text = "Conexão com o servidor perdida."
	multiplayer.multiplayer_peer = null
